# AI Playbook

> **Read this file FIRST on every prompt.** This is *the* playbook (singular): the universe's entry point. It indexes the galaxies; each galaxy's `GALAXY.md` routes the tasks its subject covers. Travel is free: load any galaxy the task needs, several at once.

> **Portability is universal.** No machine, user, or customer-company specifics anywhere: no absolute filesystem paths, no private identifiers (the install's own `OWNERS` is the one exception). Each galaxy is generic within its subject and specific about it. See `REF-Authoring.md` §2 - it's the rule that gets violated most often.

---

## The Universe

One repo, four levels: this index routes to galaxies; a galaxy's `GALAXY.md` routes to REFs (the suns); a REF routes to the planets that orbit it (skills and agents carried in the repo, mcps declared as one file each, rags reserved). `REF-Universe.md` holds the doctrine.

| Galaxy | Subject | Enter at |
|---|---|---|
| **craft** | Software-engineering practices: architecture, stacks, design, testing and documentation | [galaxies/craft/GALAXY.md](galaxies/craft/GALAXY.md) |
| **maker** | The corpus itself: universe doctrine, authoring REFs/skills/galaxies, the gates | [galaxies/maker/GALAXY.md](galaxies/maker/GALAXY.md) |
| **press** | Engagement instruments: flyers, plans, workshops, MoMs, decks, and articles - the audience-facing artifacts an engagement produces | [galaxies/press/GALAXY.md](galaxies/press/GALAXY.md) |
| **brain** | The operator's own side of the work: the AI-augmented Second Brain (how a personal knowledge vault is built and tended: PARA structure, digestion, archival) and the conversation helpers the operator invokes on the session itself rather than on the work it is about | [galaxies/brain/GALAXY.md](galaxies/brain/GALAXY.md) |
| **playground** | A low-stakes sandbox for drafting and experimenting (REFs, skills, agents, notes): exploratory and never authoritative until promoted into a curated galaxy by review | [galaxies/playground/GALAXY.md](galaxies/playground/GALAXY.md) |
| **foundry** | The delivery system: delivery lines, maintenance, promotion and application contracts | [galaxies/foundry/GALAXY.md](galaxies/foundry/GALAXY.md) |

Names are unique universe-wide, so a bare `` `REF-<Name>.md` ``, skill, or agent name resolves wherever it lives. Every planet's frontmatter names its galaxy; the gates check it against the folder it sits in.

`nebulae/<territory>/` beside the galaxies holds research in progress: unearned stardust written and judged by the Forge (`galaxies/maker/REF-Forge.md`). It informs nothing until smelted; see violation #5.

---

## Universal violations - check EVERY change, in every galaxy

1. **Don't duplicate with intent to maintain in parallel.** If two artifacts must stay in sync (code, docs, configs, schemas), propagation must be mechanical: deterministic transform, generated, or imported. Hand-edited copies drift. If propagation cannot be mechanical, don't make the copy.
2. **Em-dashes (U+2014)** - never use the em-dash character, in any artifact you write or edit. Use commas, periods, colons, or regular dashes (`-`) instead. Enforced across this repo by the intent tests (INT-SHAPE-002).
3. **Machine/user/company-specific content** - no absolute filesystem paths (`D:\<...>`, `/Users/<...>`), no private repo paths, no personal identifiers. The corpus is published cross-environment. See `REF-Authoring.md` §2. The one exception is `OWNERS` at the root: it names each install's people by sign-in email and belongs to that install (`REF-Universe.md` §5).
4. **Change-narration** - write what is, not what changed. No "no longer uses X", "dropped Y", "does not Z anymore" anywhere (docs, code, comments, commits). If the contrast matters, write an ADR; the artifact itself describes the current state as if it were the only one ever considered.
5. **Nebulae are unearned.** `nebulae/` holds stardust: research in progress, quarantined. Never route to, link, or cite nebula content outside forge work (the forge skills, or deliberate operator exploration). Stardust informs nothing until the smelt promotes it into a galaxy.
6. **Memory is transient state, not a knowledge store.** Per-machine / auto-memory holds only current, disposable working state, deleted the moment the task it tracks resolves. A durable lesson never lives in memory; it belongs in the corpus (a REF, `GALAXY.md`, or skill in the galaxy that owns the subject) or a project repo. A memory entry that outlives its task is local bloat that poisons every future load and drifts from the corpus it should have updated (violation #1); rehome it, then delete it.
7. **Rationale-narration in the artifact ("this is A, not B").** An artifact does not argue with alternatives its reader never raised. UI copy, product text, and docs say what the thing is and what the reader does with it; "this is A, not B" and "there is no X here, on purpose" narrate the author's design deliberation into the surface, a tell that serves no reader. Rationale lives in the ADR or the design record. Normative contrast that forbids a real failure mode ("the helper writes it, never an agent") is not this and stays.

Stack- and subject-specific violations live in each galaxy's `GALAXY.md` and in the Anti-Patterns sections of its REFs.
