"""Embed the approved identity in the authored Press templates, at maintenance time.

The stamp itself (the palette block, the faces, the stage, the mark) is one implementation,
`galaxies/press/skills/bootstrap-slidev-deck/press_identity.py`: the deck scaffold runs it when a
deck is made for another identity, and this script runs it here over every authored template.
The names this module re-exports (`update`, `stage`, `ROLES`, `BLOCK`) are that file's."""
from __future__ import annotations

import argparse
import importlib.util
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SKILLS = ROOT / "galaxies/press/skills"

_spec = importlib.util.spec_from_file_location(
    "press_identity", SKILLS / "bootstrap-slidev-deck" / "press_identity.py")
press_identity = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(press_identity)
ROLES, BLOCK, STAGE_CSS, STAGE_HTML = (
    press_identity.ROLES, press_identity.BLOCK, press_identity.STAGE_CSS, press_identity.STAGE_HTML)
update, stage, load_identity = press_identity.update, press_identity.stage, press_identity.load_identity

# Each authored file and what it takes. `scope` is the selector its tokens hang off: an HTML
# template holds them on the document root, so it needs none; a stylesheet a renderer owns
# scopes them to its own container, and the block has to say the same. A page frame is the
# whole file a standalone artifact is: it takes the identity's faces and its stage between its
# PRESS stage markers. A frame whose own markup may use `.stage` (a flyer's author writes its
# figures by hand) takes the stage under a class of its own (`rename_stage`). The sheet a frame
# wraps takes neither faces nor stage, because an application that renders plans loads that
# sheet too and serves its own faces and ground. A presented deck keeps its chosen appearance
# in its export, so its stylesheet takes no print rule. The deck's chrome is markup alone: it
# takes the stage element and keeps the organisation's mark where the hub projects none.
FILES = {
    "bootstrap-flyer/bootstrap.py": dict(scope="", escaped=True, frame=True, rename_stage=True),
    "bootstrap-plan/renderer/plan-renderer.css": dict(scope=" .pr-root", faces=False),
    "bootstrap-workshop/template.html": dict(scope="", frame=True, workshop=True),
    "write-mom/templates/mom-artifact.html": dict(scope=""),
    "write-status-report/templates/status-report.html": dict(scope=""),
    "write-status-brief/templates/status-brief.html": dict(scope=""),
    "bootstrap-plan/renderer/plan-page.html": dict(scope="", frame=True),
    "bootstrap-slidev-deck/layouts/ds/style.css": dict(scope="", with_stage=True, print_light=False),
    "bootstrap-slidev-deck/layouts/ds/global-top.vue": dict(markup=True),
}


def stamp(name: str, source: str, identity: dict) -> str:
    """One authored file, stamped as its entry says."""
    take = dict(FILES[name])
    if take.pop("markup", False):
        return press_identity.stamp_markup(source, identity, keep_mark_when_absent=True)
    if take.pop("frame", False):
        source = press_identity.stamp_markup(source, identity, keep_mark_when_absent=True,
                                            workshop=take.get("workshop", False),
                                            escaped=take.get("escaped", False),
                                            rename_stage=take.get("rename_stage", False))
        take["with_stage"] = True
    return press_identity.stamp_css(source, identity, **take)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    # Asked for, never assumed: a default here pointed at a checkout beside this one, so the
    # command only ran where the design hub happened to sit next door.
    parser.add_argument('--palette', type=Path, required=True,
                        help="the identity to embed: <design-systems>/<id>/identity.json")
    parser.add_argument('--check', action='store_true')
    parser.add_argument('--only', action='append', choices=FILES,
                        help='stamp only the named template; repeat for several templates')
    args = parser.parse_args()
    identity = load_identity(args.palette)
    for name in args.only or FILES:
        path = SKILLS / name
        source = path.read_text(encoding='utf-8')
        result = stamp(name, source, identity)
        if args.check and source != result:
            raise SystemExit(f'Stale Press palette: {name}')
        if not args.check:
            path.write_text(result, encoding='utf-8', newline='\n')
    print('Press palettes verified' if args.check else 'Press palettes embedded')


if __name__ == '__main__':
    main()
