r"""Shared reference-extraction logic for playbook validators.

Used by ``check_links.py`` (validates references resolve) and
``render_reference_tree.py`` (renders the reference graph as Mermaid).

What counts as a "reference":
- Markdown inline links: ``[text](path)``
- Markdown reference-style links: ``[label]: path``
- Bare absolute paths matching known prefixes (drive-letter, home-tilde)
- Backticked absolute paths with those prefixes, including those with spaces
- Bare project filenames in backticks (REF-*.md, AI-PLAYBOOK.md), resolved by walk-up
- YAML frontmatter ``refs:`` list entries (Skill SKILL.md files), per
  REF-Authoring.md §10 - the authoritative declaration of Skill->REF deps

What we deliberately skip:
- URLs (http, https, mailto, file://, etc.)
- Local anchors (``#section``)
- Placeholders containing ``<`` or ``{`` (e.g. ``<topic>``, ``{slug}``)
- Glob/wildcard patterns (``*``, ``?``)
- Configured external-drive prefixes (see ``_SKIPPABLE_DRIVE_PREFIXES``) - external storage that may not be mounted on every machine
- Root-slash paths as bare or backticked text (``/api``, ``/mcp``) - in this corpus a URL route far more often than a file, so neither absolute-path pattern reads one; a markdown link's target is taken as written, whatever its form
- Home-tilde paths (``~/...``) - the Claude runtime install convention (REF-Authoring.md §2 / REF-Foreign-Brain.md §13), not a navigable repo ref; ``~`` resolves per-machine so on-disk existence is meaningless
- Fenced code blocks (```...```) - usually shell/syntax examples, not real refs
- Double-backtick spans (``\`\`example\`\```) - convention for syntax demos

NOTE: per the playbook's portability rule (REF-Authoring.md §2), absolute paths
should not appear in playbook content. This validator still resolves them when
present so the link-checker stays useful for legacy content during migration;
the intent tests at the playbook root enforce the no-absolute-paths rule
separately.

The validator's job is playbook integrity, not exhaustive coverage. Tune by
fixing the source markdown rather than overfitting the regex.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path

__all__ = ["Reference", "extract_refs", "collect_files"]


# ``[text](path)`` - capture path, no whitespace inside the parens
_MD_LINK_RE = re.compile(r"\[[^\]]*\]\(([^)\s]+)\)")
# ``[label]: path`` - reference-style link. Require >=1 space after ``:`` so we
# don't match things like ``[Console]::OutputEncoding`` inside code samples.
_MD_REFLINK_RE = re.compile(r"^\s*\[[^\]]+\]:\s+(\S+)", re.MULTILINE)
# Bare absolute path. Boundary on left = start-of-line / whitespace / quote / paren.
# Stop on whitespace, quotes, closing brackets, backticks.
_ABS_PATH_RE = re.compile(
    r"(?:^|[\s\"'`(])"
    r"((?:[A-Za-z]:[\\/]|~[\\/])[^\s\"'`)>\]]+)"
)
# Backticked absolute path (handles spaces in folder/file names).
_BACKTICK_PATH_RE = re.compile(
    r"`((?:[A-Za-z]:[\\/]|~[\\/])[^`\n]+)`"
)
# Backticked bare project filename, resolved via walk-up. Restricted to known
# project-specific patterns to avoid false positives on generic mentions like
# ``pyproject.toml`` or ``np.ndarray``. Extend the alternation as new conventions appear.
_BACKTICK_BARE_REF_RE = re.compile(
    r"`(REF-[A-Z][A-Za-z0-9-]*\.md|AI-PLAYBOOK\.md)`"
)
# Fenced code block (```lang ... ```), DOTALL so newlines match.
_FENCED_RE = re.compile(r"```.*?```", re.DOTALL)
# Double-backtick inline span (``example``). Convention: syntax demos.
_DOUBLE_TICK_RE = re.compile(r"``[^`\n]*``")
# Single-backtick inline span (`example`). Blanked only once the passes that
# read inside one have run, so quoted syntax is not resolved as a reference.
_SINGLE_TICK_RE = re.compile(r"`[^`\n]*`")
# YAML frontmatter block at the very top of a file: ``---\n...\n---\n``.
_FRONTMATTER_RE = re.compile(r"\A---\s*\n(.*?)\n---\s*\n", re.DOTALL)
# A ``refs:`` key on its own line inside the frontmatter (block-list form).
_FM_REFS_KEY_RE = re.compile(r"^refs\s*:\s*$", re.MULTILINE)
# A list item under ``refs:``: indented ``- <name>``.
_FM_LIST_ITEM_RE = re.compile(r"^\s+-\s+(\S+)\s*$")
# Names we accept inside ``refs:`` - same convention as backticked bare refs.
_FM_REF_NAME_RE = re.compile(r"^(REF-[A-Z][A-Za-z0-9-]*|AI-PLAYBOOK)$")

_URL_PREFIXES = ("http://", "https://", "ftp://", "mailto:", "tel:", "file://")
_SKIPPABLE_DRIVE_PREFIXES: tuple[str, ...] = ()  # populate per environment if external mounts must be skipped


@dataclass(frozen=True)
class Reference:
    """One reference found inside a source file."""

    source: Path
    line: int
    raw: str         # the path as written in the source
    resolved: Path   # absolute path after expanduser / relative resolution

    def exists(self) -> bool:
        return self.resolved.exists()


def _is_skippable(target: str) -> bool:
    """Should this candidate path be ignored entirely?"""
    if not target:
        return True
    lowered = target.lower()
    if any(lowered.startswith(p) for p in _URL_PREFIXES):
        return True
    if target.startswith("#"):
        return True
    if "<" in target or "{" in target:
        return True
    if "*" in target or "?" in target:
        return True
    # Home-tilde paths (``~/...``) are a runtime-convention placeholder, not a
    # navigable repo reference. Per REF-Authoring.md §2 and REF-Foreign-Brain.md
    # §13, ``~/.claude/...`` names the Claude runtime install location shared by
    # every install. Its on-disk resolution depends on whoever runs the checker
    # (``~`` -> ``/root`` in a sandbox, ``C:\\Users\\<name>`` on a dev box), so
    # "does it exist" is both meaningless and machine-dependent - the very drift
    # this validator guards against. Skip it, like an unmounted external drive.
    if target.startswith("~/") or target.startswith("~\\"):
        return True
    if any(target.startswith(p) for p in _SKIPPABLE_DRIVE_PREFIXES):
        return True
    return False


def _strip_suffixes(target: str) -> str:
    """Drop ``#anchor`` and trailing ``:line`` / ``:line-line`` suffixes."""
    if "#" in target:
        target = target.split("#", 1)[0]
    target = re.sub(r":\d+(?:-\d+)?$", "", target)
    return target


def _resolve(raw: str, source_file: Path) -> Path:
    """Resolve a raw path string to an absolute Path."""
    target = raw.strip().strip('"').strip("'").strip("`").rstrip(".,;:!?")
    target = _strip_suffixes(target)
    if target.startswith("~"):
        return Path(target).expanduser()
    p = Path(target)
    if p.is_absolute():
        return p
    return (source_file.parent / p).resolve()


def _walk_up_resolve(filename: str, source_file: Path, max_depth: int = 6) -> Path:
    """Find ``filename`` in ``source_file``'s directory, an ancestor, or any galaxy.

    Used for bare project filenames like ``REF-CSD.md`` that can be referenced
    from any depth (e.g. from a skill subdirectory) and from any galaxy: names
    are unique universe-wide (REF-Universe.md §5), so a bare name resolves
    wherever it lives. Walks up first (same-galaxy references), then scans
    ``galaxies/*/`` from the universe root (cross-galaxy references). Returns
    the first match; if none found, returns the source-relative path so the
    caller flags it as broken.
    """
    candidate = source_file.parent
    universe_root: Path | None = None
    for _ in range(max_depth):
        if (candidate / filename).is_file():
            return candidate / filename
        if (candidate / "AI-PLAYBOOK.md").is_file() and (candidate / "galaxies").is_dir():
            universe_root = candidate
        parent = candidate.parent
        if parent == candidate:
            break
        candidate = parent
    if universe_root is not None:
        for match in sorted(universe_root.glob(f"galaxies/*/{filename}")):
            if match.is_file():
                return match
    return source_file.parent / filename


def _looks_like_path(target: str) -> bool:
    """Cheap filter: does this look path-like enough to bother resolving?

    Single-word lowercase identifiers (e.g. ``path``, ``url``, ``text``) inside
    a markdown link example are almost never real references. Real refs
    contain a slash, a dot extension, or an absolute prefix.
    """
    if "/" in target or "\\" in target:
        return True
    if "." in target:
        return True
    if target.startswith("~"):
        return True
    return False


def _blank_keeping_newlines(s: str) -> str:
    """Replace every non-newline char with a space; keep ``\\n`` so line numbers stay accurate."""
    return "".join(" " if c != "\n" else "\n" for c in s)


def _strip_skip_zones(text: str) -> str:
    """Blank fenced code blocks and double-backtick spans, keeping offsets and newlines intact."""
    def _blank(m: re.Match[str]) -> str:
        return _blank_keeping_newlines(m.group(0))

    text = _FENCED_RE.sub(_blank, text)
    text = _DOUBLE_TICK_RE.sub(_blank, text)
    return text


def _line_of(text: str, offset: int) -> int:
    return text.count("\n", 0, offset) + 1


def _blank_span(text: str, start: int, end: int) -> str:
    """Replace ``text[start:end]`` with whitespace, preserving both offsets and newlines."""
    return text[:start] + _blank_keeping_newlines(text[start:end]) + text[end:]


def _extract_frontmatter_refs(text: str, source_file: Path) -> list[Reference]:
    """Pull bare REF names from a YAML frontmatter ``refs:`` block-list.

    Skill SKILL.md files declare their REF dependencies authoritatively here;
    the body prose may or may not duplicate the mention, so the frontmatter is
    the only reliable source of Skill->REF edges. Format expected:

        ---
        refs:
          - REF-Foreign-Brain
          - REF-Tests
        ---

    Only block-list form (one item per line, dash-prefixed) is supported.
    Inline form (``refs: [REF-A, REF-B]``) isn't used in this playbook.
    """
    fm = _FRONTMATTER_RE.match(text)
    if not fm:
        return []
    fm_block_start = fm.start(1)
    fm_block = fm.group(1)

    key = _FM_REFS_KEY_RE.search(fm_block)
    if not key:
        return []

    out: list[Reference] = []
    pos = key.end()
    while pos < len(fm_block):
        nl = fm_block.find("\n", pos)
        line = fm_block[pos:nl] if nl != -1 else fm_block[pos:]
        if line and not line[0].isspace():
            break  # next top-level key terminates the list
        item = _FM_LIST_ITEM_RE.match(line)
        if item:
            raw = item.group(1).strip()
            if _FM_REF_NAME_RE.match(raw):
                target = raw if raw.endswith(".md") else f"{raw}.md"
                abs_off = fm_block_start + pos + item.start(1)
                out.append(Reference(
                    source=source_file,
                    line=_line_of(text, abs_off),
                    raw=raw,
                    resolved=_walk_up_resolve(target, source_file),
                ))
        if nl == -1:
            break
        pos = nl + 1
    return out


def extract_refs(source_file: Path) -> list[Reference]:
    r"""Extract all candidate references from ``source_file``.

    Order matters: stronger patterns run first and blank their matched
    range so weaker patterns don't double-match a substring. Without this,
    a backticked path containing spaces would get matched twice - once in
    full by the backtick pattern, and once truncated at the first space by
    the bare-path pattern.
    """
    try:
        raw_text = source_file.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return []

    text = _strip_skip_zones(raw_text)
    refs: list[Reference] = []

    # Pass 0: YAML frontmatter ``refs:`` block. Runs against the original text
    # so frontmatter line numbers are reported faithfully.
    refs.extend(_extract_frontmatter_refs(raw_text, source_file))

    def _add(target: str, offset: int) -> None:
        if _is_skippable(target):
            return
        if not _looks_like_path(target):
            return
        refs.append(Reference(
            source=source_file,
            line=_line_of(text, offset),
            raw=target,
            resolved=_resolve(target, source_file),
        ))

    # Pass 1: backticked absolute paths. Consume the whole `...` span.
    for m in list(_BACKTICK_PATH_RE.finditer(text)):
        _add(m.group(1), m.start(1))
        text = _blank_span(text, m.start(), m.end())

    # Pass 2: bare project filenames in backticks (REF-*.md, AI-PLAYBOOK.md).
    # Resolved by walking up from the source file's directory. Runs while the
    # backticks still stand, because the pattern reads inside them.
    for m in _BACKTICK_BARE_REF_RE.finditer(text):
        raw = m.group(1)
        if _is_skippable(raw):
            continue
        refs.append(Reference(
            source=source_file,
            line=_line_of(text, m.start(1)),
            raw=raw,
            resolved=_walk_up_resolve(raw, source_file),
        ))

    # Every pass that reads inside a code span has run, so what remains in one
    # is a syntax demo. Blank it, as a fenced block and a double-tick span are
    # blanked, so quoted link syntax resolves to nothing.
    text = _SINGLE_TICK_RE.sub(
        lambda m: _blank_keeping_newlines(m.group(0)), text)

    # Pass 3: markdown inline links. Consume the entire [text](path) span.
    for m in list(_MD_LINK_RE.finditer(text)):
        _add(m.group(1), m.start(1))
        text = _blank_span(text, m.start(), m.end())

    # Pass 4: reference-style links.
    for m in list(_MD_REFLINK_RE.finditer(text)):
        _add(m.group(1), m.start(1))
        text = _blank_span(text, m.start(), m.end())

    # Pass 5: bare absolute paths in whatever's left.
    for m in _ABS_PATH_RE.finditer(text):
        _add(m.group(1), m.start(1))

    return refs


def collect_files(root: Path, extensions: tuple[str, ...] = (".md", ".py")) -> list[Path]:
    """All scannable files under ``root``, sorted, with junk dirs excluded."""
    # A local virtualenv is junk for this purpose, exactly as node_modules is:
    # `.gitignore` expects `.venv/` in a working clone, and an installed package's
    # source is full of path-shaped strings (regex fragments, escapes) that are not
    # references this corpus authored or can resolve.
    excluded = {"node_modules", ".git", "__pycache__", ".pytest_cache",
                ".mypy_cache", ".ruff_cache", "dist", "build", ".astro",
                ".venv", "venv", "site-packages"}
    out: list[Path] = []
    for ext in extensions:
        for p in root.rglob(f"*{ext}"):
            if any(part in excluded for part in p.parts):
                continue
            out.append(p)
    return sorted(set(out))
