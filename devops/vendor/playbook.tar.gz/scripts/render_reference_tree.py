#!/usr/bin/env python3
"""Render the playbook reference graph as a radial tree.

Visualizes the universe's levels - Playbook -> REF -> carried planets - as
concentric rings in a self-contained HTML file:

    center       AI-PLAYBOOK.md
    inner ring   REF-*.md files (the suns)
    middle ring  agents/*.md files (who runs the work), each placed at its
                 home sun's bearing (REF-Universe.md §3: a planet orbits its
                 home sun in every view)
    outer ring   skills/*/SKILL.md files (what gets done)

Cross-references between REFs are drawn as arcs inside the inner ring; skill
and agent citations are drawn as spokes toward the REFs they cite; playbook
routing is drawn as faint spokes from the center; sibling cross-references
between skills are drawn as arcs across the outer ring.

Default behaviour: writes ``tree.html`` into the playbook root and opens it
in the default browser.

Usage:
    python render_reference_tree.py
    python render_reference_tree.py --no-open
    python render_reference_tree.py --root /path/to/other/playbook
"""

from __future__ import annotations

import argparse
import json
import re
import sys
import webbrowser
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from _refs import collect_files, extract_refs  # noqa: E402

ENTRY_POINT = "AI-PLAYBOOK.md"
OUTPUT_NAME = "tree.html"

# The first entry of a frontmatter ``refs:`` list - the planet's home sun.
_HOME_SUN_RE = re.compile(r"^refs:\s*\n\s+-\s+(\S+)", re.MULTILINE)


def classify(path: Path, root: Path) -> str | None:
    """Return 'playbook', 'ref', 'agent', 'skill', or None for files outside the layer model.

    Documents live at the universe root and one level into galaxies/<name>/
    (REF-Universe.md §1); both shelves classify identically.
    """
    try:
        rel = path.relative_to(root)
    except ValueError:
        return None
    parts = rel.parts
    if parts[:1] == ("galaxies",) and len(parts) >= 3:
        parts = parts[2:]
    name = parts[-1]
    if len(parts) == 1 and name == ENTRY_POINT:
        return "playbook"
    if len(parts) == 1 and name.startswith("REF-") and name.endswith(".md"):
        return "ref"
    if len(parts) == 2 and parts[0] == "agents" and name.endswith(".md"):
        return "agent"
    if len(parts) == 3 and parts[0] == "skills" and name == "SKILL.md":
        return "skill"
    return None


def _home_sun(path: Path) -> str | None:
    """The agent's home sun (first ``refs:`` entry), or None when undeclared."""
    m = _HOME_SUN_RE.search(path.read_text(encoding="utf-8"))
    return m.group(1) if m else None


def _node_id(path: Path, root: Path) -> str:
    return str(path.relative_to(root)).replace("\\", "/")


def _label(path: Path, kind: str) -> str:
    if kind == "skill":
        return path.parent.name
    return path.stem


def build_data(root: Path) -> dict:
    """Walk the playbook and produce the JSON the radial view consumes."""
    nodes: dict[Path, str] = {}
    raw_edges: list[tuple[Path, Path]] = []
    for f in collect_files(root, extensions=(".md",)):
        kind = classify(f, root)
        if kind is None:
            continue
        nodes[f] = kind
        for ref in extract_refs(f):
            target = ref.resolved
            if not target.exists():
                continue
            tgt_kind = classify(target, root)
            if tgt_kind is None:
                continue
            nodes.setdefault(target, tgt_kind)
            raw_edges.append((f, target))

    playbook_path = next((p for p, k in nodes.items() if k == "playbook"), None)
    if playbook_path is None:
        raise SystemExit(f"AI-PLAYBOOK.md not found under {root}")

    refs = sorted([p for p, k in nodes.items() if k == "ref"], key=lambda p: p.name)
    agents = sorted([p for p, k in nodes.items() if k == "agent"], key=lambda p: p.stem)
    skills = sorted([p for p, k in nodes.items() if k == "skill"],
                    key=lambda p: p.parent.name)

    ref_ids_by_stem = {p.stem: _node_id(p, root) for p in refs}
    data: dict = {
        "playbook": {
            "id": _node_id(playbook_path, root),
            "label": _label(playbook_path, "playbook"),
        },
        "refs":   [{"id": _node_id(p, root), "label": _label(p, "ref")}   for p in refs],
        "agents": [
            {
                "id": _node_id(p, root),
                "label": _label(p, "agent"),
                "home": ref_ids_by_stem.get(_home_sun(p) or ""),
            }
            for p in agents
        ],
        "skills": [{"id": _node_id(p, root), "label": _label(p, "skill")} for p in skills],
        "edges": [],
    }

    seen: set[tuple[str, str]] = set()
    for src, tgt in raw_edges:
        if src == tgt:
            continue
        sid, tid = _node_id(src, root), _node_id(tgt, root)
        if (sid, tid) in seen:
            continue
        seen.add((sid, tid))
        data["edges"].append({
            "from": sid,
            "to": tid,
            "kind": f"{nodes[src]}->{nodes[tgt]}",
        })
    return data


_HTML_TEMPLATE = r"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Playbook Reference Tree</title>
<script src="https://cdn.jsdelivr.net/npm/d3@7/dist/d3.min.js"></script>
<style>
  :root { color-scheme: light dark; }
  body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", system-ui, sans-serif;
         margin: 0; padding: 1.25rem; background: #fafafa; color: #222; }
  h1 { margin: 0 0 0.25rem; font-size: 1.4rem; }
  .meta { color: #666; font-size: 0.85rem; margin-bottom: 0.6rem; }
  .stats { font-size: 0.8rem; color: #888; margin-bottom: 0.75rem; }
  .stats b { color: #0a558c; }
  svg { background: white; border-radius: 8px; border: 1px solid #ddd; display: block;
        max-width: 100%; height: auto; }
  .legend { margin-top: 0.75rem; font-size: 0.85rem; color: #555;
            display: flex; gap: 1.5rem; flex-wrap: wrap; }
  .legend span { display: inline-flex; align-items: center; gap: 0.4rem; }
  .legend .swatch { width: 28px; height: 0; border-top: 2px solid; }
  .node text { pointer-events: none; user-select: none; font-size: 11px; }
  .node circle { stroke-width: 1.5; cursor: pointer; transition: r 0.1s; }
  .node:hover circle { r: 9; }
  .node--playbook circle { fill: #1f3a5f; stroke: #0a1f3a; }
  .node--playbook text { font-size: 13px; font-weight: 600; fill: white; }
  .node--ref circle { fill: #4a7ba7; stroke: #2a5582; }
  .node--ref text { fill: #1a2a3a; }
  .node--agent circle { fill: #8c5a7a; stroke: #6c3a5a; }
  .node--agent text { fill: #2a1a24; }
  .node--skill circle { fill: #5a8c4a; stroke: #3a6c2a; }
  .node--skill text { fill: #1a2a1a; font-style: italic; }
  .edge { fill: none; pointer-events: none; transition: opacity 0.15s; }
  .edge--playbook-ref { stroke: #aaa; stroke-width: 1; stroke-opacity: 0.22; }
  .edge--ref-ref     { stroke: #2a5582; stroke-width: 1.4; stroke-opacity: 0.55; }
  .edge--agent-ref   { stroke: #6c3a5a; stroke-width: 1.4; stroke-opacity: 0.6; stroke-dasharray: 4,3; }
  .edge--skill-ref   { stroke: #3a6c2a; stroke-width: 1.4; stroke-opacity: 0.6; stroke-dasharray: 4,3; }
  .edge--skill-skill { stroke: #c47a2a; stroke-width: 1.2; stroke-opacity: 0.55; stroke-dasharray: 2,3; }
  .dim { opacity: 0.06 !important; }
  .highlight { stroke-opacity: 1 !important; stroke-width: 2.5 !important; }
  @media (prefers-color-scheme: dark) {
    body { background: #1a1a1a; color: #eee; }
    .meta, .legend { color: #aaa; }
    svg { background: #222; border-color: #444; }
    .node--ref text { fill: #d0e0f0; }
    .node--agent text { fill: #e8c8dc; }
    .node--skill text { fill: #d0e8c0; }
    .edge--ref-ref { stroke: #6aa5d8; }
    .edge--agent-ref { stroke: #cc88b0; }
    .edge--skill-ref { stroke: #8acc70; }
    .edge--skill-skill { stroke: #e3a368; }
    .edge--playbook-ref { stroke: #777; }
  }
</style>
</head>
<body>
<h1>Playbook Reference Tree</h1>
<div class="meta">The universe's levels: <strong>Playbook -> REF -> the planets that orbit it</strong> (agents inner, skills outer). Hover a node to highlight its connections.</div>
<div class="stats">
  <b id="s-refs">0</b> REFs · <b id="s-agents">0</b> agents · <b id="s-skills">0</b> skills · <b id="s-edges">0</b> references
</div>
<svg id="viz" width="1200" height="1200" viewBox="0 0 1200 1200"></svg>
<div class="legend">
  <span><span class="swatch" style="border-color:#aaa"></span>Playbook -> REF (routing)</span>
  <span><span class="swatch" style="border-color:#2a5582"></span>REF &lt;-&gt; REF (cross-reference)</span>
  <span><span class="swatch" style="border-color:#6c3a5a; border-top-style:dashed"></span>Agent -> REF (orbit)</span>
  <span><span class="swatch" style="border-color:#3a6c2a; border-top-style:dashed"></span>Skill -> REF (instantiation)</span>
  <span><span class="swatch" style="border-color:#c47a2a; border-top-style:dotted"></span>Skill &lt;-&gt; Skill (cross-reference)</span>
</div>

<script>
const data = __DATA__;
document.getElementById("s-refs").textContent = data.refs.length;
document.getElementById("s-agents").textContent = data.agents.length;
document.getElementById("s-skills").textContent = data.skills.length;
document.getElementById("s-edges").textContent = data.edges.length;

const W = 1200, H = 1200;
const cx = W / 2, cy = H / 2;
const R_REF = 320;
const R_AGENT = 415;
const R_SKILL = 510;

// Place playbook at center.
data.playbook.kind = "playbook";
data.playbook.x = cx; data.playbook.y = cy;

// Place REFs evenly around the inner ring.
const N = data.refs.length;
data.refs.forEach((r, i) => {
  r.kind = "ref";
  r.angle = (i / N) * 2 * Math.PI - Math.PI / 2;
  r.x = cx + R_REF * Math.cos(r.angle);
  r.y = cy + R_REF * Math.sin(r.angle);
});

const byId = { [data.playbook.id]: data.playbook };
data.refs.forEach(r => byId[r.id] = r);
data.agents.forEach(a => { a.kind = "agent"; byId[a.id] = a; });
data.skills.forEach(s => { s.kind = "skill"; byId[s.id] = s; });

// Place skills at the circular mean of the angles of REFs they cite.
data.skills.forEach(s => {
  const cited = data.edges
    .filter(e => e.from === s.id && byId[e.to] && byId[e.to].kind === "ref")
    .map(e => byId[e.to].angle);
  let angle = 0;
  if (cited.length) {
    let sx = 0, sy = 0;
    cited.forEach(a => { sx += Math.cos(a); sy += Math.sin(a); });
    angle = Math.atan2(sy, sx);
  }
  s.angle = angle;
});

// Place agents at their HOME sun's bearing (a planet orbits its home sun in
// every view, REF-Universe.md §3); the citation mean is only the fallback for
// an agent whose home did not resolve.
data.agents.forEach(a => {
  const home = a.home && byId[a.home];
  if (home && home.kind === "ref") {
    a.angle = home.angle;
    return;
  }
  const cited = data.edges
    .filter(e => e.from === a.id && byId[e.to] && byId[e.to].kind === "ref")
    .map(e => byId[e.to].angle);
  let sx = 0, sy = 0;
  cited.forEach(t => { sx += Math.cos(t); sy += Math.sin(t); });
  a.angle = cited.length ? Math.atan2(sy, sx) : 0;
});

// Spread each ring's labels apart if they collide.
const MIN_GAP = (2 * Math.PI) / 60;
function spread(ring) {
  const sorted = [...ring].sort((a, b) => a.angle - b.angle);
  for (let i = 1; i < sorted.length; i++) {
    const gap = sorted[i].angle - sorted[i-1].angle;
    if (gap < MIN_GAP) sorted[i].angle = sorted[i-1].angle + MIN_GAP;
  }
}
spread(data.skills);
spread(data.agents);
data.skills.forEach(s => {
  s.x = cx + R_SKILL * Math.cos(s.angle);
  s.y = cy + R_SKILL * Math.sin(s.angle);
});
data.agents.forEach(a => {
  a.x = cx + R_AGENT * Math.cos(a.angle);
  a.y = cy + R_AGENT * Math.sin(a.angle);
});

// Classify each edge for styling. Skip edges that don't fit the layer model
// (e.g. ref->playbook back-edges).
function edgeClass(e) {
  const a = byId[e.from], b = byId[e.to];
  if (!a || !b) return null;
  if (a.kind === "playbook" && b.kind === "ref")   return "edge--playbook-ref";
  if (a.kind === "ref"      && b.kind === "ref")   return "edge--ref-ref";
  if (a.kind === "agent"    && b.kind === "ref")   return "edge--agent-ref";
  if (a.kind === "skill"    && b.kind === "ref")   return "edge--skill-ref";
  if (a.kind === "skill"    && b.kind === "skill") return "edge--skill-skill";
  return null;
}

function edgePath(e) {
  const a = byId[e.from], b = byId[e.to];
  if (e._class === "edge--ref-ref" || e._class === "edge--skill-skill") {
    // Quadratic Bezier with control point pulled toward the center, so
    // intra-ring arcs bow inward instead of cutting straight across.
    const mx = (a.x + b.x) / 2, my = (a.y + b.y) / 2;
    const cpx = mx + 0.55 * (cx - mx), cpy = my + 0.55 * (cy - my);
    return `M${a.x},${a.y} Q${cpx},${cpy} ${b.x},${b.y}`;
  }
  return `M${a.x},${a.y} L${b.x},${b.y}`;
}

const svg = d3.select("#viz");

// Draw faint guide rings.
svg.append("g").selectAll("circle")
  .data([R_REF, R_AGENT, R_SKILL])
  .join("circle")
  .attr("cx", cx).attr("cy", cy).attr("r", d => d)
  .attr("fill", "none").attr("stroke", "#e5e5e5").attr("stroke-dasharray", "2,4");

const edgeData = data.edges
  .map(e => ({ ...e, _class: edgeClass(e) }))
  .filter(e => e._class);

const edgeSel = svg.append("g").selectAll("path")
  .data(edgeData)
  .join("path")
  .attr("class", d => `edge ${d._class}`)
  .attr("d", edgePath);

const nodeLayer = svg.append("g");

function placeLabel(g, datum, dx) {
  const deg = datum.angle * 180 / Math.PI;
  const flip = Math.cos(datum.angle) < 0;
  const labelDeg = flip ? deg + 180 : deg;
  const offset = flip ? -dx : dx;
  g.append("text")
    .attr("transform", `rotate(${labelDeg}) translate(${offset},0)`)
    .attr("text-anchor", flip ? "end" : "start")
    .attr("dy", "0.32em");
}

// Playbook node (center).
const pbG = nodeLayer.append("g")
  .attr("class", "node node--playbook")
  .attr("transform", `translate(${data.playbook.x},${data.playbook.y})`)
  .datum(data.playbook);
pbG.append("circle").attr("r", 28);
pbG.append("text").attr("text-anchor", "middle").attr("dy", "0.32em")
  .text("PLAYBOOK");

// REF nodes.
data.refs.forEach(r => {
  const g = nodeLayer.append("g")
    .attr("class", "node node--ref")
    .attr("transform", `translate(${r.x},${r.y})`)
    .datum(r);
  g.append("circle").attr("r", 6);
  placeLabel(g, r, 12);
  g.select("text").text(r.label.replace(/^REF-/, ""));
});

// Agent nodes.
data.agents.forEach(a => {
  const g = nodeLayer.append("g")
    .attr("class", "node node--agent")
    .attr("transform", `translate(${a.x},${a.y})`)
    .datum(a);
  g.append("circle").attr("r", 5);
  placeLabel(g, a, 11);
  g.select("text").text(a.label);
});

// Skill nodes.
data.skills.forEach(s => {
  const g = nodeLayer.append("g")
    .attr("class", "node node--skill")
    .attr("transform", `translate(${s.x},${s.y})`)
    .datum(s);
  g.append("circle").attr("r", 5);
  placeLabel(g, s, 11);
  g.select("text").text(s.label);
});

// Hover: highlight incident edges, dim the rest.
const allNodes = nodeLayer.selectAll(".node");
allNodes
  .on("mouseover", function (event, d) {
    const id = d.id;
    edgeSel
      .classed("dim",       e => e.from !== id && e.to !== id)
      .classed("highlight", e => e.from === id || e.to === id);
    const neighbors = new Set([id]);
    data.edges.forEach(e => {
      if (e.from === id) neighbors.add(e.to);
      if (e.to   === id) neighbors.add(e.from);
    });
    allNodes.classed("dim", n => !neighbors.has(n.id));
  })
  .on("mouseout", function () {
    edgeSel.classed("dim", false).classed("highlight", false);
    allNodes.classed("dim", false);
  });
</script>
</body>
</html>
"""


def render_html(data: dict) -> str:
    return _HTML_TEMPLATE.replace("__DATA__", json.dumps(data))


def main() -> int:
    ap = argparse.ArgumentParser(
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    ap.add_argument(
        "--root", type=Path,
        default=Path(__file__).resolve().parent.parent,
        help="playbook root to scan (default: parent of this script's dir)",
    )
    ap.add_argument(
        "--no-open", action="store_true",
        help="skip launching the browser after writing the file",
    )
    args = ap.parse_args()

    root: Path = args.root.resolve()
    out_path = root / OUTPUT_NAME

    data = build_data(root)
    out_path.write_text(render_html(data), encoding="utf-8")

    print(f"Wrote {out_path}")
    print(f"  {len(data['refs'])} REFs, {len(data['agents'])} agents, "
          f"{len(data['skills'])} skills, {len(data['edges'])} references")

    if not args.no_open:
        webbrowser.open(out_path.as_uri())
    return 0


if __name__ == "__main__":
    sys.exit(main())
