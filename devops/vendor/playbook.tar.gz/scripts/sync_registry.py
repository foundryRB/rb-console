#!/usr/bin/env python3
"""Regenerate the Available Skills table in every galaxy's GALAXY.md.

Each row is a mechanical projection of one skill's residence and frontmatter
(Top Violation #1: no hand-maintained parallel copies): the name is its folder,
the master is that folder's SKILL.md, and the refs are its `refs:` list. This
script is the propagation mechanism; the prose around the table is authored and
is left untouched.

Rows are ordered by skill name so the projection is deterministic. Refs keep
their frontmatter order, because the first entry is the skill's home sun
(REF-Universe.md §3) and sorting would erase that.

Usage:
    python scripts/sync_registry.py            # rewrite tables in place
    python scripts/sync_registry.py --check    # exit 1 if anything would change
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

import yaml

__all__ = ["collect_rows", "render_table", "sync"]

_HEADING = "## Available Skills"
_HEADER = "| Skill | Master | Refs |"
_SEPARATOR = "|---|---|---|"


def _frontmatter(path: Path) -> dict:
    text = path.read_text(encoding="utf-8")
    if not text.startswith("---"):
        raise SystemExit(f"error: {path} has no frontmatter block")
    end = text.find("\n---", 3)
    if end == -1:
        raise SystemExit(f"error: {path} has an unterminated frontmatter block")
    return yaml.safe_load(text[3:end]) or {}


def collect_rows(galaxy_dir: Path) -> list[tuple[str, str, list[str]]]:
    """Every skill this galaxy shelves, as (name, master path, refs)."""
    rows: list[tuple[str, str, list[str]]] = []
    for skill_md in sorted((galaxy_dir / "skills").glob("*/SKILL.md")):
        name = skill_md.parent.name
        refs = [str(r) for r in (_frontmatter(skill_md).get("refs") or [])]
        rows.append((name, f"skills/{name}/SKILL.md", refs))
    return sorted(rows)


def render_table(rows: list[tuple[str, str, list[str]]]) -> list[str]:
    lines = [_HEADER, _SEPARATOR]
    for name, master, refs in rows:
        cited = ", ".join(f"`{ref}`" for ref in refs)
        lines.append(f"| `{name}` | `{master}` | {cited} |")
    return lines


def _section_span(lines: list[str]) -> tuple[int, int] | None:
    """(start, end) of the Available Skills section; end is exclusive.

    The heading carries a suffix in the shelves that have one ('(invocable)'),
    so it is matched by prefix.
    """
    start: int | None = None
    for i, line in enumerate(lines):
        if start is None:
            if line.strip().startswith(_HEADING):
                start = i
        elif line.startswith("## "):
            return start, i
    return None if start is None else (start, len(lines))


def _table_span(lines: list[str], section: tuple[int, int]) -> tuple[int, int] | None:
    """(start, end) of the contiguous table block inside the section."""
    start, end = section
    for i in range(start, end):
        if lines[i].lstrip().startswith("|"):
            j = i
            while j < end and lines[j].lstrip().startswith("|"):
                j += 1
            return i, j
    return None


def sync(pack_root: Path, write: bool) -> list[str]:
    """Return galaxies whose table is out of sync (and fix it if write)."""
    galaxies = pack_root / "galaxies"
    stale: list[str] = []
    for galaxy_dir in sorted(d for d in galaxies.iterdir() if d.is_dir()):
        galaxy_md = galaxy_dir / "GALAXY.md"
        if not galaxy_md.is_file():
            continue
        original = galaxy_md.read_text(encoding="utf-8")
        lines = original.splitlines()
        section = _section_span(lines)
        if section is None:
            if list((galaxy_dir / "skills").glob("*/SKILL.md")):
                raise SystemExit(
                    f"error: {galaxy_dir.name} shelves skills but its GALAXY.md "
                    f"has no '{_HEADING}' section"
                )
            continue
        span = _table_span(lines, section)
        if span is None:
            raise SystemExit(
                f"error: {galaxy_dir.name}: '{_HEADING}' section has no table to project into"
            )
        table = render_table(collect_rows(galaxy_dir))
        lines = lines[: span[0]] + table + lines[span[1] :]
        new_text = "\n".join(lines).rstrip("\n") + "\n"
        if new_text != original:
            stale.append(galaxy_md.parent.name)
            if write:
                galaxy_md.write_text(new_text, encoding="utf-8", newline="\n")
    return stale


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--check", action="store_true", help="Report drift; write nothing.")
    args = ap.parse_args()
    pack_root = Path(__file__).resolve().parents[1]
    stale = sync(pack_root, write=not args.check)
    if not stale:
        print("skill registries in sync")
        return 0
    verb = "out of sync" if args.check else "rewritten"
    for name in stale:
        print(f"{verb}: {name}")
    return 1 if args.check else 0


if __name__ == "__main__":
    sys.exit(main())
