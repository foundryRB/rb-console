#!/usr/bin/env python3
"""Validate that references in the playbook resolve on disk.

Walks all *.md and *.py under the playbook root, extracts markdown links and
bare absolute paths, and checks each one points to a real file or directory.

Exits 0 if every reference resolves; 1 if any are broken.

Usage:
    python check_links.py [--root <dir>] [--quiet]

Run before refactoring to establish a green baseline; run again after to catch
anything the refactor broke. The diff *is* the migration checklist.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from _refs import Reference, collect_files, extract_refs  # noqa: E402


def _format_ref(ref: Reference, root: Path) -> str:
    try:
        rel_source = ref.source.relative_to(root)
    except ValueError:
        rel_source = ref.source
    return f"  {rel_source}:{ref.line}\n    raw:      {ref.raw}\n    resolved: {ref.resolved}"


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument(
        "--root",
        type=Path,
        default=Path(__file__).resolve().parent.parent,
        help="root to scan (default: playbook/)",
    )
    ap.add_argument("--quiet", action="store_true",
                    help="only print broken refs and final summary")
    args = ap.parse_args()

    root: Path = args.root.resolve()
    files = collect_files(root)

    if not args.quiet:
        print(f"Scanning {len(files)} file(s) under {root}")

    broken: list[Reference] = []
    total = 0
    for f in files:
        for ref in extract_refs(f):
            total += 1
            if not ref.exists():
                broken.append(ref)

    if not broken:
        print(f"OK: {total} reference(s) checked, all resolve")
        return 0

    print(f"\nBROKEN: {len(broken)} of {total} reference(s) failed to resolve\n")
    by_source: dict[Path, list[Reference]] = {}
    for ref in broken:
        by_source.setdefault(ref.source, []).append(ref)
    for source in sorted(by_source):
        for ref in by_source[source]:
            print(_format_ref(ref, root))
    return 1


if __name__ == "__main__":
    sys.exit(main())
