#!/usr/bin/env python3
"""Install or refresh the playbook's skills and agents in the harnesses on this machine.

One installer, two sources, one write. Run from a playbook clone, it installs the
clone's skills and renders every agent for every harness. Run from a
playbook-studio install bundle (this same file, unpacked at the bundle's
scripts/install_playbook.py, under the root that holds its manifest.json), it
installs the bundle's skills and the agents the studio rendered for one harness
with these same renderers. The write is this file's alone, whichever the source:

- a skill is compared with what is installed, file by file, by its bytes and (on
  POSIX) its executable bit; one that differs is staged whole in a hidden sibling
  folder and renamed into place, so an interrupted run leaves every skill folder
  whole, old or new;
- an agent file is compared by its bytes and replaced by an atomic rename;
- a symlinked skill folder or agent file is left alone;
- nothing is deleted unless --prune is passed;
- the output is one summary table, and a note to restart the session when anything
  changed.

Skills install once. SKILL.md is the shared Agent Skills format, and ~/.claude/skills
is a location every harness we run reads - OpenCode lists it among its own search
paths - so one copy serves them all. Agents are the kind that does not travel: each
harness spells an agent definition its own way and reads it from its own directory,
so the same corpus file is rendered once per harness (REF-Authoring section 13: the
file is one agent definition, and each runtime spells its fields its own way).

A clone sweep renders for every harness, unconditionally and without a flag to
select between them: a harness that is not installed here simply gets a directory
nobody reads, which costs a few kilobytes, where a flag costs the colleague who did
not know to pass it their whole agent roster. What each rendering can carry differs,
and the mapping lives here once per harness so the corpus field and the runtime
field never drift apart:

    corpus          claude-code                     opencode
    name            name:                           the file name
    description     description:                    description:
    skills          skills: (preloaded)             permission.skill (a licence)
    doors           mcpServers:                     - (bound globally, see below)
    permission      permissionMode:                 permission.bash
    writes: false   disallowedTools: <editing>      permission.edit: deny
    the body        the system prompt               the system prompt
    a model         none - the environment binds it, in both

OpenCode binds MCP servers globally in opencode.json rather than per agent, so
an agent's doors cannot be a field there; they are written as a comment naming
the servers to configure, because dropping them silently would lose the one
fact that says which doors the agent needs.

Installing is additive, so a skill renamed or deleted in the playbook lingers
in the runtime directory forever. --prune makes the runtime an exact mirror of
the playbook's current set: it removes EVERY folder there that is not a current
playbook skill, which is the orphans and also any skill installed from another
source, since nothing distinguishes them. That is why it is opt-in, and why a
symlinked folder is left alone - a link into a working copy is how a skill is
developed against a live runtime. Under the same flag, an agent file whose name
is not a current playbook agent is removed - from each harness's agents
directory in turn, since each holds its own rendering of the same roster. Without
the flag, the table names those same entries as gone upstream.

From a clone, the agent renderers need PyYAML. From a bundle nothing beyond the
standard library of Python 3.8 or newer is needed, because the agents arrive
rendered.

Usage:
    python scripts/install_playbook.py                 # install every skill and agent
    python scripts/install_playbook.py --only digest   # one skill (repeatable); no agents
    python scripts/install_playbook.py --list          # show what would install
    python scripts/install_playbook.py --prune         # also drop every non-playbook entry
    [--runtime-dir <path>]           # default: ~/.claude/skills
    [--agents-dir <path>]            # default: ~/.claude/agents
    [--opencode-agents-dir <path>]   # default: $XDG_CONFIG_HOME/opencode/agents,
                                     # or ~/.config/opencode/agents without it
"""

from __future__ import annotations

import argparse
import contextlib
import hashlib
import json
import os
import shutil
import stat
import sys
import uuid
from collections.abc import Callable
from pathlib import Path, PurePosixPath
from typing import NamedTuple

__all__ = [
    "AGENT_RUNTIMES",
    "AgentRuntime",
    "main",
    "render_opencode_agent",
    "render_runtime_agent",
]

#: The runtime tools that change files; a read-only posture denies exactly these.
_EDITING_TOOLS = ("Edit", "Write", "MultiEdit", "NotebookEdit")

#: A skill folder's files, less what running its scripts leaves behind.
_IGNORED_DIRS = ("__pycache__",)
_IGNORED_SUFFIXES = (".pyc",)

#: A bundle announces itself by its manifest at the root this file installs from.
_MANIFEST = "manifest.json"
_BUNDLE_FORMAT = 1

#: Hidden siblings a run stages into and retires through. The leading dot keeps
#: them out of the prune and out of every harness's skill discovery.
_STAGED = ".playbook-staged-"
_RETIRED = ".playbook-retired-"

_RESTART_NOTE = "Restart the session to load the new and updated skills and agents."

#: Whether this machine keeps an executable bit. Windows has none to keep, so there
#: a file's mode never makes a skill differ.
_MODES = os.name != "nt"

_STATUSES = ("new", "updated", "unchanged", "gone upstream")


def _yaml_scalar(text: str) -> str:
    """A one-line YAML value, double-quoted so punctuation never changes its meaning."""
    return '"' + text.replace("\\", "\\\\").replace('"', '\\"') + '"'


def _split_agent(text: str) -> tuple[dict, str]:
    """An agent file's frontmatter mapping and its body, or raise on a malformed file."""
    import yaml  # noqa: PLC0415 - only rendering reads frontmatter, and a bundle renders nothing

    if not text.startswith("---"):
        raise ValueError("agent file has no frontmatter block")
    end = text.find("\n---", 3)
    if end == -1:
        raise ValueError("agent file has an unterminated frontmatter block")
    return yaml.safe_load(text[3:end]) or {}, text[end + 4 :].strip("\n")


def opencode_agents_default() -> Path:
    """OpenCode's global agents directory, honoring XDG_CONFIG_HOME where it is set."""
    configured = os.environ.get("XDG_CONFIG_HOME")
    root = Path(configured) if configured else Path.home() / ".config"
    return root / "opencode" / "agents"


def render_opencode_agent(text: str) -> str:
    """A playbook agent file, rendered in OpenCode's agent shape.

    OpenCode takes the agent's name from the file name, so no name field is
    written; posture becomes its permission object, and the licence becomes a
    skill permission map that denies the auto-discovered set and allows exactly
    what the corpus licensed.
    """
    fm, body = _split_agent(text)
    posture = fm.get("posture") or {}
    lines = [
        "---",
        f"description: {_yaml_scalar(str(fm['description']))}",
        "mode: all",
    ]
    doors = [str(d) for d in (fm.get("doors") or [])]
    if doors:
        lines.append(
            f"# doors: {', '.join(doors)} - configure these MCP servers in opencode.json; "
            "OpenCode binds them globally, not per agent"
        )
    lines.append("permission:")
    lines.append(f"  edit: {'allow' if posture.get('writes') else 'deny'}")
    lines.append(f"  bash: {'allow' if posture.get('permission') == 'auto' else 'ask'}")
    skills = [str(s) for s in (fm.get("skills") or [])]
    if skills:
        lines.append("  skill:")
        lines.append('    "*": deny')
        lines += [f'    "{s}": allow' for s in skills]
    lines.append("---")
    return "\n".join(lines) + "\n\n" + body + "\n"


def render_runtime_agent(text: str) -> str:
    """A playbook agent file, rendered in the Claude runtime's agent shape.

    The corpus file holds the agent (REF-Authoring section 13); this is the one
    place its fields are spelled the runtime's way, so the two never drift.
    """
    fm, body = _split_agent(text)
    posture = fm.get("posture") or {}
    lines = [
        "---",
        f"name: {fm['name']}",
        f"description: {_yaml_scalar(str(fm['description']))}",
    ]
    skills = [str(s) for s in (fm.get("skills") or [])]
    if skills:
        lines.append("skills:")
        lines += [f"  - {s}" for s in skills]
    doors = [str(d) for d in (fm.get("doors") or [])]
    if doors:
        lines.append("mcpServers:")
        lines += [f"  - {d}" for d in doors]
    lines.append(f"permissionMode: {posture.get('permission')}")
    if posture.get("writes") is False:
        lines.append(f"disallowedTools: {', '.join(_EDITING_TOOLS)}")
    lines.append("---")
    return "\n".join(lines) + "\n\n" + body + "\n"


class AgentRuntime(NamedTuple):
    """One harness: what it calls itself, how it spells an agent, where it reads them."""

    name: str
    render: Callable[[str], str]
    install_hint: str
    dest: str


#: Every harness this machine may run. A clone sweep writes all of them, so no
#: colleague's roster depends on a flag. This tuple is the single home of the set:
#: anything serving these renderings (the studio's door, for one) reads it from
#: here rather than restating which harnesses exist or where each one looks.
AGENT_RUNTIMES = (
    AgentRuntime("claude-code", render_runtime_agent, "~/.claude/agents/", "agents_dir"),
    AgentRuntime(
        "opencode", render_opencode_agent, "~/.config/opencode/agents/", "opencode_agents_dir"
    ),
)


class _Source(NamedTuple):
    """Skill folders by name, and per harness the agent files to install, by file name."""

    label: str
    skills: dict
    agents: list


def _clone_source(root: Path, render: bool) -> _Source:
    """A playbook clone: its skills, and every agent rendered for every harness."""
    skill_dirs = list((root / "skills").glob("*")) + list(root.glob("galaxies/*/skills/*"))
    skills = {d.name: d for d in sorted(skill_dirs) if d.is_dir() and (d / "SKILL.md").is_file()}
    agents = []
    if render:
        paths = sorted(root.glob("galaxies/*/agents/*.md"), key=lambda p: p.stem)
        texts = [(p.name, p.read_text(encoding="utf-8")) for p in paths]
        agents = [
            (runtime, {name: runtime.render(text).encode("utf-8") for name, text in texts})
            for runtime in AGENT_RUNTIMES
        ]
    return _Source(f"the clone at {root}", skills, agents)


def _bundle_source(root: Path) -> _Source:
    """A studio install bundle, after checking every file it names against its hash and
    that each skill folder holds no file it does not name."""
    manifest = json.loads((root / _MANIFEST).read_text(encoding="utf-8"))
    if manifest.get("format") != _BUNDLE_FORMAT:
        raise SystemExit(f"unsupported bundle format: {manifest.get('format')!r}")
    runtime = next((r for r in AGENT_RUNTIMES if r.name == manifest.get("runtime")), None)
    if runtime is None:
        raise SystemExit(f"this installer renders for no harness named {manifest.get('runtime')!r}")
    skills: dict[str, Path] = {}
    listed: dict[str, set[str]] = {}
    agents: dict[str, bytes] = {}
    for entry in manifest["files"]:
        parts = PurePosixPath(entry["path"]).parts
        if len(parts) < 2 or parts[0] not in ("skills", "agents") or ".." in parts:
            raise SystemExit(f"the bundle names a file outside its layout: {entry['path']}")
        path = root.joinpath(*parts)
        if not path.is_file():
            raise SystemExit(f"the bundle lacks a file its manifest names: {entry['path']}")
        if _sha256(path) != entry["sha256"]:
            raise SystemExit(f"the bundle file {entry['path']} does not match its manifest hash")
        if parts[0] == "skills":
            skills[parts[1]] = root / "skills" / parts[1]
            listed.setdefault(parts[1], set()).add("/".join(parts[2:]))
        else:
            agents[parts[1]] = path.read_bytes()
    for name, folder in skills.items():
        unlisted = sorted(set(_skill_files(folder)) - listed[name])
        if unlisted:
            raise SystemExit(
                f"the bundle holds a file its manifest does not name: skills/{name}/{unlisted[0]}"
            )
    label = f"the studio bundle {str(manifest.get('digest', ''))[:12]} for {runtime.name}"
    return _Source(label, skills, [(runtime, agents)])


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 16), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _executable(path: Path) -> bool:
    return _MODES and bool(path.stat().st_mode & stat.S_IXUSR)


def _skill_files(folder: Path) -> dict[str, Path]:
    """Every file of a skill folder by its relative path, less bytecode caches."""
    found: dict[str, Path] = {}
    for current, dirs, names in os.walk(folder):
        dirs[:] = sorted(d for d in dirs if d not in _IGNORED_DIRS)
        for name in sorted(names):
            if name.endswith(_IGNORED_SUFFIXES):
                continue
            path = Path(current, name)
            found[path.relative_to(folder).as_posix()] = path
    return found


def _fingerprint(folder: Path) -> dict[str, tuple[str, bool]]:
    """What makes two copies of a skill the same: each file's bytes and executable bit."""
    return {rel: (_sha256(p), _executable(p)) for rel, p in _skill_files(folder).items()}


def _remove(path: Path) -> None:
    if path.is_dir() and not path.is_symlink():
        shutil.rmtree(path)
    else:
        path.unlink()


def _swap_in(source: Path, target: Path) -> None:
    """Stage a whole skill folder beside its target, then rename it into place.

    The target is only ever the complete old folder or the complete new one: the
    stage is written in full before anything moves, a failure while staging
    removes the stage, and a failure while renaming puts the old folder back.
    """
    tag = uuid.uuid4().hex[:12]
    stage = target.parent / f"{_STAGED}{target.name}-{tag}"
    try:
        for rel_path, path in _skill_files(source).items():
            dest = stage.joinpath(*rel_path.split("/"))
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(path, dest)
            if _executable(path):
                mode = dest.stat().st_mode
                dest.chmod(mode | ((mode & 0o444) >> 2))
    except BaseException:
        shutil.rmtree(stage, ignore_errors=True)
        raise
    retired = None
    try:
        if target.exists():
            aside = target.parent / f"{_RETIRED}{target.name}-{tag}"
            os.replace(target, aside)
            retired = aside
        os.replace(stage, target)
    except BaseException:
        if retired is not None:
            os.replace(retired, target)
        shutil.rmtree(stage, ignore_errors=True)
        raise
    if retired is not None:
        # The new folder is in place; a retired copy that will not go yet is
        # cleared by the next run.
        with contextlib.suppress(OSError):
            _remove(retired)


def _replace_file(target: Path, data: bytes) -> None:
    """Write one file beside its target and rename it over the target."""
    stage = target.parent / f"{_STAGED}{target.name}-{uuid.uuid4().hex[:12]}"
    try:
        stage.write_bytes(data)
        os.replace(stage, target)
    except BaseException:
        with contextlib.suppress(OSError):
            stage.unlink()
        raise


def _clear_leftovers(folder: Path) -> None:
    """Remove what a run killed outright left behind: stages and retired copies."""
    if not folder.is_dir():
        return
    for entry in folder.iterdir():
        if entry.name.startswith((_STAGED, _RETIRED)):
            with contextlib.suppress(OSError):
                _remove(entry)


class _Report:
    """What a run did, per group (the skills, or one harness's agents), in order."""

    def __init__(self) -> None:
        self.groups: list[tuple[str, Path]] = []
        self.rows: list[tuple[str, str, str]] = []
        self.linked: list[str] = []
        self.failed: list[str] = []

    def add(self, group: str, name: str, status: str) -> None:
        self.rows.append((group, name, status))

    def names(self, status: str) -> list[str]:
        return [f"{group}/{name}" for group, name, s in self.rows if s == status]

    def count(self, group: str, status: str) -> int:
        return sum(1 for g, _, s in self.rows if g == group and s == status)

    @property
    def changed(self) -> bool:
        return any(s in ("new", "updated", "pruned") for _, _, s in self.rows)


def _write_skills(skills: dict[str, Path], runtime_dir: Path, report: _Report) -> None:
    runtime_dir.mkdir(parents=True, exist_ok=True)
    for name in sorted(skills):
        source, target = skills[name], runtime_dir / name
        if target.is_symlink():
            report.linked.append(f"skills/{name}")
            continue
        if target.is_dir():
            if _fingerprint(target) == _fingerprint(source):
                report.add("skills", name, "unchanged")
                continue
            status = "updated"
        else:
            status = "updated" if target.exists() else "new"
        try:
            _swap_in(source, target)
        except OSError as exc:
            report.failed.append(f"skills/{name} ({exc})")
            continue
        report.add("skills", name, status)


def _write_agents(
    rendered: dict[str, bytes], agents_dir: Path, group: str, report: _Report
) -> None:
    agents_dir.mkdir(parents=True, exist_ok=True)
    for filename in sorted(rendered):
        name, target = Path(filename).stem, agents_dir / filename
        if target.is_symlink():
            report.linked.append(f"{group}/{name}")
            continue
        if target.is_file():
            if target.read_bytes() == rendered[filename]:
                report.add(group, name, "unchanged")
                continue
            status = "updated"
        else:
            status = "new"
        try:
            _replace_file(target, rendered[filename])
        except OSError as exc:
            report.failed.append(f"{group}/{name} ({exc})")
            continue
        report.add(group, name, status)


def _stale_skills(runtime_dir: Path, available: list[str]) -> list[Path]:
    """Runtime folders that are not current playbook skills.

    Only real directories are candidates: a dotted entry is never one, and neither is
    a symlinked folder - the runtime directory belongs to the user, and a link into a
    working copy is the ordinary way to develop a skill against a live runtime. It is
    also the one candidate `shutil.rmtree` refuses outright, which would abort the
    sweep partway and leave the rest of the run undone.
    """
    if not runtime_dir.is_dir():
        return []
    return [
        entry
        for entry in sorted(runtime_dir.iterdir())
        if entry.is_dir()
        and not entry.is_symlink()
        and not entry.name.startswith(".")
        and entry.name not in available
    ]


def _prune(
    runtime_dir: Path, available: list[str], failed: list[str] | None = None
) -> list[str]:
    """Remove runtime folders that are not current playbook skills; return their names.

    The sweep runs to completion: a folder that cannot be removed is recorded in
    `failed` and the next candidate is tried.
    """
    removed = []
    for entry in _stale_skills(runtime_dir, available):
        try:
            shutil.rmtree(entry)
        except OSError as exc:
            if failed is not None:
                failed.append(f"skills/{entry.name} ({exc})")
            continue
        removed.append(entry.name)
    return removed


def _stale_agents(agents_dir: Path, names: list[str]) -> list[Path]:
    """Agent files in one harness's directory whose name is not a current playbook agent."""
    if not agents_dir.is_dir():
        return []
    return [
        entry
        for entry in sorted(agents_dir.glob("*.md"))
        if entry.is_file() and not entry.is_symlink() and entry.stem not in names
    ]


def render_table(source: _Source, prune: bool, report: _Report) -> str:
    """The run's only output: counts per group and status, then the names that moved."""
    lines = [f"playbook toolchain from {source.label}"]
    lines += [f"{group}: {folder}" for group, folder in report.groups]
    lines.append("")
    width = max([len("skills")] + [len(group) for group, _ in report.groups])
    columns = [(status, max(len(status), 7)) for status in _STATUSES]
    lines.append(" " * width + "  " + "  ".join(s.rjust(w) for s, w in columns))
    for group, _ in report.groups:
        cells = [
            str(report.count(group, "pruned" if prune and s == "gone upstream" else s)).rjust(w)
            for s, w in columns
        ]
        lines.append(group.ljust(width) + "  " + "  ".join(cells))
    details = [
        ("new", report.names("new")),
        ("updated", report.names("updated")),
        ("gone upstream, kept (--prune removes)", report.names("gone upstream")),
        ("gone upstream, pruned", report.names("pruned")),
        ("left alone, symlinked", report.linked),
        ("failed", report.failed),
    ]
    listed = [f"{label}: {', '.join(names)}" for label, names in details if names]
    if listed:
        lines.append("")
        lines.extend(listed)
    if report.changed:
        lines.extend(["", _RESTART_NOTE])
    return "\n".join(lines) + "\n"


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--only", action="append", default=None, help="Skill name (repeatable)")
    ap.add_argument("--runtime-dir", type=Path, default=Path.home() / ".claude" / "skills")
    ap.add_argument("--agents-dir", type=Path, default=Path.home() / ".claude" / "agents")
    ap.add_argument("--opencode-agents-dir", type=Path, default=None)
    ap.add_argument("--list", action="store_true", help="List installable skills and exit")
    ap.add_argument(
        "--prune",
        action="store_true",
        help=(
            "Also remove every folder in the runtime directory that is not a current "
            "playbook skill, including skills installed from other sources, and every "
            "agent file that is not a current playbook agent (symlinks are left alone)"
        ),
    )
    args = ap.parse_args(argv)
    if args.opencode_agents_dir is None:
        args.opencode_agents_dir = opencode_agents_default()
    with contextlib.suppress(AttributeError, ValueError):
        sys.stdout.reconfigure(errors="replace")

    root = Path(__file__).resolve().parents[1]
    if (root / _MANIFEST).is_file():
        source = _bundle_source(root)
    else:
        source = _clone_source(root, render=not args.only and not args.list)
    available = sorted(source.skills)

    if args.list:
        for name in available:
            print(name)
        return 0

    names = args.only or available
    unknown = [n for n in names if n not in available]
    if unknown:
        print(f"error: unknown skill(s): {', '.join(unknown)}", file=sys.stderr)
        return 2

    report = _Report()
    status = "pruned" if args.prune else "gone upstream"
    report.groups.append(("skills", args.runtime_dir))
    _clear_leftovers(args.runtime_dir)
    _write_skills({n: source.skills[n] for n in names}, args.runtime_dir, report)
    if args.prune:
        stale = _prune(args.runtime_dir, available, report.failed)
    else:
        stale = [entry.name for entry in _stale_skills(args.runtime_dir, available)]
    for name in stale:
        report.add("skills", name, status)

    # A full sweep carries the roster - into every harness's own directory, so an
    # agent is where each one looks for it. --only is a single skill: agents stay put.
    if not args.only:
        for runtime, rendered in source.agents:
            group = f"{runtime.name} agents"
            agents_dir = getattr(args, runtime.dest)
            report.groups.append((group, agents_dir))
            _clear_leftovers(agents_dir)
            _write_agents(rendered, agents_dir, group, report)
            for entry in _stale_agents(agents_dir, [Path(f).stem for f in rendered]):
                if args.prune:
                    try:
                        entry.unlink()
                    except OSError as exc:
                        report.failed.append(f"{group}/{entry.stem} ({exc})")
                        continue
                report.add(group, entry.stem, status)

    sys.stdout.write(render_table(source, args.prune, report))
    return 1 if report.failed else 0


if __name__ == "__main__":
    sys.exit(main())
