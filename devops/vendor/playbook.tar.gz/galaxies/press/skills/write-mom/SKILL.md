---
name: write-mom
description: "Produce a MoM per REF-MoM from a working session's capture (a workshop export, plan rows, or raw notes): draft the one-screen content (context paragraph, three to five key outcomes, one consolidated Owner/Action/Due table with dates resolved absolute against the session date), review it with the operator as plain content before any render, then encode it as the MoM dataset and emit the two projections in one pass from the skill's templates, the themed HTML artifact carrying the dataset with its fixed renderer and the email-safe HTML export with its derived pipe-separated subject line. The digest sibling of bootstrap-workshop: the capture stays the record, the dataset is the MoM, the renders are projections."
galaxy: press
refs:
  - REF-MoM
  - REF-Workshop
---

# Write MoM

Invoked after a working session, when its capture exists and the room's outcomes must reach the people who were not in it. Input: the session capture (a workshop export per REF-Workshop, plan rows per REF-Plan, or raw notes) plus the session date and participants. Output: one MoM dataset and its two projections, a themed HTML artifact carrying the dataset with a fixed renderer, and an email-safe HTML export generated from the same dataset.

## Appearance

Read `THEMING.md` alongside the routed REF. Use the shipped template or complete selected slide theme for palette, artwork and typography. Material and decorative motion are authored choices; add no Glass/Solid or Motion controls to normal outputs. Verify Light/Dark, narrow layouts, print/export and reduced motion for the surfaces being changed.

## Pre-flight

1. Read `REF-MoM.md` whole; its dataset schema, writing rules, and projection rules govern everything below.
2. Locate and read the whole capture. If the capture cannot be found, stop and ask; a MoM invented from memory is a fork of the record.
3. Confirm the session date and the participant list; owners named in the capture are not automatically the attendees.

## Steps

1. **Draft the content**, per REF-MoM sections 2 and 3, as plain markdown in conversation:
   - Masthead: session name, date, participants.
   - Context: one paragraph stating what the session was, what it walked, and what state it left things in. Write it after the outcomes so it states what actually happened.
   - Key outcomes: three to five bullets, each led by one bolded sentence carrying a call (something now true or decided), with at most two supporting sentences.
   - Actions: one Owner / Action / Due table of the session's own actions. Then the check (REF-MoM section 3): list every action the earlier MoMs of the engagement left open that is neither in this table nor closed in the plan, and put that list to the operator with the draft; the operator carries, re-dates, or drops each one. Never append a carried row on your own, and never restore a row the operator removed. Merge ledger items sharing an owner and a theme into one row, the row citing the plan ids it moves in parentheses; resolve relative dates ("end of week") to real dates against the session date, computing them against a calendar rather than from memory, and check that any weekday you name is that date's actual day; leave project-relative dates as the capture states them. Every row names a person, or the explicit All.
   - Footer: one line pointing at the capture.
2. **Review with the operator.** Iterate on the content until approved. Render nothing yet. When the operator asks for shorter, cut rows and bullets by consolidating harder; never shrink the font or add sections.
3. **Encode the approved content as the dataset** per the REF-MoM section 2 schema: `meta` (id, eyebrow, title, `sessions` as ISO date / dateLabel / participants entries), `context`, `outcomes` as lead/detail pairs, `actions` as owner/action/due rows, `footer`. The dataset carries every content string; nothing content-bearing lives anywhere else. Where a MoM for an earlier session exists and has not been sent, grow that dataset instead of starting one: its `meta.sessions` gains an entry, its outcomes merge, and its action rows dedupe.
4. **Emit the MoM** by instantiating `templates/mom-artifact.html`, replacing `{{TITLE}}` with `meta.title` and `{{DATASET_JSON}}` with the dataset. That one file carries both projections: it renders the page and builds the email from the same block, so there is no second file to generate. Never edit the template's markup, styles, or script per MoM. Publish it as the platform's shareable page when a publishing surface exists; otherwise deliver the file.
5. **Deliver it and hand over the controls**: name the file, say the dataset sits in the `mom-data` block at the top of it, and say the page's own button copies the email version to the clipboard for pasting into a new mail message. The operator changes a word by editing that block and reloading, with no help needed. Say too that the block is JSON, so a quote inside a string needs escaping as `\"`; the page names the fault when it cannot parse, and knowing that in advance saves the surprise.
6. The MoM stands as sent. A later correction is a follow-up note, never an edit of the record. A content change before sending is a dataset change and a republish.

## Failure modes

- **The draft outgrows one screen.** The MoM is re-dumping the ledger. Consolidate actions per owner and theme, cut outcome bullets to the calls, and point at the capture for everything else.
- **A date is written from memory.** Weekday arithmetic done in the head is the error a reader trusts on sight: a due that names a day the date is not sends its owner to the wrong day. Compute `meta.dateLabel` and every due against a calendar, and check the weekday matches before the content goes to the operator.
- **An action has no owner.** Do not invent one and do not write "the team"; ask the operator, or carry it as All only when the room truly owns it together.
- **The capture and the operator's memory disagree.** The capture wins on facts (ids, owners, dates); the operator wins on what the room meant. Surface the conflict instead of silently picking.
- **A projection needs content the dataset lacks.** Grow the dataset, never the template; a content string typed into a template instantiation is a fork the next re-emit erases.
- **The email is about to be written as its own file.** It is not one. The page builds it from the dataset on demand, which is what keeps the two from drifting; a separate file would need regenerating by hand for every word changed.
- **A preview of the email is about to be added to the page.** It does not want one: the email is a thing to paste, and a framed preview renders blank under a strict artifact CSP regardless. The control copies and reports, and shows nothing.
- **The operator edits the dataset and the page goes blank.** The guard names the fault; read what it says. It is nearly always a quote inside a string that needs escaping as `\"`, or a comma after the last item of a list.
- **An em-dash appears anywhere.** Hard rule (INT-SHAPE-002): none, in the dataset or in either projection.
