---
name: write-commercial-brief
description: "Write or revise a commercial brief per REF-CommercialBrief, the first page on a request, from the request and the author's understanding before anything is scoped: sort what is in hand into heard, assumed and proposed, draw today's path and the proposed solution as figures, and fill the fixed spine (context, problem, solution, open points) on the brief bootstrap-flyer scaffolds, with every open point something a named person can close and the requester's hand-over as one action with its list. Called again when answers arrive, it revises the same brief: each answered point moves into the section it changes and leaves the open list."
galaxy: press
refs:
  - REF-CommercialBrief
  - REF-Flyer
---

# Write commercial brief

Invoked when a request, an opportunity or an idea needs its first page, or when a brief has answers to absorb. Input: whatever is in hand, which is the request as it arrived (a message, a document, a conversation), anything the requester has said since, and the earlier version of the brief when there is one. Output: one self-contained `<slug>.html`, a brief on the flyer frame.

## Appearance

Read `THEMING.md` alongside the routed REF. Use the shipped template or complete selected slide theme for palette, artwork and typography. Material and decorative motion are authored choices; add no Glass/Solid or Motion controls to normal outputs. Verify Light/Dark, narrow layouts, print/export and reduced motion for the surfaces being changed.

## Pre-flight

1. **Read** `REF-CommercialBrief.md` whole, and `REF-Flyer.md` §6 (legend and figures), §8 (copy rules) and §10 (generation flow) for the page.
2. **Gather what is in hand**: the request in the requester's own words, what they have said since, and the earlier version of the brief when there is one. Nothing else is required; an estimate, a plan or a prototype is never an input (`REF-CommercialBrief.md` §3).
3. **Name the reader**: who asked, and who they will pass the page to. Their three questions are fixed (`REF-CommercialBrief.md` §1).
4. **Confirm with the user** the brief's name, the language the reader reads in, and where it is kept: a file path, or the flyer workshop when one is connected.

## Steps

1. **Sort the material** into heard, assumed and proposed (`REF-CommercialBrief.md` §4). Heard stays in the requester's words. Every gap met while sorting becomes an open point of one of three kinds (`REF-CommercialBrief.md` §2): a question only the requester can answer, a reading of ours to confirm, or something that is ours to work out. Check each question against what was heard; one the request already answers is dropped.
2. **Draft the content as plain text** on the spine (`REF-CommercialBrief.md` §2): the context items, today's path and its breaks, the proposed parts and which of them exist, the open points by kind, and what the requester is asked to hand over, as one action with its items listed. Add an optional section (`REF-CommercialBrief.md` §3) only when the reader's question needs it.
3. **Show the draft to the user** before drawing anything. A wrong reading of the request is cheapest to fix here.
4. **Scaffold the frame** with `bootstrap-flyer --brief`, and set the contents to the brief's sections (`REF-Flyer.md` §3). For a revision, open the current version instead.
5. **Draw the two figures first** (`REF-Flyer.md` §6): today's path with each break marked, and the solution with its status channel and legend. Then fill the sections around them, each block in the form of its content (`REF-Flyer.md` §8): numbers, labels, steps, two columns, a checklist for the hand-over; a paragraph only where none of these fits.
6. **Set the status line** on the masthead (concept, version, date), and mark every assumption with the treatment the legend declares.
7. **Verify** the frame and the figures per `REF-Flyer.md` §10 steps 5 and 6, then the content: each context item traces to something the requester said, each assumption appears in the open points as a reading to confirm, each open point names who closes it, no question is put to the requester that is ours to work out or that the request already answers, the hand-over is one action with its list, the contents have one entry per section, and no price, effort figure or delivery date is on the page.
8. **Deliver** the file, or a version in the flyer workshop. Tell the user what is open and who closes each point. Where a workshop frames the page inside its own, give the reader the address of the page itself.

### Revising a brief

When answers arrive, each answered point moves into the section it changes, a figure is redrawn when the answer changes the mechanism, the point leaves the open list, and the status line takes the next version and its date (`REF-CommercialBrief.md` §5). Questions the answers raise join the open list.

## Failure modes

- **Today's path is unknown.** The problem section says what is known and stops; the missing steps are open points. A path is never invented to complete the figure.
- **A context item traces to nothing the requester said.** It is an assumption: move it out of the context, mark it, and list it.
- **The first version has no open points.** Reread the request for what was assumed silently; a first reading with nothing open has usually guessed.
- **An assumption is on the list as a question.** State the answer assumed, for the requester to confirm or correct; a question hides what was assumed.
- **A question for the requester is ours to answer.** The basis of a number we proposed, or where the proposal stops applying, goes under our name.
- **The page reads as prose.** Two figures above paragraphs and tables: give each block the form of its content (`REF-Flyer.md` §8).
- **The page reads as a proposal.** Prices, effort figures and dates come out; levers and order stay, marked indicative.
- **An answer contradicts an earlier version.** The page states the current understanding only; the earlier version stays in the version history.
- **An em-dash appears anywhere.** Hard rule (INT-SHAPE-002): none, in the copy or in a figure label.

## See also

- `REF-CommercialBrief.md`. The pattern this skill instantiates.
- `REF-Flyer.md` and `bootstrap-flyer`. The page a brief is written on, and its scaffold.
- `bootstrap-workshop`. A session is one way to answer the open points.
