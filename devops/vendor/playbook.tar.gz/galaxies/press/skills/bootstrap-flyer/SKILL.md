---
name: bootstrap-flyer
description: "Scaffold a new HTML/CSS flyer per REF-Flyer, a one-sheet leave-behind or a longer brief for discussion: a single self-contained <flyer-name>.html carrying the token :root block, the desk/sheet skeleton, a print block, and a sample masthead plus one section. Renders as-is (offline, and as a claude.ai Artifact); deploys one .html per flyer to any static host. Standalone, printable sibling of bootstrap-slidev-deck."
galaxy: press
refs:
  - REF-Flyer
---

# Bootstrap flyer

Invoked when the user wants to start a new HTML/CSS flyer (a hostable-and-printable page: a one-sheet leave-behind, or a brief a reader works through to discuss or decide), or add one to a project. This skill produces a *working*, self-contained `<flyer-name>.html`: opening it in a browser, or dropping it into a claude.ai Artifact, renders a finished-looking flyer with no build step and no external requests. Sane defaults; the author fills the content from there.

The standalone, printable sibling of `bootstrap-slidev-deck` (sequential decks). Reference pattern: `REF-Flyer.md` (the desk/sheet structure, the token palette, the three-role type system, the print block).

## Appearance

Read `THEMING.md` alongside the routed REF. Use the shipped template or complete selected slide theme for palette, artwork and typography. Material and decorative motion are authored choices; add no Glass/Solid or Motion controls to normal outputs. Verify Light/Dark, narrow layouts, print/export and reduced motion for the surfaces being changed.

## Pre-flight

1. **Read** `REF-Flyer.md` for the two lengths (§1, sheet and brief), the desk/sheet structure (§3), the token palette (§4), the three-role type system (§5), the grid, legend and figure rules (§6), the print rules (§7), and the content rules (§8, especially the reader's question first, the no-em-dash hard rule and lowercase-mono tool labels).
2. **Name the reader and the question** the page answers, and list what they have to see for that (`REF-Flyer.md` §10 step 1). The list picks sheet or brief and names the figures; it comes before the scaffold. A brief is scaffolded with `--brief`.
3. **Confirm the flyer name and title** with the user. The name becomes the `<slug>.html` filename (one `.html` per flyer, §9); the title becomes the `<title>` tag and the masthead name.
4. **Confirm the output path**. A single file; default the current directory. It does not need its own project folder.

## What it produces

One file: `<slug>.html`, self-contained, carrying:

```
<title>…</title>
<style>
  :root { … }        # the locked token palette (--desk, --sheet, --ink, --steel,
                     #   --steel-2, --highlight, --muted, --line, --blueprint, + tints)
                     #   and the three font stacks (--sans, --serif, --mono)
  .desk { … }        # the tinted mat: full viewport, padding, sans + ink
  .sheet { … }       # the centered identity surface: max-width 1120px, soft shadow, radius
  @keyframes rise    # one subtle entrance, gated by prefers-reduced-motion
  …                  # eyebrow, mono, thesis, section, footer, one diagram panel
  @media print { … } # @page A4 + print-color-adjust:exact; strips the desk
</style>
<div class="desk"><article class="sheet">
  <header class="mast"> … </header>   # doc-ref, eyebrow, big name, one-line lede, hard rule
  <section class="thesis"> … </section>  # one emphasized thesis line
  <section> … </section>              # one sample content section (eyebrow + body)
  <footer class="foot"> … </footer>   # mono identity strip
</article></div>
```

With `--brief` the same frame carries the brief length (`REF-Flyer.md` §1, §3):

```
<style>
  …                  # everything above, plus section heads, a legend, and a figure
                     #   panel that scrolls inside itself
  .toc { … }         # the contents: a rail beside the sections on a wide window,
                     #   a bar pinned to the top on a narrow one; left out in print
  @media print { … } # figures and blocks never split; a heading stays with its block
</style>
<div class="desk"><article class="sheet">
  <header class="mast"> … </header>
  <div class="brief">
    <nav class="toc"> … </nav>         # one entry per section, a section's parts under it
    <div class="main">
      <section class="thesis"> … </section>
      <section id="…"> … </section>  # eyebrow, heading, lead, a sample figure with its legend
      <section id="…"> … </section>  # two more sample sections
    </div>
  </div>
  <footer class="foot"> … </footer>
</article></div>
<script> … </script>                  # inline: marks the contents entry being read
```

The output is deliberately Artifact-safe (`REF-Flyer.md` §7): no `<link>`, no external `<script>`, no remote `<img>`, all CSS inline. The same file that renders as a claude.ai Artifact is the file that deploys.

## Steps

1. **Run the scaffolder** (the `bootstrap.py` beside this SKILL.md):
   ```bash
   python bootstrap.py --out <path> --name "<Flyer Name>" [--brief] [--eyebrow "<ORG · CONTEXT>"]
   ```
   Writes `<path>/<slug>.html` (slug derived from the name). Refuses to overwrite an existing file. `--brief` scaffolds the brief length; without it the output is a sheet. `--eyebrow` sets the masthead label; omit for a neutral default.
2. **Verify it renders**: open `<slug>.html` in a browser (it must render with the network unplugged), then print-preview (one A4 sheet, colors intact), then narrow the window to a phone width (no sideways scroll). On a brief, also scroll it at a wide and at a narrow window: the contents stay on screen, as a rail and then as a bar, and mark the part being read; print-preview shows no contents and no figure split across pages. This is the flyer's whole correctness check (`REF-Flyer.md` §2, §10).
3. **Fill the content**: draw the figures first (`REF-Flyer.md` §6, the figure draws the mechanism), then replace the sample masthead, thesis, and section with the real distillation around them. Keep the frame; only fill it. On a brief, keep the contents in step with the page: every section has an id and an entry, a part of a section worth reaching directly gets an entry of class `sub`, and an entry leaves with its section (`REF-Flyer.md` §3). Honor the content rules (`REF-Flyer.md` §8): a sheet is one page with at most one figure, a brief is as long as its question with one figure per section and every other block in the form of its content, lowercase-mono tool labels, one strongest content emphasis, and NO em-dashes anywhere. Then verify the content as well as the frame (`REF-Flyer.md` §10 steps 5 and 6).
4. **Set the favicon and deploy** (see below).
5. **Surface to user**:
   - "Flyer scaffolded at `<slug>.html`. Open it to preview (renders offline and as a claude.ai Artifact). Fill the masthead, thesis, and section; keep the token `:root` block and the desk/sheet frame. Deploy by dropping the one `.html` onto any static host behind auth, one file per flyer."

## Favicon and deploy (per REF-Flyer §9)

- **As a claude.ai Artifact**: pass one or two emoji as the Artifact favicon (e.g. a spec-sheet or factory glyph). Keep it stable across redeploys of the same flyer.
- **As a hosted page**: the flyer deploys to any host that serves static files behind auth, one `.html` per flyer. The file ships as authored: no serve-time templating, no separate build. To add a flyer, drop its `<slug>.html` into the host's served directory and commit. A host deployed on the Foundry follows `REF-AppContract.md` for admission and its chosen authentication posture.

## Page authoring rules (per REF-Flyer §4 to §8)

- **Every color is a `:root` token.** No raw hex outside `:root` (except the print block). Add a token; never a one-off hex.
- **Keep one strongest content emphasis.** Brand marks and peripheral motion remain subordinate.
- **Three type roles, each with one job.** Sans for body and headings, the identity's thesis face for an optional emphasized line, mono for eyebrows, tool labels, and the footer. No webfont CDN links.
- **Grids never scroll sideways.** Every grid child carries `min-width:0`; columns collapse at breakpoints.
- **One figure, one claim.** A sheet carries at most one figure; a brief carries one per section. Each draws the mechanism: real parts, labelled arrows, inline SVG on the page's tokens.
- **NO em-dashes, anywhere.** Recast with a comma, colon, semicolon, or two sentences. Hard rule.
- **The reader's question picks the length.** A sheet is one page: cut, do not shrink. When the cut would remove what the reader asked to see, the page is a brief.

## CLI options

| Flag | Default | Purpose |
|---|---|---|
| `--out <path>` | current directory | Directory to write `<slug>.html` into |
| `--name "<text>"` | required | Flyer name (masthead name + `<title>`); also slugified for the filename |
| `--eyebrow "<text>"` | a neutral placeholder | The masthead eyebrow label (uppercase mono) |
| `--slug <text>` | derived from `--name` | Override the output filename stem |
| `--brief` | off | Scaffold the brief length: sections under contents that stay on screen, a sample figure, print rules that paginate |
| `--force` | off | Overwrite an existing file (default: refuse) |

## Failure modes

- **Target `.html` already exists**: the scaffolder refuses; pass `--force` to overwrite, or pick a different `--slug`.
- **Output directory does not exist**: the scaffolder creates it; if the path is a file, it errors.
- **An em-dash slips into authored content**: the playbook intent tests (INT-SHAPE-002) fail on it; recast per `REF-Flyer.md` §8. The scaffolded skeleton ships em-dash-free.
- **A contents entry goes nowhere, or a section has none**: an entry whose `href` matches no id on the page is dead, and a section with no entry cannot be reached. Keep the two in step (`REF-Flyer.md` §3).
- **The contents scroll away**: something between the contents and the page has become a scroll container (an `overflow` other than `clip` on the sheet or on a wrapper). Remove it; the scaffold's sheet clips without scrolling.
- **The page fetches something external**: it will render locally but break under the Artifact CSP and offline; remove the external reference and inline it (`REF-Flyer.md` §7).

## Anti-patterns

- Hand-writing the desk/sheet frame or the token palette instead of scaffolding it. The frame is fixed; only the content changes.
- Adding competing primary emphases, or a second figure on a sheet. Distill the content hierarchy.
- Filling a figure panel with boxes of prose. A figure draws the parts and labels what moves between them.
- Introducing a build step, a framework, or an external stylesheet. A flyer is one self-contained file.
- Shrinking type to cram more onto the page. Cut content until it fits one sheet.
- Scaffolding a sheet for a page that will scroll, then hand-adding section links to the masthead. Scaffold the brief length; its contents stay on screen.

## See also

- `REF-Flyer.md`. The pattern this skill instantiates.
- `REF-AppContract.md` sections 2 to 4: application admission, authentication and repository obligations for a host deployed on the Foundry.
- `REF-Authoring.md` §2. Portability rules; the skill and its scaffold stay generic (no machine, user, or project specifics in the emitted file).
- `bootstrap-slidev-deck`. Sibling skill for the sequential-presentation shape; a flyer is the single-page, printable counterpart.
