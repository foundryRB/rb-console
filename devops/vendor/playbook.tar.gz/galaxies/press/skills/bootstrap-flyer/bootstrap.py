#!/usr/bin/env python3
"""Scaffold a new HTML/CSS flyer (REF-Flyer), as a sheet or as a brief.

Writes one self-contained <slug>.html: the locked token :root block, the
desk/sheet skeleton, a print block, a sample masthead, one emphasized thesis line
(the primary content emphasis), and one content section. With --brief it writes
the brief length instead: the same frame, with contents that stay on screen and
mark the part being read, sample sections that lead with a figure, and print
rules that paginate. No build step, no framework, no external requests: the file
renders as-is offline and as a claude.ai Artifact. Refuses to overwrite unless
--force. The caller fills the content afterwards (see SKILL.md).

Usage:
    python bootstrap.py --name "<Flyer Name>" [--out <dir>] [--brief] \
        [--eyebrow "<ORG . CONTEXT>"] [--slug <stem>] [--force]
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

__all__ = ["main", "slugify", "render"]

# ---------------------------------------------------------------------------
# The flyer template.
#
# One <style> block carrying the token palette + the three font stacks, the
# desk/sheet frame, the eyebrow/mono/thesis/section/footer rules, one diagram
# panel, responsive breakpoints, and the print block. Then the markup: a
# masthead, a thesis (the one --highlight accent), one sample section, a footer.
#
# Doubled braces ({{ }}) are literal CSS braces; single braces are .format
# fields. The body, and the brief's styles and script, are fields: a sheet takes
# SHEET_BODY and nothing else, a brief takes the BRIEF_* blocks below, which are
# plain text and so keep single braces. Keep this em-dash free (INT-SHAPE-002), ASCII-only (use an HTML entity
# like &middot; for any non-ASCII glyph, REF-Flyer.md section 7), and free of
# external requests (REF-Flyer.md section 7).
# ---------------------------------------------------------------------------

FLYER_TMPL = """<title>{title}</title>
<style>
  :root{{

    --grid:rgba(30,74,90,.07);
    --tint:rgba(30,74,90,.055);

  }}
  *{{box-sizing:border-box}}

  /* ---- desk + sheet ---- */
  .desk{{
    width:100%;min-height:100vh;background:var(--desk);
    padding:clamp(16px,4vw,44px);
    font-family:var(--sans);color:var(--ink);
    -webkit-font-smoothing:antialiased;
  }}
  .sheet{{
    width:100%;max-width:1120px;margin:0 auto;background:var(--sheet);
    border:1px solid var(--line);border-radius:4px;
    box-shadow:0 18px 50px -24px rgba(20,30,36,.55);
    padding:clamp(26px,4.6vw,54px);
    position:relative;overflow:hidden;
    animation:rise .5s ease both;
  }}
  @keyframes rise{{from{{opacity:0;transform:translateY(10px)}}to{{opacity:1;transform:none}}}}

  /* ---- shared marks ---- */
  .eyebrow{{font-family:var(--mono);font-size:11px;letter-spacing:.16em;
    text-transform:uppercase;color:var(--muted)}}
  .eyebrow.steel{{color:var(--steel);font-weight:600}}
  .mono{{font-family:var(--mono)}}
  em{{font-style:normal;color:var(--steel);font-weight:600}}
  b{{font-weight:700}}

  /* ---- masthead ---- */
  .mast{{position:relative;padding-bottom:18px;border-bottom:1.5px solid var(--ink)}}
  .lockup{{display:flex;align-items:center;margin-bottom:12px;color:var(--ink)}}
  .lockup-tile{{flex:none;width:40px;height:40px}}
  .lockup-words{{display:flex;flex-direction:column;justify-content:center;min-height:32px;margin-left:10px;padding-left:10px;border-left:1px solid var(--line);line-height:1.15}}
  .lockup-words b{{font-family:var(--sans);font-size:13px;font-weight:700;letter-spacing:.06em}}
  .lockup-words i{{margin-top:2px;font-family:var(--mono);font-style:normal;font-size:9.5px;font-weight:600;letter-spacing:.22em;text-transform:uppercase;color:var(--muted)}}
  .docref{{position:absolute;top:2px;right:0;font-family:var(--mono);font-size:10px;
    letter-spacing:.12em;color:var(--muted);text-align:right;line-height:1.5}}
  .name{{font-size:clamp(38px,6.2vw,60px);font-weight:800;letter-spacing:-.022em;
    line-height:.96;margin:10px 0 0;text-wrap:balance}}
  .deflede{{margin:14px 0 0;font-size:clamp(15px,1.7vw,17px);line-height:1.5;
    max-width:60ch;color:var(--ink)}}

  section{{margin-top:clamp(22px,3vw,30px)}}
  section > p{{max-width:75ch}}

  /* ---- thesis: the primary content emphasis ---- */
  .thesis{{border-left:3px solid var(--highlight);padding-left:20px}}
  .thesis .eyebrow{{margin-bottom:10px}}
  .thesisline{{font-family:var(--serif);font-style:italic;
    font-size:clamp(27px,4vw,42px);line-height:1.16;margin:0;color:var(--ink);
    text-wrap:balance;max-width:26ch}}
  .thesissub{{margin:12px 0 0;font-family:var(--mono);font-size:12px;letter-spacing:.05em;
    text-transform:uppercase;color:var(--highlight);font-weight:600;line-height:1.5}}

  /* ---- a content grid (columns collapse; min-width:0 kills sideways scroll) ---- */
  .grid3{{display:grid;grid-template-columns:repeat(3,1fr);gap:16px;margin-top:14px}}
  .pt{{min-width:0;border-top:2px solid var(--ink);padding-top:11px}}
  .pt h3{{margin:0 0 5px;font-size:15px;font-weight:700;letter-spacing:-.01em;line-height:1.12}}
  .pt p{{margin:0;font-size:13px;line-height:1.5;color:var(--ink)}}

  /* ---- one optional diagram panel (faint engineering grid) ---- */
  .diagram{{margin-top:14px;background:var(--blueprint);border:1px solid var(--line);
    border-radius:5px;padding:16px;
    background-image:
      linear-gradient(var(--grid) 1px,transparent 1px),
      linear-gradient(90deg,var(--grid) 1px,transparent 1px);
    background-size:22px 22px}}
  .bar{{display:flex;align-items:center;gap:12px;flex-wrap:wrap;color:var(--sheet);
    border-radius:4px;padding:10px 14px;background:var(--ink)}}
  .blabel{{font-family:var(--mono);font-size:10px;letter-spacing:.18em;color:var(--sheet)}}
  .btext{{font-size:15px;font-weight:700}}

  /* ---- footer ---- */
  .foot{{margin-top:clamp(24px,3.4vw,32px);padding-top:12px;border-top:1px solid var(--line);
    display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap;
    font-size:10.5px;letter-spacing:.08em;color:var(--muted)}}

  /* ---- responsive: one page on a phone, still one page on A4 ---- */
  @media (max-width:640px){{
    .grid3{{grid-template-columns:1fr}}
    .docref{{display:none}}
  }}
  @media (prefers-reduced-motion:reduce){{.sheet{{animation:none}}}}

  /* ---- print: strip the desk, print as a clean sheet ---- */
  @media print{{
    *{{-webkit-print-color-adjust:exact;print-color-adjust:exact}}
    @page{{size:A4;margin:11mm}}
    .desk{{background:#fff;padding:0;min-height:0}}
    .sheet{{box-shadow:none;border:none;max-width:none;border-radius:0;animation:none;padding:0}}
    section{{margin-top:16px}}
    .thesisline{{font-size:26px}}
    .diagram{{padding:12px}}
  }}

  body{{margin:0;background:var(--desk);isolation:isolate}}
  .desk{{background:transparent}}
  @media screen{{.sheet{{background:color-mix(in srgb,var(--sheet) 95%,transparent);backdrop-filter:blur(18px);border-radius:12px}}}}
  @media(prefers-reduced-transparency:reduce),(prefers-contrast:more){{.sheet{{background:var(--sheet);backdrop-filter:none}}}}
  @media print{{.sheet{{backdrop-filter:none}}}}
{brief_css}/* PRESS stage */
/* -- The Software Engineering stage, the deck shell's own --------------------------------------------
   Sized on its own box (positions in %, drifts and the grid in container units), so the same stage
   fills a slide canvas or a browser window. Source: design-systems/rb-software-engineering/
   brand/stage_css.py render_page(). Print hides it, reduced motion stops it, a hidden page pauses it. */
[data-stage="field"]{{position:fixed;inset:0;z-index:-1;overflow:hidden;pointer-events:none;container-type:size;background:linear-gradient(160deg,#0b0d12 0%,#070910 55%,#04050a 100%)}}
[data-stage="field"] [data-stage]{{position:absolute;display:block}}
[data-stage^="glow"]{{border-radius:50%;will-change:transform;animation-timing-function:linear;animation-iteration-count:infinite}}
[data-stage="glow-a"]{{left:-21.12%;top:-30.11%;width:81.22%;height:95.06%;background:radial-gradient(closest-side,rgba(78,224,160,0.30) 0%,rgba(0,168,107,0.10) 55%,rgba(0,168,107,0) 100%);animation-name:rb-glow-a;animation-duration:26s}}
@keyframes rb-glow-a{{0%,100%{{transform:translate(0,0)}}33.33%{{transform:translate(8.57cqw,8.71cqh)}}66.67%{{transform:translate(-3.88cqw,5.08cqh)}}}}
[data-stage="glow-b"]{{left:36.02%;top:25.03%;width:93.67%;height:104.85%;background:radial-gradient(closest-side,rgba(27,36,54,0.85) 0%,rgba(27,36,54,0) 100%);animation-name:rb-glow-b;animation-duration:34s}}
@keyframes rb-glow-b{{0%,100%{{transform:translate(0,0)}}33.33%{{transform:translate(-7.04cqw,-7.44cqh)}}66.67%{{transform:translate(4.69cqw,-3.81cqh)}}}}
[data-stage="glow-c"]{{left:35.92%;top:-22.49%;width:68.78%;height:75.1%;background:radial-gradient(closest-side,rgba(0,168,107,0.16) 0%,rgba(0,168,107,0) 100%);animation-name:rb-glow-c;animation-duration:41s}}
@keyframes rb-glow-c{{0%,100%{{transform:translate(0,0)}}33.33%{{transform:translate(-5.51cqw,11.25cqh)}}66.67%{{transform:translate(3.16cqw,6.17cqh)}}}}
[data-stage="grid"]{{inset:0;background-image:repeating-linear-gradient(rgba(255,255,255,.022) 0 1px,transparent 1px 4px),linear-gradient(to right,rgba(0,168,107,.13) 1px,transparent 1px),linear-gradient(to bottom,rgba(0,168,107,.13) 1px,transparent 1px),linear-gradient(to right,rgba(0,168,107,.07) 1px,transparent 1px),linear-gradient(to bottom,rgba(0,168,107,.07) 1px,transparent 1px);background-size:auto,12.5cqw 12.5cqw,12.5cqw 12.5cqw,3.125cqw 3.125cqw,3.125cqw 3.125cqw}}
[data-stage="motes"]{{inset:0}}
[data-stage="motes"]>span{{position:absolute;border-radius:50%;background:#4ee0a0;opacity:0;will-change:transform,opacity;animation:rb-mote linear infinite}}
@keyframes rb-mote{{0%{{transform:translateY(0);opacity:0}}25%{{opacity:var(--mote)}}70%{{opacity:var(--mote)}}100%{{transform:translateY(-23.58cqh);opacity:0}}}}
[data-stage="motes"]>span:nth-child(1){{left:9.18%;top:86.17%;width:2.8px;height:2.8px;animation-duration:13s;animation-delay:-1.4s;--mote:0.69}}
[data-stage="motes"]>span:nth-child(2){{left:18.98%;top:92.7%;width:2.1px;height:2.1px;animation-duration:17s;animation-delay:-6.2s;--mote:0.5}}
[data-stage="motes"]>span:nth-child(3){{left:27.45%;top:77.28%;width:3.2px;height:3.2px;animation-duration:11.5s;animation-delay:-3.1s;--mote:0.75}}
[data-stage="motes"]>span:nth-child(4){{left:37.96%;top:96.33%;width:2.3px;height:2.3px;animation-duration:15.5s;animation-delay:-9s;--mote:0.56}}
[data-stage="motes"]>span:nth-child(5){{left:44.59%;top:81.81%;width:2.6px;height:2.6px;animation-duration:19s;animation-delay:-2.2s;--mote:0.63}}
[data-stage="motes"]>span:nth-child(6){{left:52.14%;top:90.7%;width:2px;height:2px;animation-duration:12.5s;animation-delay:-7.7s;--mote:0.48}}
[data-stage="motes"]>span:nth-child(7){{left:57.96%;top:75.46%;width:3.1px;height:3.1px;animation-duration:16s;animation-delay:-4.5s;--mote:0.73}}
[data-stage="motes"]>span:nth-child(8){{left:65.51%;top:94.69%;width:2.4px;height:2.4px;animation-duration:14s;animation-delay:-11.3s;--mote:0.53}}
[data-stage="motes"]>span:nth-child(9){{left:71.53%;top:83.81%;width:2.1px;height:2.1px;animation-duration:18.5s;animation-delay:-0.9s;--mote:0.6}}
[data-stage="motes"]>span:nth-child(10){{left:78.47%;top:91.61%;width:2.9px;height:2.9px;animation-duration:12s;animation-delay:-5.6s;--mote:0.7}}
[data-stage="motes"]>span:nth-child(11){{left:85%;top:78.19%;width:2.3px;height:2.3px;animation-duration:20s;animation-delay:-8.4s;--mote:0.55}}
[data-stage="motes"]>span:nth-child(12){{left:91.63%;top:95.42%;width:2.6px;height:2.6px;animation-duration:15s;animation-delay:-3.7s;--mote:0.65}}
[data-stage="motes"]>span:nth-child(13){{left:5%;top:74.56%;width:2px;height:2px;animation-duration:21s;animation-delay:-10.1s;--mote:0.45}}
[data-stage="motes"]>span:nth-child(14){{left:23.37%;top:99.95%;width:2.8px;height:2.8px;animation-duration:13.8s;animation-delay:-12.6s;--mote:0.63}}
[data-stage="motes"]>span:nth-child(15){{left:48.47%;top:99.05%;width:2.1px;height:2.1px;animation-duration:17.6s;animation-delay:-2.8s;--mote:0.5}}
[data-stage="motes"]>span:nth-child(16){{left:75%;top:101.41%;width:2.4px;height:2.4px;animation-duration:16.4s;animation-delay:-6.9s;--mote:0.58}}
[data-stage="motes"]>span:nth-child(17){{left:96.12%;top:87.44%;width:2.3px;height:2.3px;animation-duration:19.6s;animation-delay:-14.2s;--mote:0.54}}
[data-stage="motes"]>span:nth-child(18){{left:33.57%;top:86.17%;width:2px;height:2px;animation-duration:22s;animation-delay:-1.7s;--mote:0.43}}
[data-stage="vignette"]{{inset:0;background:radial-gradient(72% 72% at 50% 42%,rgba(0,0,0,0) 55%,rgba(0,0,0,.55) 100%)}}
:root[data-theme="light"] [data-stage="field"]{{background:none}}
:root[data-theme="light"] [data-stage="grid"]{{background-image:linear-gradient(to right,rgba(0,122,77,.07) 1px,transparent 1px),linear-gradient(to bottom,rgba(0,122,77,.07) 1px,transparent 1px),linear-gradient(to right,rgba(0,122,77,.035) 1px,transparent 1px),linear-gradient(to bottom,rgba(0,122,77,.035) 1px,transparent 1px);background-size:12.5cqw 12.5cqw,12.5cqw 12.5cqw,3.125cqw 3.125cqw,3.125cqw 3.125cqw}}
:root[data-theme="light"] [data-stage="motes"]>span{{background:#00a86b}}
:root[data-theme="light"] [data-stage="vignette"]{{display:none}}
:root[data-theme="light"] [data-stage="glow-a"]{{background:radial-gradient(closest-side,rgba(255,255,255,0.95) 0%,rgba(255,255,255,0) 100%);animation-duration:48s}}
:root[data-theme="light"] [data-stage="glow-b"]{{background:radial-gradient(closest-side,rgba(37,40,43,0.055) 0%,rgba(37,40,43,0) 100%)}}
:root[data-theme="light"] [data-stage="glow-c"]{{display:none}}
@media (prefers-color-scheme: light) {{
:root:not([data-theme="dark"]) [data-stage="field"]{{background:none}}
:root:not([data-theme="dark"]) [data-stage="grid"]{{background-image:linear-gradient(to right,rgba(0,122,77,.07) 1px,transparent 1px),linear-gradient(to bottom,rgba(0,122,77,.07) 1px,transparent 1px),linear-gradient(to right,rgba(0,122,77,.035) 1px,transparent 1px),linear-gradient(to bottom,rgba(0,122,77,.035) 1px,transparent 1px);background-size:12.5cqw 12.5cqw,12.5cqw 12.5cqw,3.125cqw 3.125cqw,3.125cqw 3.125cqw}}
:root:not([data-theme="dark"]) [data-stage="motes"]>span{{background:#00a86b}}
:root:not([data-theme="dark"]) [data-stage="vignette"]{{display:none}}
:root:not([data-theme="dark"]) [data-stage="glow-a"]{{background:radial-gradient(closest-side,rgba(255,255,255,0.95) 0%,rgba(255,255,255,0) 100%);animation-duration:48s}}
:root:not([data-theme="dark"]) [data-stage="glow-b"]{{background:radial-gradient(closest-side,rgba(37,40,43,0.055) 0%,rgba(37,40,43,0) 100%)}}
:root:not([data-theme="dark"]) [data-stage="glow-c"]{{display:none}}
}}
@media print{{[data-stage="field"]{{display:none!important}}}}
@media (prefers-reduced-motion: reduce){{[data-stage],[data-stage] span{{animation:none!important}}}}
html[data-hidden="true"] [data-stage],html[data-hidden="true"] [data-stage] span{{animation-play-state:paused!important}}
/* /PRESS stage */
/* PRESS palette */
:root,:root[data-theme="light"]{{color-scheme:light;--desk:#f2f2f2;--sheet:#ffffff;--ink:#25282b;--muted:#4a4d4e;--line:#bebebe;--steel:#007a4d;--highlight:#007a4d;--blueprint:#f2f2f2;--sans:-apple-system, "SF Pro Display", "Helvetica Neue", "Segoe UI", Arial, sans-serif;--serif:-apple-system, "SF Pro Display", "Helvetica Neue", "Segoe UI", Arial, sans-serif;--mono:ui-monospace, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;}}
@media(prefers-color-scheme:dark){{:root:not([data-theme="light"]){{color-scheme:dark;--desk:#04050a;--sheet:#11141b;--ink:#f2f4f8;--muted:#c3cad6;--line:#353b47;--steel:#4ee0a0;--highlight:#4ee0a0;--blueprint:#0b0d12;--sans:-apple-system, "SF Pro Display", "Helvetica Neue", "Segoe UI", Arial, sans-serif;--serif:-apple-system, "SF Pro Display", "Helvetica Neue", "Segoe UI", Arial, sans-serif;--mono:ui-monospace, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;}}}}
:root[data-theme="dark"]{{color-scheme:dark;--desk:#04050a;--sheet:#11141b;--ink:#f2f4f8;--muted:#c3cad6;--line:#353b47;--steel:#4ee0a0;--highlight:#4ee0a0;--blueprint:#0b0d12;--sans:-apple-system, "SF Pro Display", "Helvetica Neue", "Segoe UI", Arial, sans-serif;--serif:-apple-system, "SF Pro Display", "Helvetica Neue", "Segoe UI", Arial, sans-serif;--mono:ui-monospace, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;}}
@media print{{:root,:root[data-theme="light"],:root[data-theme="dark"],:root:not([data-theme="light"]){{color-scheme:light;--desk:#f2f2f2;--sheet:#ffffff;--ink:#25282b;--muted:#4a4d4e;--line:#bebebe;--steel:#007a4d;--highlight:#007a4d;--blueprint:#f2f2f2;--sans:-apple-system, "SF Pro Display", "Helvetica Neue", "Segoe UI", Arial, sans-serif;--serif:-apple-system, "SF Pro Display", "Helvetica Neue", "Segoe UI", Arial, sans-serif;--mono:ui-monospace, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;}}}}
/* /PRESS palette */
</style>

<!-- PRESS stage -->
<div data-stage="field" aria-hidden="true"><span data-stage="glow-a"></span><span data-stage="glow-b"></span><span data-stage="glow-c"></span><span data-stage="grid"></span><span data-stage="motes"><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span></span><span data-stage="vignette"></span></div>
<!-- /PRESS stage -->
<div class="desk">
  <article class="sheet">

    <header class="mast">
      <div class="lockup"><svg class="lockup-tile" viewBox="0 0 120 120" aria-hidden="true"><rect x="6" y="6" width="108" height="108" rx="18" fill="none" stroke="currentColor" stroke-width="8"/><text x="60" y="77" text-anchor="middle" font-family="system-ui,-apple-system,Segoe UI,sans-serif" font-size="48" font-weight="800" fill="currentColor">RB</text></svg><span class="lockup-words"><b>Software Engineering</b><i>RB</i></span></div>
      <div class="docref">{kind}<br>{slug} &middot; v0.1</div>
      <div class="eyebrow">{eyebrow}</div>
      <h1 class="name">{title}</h1>
      <p class="deflede">One line that says what this flyer is, in plain words. Replace this
        lede with the real one-sentence summary.</p>
    </header>

{body}
    <footer class="foot">
      <span class="mono">{eyebrow}</span>
      <span class="mono">{title} &middot; v0.1</span>
    </footer>

  </article>
</div>
<script>(function(){{function visibility(){{document.documentElement.dataset.hidden=String(document.hidden)}}document.addEventListener('visibilitychange',visibility);visibility()}})();</script>
{brief_script}"""

# The sample body of a sheet: one thesis, one section.
SHEET_BODY = """    <section class="thesis">
      <div class="eyebrow steel">The one point</div>
      <p class="thesisline">The single most important thing this page exists to say, held on
        one serif line.</p>
      <p class="thesissub">A short supporting statement keeps the main point clear.</p>
    </section>

    <section>
      <div class="eyebrow steel">A section</div>
      <div class="grid3">
        <div class="pt">
          <h3>First point</h3>
          <p>A short supporting block. Keep it tight; a flyer is one page, not a document with
            a scrollbar.</p>
        </div>
        <div class="pt">
          <h3>Second point</h3>
          <p>Tool and component names go in lowercase mono, like <span class="mono">estimatekit</span>,
            consistently.</p>
        </div>
        <div class="pt">
          <h3>Third point</h3>
          <p>Cut until it fits one sheet. Do not shrink the type to cram more in.</p>
        </div>
      </div>
    </section>
"""

# ---------------------------------------------------------------------------
# The brief length (REF-Flyer.md sections 1 and 3): what a page that scrolls
# needs on top of the frame. Section heads, a figure panel that scrolls inside
# itself, contents that stay on screen, and print rules that paginate.
# ---------------------------------------------------------------------------

BRIEF_CSS = """
  /* ---- brief: section heads ---- */
  .sec-h{margin:6px 0 0;font-size:clamp(21px,2.6vw,26px);font-weight:800;letter-spacing:-.015em;
    line-height:1.1;text-wrap:balance}
  .sec-lead{margin:8px 0 0;font-size:14.5px;line-height:1.5;max-width:75ch}
  .sub-h{margin:26px 0 0;font-size:15px;font-weight:700}
  .keep{break-inside:avoid}

  /* ---- brief: figures (a wide figure scrolls inside its own panel) ---- */
  .legend{display:flex;flex-wrap:wrap;gap:8px 22px;align-items:center;margin-top:14px;
    font-size:12px;color:var(--muted)}
  .legend span{display:inline-flex;align-items:center;gap:7px}
  .legend svg{flex:none;width:30px;height:16px}
  .fig{margin:0}
  .figwrap{overflow-x:auto}
  .figwrap svg{display:block;width:100%;min-width:720px;height:auto}
  .cap{margin:10px 0 0;font-size:13px;line-height:1.5;max-width:75ch}
  .n-box{fill:var(--sheet);stroke:var(--ink);stroke-width:1.5}
  .n-new{fill:var(--sheet);stroke:var(--steel);stroke-width:1.5;stroke-dasharray:6 4}
  .n-t{font-family:var(--sans);font-size:14px;font-weight:700;fill:var(--ink)}
  .n-s{font-family:var(--sans);font-size:11px;fill:var(--muted)}
  .a-line{fill:none;stroke:var(--ink);stroke-width:1.3}
  .a-head{fill:var(--ink)}
  .a-lab{font-family:var(--mono);font-size:10px;fill:var(--muted)}

  /* ---- brief: contents, always on screen ---- */
  /* clip keeps the sheet's rounded edge without making it a scroll container,
     so the contents can stick to the viewport */
  .sheet{overflow:clip}
  html{scroll-padding-top:64px}
  @media (prefers-reduced-motion:no-preference){html{scroll-behavior:smooth}}
  .toc{position:sticky;top:0;z-index:5;display:flex;align-items:center;gap:4px;
    overflow-x:auto;scrollbar-width:none;padding:8px 0;background:var(--sheet);
    border-bottom:1px solid var(--line);font-family:var(--mono);font-size:11px;
    letter-spacing:.08em;text-transform:uppercase}
  .toc::-webkit-scrollbar{display:none}
  .toc h2,.toc .sub{display:none}
  .toc a{flex:none;color:var(--muted);text-decoration:none;font-weight:600;padding:6px 10px;
    border-radius:4px;white-space:nowrap}
  .toc a i{font-style:normal;font-family:var(--mono);margin-right:7px;color:var(--steel)}
  .toc a:hover{color:var(--ink)}
  .toc a.insec{color:var(--steel);background:var(--tint)}
  .toc .up{margin-left:auto}
  /* the rail: beside the sections once the frame has room for both */
  @media screen and (min-width:1340px){
    html{scroll-padding-top:24px}
    .sheet{max-width:1320px}
    .brief{display:grid;grid-template-columns:200px minmax(0,1fr);gap:40px;align-items:start}
    .main{min-width:0}
    .toc{top:20px;display:block;margin:clamp(22px,3vw,30px) 0 0;padding:0;background:none;
      border-bottom:none;max-height:calc(100vh - 40px);overflow:hidden auto;
      font-family:var(--sans);font-size:13px;letter-spacing:0;text-transform:none}
    .toc h2{display:block;margin:0 0 4px;font-family:var(--mono);font-size:10px;
      letter-spacing:.16em;text-transform:uppercase;color:var(--muted);font-weight:600}
    .toc a{display:block;padding:5px 10px;border-left:2px solid var(--line);border-radius:0;
      white-space:normal;line-height:1.35;font-weight:400}
    .toc a i{font-size:10.5px}
    .toc a.sec{margin-top:10px;font-weight:700;color:var(--ink)}
    .toc a.sub{display:block;padding-left:22px;font-size:12.5px}
    .toc a.insec{background:none;color:var(--ink);border-left-color:var(--ink)}
    .toc a.active{color:var(--steel);border-left-color:var(--steel);background:var(--tint);
      font-weight:600}
    .toc .up{margin:16px 0 0;border-left-color:transparent;font-family:var(--mono);
      font-size:10px;letter-spacing:.14em;text-transform:uppercase}
  }

  /* ---- brief: print paginates, and paper has no contents ---- */
  @media print{
    .toc{display:none}
    .fig,.pt,.keep,.legend,.sec-lead,.cap,tr{break-inside:avoid}
    .sec-h,.sub-h,.eyebrow{break-after:avoid}
    .figwrap{overflow:visible}
    .figwrap svg{min-width:0}
  }
"""

# Sections under contents. Every contents entry points at an id on the page: a
# section, or a part inside one (class "sub", shown in the rail under its section).
BRIEF_BODY = """    <div class="brief">
      <nav class="toc" aria-label="Contents">
        <h2>Contents</h2>
        <a class="sec" href="#first"><i>01</i>First section</a>
        <a class="sub" href="#first-part">A part of it</a>
        <a class="sec" href="#second"><i>02</i>Second section</a>
        <a class="sec" href="#third"><i>03</i>Third section</a>
        <a class="up" href="#top">Top</a>
      </nav>
      <div class="main">

    <section class="thesis">
      <div class="eyebrow steel">The one point</div>
      <p class="thesisline">The single most important thing this page exists to say, held on
        one serif line.</p>
      <p class="thesissub">A short supporting statement keeps the main point clear.</p>
    </section>

    <section id="first">
      <div class="keep">
      <div class="eyebrow steel">01 &middot; First section</div>
      <h2 class="sec-h">The part of the question this section answers</h2>
      <p class="sec-lead">One or two lines, then the figure. Every section answers part of the
        reader's question and leads with its figure or table.</p>
      <div class="legend">
        <span><svg viewBox="0 0 30 16" aria-hidden="true"><rect class="n-box" x="1" y="1" width="28" height="14" rx="3"/></svg>exists today</span>
        <span><svg viewBox="0 0 30 16" aria-hidden="true"><rect class="n-new" x="1" y="1" width="28" height="14" rx="3"/></svg>to be built</span>
      </div>
      <figure class="fig">
        <div class="diagram"><div class="figwrap">
          <svg viewBox="-10 0 780 120" role="img" aria-label="A part that exists hands something to a part that is to be built.">
            <defs><marker id="ah" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="9" markerHeight="9" orient="auto"><path class="a-head" d="M0 1 L10 5 L0 9 z"/></marker></defs>
            <rect class="n-box" x="0" y="20" width="230" height="80" rx="5"/>
            <text class="n-t" x="16" y="52">A part that exists</text>
            <text class="n-s" x="16" y="72">a name and one short line</text>
            <path class="a-line" d="M230 60 H530" marker-end="url(#ah)"/>
            <text class="a-lab" x="380" y="51" text-anchor="middle">what moves between them</text>
            <rect class="n-new" x="530" y="20" width="230" height="80" rx="5"/>
            <text class="n-t" x="546" y="52">A part to be built</text>
            <text class="n-s" x="546" y="72">dashed, as the legend says</text>
          </svg>
        </div></div>
        <figcaption class="cap">The caption states the one claim the figure makes.</figcaption>
      </figure>
      </div>

      <h3 class="sub-h" id="first-part">A part of it</h3>
      <div class="grid3">
        <div class="pt">
          <h3>First point</h3>
          <p>Give each block the form of its content: a count is a number, a set is a row of
            labels, a sequence is steps.</p>
        </div>
        <div class="pt">
          <h3>Second point</h3>
          <p>Tool and component names go in lowercase mono, like <span class="mono">estimatekit</span>,
            consistently.</p>
        </div>
        <div class="pt">
          <h3>Third point</h3>
          <p>A brief is as long as its question. A section that answers nothing is cut.</p>
        </div>
      </div>
    </section>

    <section id="second">
      <div class="eyebrow steel">02 &middot; Second section</div>
      <h2 class="sec-h">The next part of the question</h2>
      <p class="sec-lead">Add its figure or table here. Give the section an id and an entry in
        the contents; remove the entry when the section goes.</p>
    </section>

    <section id="third">
      <div class="eyebrow steel">03 &middot; Third section</div>
      <h2 class="sec-h">What is still open</h2>
      <p class="sec-lead">A brief put on the table of a discussion ends on what the reader is
        asked to answer or decide.</p>
    </section>

      </div>
    </div>
"""

# Marks the contents entry being read. Measured from the scroll position, so it
# behaves the same when a host frames the page. With script off, the entries are
# still links.
BRIEF_SCRIPT = """<script>(function(){var nav=document.querySelector('.toc');if(!nav)return;
var links=[].slice.call(nav.querySelectorAll('a.sec,a.sub'));
var targets=links.map(function(a){return document.getElementById(a.hash.slice(1))}).filter(Boolean);
var cur=null,busy=false;
function spy(){var act=null,i,d=document.documentElement;
for(i=0;i<targets.length;i++){if(targets[i].getBoundingClientRect().top<=130)act=targets[i]}
if(act&&window.innerHeight+window.scrollY>=d.scrollHeight-2)act=targets[targets.length-1];
var id=act?act.id:'';if(id===cur)return;cur=id;
var sec=act?(act.closest('section')||act).id:'';
links.forEach(function(a){var on=a.hash==='#'+id;a.classList.toggle('active',on);
a.classList.toggle('insec',a.classList.contains('sec')&&a.hash==='#'+sec);
if(on)a.setAttribute('aria-current','location');else a.removeAttribute('aria-current')});
var s=nav.querySelector('a.insec');
if(s&&nav.scrollWidth>nav.clientWidth)nav.scrollLeft=s.offsetLeft-16}
function tick(){if(busy)return;busy=true;requestAnimationFrame(function(){spy();busy=false})}
addEventListener('scroll',tick,{passive:true});addEventListener('resize',tick);spy()})();</script>
"""


def slugify(name: str) -> str:
    out: list[str] = []
    prev_dash = False
    for c in name.lower():
        if c.isalnum():
            out.append(c)
            prev_dash = False
        elif not prev_dash:
            out.append("-")
            prev_dash = True
    return "".join(out).strip("-")


def _ascii_safe(s: str) -> str:
    """Encode any non-ASCII character as a numeric HTML entity, so scaffold
    output stays pure ASCII (REF-Flyer.md section 7): a served page may have no
    declared charset, and a raw non-ASCII byte renders as mojibake."""
    return "".join(c if c.isascii() else f"&#{ord(c)};" for c in s)


def render(*, title: str, slug: str, eyebrow: str, brief: bool = False) -> str:
    """Return the self-contained flyer HTML for the given fields (pure ASCII): a
    sheet, or with `brief` the brief length."""
    out = FLYER_TMPL.format(
        title=_ascii_safe(title), slug=_ascii_safe(slug), eyebrow=_ascii_safe(eyebrow),
        kind="BRIEF" if brief else "FLYER",
        body=BRIEF_BODY if brief else SHEET_BODY,
        brief_css=BRIEF_CSS.lstrip("\n") if brief else "",
        brief_script=BRIEF_SCRIPT if brief else "",
    )
    if not out.isascii():
        raise ValueError(
            "flyer output is not pure ASCII; use HTML entities for non-ASCII glyphs "
            "(REF-Flyer.md section 7)"
        )
    return out


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--name", required=True, help="Flyer name (masthead name + <title>).")
    ap.add_argument("--out", type=Path, default=Path("."), help="Directory to write <slug>.html into.")
    ap.add_argument("--eyebrow", default="ORG · CONTEXT",
                    help="Masthead eyebrow label (uppercase mono).")
    ap.add_argument("--slug", default=None, help="Override the output filename stem.")
    ap.add_argument("--brief", action="store_true",
                    help="Scaffold the brief length: sections under contents that stay on screen.")
    ap.add_argument("--force", action="store_true", help="Overwrite an existing file.")
    args = ap.parse_args()

    title = args.name.strip()
    if not title:
        print("error: --name must not be empty", file=sys.stderr)
        return 2
    slug = (args.slug or slugify(title)).strip()
    if not slug:
        print("error: could not derive a slug; pass --slug", file=sys.stderr)
        return 2

    out_dir: Path = args.out
    if out_dir.exists() and not out_dir.is_dir():
        print(f"error: --out is not a directory: {out_dir}", file=sys.stderr)
        return 2
    out_dir.mkdir(parents=True, exist_ok=True)

    target = out_dir / f"{slug}.html"
    if target.exists() and not args.force:
        print(f"error: {target} already exists (pass --force to overwrite)", file=sys.stderr)
        return 2

    html = render(title=title, slug=slug, eyebrow=args.eyebrow.strip(), brief=args.brief)
    target.write_text(html, encoding="utf-8", newline="\n")

    print(f"Created {target}")
    print()
    print("Next steps:")
    print(f"  open {target}          # renders offline and as a claude.ai Artifact")
    if args.brief:
        print("  scroll                 # the contents stay on screen and mark the part being read")
        print("  print-preview          # no figure split across pages, no contents, colors intact")
        print("  narrow the viewport    # the contents become a bar; no sideways scroll")
        print("  then fill the masthead, thesis, and sections; keep the contents in step with them.")
    else:
        print("  print-preview          # one A4 sheet, colors intact")
        print("  narrow the viewport    # no sideways scroll")
        print("  then fill the masthead, thesis, and section (keep the token :root block).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
