---
name: bootstrap-workshop
description: "Scaffold a new typed working-session instrument per REF-Workshop: a single self-contained <session-name>.html carrying one session dataset of typed activities (frame, collect, walk, sort, assign, close) and the fixed renderer that gives each type its own full-screen working surface, records outcomes live on the surface (persisted locally, exported at the close), and gates the facilitator script behind the presentable room view. The author edits only the dataset. The session sibling of bootstrap-plan; the capture lands back in the plan."
galaxy: press
refs:
  - REF-Workshop
  - REF-Plan
---

# Bootstrap workshop

Invoked when the user wants to run a workshop or any live, timeboxed working session: a session that works items with a room and must produce recorded outcomes. This skill produces a *working*, self-contained `<session-name>.html` that opens on the room cover, walks typed activity surfaces the facilitator records decisions on, and exports the capture at the close. The author then replaces the example dataset; the renderer is fixed.

Reference pattern: `REF-Workshop.md` (the typed-activity architecture, the two audiences, live capture, the plan sync).

## Appearance

Read `THEMING.md` alongside the routed REF. Use the shipped template or complete selected slide theme for palette, artwork and typography. Material and decorative motion are authored choices; add no Glass/Solid or Motion controls to normal outputs. Verify Light/Dark, narrow layouts, print/export and reduced motion for the surfaces being changed.

## Pre-flight

1. **Read** `REF-Workshop.md` whole (it is short). The architecture is §2: activities are typed, and the type is a triple of contract, surface, and capture.
2. **Confirm the session name, date, and duration** with the user; the name becomes `<slug>.html` and the cover.
3. **Locate the plan.** When the session runs over a plan (`REF-Plan.md`), activity items cite the plan's ids and facts verbatim, so the capture lands without translation. A session with no plan behind it still runs; its capture then seeds one.
4. **Design the session as activities**, each of a type: what work each block does decides its kind, its outcome vocabulary (verdicts or buckets), and its timebox. Work that fits no type grows the type system (renderer and REF §2 together), never a one-off screen.

## What it produces

One file: `<slug>.html`, rendered from the `template.html` beside this SKILL.md, carrying:

```
<meta charset="utf-8"> + <title>
<link>  the font host (the one permitted external request), full fallback stacks
<style> the stage tokens (dark room), the script tokens (paper), the outcome
        trio (ok, mid, hot) with deep fills; per-type surface layouts
<div class="script"> + <div class="room"> + the capture overlay + <noscript>
<script type="application/json" id="session-data">   <- THE DATASET: the only
        block the author edits (meta + typed activities)
<script> the fixed renderer: the room (cover default, one surface per
        activity, arrows step items then activities, esc to cover, s for the
        script), live capture into local state, the generated read-back and
        export, and the internal facilitator script with recorded state inline
</script>
```

## Steps

1. **Run the scaffolder** (the `bootstrap.py` beside this SKILL.md):
   ```bash
   python bootstrap.py --out <path> --name "<Session Name>" [--eyebrow "<ORG . CONTEXT>"]
   ```
   Writes `<path>/<slug>.html`. Refuses to overwrite; a follow-up session is a new instrument, not an edit of the last one (`REF-Workshop.md` §4).
2. **Author the dataset** per `REF-Workshop.md` §3: activities of the right types with honest timeboxes that sum to the session; `meta.question` and every item in the room's language; the facilitator layer (goal, run, say, watch) under `script`; items citing the plan's ids and facts verbatim; verdicts and buckets named for the outcomes the session must produce.
3. **Touch nothing outside the dataset.** A missing surface type is a skill revision (template + REF §2 together), not a per-session hack.
4. **Verify** (`REF-Workshop.md` §9): the file opens on the cover with zero console errors; every surface is worked (type a slot, stamp a verdict, land an item, enter a name); the state survives a refresh; `s` opens the script and shows the recorded state; print yields the script.
5. **Run the session** from the stage, recording on the surface; **export the capture at the close** and land it in the plan as decision fields, status flips, and log rows. The workshop stands as run.

## Failure modes

- **Target `.html` already exists**: the scaffolder refuses; a follow-up session is a new file.
- **`template.html` missing beside the script**: the scaffolder refuses; reinstall the skill folder whole.
- **A sort queue or walk trail beyond about ten items**: the room cannot work it; split the activity.
- **Timeboxes that do not sum to `meta.duration`**: the rundown exposes it; fix the data before the room does.
- **State did not survive a refresh**: the browser context blocked local storage; run from the downloaded file or keep the one tab open, and export the capture before closing.
- **An em-dash in dataset strings**: the playbook intent tests (INT-SHAPE-002) fail on it; recast.

## See also

- `REF-Workshop.md`. The pattern this skill instantiates, including the type table this template implements.
- `bootstrap-plan`. The steering sibling: the system of record the session's items come from and its capture lands into.
