#!/usr/bin/env python3
"""Scaffold a new typed working-session instrument (REF-Workshop).

Writes one self-contained <slug>.html from the template.html beside this
script: the stage and script token system, the fixed typed-activity renderer
(frame, collect, walk, sort, assign, close surfaces; live capture persisted
locally; the generated read-back and export; the gated facilitator script),
and a small example session exercising every type. The author edits ONLY the
dataset (the <script type="application/json"> block). The file opens on the
room cover; the script is reached deliberately. Refuses to overwrite unless
--force.

Usage:
    python bootstrap.py --name "<Session Name>" [--out <dir>] \
        [--eyebrow "<ORG . CONTEXT>"] [--slug <stem>] [--force]
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

__all__ = ["main", "slugify", "render"]

TEMPLATE_PATH = Path(__file__).resolve().parent / "template.html"


def slugify(name: str) -> str:
    out: list[str] = []
    prev_dash = False
    for c in name.lower():
        if c.isalnum():
            out.append(c)
            prev_dash = False
        elif not prev_dash:
            out.append("-")
            prev_dash = True
    return "".join(out).strip("-")


def render(*, title: str, slug: str, eyebrow: str) -> str:
    """Return the self-contained workshop HTML for the given fields."""
    template = TEMPLATE_PATH.read_text(encoding="utf-8")
    return (
        template
        .replace("__TITLE__", title)
        .replace("__SLUG__", slug)
        .replace("__EYEBROW__", eyebrow)
    )


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--name", required=True, help="Session name (cover title + <title>).")
    ap.add_argument("--out", type=Path, default=Path("."), help="Directory to write <slug>.html into.")
    ap.add_argument("--eyebrow", default="ORG · CONTEXT",
                    help="Cover and script eyebrow label.")
    ap.add_argument("--slug", default=None, help="Override the output filename stem.")
    ap.add_argument("--force", action="store_true", help="Overwrite an existing file.")
    args = ap.parse_args()

    title = args.name.strip()
    if not title:
        print("error: --name must not be empty", file=sys.stderr)
        return 2
    slug = (args.slug or slugify(title)).strip()
    if not slug:
        print("error: could not derive a slug; pass --slug", file=sys.stderr)
        return 2

    if not TEMPLATE_PATH.is_file():
        print(f"error: template not found beside the script: {TEMPLATE_PATH}", file=sys.stderr)
        return 2

    out_dir: Path = args.out
    if out_dir.exists() and not out_dir.is_dir():
        print(f"error: --out is not a directory: {out_dir}", file=sys.stderr)
        return 2
    out_dir.mkdir(parents=True, exist_ok=True)

    target = out_dir / f"{slug}.html"
    if target.exists() and not args.force:
        print(f"error: {target} already exists (pass --force to overwrite)", file=sys.stderr)
        return 2

    target.write_text(render(title=title, slug=slug, eyebrow=args.eyebrow.strip()),
                      encoding="utf-8", newline="\n")

    print(f"Created {target}")
    print()
    print("Next steps:")
    print(f"  open {target}          # opens on the room cover; zero console errors")
    print("  edit the dataset       # the <script type=\"application/json\"> block ONLY")
    print("  work every surface     # type, stamp, land, name; state survives refresh")
    print("  press s                # the facilitator script, with recorded state inline")
    print("  print-preview          # always the script")
    return 0


if __name__ == "__main__":
    sys.exit(main())
