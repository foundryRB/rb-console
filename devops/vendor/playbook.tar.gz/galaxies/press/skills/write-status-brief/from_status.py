#!/usr/bin/env python3
"""Feed an executive brief from a status report.

The brief is a second read of the report's period: the verdict, the skies, and the calendar
are copied from the report, the lanes are folded into at most three by the fold the author
declares, and the one line of need is seeded from the asks due by the checkpoint. Two agents
feeding the same report with the same fold get the same brief. Only the lane notes and the
need sentence are seeded for the author.

Usage:
    python from_status.py --status <plan-id>-status-<end>.html
        [--lanes "a,b,c+d=Name"] [--audience "<readers>"] [--issued YYYY-MM-DD]
        [--out <dir>] [--force] [--dataset-only]

The fold (--lanes): a comma-separated list of brief lanes, each one or more of the report's
lane ids joined by "+", with an optional "=Name" naming the folded lane. At most three.
Required when the report carries more than three lanes; absent, a report with three lanes or
fewer keeps them all, in order.
"""
from __future__ import annotations
import argparse, datetime as dt, json, re, sys
from pathlib import Path

TEMPLATE = Path(__file__).resolve().parent / "templates" / "status-brief.html"
STATUS_DATA = re.compile(r'<script type="application/json" id="status-data">(.*?)</script>', re.S)
RANK = {"sunny": 0, "cloudy": 1, "stormy": 2}


def D(s: str) -> dt.date:
    return dt.date.fromisoformat(s)


def load_status(path: Path) -> dict:
    m = STATUS_DATA.search(path.read_text(encoding="utf-8"))
    if not m:
        raise SystemExit(f"error: no status-data block in {path}")
    return json.loads(m.group(1).replace("<\\/", "</"))


def parse_fold(spec: str | None, lanes: list[dict]) -> list[tuple[list[str], str | None]]:
    """The fold as [(source lane ids, name or None)], validated against the report's lanes."""
    known = [l["id"] for l in lanes]
    if not spec:
        if len(known) > 3:
            raise SystemExit(f"error: the report carries {len(known)} lanes ({', '.join(known)}); "
                             "declare the fold with --lanes, at most three")
        return [([i], None) for i in known]
    fold: list[tuple[list[str], str | None]] = []
    seen: set[str] = set()
    for entry in (e.strip() for e in spec.split(",") if e.strip()):
        name = None
        if "=" in entry:
            entry, name = (p.strip() for p in entry.split("=", 1))
        ids = [i.strip() for i in entry.split("+") if i.strip()]
        for i in ids:
            if i not in known:
                raise SystemExit(f"error: unknown lane {i!r}; the report's lanes are {', '.join(known)}")
            if i in seen:
                raise SystemExit(f"error: lane {i!r} is folded twice")
            seen.add(i)
        fold.append((ids, name or None))
    if len(fold) > 3:
        raise SystemExit(f"error: {len(fold)} brief lanes; the brief carries at most three")
    if not fold:
        raise SystemExit("error: --lanes names no lane")
    return fold


def fold_lanes(lanes: list[dict], fold: list[tuple[list[str], str | None]]) -> list[dict]:
    by_id = {l["id"]: l for l in lanes}
    rows = []
    for ids, name in fold:
        srcs = [by_id[i] for i in ids]
        sky = max((s.get("sky", "sunny") for s in srcs), key=lambda k: RANK.get(k, 1))
        decided: list[str] = []
        for s in srcs:
            decided += [i for i in s.get("decided_by", []) if i not in decided]
        notes = " ".join(s.get("note", "").strip() for s in srcs if s.get("note", "").strip())
        rows.append({"id": "-".join(ids), "name": name or srcs[0].get("name", ids[0]), "sky": sky,
                     "from": ids, "decided_by": decided,
                     "note": f"[Author: one sentence. Seed: {notes}]" if notes else "[Author: one sentence.]"})
    return rows


def derive(status: dict, fold: list[tuple[list[str], str | None]], *, audience: str,
           issued: dt.date, status_file: str) -> dict:
    src_meta = status.get("meta", {})
    meta = dict(src_meta)
    plan = dict(meta.get("plan", {}))
    if not status_file:
        plan["file"] = ""
    cp = status.get("checkpoint") or {}
    cutoff = cp.get("date") or (issued + dt.timedelta(days=7)).isoformat()

    # RULE need: the asks due on or before the checkpoint, each with its owner and date, as the seed;
    # the refs are their union so the ids still open the plan
    due = sorted((a for a in status.get("asks", []) if a.get("by") and a["by"] <= cutoff),
                 key=lambda a: (a["by"], a.get("owner", "")))
    refs: list[str] = []
    for a in due:
        refs += [r for r in a.get("refs", []) if r not in refs]
    seeds = "; ".join(f"{a.get('owner', '')}: {a.get('ask', '')} by {a['by']}" for a in due)
    need = {"text": (f"[Author: one sentence with named owners and absolute dates. Seeds: {seeds}]" if due
                     else "[Author: one sentence, or empty.]"),
            "refs": refs}

    title = plan.get("title", "the plan")
    source = {"id": src_meta.get("id", ""), "title": src_meta.get("title", ""),
              "issued": src_meta.get("issued", ""), "file": status_file}
    meta.update({
        "id": f"{src_meta.get('id', 'status')}-exec",
        "title": f"{title}: executive brief",
        "issued": issued.isoformat(),
        "audience": audience,
        "state": "draft",
        "plan": plan,
        "source": source,
    })
    return {
        "meta": meta,
        "outlook": dict(status.get("outlook", {})),
        "lanes": fold_lanes(status.get("lanes", []), fold),
        "need": need,
        "horizon": status.get("horizon"),
        "gates": status.get("gates", []),
        "milestones": status.get("milestones", []),
        "ledger": status.get("ledger"),
        "footer": (f"Read from {source['title']} issued {source['issued']}, over {title} {plan.get('version', '')}. "
                   "The report carries the detail; the small ids open the plan's rows."),
    }


def render(dataset: dict) -> str:
    tpl = TEMPLATE.read_text(encoding="utf-8")
    body = json.dumps(dataset, indent=2, ensure_ascii=False).replace("</", "<\\/")
    return tpl.replace("{{TITLE}}", dataset["meta"]["title"]).replace("{{DATASET_JSON}}", body)


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--status", required=True, type=Path)
    ap.add_argument("--lanes", help='the fold, e.g. "uc1,uc2,ground+model=Ground"')
    ap.add_argument("--audience", default=""); ap.add_argument("--issued")
    ap.add_argument("--out", type=Path); ap.add_argument("--dataset-only", action="store_true"); ap.add_argument("--force", action="store_true")
    a = ap.parse_args()
    if not a.status.is_file():
        print(f"error: status report not found: {a.status}", file=sys.stderr); return 2
    status = load_status(a.status)
    if status.get("meta", {}).get("state") != "issued":
        print("warning: the report is not issued; the brief inherits its seeds and issues after it", file=sys.stderr)
    fold = parse_fold(a.lanes, status.get("lanes", []))
    issued = D(a.issued) if a.issued else D(status["meta"]["issued"])
    out_dir = a.out or a.status.parent
    status_file = a.status.name if out_dir.resolve() == a.status.parent.resolve() else ""
    ds = derive(status, fold, audience=a.audience, issued=issued, status_file=status_file)
    if a.dataset_only:
        print(json.dumps(ds, indent=2, ensure_ascii=False)); return 0
    target = out_dir / f"{ds['meta']['id']}.html"
    if target.exists() and not a.force:
        print(f"error: {target} exists (pass --force to re-feed a draft)", file=sys.stderr); return 2
    target.write_text(render(ds), encoding="utf-8", newline="\n")
    print(f"Created {target}  ({ds['meta']['period']['label']}, issued {ds['meta']['issued']})")
    print("  outlook " + str(ds["outlook"].get("sky")) + " · lanes "
          + ", ".join(f"{l['name']} [{'+'.join(l['from'])}] {l['sky']}" for l in ds["lanes"])
          + f" · need seeded from {len(ds['need']['refs'])} refs")
    print("Author the judgment fields in the brief-data block, then set meta.state to \"issued\": lanes[].note and need.text.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
