---
name: write-status-brief
description: "Produce an executive brief per REF-StatusReport from an issued status report: feed the report's dataset through the deterministic from_status.py, which copies the verdict and the road ahead, folds the lanes into at most three by the fold the author declares, and seeds the one line of need from the asks due by the checkpoint, rendered by the fixed one-screen template; then author only the lane notes and the need sentence, verify, and issue. The executive sibling of write-status-report: the status report stays the record for the period, the brief is its ten-second read."
galaxy: press
refs:
  - REF-StatusReport
  - REF-Plan
---

# Write status brief

Invoked when an issued status report (`write-status-report`) owes its executive readers a ten-second read of the same period. Input: the status report file and the fold of its lanes. Output: one self-contained `<plan-id>-status-<end>-exec.html` beside the report, in `draft` until the author finishes the two judgment fields and flips it to `issued`.

## Appearance

Read `THEMING.md` alongside the routed REF. Use the shipped template or complete selected slide theme for palette, artwork and typography. Material and decorative motion are authored choices; add no Glass/Solid or Motion controls to normal outputs. Verify Light/Dark, narrow layouts, print/export and reduced motion for the surfaces being changed.

## Pre-flight

1. Read `REF-StatusReport.md` §11 whole; the brief's dataset, derivation rules, and projection are there, and §2 governs what may be typed at all.
2. Locate the status report and confirm it is issued, or at least finished: a brief fed from a report with bracketed seeds inherits them.
3. Decide the fold: which of the report's lanes the readers steer by, at most three, and which fold into one. The fold is a judgment; it is declared on the command line and recorded in each brief lane's `from`, never typed into the file.
4. Confirm who reads the brief when the report's audience is not the brief's, and the issue date when it is not the report's.

## Steps

1. **Feed the brief** (the `from_status.py` beside this SKILL.md; it reads `templates/status-brief.html`):
   ```bash
   python from_status.py --status <plan-id>-status-<end>.html --lanes "uc1,uc2,ground+model=Ground" --audience "<readers>"
   ```
   Writes `<plan-id>-status-<end>-exec.html` beside the report (or into `--out`), the verdict, the skies, and the calendar copied from the report, the lanes folded, and the two judgment fields seeded in brackets. Refuses to overwrite; `--force` re-feeds a draft after the report changes. `--dataset-only` prints the dataset for inspection. On Windows, run with `PYTHONUTF8=1` so the report's middots survive.
2. **Read the folded lanes against the report.** A folded lane's sky is the worst of its sources and its `decided_by` their union; when that reads wrong, the fix is the fold, or the report's own lane skies, and then a re-feed. The brief carries no sky of its own.
3. **Author the judgment fields** in the `brief-data` block, and only those:
   - `lanes[].note`: one sentence per lane, cut from the seed; the report carries the rest.
   - `need.text`: one sentence with absolute dates, cut from the seeded asks, naming an owner only where the reader must act on that owner; `need.refs` keeps the ids the sentence clears.
   Bracketed seeds still on the page mean the brief is unfinished.
4. **Verify** (`REF-StatusReport.md` §9 applies): open the file in both themes, zero console errors, click an id (the plan opens at its row), the footer opens the report, the road ahead matches the report's, print preview fits one page.
5. **Issue**: set `meta.state` to `"issued"`, after the report is. Deliver the file and say where the dataset sits.

## Failure modes

- **The report has no `status-data` block.** The file is not a REF-StatusReport instrument; the feed reads a status report, never a plan.
- **The feed refuses the fold.** More than three brief lanes, an unknown lane id, or a lane folded twice; the report's lane ids sit in its `lanes` collection.
- **The brief is not beside the report.** Ids render as text and the footer has no link; write the brief into the report's directory.
- **A verdict or a sky reads wrong.** The report is wrong, or the plan under it; fix the plan, re-feed the report, re-feed the brief. The brief is two steps downstream of the record.
- **A note runs past one sentence.** Cut it; the footer links the report for the detail.
- **The need line says "next week" or "the client".** Absolute dates, as the asks carry them.
- **The dataset fails to parse.** The page names the fault where the brief would be; it is nearly always a quote inside a string that needs escaping as `\"`, or a comma after the last item.
- **An em-dash appears anywhere.** Hard rule (INT-SHAPE-002): none, in the dataset or in the template.

## See also

- `REF-StatusReport.md` §11. The pattern this skill instantiates.
- `write-status-report`. The report this brief reads; a period without a status report has no brief.
- `write-mom`. The session sibling: a MoM digests one event, a status report one period, a brief the period's verdict.
