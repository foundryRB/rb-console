---
name: bootstrap-plan
description: "Scaffold a new data-driven project-plan instrument per REF-Plan: a single self-contained <plan-name>.html carrying one embedded dataset (items, gates, log) and the fixed renderer with one projection per content type (masthead band with stat tiles, milestone rail, month-gridded schedule chart with gate rows, checkpoint and today lines, one id-ordered dependency table with priority badges and sub-dependency indentation, one-line assumption statements, workstream and risk tables, gate ladder, day-grouped newest-first decision log, a ledger of effort and delay derived from the same dataset), rows closed to their name line, every id in prose linked to its row, lane, status, priority, and owner filters composing from one state, themed light and dark with machine-validated lane and status palettes. The author edits only the dataset. The steering sibling of bootstrap-workshop; sessions write their outcomes back into the plan and status reports project it per period."
galaxy: press
refs:
  - REF-Plan
  - REF-Workshop
---

# Bootstrap plan

Invoked when the user wants a project or engagement plan: the steering instrument and system of record for milestones, dependencies, assumptions, risks, and workstreams. This skill produces a *working*, self-contained `<plan-name>.html`: opening it renders the cockpit (stat strip, rail, schedule, tables, gates, log) from a small example dataset with no build step. The author then replaces the dataset; the renderer and frame are fixed and never edited per plan.

Reference pattern: `REF-Plan.md` (the model, the views, the identity, the runtime rules).

## Appearance

Read `THEMING.md` alongside the routed REF. Use the shipped template or complete selected slide theme for palette, artwork and typography. Material and decorative motion are authored choices; add no Glass/Solid or Motion controls to normal outputs. Verify Light/Dark, narrow layouts, print/export and reduced motion for the surfaces being changed.

## Pre-flight

1. **Read** `REF-Plan.md` whole (it is short). The one rule is §2: the dataset is the artifact, every pixel a projection.
2. **Confirm the plan name and title** with the user; the name becomes `<slug>.html` and the masthead.
3. **Confirm the output path.** One plan per engagement; versions of one plan live beside each other in a directory the engagement owns.
4. **Check the shape is right**: a one-glance page is a flyer, a pitch is a deck, a live session is a workshop, a period's read is a status report (`REF-Plan.md` §1). The plan is the record they all resolve against.
5. **Name the lanes.** As many as the engagement has, in the order they should read, an optional lane among them when optional work exists; the scaffold carries five validated lane hues.

## What it produces

One file: `<slug>.html`, self-contained, carrying:

```
<meta charset="utf-8"> + <title>
renderer/plan-page.html, the one page frame, filled:
<style> renderer/plan-renderer.css, inlined: five machine-validated lane hues,
        the reserved status trio, and the identity block the design hub stamps
        (light, guarded media dark, [data-theme] overrides, print); then the
        page's own ground, the identity's faces inlined as data URIs so the
        file makes no request, and the identity's stage
<div class="stage"> (the identity's ambient ground, behind everything)
<div id="plan-root"> + <noscript>
<script type="application/json" id="plan-data">   <- THE DATASET: the only
        block the author edits (meta, lanes, items, gates, log)
<script> renderer/plan-renderer.js, inlined: one projection per content type,
        masthead band
        with stat tiles, milestone rail, week-gridded schedule chart with gate
        and today lines, the one id-ordered dependency table (priority badges,
        sub-dependency indentation), one-line assumption statements, workstream
        and risk tables, the gate ladder with its closed count, the newest-first
        decision log; rows closed to their name line behind a caret; every id in
        prose, edges, refs, and the chart linked to its row; lane, status,
        priority, and owner filters cutting everything from one state;
        the ledger of effort and delay derived from the dataset; descoped and
        superseded rows hidden except under their pills; textContent only
```

## Steps

1. **Run the scaffolder** (the `bootstrap.py` beside this SKILL.md):
   ```bash
   python bootstrap.py --out <path> --name "<Plan Name>" [--eyebrow "<ORG . CONTEXT>"]
   ```
   Writes `<path>/<slug>.html`. Refuses to overwrite; a new version of an existing plan is a new file beside it (`REF-Plan.md` §8), so `--force` is only for discarding a scaffold that was never filled.
2. **Author the dataset**: replace the example `meta`, `lanes`, `items`, `gates`, and `log` with the real model per `REF-Plan.md` §3: stable ids, named owners, absolute dates, ISO dates only where real dates exist, edges via `parent` and `needs`, priorities on dependencies, the `critical` flag authored, decisions only in `decision` fields and the log. Keep `meta.focus` to two sentences of dates and facts. A window of work is a track; a delivery highlight is a log row. A miss is never a date edit: the gate keeps its day, the overdue item its need date, work the miss spawns or a decision adds names its `cause`, a moved milestone says in its `when` where it was, overtaken work is `superseded` with its window, and removed work is `descoped` with the window it had, while an exploration that never had one stays dateless; the ledger counts the gates' days and the tracks' windows, once each, released work as a negative.
3. **Touch nothing outside the dataset.** The renderer, tokens, and frame are the fixed skeleton. If a projection is missing something, that is a change to `renderer/` here, never a per-plan hack: `renderer/plan-renderer.{js,css}` is the one canonical source every consumer of a REF-Plan render reads, so a fix made here reaches all of them and a fix made anywhere else is a fork.
4. **Audit the dataset** with the `audit.py` beside this SKILL.md (`python audit.py <plan.html>`): every reference resolves, no live date falls on a weekend, nothing starts before what it needs is done, no gate still ahead falls due before its evidence (a gate past its day and open is a miss the ledger counts, not an ordering defect), every live milestone carries a date, every milestone and gate has a short name. A finding is a dataset edit, then a re-run; the audit exits non-zero until clean.
5. **Verify** (`REF-Plan.md` §9): open the file (every projection renders, zero console errors), click an id in prose (its row highlights and opens), toggle the descoped pill, flip the theme, narrow to phone width (only the chart's and the tables' own containers scroll), print-preview (A4 landscape, filter bar gone, rows unsplit).
5. **Surface to user**:
   - "Plan scaffolded at `<slug>.html`. Edit only the `plan-data` JSON block; the cockpit renders it. Re-publishing is a new version beside this file with the stamp bumped and the log carrying the diff; workshop outcomes land here as decision fields, status flips, and log rows; a status report for any period projects from this file (`write-status-report`)."
6. **Publish every later version** with the `publish.py` beside this SKILL.md, never by hand: edit the dataset (in the plan's own block, or in a JSON file passed as `--dataset`), then
   ```bash
   python publish.py --plan <current plan.html> --version v0.12 --log "<what changed and why>" --refs G1,M3
   ```
   It bumps the version and date, prepends the log row, re-renders the file from this skill's current template so every plan carries the one renderer, refuses to publish while the audit has findings, writes `<stem>-<version>.html` beside the old file and moves the old file into `_archive/`. A renderer change in this skill reaches an existing plan the same way: publish it again with a log row saying so.


## Failure modes

- **Target `.html` already exists**: the scaffolder refuses; a new version is a new file beside the old.
- **A lane id in an item does not match `lanes`**: the renderer falls back to the first lane color; fix the dataset, not the renderer.
- **More than five lanes**: the token system carries five validated lane hues; a sixth lane needs a sixth validated token added deliberately in all three theme blocks (run a palette validator; never eyeball) or a folding of lanes.
- **An id in prose does not link**: the link pattern derives from the dataset's ids, so the id is misspelled in the prose or the item does not exist; fix the dataset.
- **An em-dash in dataset strings**: the playbook intent tests (INT-SHAPE-002) fail on it; recast.
- **The page fetches anything**: it will break under the Artifact CSP; inline it or remove it.

## See also

- `REF-Plan.md`. The pattern this skill instantiates.
- `bootstrap-workshop`. The session sibling: consumes this plan's item ids, and its capture lands back in this plan's dataset.
- `write-status-report`. The period sibling: projects this plan's dataset into a one-page status report for a reporting window.
