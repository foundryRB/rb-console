#!/usr/bin/env python3
"""Audit a plan instrument's dataset (REF-Plan section 10): every reference resolves, no live date falls on a
weekend, no item starts before something it needs is done, no gate still ahead falls due before the evidence it closes on, every live
milestone carries a date. A gate past its day and still open is a miss: its evidence closes after it by definition,
the ledger counts the days, and the audit leaves it alone.

Usage:
    python audit.py <plan.html>

Exit code 0 when clean, 1 when any finding is printed. Reads the plan-data block and nothing else.
"""
from __future__ import annotations

import datetime as dt
import json
import re
import sys
from pathlib import Path

PLAN_DATA = re.compile(r'<script type="application/json" id="plan-data">(.*?)</script>', re.S)


def load(path: Path) -> dict:
    m = PLAN_DATA.search(path.read_text(encoding="utf-8"))
    if not m:
        raise SystemExit(f"error: no plan-data block in {path}")
    return json.loads(m.group(1))


def audit(plan: dict, today: str | None = None) -> list[str]:
    today = today or dt.date.today().isoformat()
    items = {i["id"]: i for i in plan.get("items", [])}
    gates = {g["id"]: g for g in plan.get("gates", [])}
    ids = set(items) | set(gates)
    live = [i for i in items.values() if i.get("status") not in ("descoped", "superseded")]
    findings: list[str] = []

    def day(x: str) -> str | None:
        if x in gates:
            g = gates[x]
            return g["closed"]["date"] if g.get("closed") else g.get("due")
        i = items[x]
        return i.get("due") or i.get("end")

    def start(x: str) -> str | None:
        i = items.get(x)
        return (i.get("start") if i else None) or day(x)

    # references resolve
    for i in items.values():
        for n in i.get("needs") or []:
            if n not in ids:
                findings.append(f"{i['id']} needs {n}, which does not exist")
        if i.get("parent") and i["parent"] not in ids:
            findings.append(f"{i['id']} names parent {i['parent']}, which does not exist")
        if i.get("cause") and i["cause"] not in ids:
            findings.append(f"{i['id']} names cause {i['cause']}, which does not exist")
        if i.get("status") == "superseded" and not (i.get("decision") or {}).get("date"):
            findings.append(f"{i['id']} is superseded but no decision dates the day it was overtaken")
    for g in gates.values():
        for r in g.get("refs") or []:
            if r not in ids:
                findings.append(f"{g['id']} references {r}, which does not exist")
    for r in plan.get("log", []):
        for x in r.get("refs") or []:
            if x != "PLAN" and x not in ids:
                findings.append(f"log row of {r.get('date')} references {x}, which does not exist")
    for lane in (i.get("lane") for i in live):
        if lane and lane not in {l["id"] for l in plan.get("lanes", [])}:
            findings.append(f"lane {lane} is not in lanes")

    # live dates land on working days
    for i in live:
        for k in ("due", "start", "end"):
            v = i.get(k)
            if v and dt.date.fromisoformat(v).weekday() >= 5:
                findings.append(f"{i['id']} {k} {v} is a {dt.date.fromisoformat(v).strftime('%A')}")
    for g in gates.values():
        v = g.get("due")
        if v and not g.get("closed") and dt.date.fromisoformat(v).weekday() >= 5:
            findings.append(f"{g['id']} due {v} is a {dt.date.fromisoformat(v).strftime('%A')}")

    # order: nothing starts before what it needs is done; a gate falls due no earlier than its evidence
    for i in live:
        for n in i.get("needs") or []:
            if n in items and items[n].get("status") in ("descoped", "superseded"):
                continue
            a, b = start(i["id"]), day(n) if n in ids else None
            if a and b and a < b:
                findings.append(f"{i['id']} starts {a} but needs {n}, which closes {b}")
    for g in gates.values():
        if not g.get("closed") and g.get("due") and g["due"] < today:
            continue  # a missed gate: its evidence runs late by definition, and the ledger counts it
        for r in g.get("refs") or []:
            if r in items and items[r].get("status") in ("descoped", "superseded"):
                continue
            a, b = day(g["id"]), day(r) if r in ids else None
            if a and b and b > a:
                findings.append(f"{g['id']} falls due {a} but its evidence {r} closes {b}")

    # a milestone is a date closed on evidence; without a date it has no place on the rail or the chart
    for i in live:
        if i.get("type") == "milestone" and not (i.get("due") or (i.get("start") and i.get("end"))):
            findings.append(f"{i['id']} is a milestone without a date")

    # a milestone or gate without a short name cannot be labelled on a calendar
    for i in live:
        if i.get("type") == "milestone" and not i.get("short"):
            findings.append(f"{i['id']} has no short name")
    for g in gates.values():
        if not g.get("short"):
            findings.append(f"{g['id']} has no short name")
    return findings


def main() -> int:
    if len(sys.argv) != 2:
        print(__doc__)
        return 2
    path = Path(sys.argv[1])
    if not path.is_file():
        print(f"error: plan not found: {path}", file=sys.stderr)
        return 2
    findings = audit(load(path))
    if findings:
        print(f"{len(findings)} finding(s) in {path.name}:")
        for f in findings:
            print("  " + f)
        return 1
    print(f"{path.name}: clean (references resolve, working days, order holds, milestones dated, short names present)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
