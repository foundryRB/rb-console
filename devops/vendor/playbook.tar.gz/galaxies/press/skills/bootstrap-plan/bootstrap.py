#!/usr/bin/env python3
"""Scaffold a new data-driven project-plan instrument (REF-Plan).

Writes one self-contained <slug>.html: the canonical renderer (renderer/
plan-renderer.js and its stylesheet, whose palette block carries the
identity's own faces inlined, so the file makes no request), a starter
dataset, and nothing else. The author edits ONLY the
dataset (the <script type="application/json"> block); the renderer is the
fixed skeleton, shared with every other consumer of renderer/ rather than
reimplemented here.

Usage:
    python bootstrap.py --name "<Plan Name>" [--out <dir>] \
        [--eyebrow "<ORG . CONTEXT>"] [--slug <stem>] [--force]
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from html import escape
from pathlib import Path

__all__ = ["main", "slugify", "render", "render_dataset", "EXAMPLE_DATASET"]

RENDERER_DIR = Path(__file__).resolve().parent / "renderer"

# ---------------------------------------------------------------------------
# The starter dataset. This is the only part an author edits, and the only
# part this file owns: every plan the skill emits carries the same renderer.
# Keep it em-dash free (INT-SHAPE-002).
# ---------------------------------------------------------------------------

EXAMPLE_DATASET = r"""{
  "meta": {
    "id": "__SLUG__",
    "title": "__TITLE__",
    "eyebrow": "__EYEBROW__",
    "version": "v0.1 draft",
    "date": "2030-01-01",
    "classification": "Internal",
    "focus": "2030-01-01 to 2030-03-31. M2 gate on 2030-01-21; DEP-001 blocked, due 2030-01-15.",
    "lede": "One sentence saying what this plan tracks and between whom. Replace it, then author the dataset below; the renderer and frame are fixed.",
    "anchor": "2030-01-01",
    "horizon": ["2030-01-01", "2030-03-31"],
    "sources": ["name the sources this dataset was seeded from"]
  },
  "lanes": [
    {"id": "shared", "name": "Shared · joint steering"},
    {"id": "delivery", "name": "Delivery · the delivering side"},
    {"id": "customer", "name": "Customer · the receiving side"},
    {"id": "optional", "name": "Optional · runs without"}
  ],
  "items": [
    {"id":"ASM-01","type":"assumption","name":"An assumption the calendar stands on","body":"State the assumption as fact. It holds until recorded otherwise.","note":"A recorded blocker with an owner and a due date, and the dates re-anchor.","owner":"Joint steering","lane":"shared","status":"ok","when":"stamped 2030-01-05"},
    {"id":"ASM-02","type":"assumption","name":"A second assumption, still to validate","body":"The statement, one to three lines.","note":"What re-dates if it does not hold, and which milestone moves with it.","owner":"Joint steering","lane":"shared","status":"wait","when":"validate at kickoff"},
    {"id":"DEP-001","type":"dependency","name":"A tracked dependency, blocked","body":"One to three lines saying exactly what is needed. Ids in prose link to their rows: M1 waits on this.","note":"The one free slot: what this item means in practice.","owner":"A named role","lane":"customer","priority":"blocker","status":"block","when":"by 2030-01-15","due":"2030-01-15","critical":true},
    {"id":"DEP-001a","type":"dependency","name":"A sub-dependency","body":"Indented under its parent in the table; the parent field carries the edge.","owner":"A named role","lane":"customer","priority":"high","status":"wait","when":"by 2030-02-01","due":"2030-02-01","parent":"DEP-001"},
    {"id":"DEP-002","type":"dependency","name":"A tracked dependency, decided","body":"The same row shape with its outcome recorded in the decision field.","owner":"A named role","lane":"delivery","priority":"high","status":"ok","when":"granted 2030-01-10","due":"2030-01-10","decision":{"date":"2030-01-10","who":"A named person","text":"The decision, written as a decision: who grants what, by when."}},
    {"id":"DEP-003","type":"dependency","name":"An optional dependency","body":"The work runs without it; the optional lane and the optional priority both say so.","owner":"A named role","lane":"optional","priority":"optional","status":"wait","when":"when available"},
    {"id":"DEP-004","type":"dependency","name":"A descoped dependency","body":"Keeps its id and its row; hidden by every filter state except the descoped pill.","owner":"A named role","lane":"delivery","priority":"medium","status":"descoped","when":"descoped 2030-01-10","decision":{"date":"2030-01-10","who":"A named person","text":"Out of scope for this plan; the log row cites this id."}},
    {"id":"M1","type":"milestone","name":"A milestone","short":"First milestone","body":"What closes it: evidence, never a date alone.","owner":"Joint steering","lane":"shared","status":"wait","when":"2030-02-15","due":"2030-02-15","needs":["DEP-001"]},
    {"id":"M2","type":"milestone","name":"A critical milestone","short":"Critical","body":"Critical-path milestones render outlined on the schedule and the rail; gates draw the dashed lines.","owner":"Joint steering","lane":"shared","status":"block","when":"2030-01-21","due":"2030-01-21","critical":true},
    {"id":"M3","type":"milestone","name":"The closing milestone","short":"Handover","body":"What the engagement hands over, and who accepts it.","owner":"A named person","lane":"customer","status":"wait","when":"2030-03-20","due":"2030-03-20","needs":["TRK-02"]},
    {"id":"TRK-01","type":"track","name":"A workstream","body":"What this track does, the dependencies it consumes, and the milestone or gate it closes.","owner":"A named role","lane":"delivery","status":"wait","when":"Jan 15 - Feb 15","start":"2030-01-15","end":"2030-02-15","needs":["DEP-001"]},
    {"id":"TRK-02","type":"track","name":"A second workstream","body":"Tracks render as bars on the schedule, in their lane's color. A window of work is always a track.","owner":"A named role","lane":"customer","status":"wait","when":"Feb 18 - Mar 15","start":"2030-02-18","end":"2030-03-15","needs":["M1"]},
    {"id":"TRK-03","type":"track","name":"An optional workstream","body":"Runs if DEP-003 lands; the plan closes without it.","owner":"A named role","lane":"optional","status":"wait","when":"Feb 15 - Mar 08","start":"2030-02-15","end":"2030-03-08","needs":["DEP-003"]},
    {"id":"RSK-01","type":"risk","name":"A risk that realistically bites","body":"State the risk plainly.","note":"The mitigation: what is already scheduled against it, and where.","owner":"A named role","lane":"shared","status":"wait","when":"open"}
  ],
  "gates": [
    {"id":"G1","name":"Plan approved","short":"Plan approved","evidence":"The assumptions stamped and the calendar accepted by both sides.","closer":"Joint steering","refs":["ASM-01","ASM-02"],"closed":{"date":"2030-01-05","who":"Joint steering","where":"kickoff"}},
    {"id":"G2","name":"Access granted","short":"Access granted","evidence":"What closes it: evidence, never a date.","closer":"Who closes it","refs":["DEP-001","M2"]},
    {"id":"G3","name":"Acceptance","short":"Acceptance","evidence":"The closing milestone accepted on the live result.","closer":"A named person","refs":["M3"]}
  ],
  "log": [
    {"date":"2030-01-01","refs":["PLAN"],"text":"Plan v0.1 scaffolded. The log is append-only and renders newest first: a reversed decision is a new row citing the old.","who":"The author"},
    {"date":"2030-01-05","refs":["G1","ASM-01"],"text":"G1 closed at kickoff; ASM-01 stamped.","who":"Joint steering"},
    {"date":"2030-01-10","refs":["DEP-002","DEP-004"],"text":"DEP-002 granted. DEP-004 descoped: the work runs without it. A delivery highlight is a row like this one, never a new item type.","who":"A named person"}
  ]
}"""


def _renderer_js() -> str:
    return (RENDERER_DIR / "plan-renderer.js").read_text(encoding="utf-8")


def _renderer_css() -> str:
    """The canonical stylesheet, as it is: its palette block already carries the
    identity's own faces inlined, so the file it lands in issues no request."""
    return (RENDERER_DIR / "plan-renderer.css").read_text(encoding="utf-8")


def slugify(name: str) -> str:
    s = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")
    return s or "plan"


def render_dataset(dataset: dict) -> str:
    """One self-contained plan file: the renderer's page frame, filled with the dataset, the
    renderer, and the identity's faces and stage that the frame and the sheet already carry."""
    meta = dataset.get("meta", {})
    name = meta.get("title", meta.get("id", "Untitled plan"))
    version = meta.get("version", "")
    title = escape(f"{name} . {version}" if version else name)
    body = json.dumps(dataset, indent=2, ensure_ascii=False).replace("</", "<\\/")
    page = (RENDERER_DIR / "plan-page.html").read_text(encoding="utf-8")
    # The dataset goes in last, so nothing an author writes is ever read as a slot.
    return (page.replace("__TITLE__", title)
                .replace("/*__RENDERER_CSS__*/", _renderer_css())
                .replace("/*__RENDERER_JS__*/", _renderer_js())
                .replace("__DATASET__", body))


def render(*, title: str, slug: str, eyebrow: str) -> str:
    raw = (EXAMPLE_DATASET
           .replace("__TITLE__", title)
           .replace("__SLUG__", slug)
           .replace("__EYEBROW__", eyebrow))
    return render_dataset(json.loads(raw))


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--name", required=True, help="The plan's title.")
    ap.add_argument("--out", type=Path, default=Path("."), help="Where the file is written.")
    ap.add_argument("--eyebrow", default="ORG . CONTEXT", help="The line above the title.")
    ap.add_argument("--slug", default=None, help="The file stem and the plan id (default: from the name).")
    ap.add_argument("--force", action="store_true", help="Overwrite an existing file.")
    a = ap.parse_args()

    slug = a.slug or slugify(a.name)
    target = a.out / f"{slug}.html"
    if target.exists() and not a.force:
        print(f"error: {target} exists; pass --force to overwrite", file=sys.stderr)
        return 2
    a.out.mkdir(parents=True, exist_ok=True)
    target.write_text(render(title=a.name, slug=slug, eyebrow=a.eyebrow), encoding="utf-8", newline="\n")
    print(f"wrote {target}")
    print("Edit the plan-data block only; then: python audit.py " + str(target))
    return 0


if __name__ == "__main__":
    sys.exit(main())
