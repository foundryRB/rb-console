#!/usr/bin/env python3
"""Publish the next version of a plan instrument (REF-Plan section 8).

The author edits the dataset in the current plan file (the plan-data block) or hands in a JSON file with the
edited dataset. This step does the mechanical rest: bumps meta.version and meta.date, prepends the log row,
re-renders the file from this skill's current template so every plan carries the one renderer, refuses to
publish while the audit has findings, writes <id>-<version>.html beside the old file and moves the old file
into the archive directory.

Usage:
    python publish.py --plan <current plan.html> --version v0.12 --log "<what changed, in the log's voice>"
        [--refs G1,M3,DEP-002] [--who "<name>"] [--date YYYY-MM-DD] [--dataset <edited.json>]
        [--archive <dir, default: _archive beside the plan>] [--keep]
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import re
import shutil
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import audit as audit_mod  # noqa: E402
import bootstrap  # noqa: E402

PLAN_DATA = re.compile(r'(<script type="application/json" id="plan-data">)(.*?)(</script>)', re.S)


def load(path: Path) -> dict:
    m = PLAN_DATA.search(path.read_text(encoding="utf-8"))
    if not m:
        raise SystemExit(f"error: no plan-data block in {path}")
    return json.loads(m.group(2))


def render(dataset: dict) -> str:
    # The dataset is the only thing a publish carries forward: the renderer
    # comes from the skill's canonical renderer/ every time, which is how a
    # republished plan picks up a renderer fix without being re-scaffolded.
    return bootstrap.render_dataset(dataset)


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--plan", required=True, type=Path, help="The current plan file.")
    ap.add_argument("--version", required=True, help="The new version stamp, e.g. v0.12.")
    ap.add_argument("--log", required=True, help="The log row's text: what changed and why, ids in prose.")
    ap.add_argument("--refs", default="", help="Comma-separated ids the row touches; PLAN is added when the row is about the instrument.")
    ap.add_argument("--who", default="", help="Who publishes; defaults to the previous log row's author.")
    ap.add_argument("--date", default=None, help="ISO date of the publish; default today.")
    ap.add_argument("--dataset", type=Path, default=None, help="A JSON file holding the edited dataset (default: the plan's own block).")
    ap.add_argument("--archive", type=Path, default=None, help="Where the previous file goes (default: _archive beside the plan).")
    ap.add_argument("--keep", action="store_true", help="Leave the previous file in place instead of archiving it.")
    a = ap.parse_args()

    if not a.plan.is_file():
        print(f"error: plan not found: {a.plan}", file=sys.stderr); return 2
    d = json.loads(a.dataset.read_text(encoding="utf-8")) if a.dataset else load(a.plan)
    meta = d.setdefault("meta", {})
    if meta.get("version") == a.version:
        print(f"error: the plan is already {a.version}; bump the version", file=sys.stderr); return 2
    date = a.date or dt.date.today().isoformat()
    who = a.who or (d.get("log") or [{}])[0].get("who", "") or "The author"
    refs = [r.strip() for r in a.refs.split(",") if r.strip()]
    if "PLAN" not in refs and (not refs or a.log.lstrip().startswith(a.version)):
        refs = ["PLAN"] + refs   # a row about the instrument itself names PLAN, as REF-Plan section 3 asks
    meta["version"], meta["date"] = a.version, date
    d.setdefault("log", []).insert(0, {"date": date, "who": who, "refs": refs, "text": a.log})

    findings = audit_mod.audit(d)
    if findings:
        print(f"refused: {len(findings)} audit finding(s); fix the dataset, then publish again")
        for f in findings:
            print("  " + f)
        return 1
    if chr(0x2014) in json.dumps(d, ensure_ascii=False):
        print("refused: an em-dash is in the dataset (INT-SHAPE-002)"); return 1

    stem = re.sub(r"-v\d+\.\d+.*$", "", a.plan.stem) or meta.get("id", "plan")
    target = a.plan.parent / f"{stem}-{a.version}.html"
    if target.exists():
        print(f"error: {target} already exists", file=sys.stderr); return 2
    target.write_text(render(d), encoding="utf-8", newline="\n")
    if not a.keep and a.plan.resolve() != target.resolve():
        arch = a.archive or (a.plan.parent / "_archive")
        arch.mkdir(parents=True, exist_ok=True)
        shutil.move(str(a.plan), str(arch / a.plan.name))
        print(f"published {target.name}; {a.plan.name} archived to {arch.name}/")
    else:
        print(f"published {target.name}")
    print("audit: clean")
    return 0


if __name__ == "__main__":
    sys.exit(main())
