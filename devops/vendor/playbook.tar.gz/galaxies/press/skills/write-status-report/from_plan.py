#!/usr/bin/env python3
"""Feed a status report from a plan instrument.

Every factual collection is derived from the plan dataset by one stated rule, so two agents
feeding the same plan for the same window get the same report. Only the judgment fields
(outlook headline, summary, lane notes, asks) are seeded for the author. The plan's ledger comes across
as the plan's renderer derives it on the issue date, folded by kind.

Usage:
    python from_plan.py --plan <plan.html> --week 2026-W36 [--issued YYYY-MM-DD]
        [--author "<name>"] [--audience "<readers>"] [--out <dir>] [--force] [--dataset-only]
"""
from __future__ import annotations
import argparse, calendar, datetime as dt, json, re, sys
from pathlib import Path

TEMPLATE = Path(__file__).resolve().parent / "templates" / "status-report.html"
PLAN_DATA = re.compile(r'<script type="application/json" id="plan-data">(.*?)</script>', re.S)
OPEN = ("wait", "block")


def D(s: str) -> dt.date:
    return dt.date.fromisoformat(s)


def load_plan(path: Path) -> dict:
    m = PLAN_DATA.search(path.read_text(encoding="utf-8"))
    if not m:
        raise SystemExit(f"error: no plan-data block in {path}")
    return json.loads(m.group(1))


def window(args) -> tuple[dt.date, dt.date, str]:
    if args.week:
        m = re.fullmatch(r"(\d{4})-W(\d{1,2})", args.week)
        if not m:
            raise SystemExit("error: --week takes YYYY-Www")
        s = dt.date.fromisocalendar(int(m.group(1)), int(m.group(2)), 1)
        return s, s + dt.timedelta(days=6), "weekly"
    if args.month:
        y, mo = (int(v) for v in args.month.split("-"))
        return dt.date(y, mo, 1), dt.date(y, mo, calendar.monthrange(y, mo)[1]), "monthly"
    if args.from_ and args.to:
        return D(args.from_), D(args.to), "custom"
    raise SystemExit("error: pass --week, --month, or --from and --to")


def label(s: dt.date, e: dt.date, kind: str, week_no: int | None = None) -> str:
    """The window's human form; a weekly window is numbered by the plan's week when one is given, else ISO.
    A one-day window (a daily) is the day itself, never a span of one."""
    if s == e:
        span = f"{s.day} {s.strftime('%B')} {s.year}"
    elif s.month == e.month:
        span = f"{s.day} to {e.day} {e.strftime('%B')} {e.year}"
    else:
        span = f"{s.day} {s.strftime('%B')} to {e.day} {e.strftime('%B')} {e.year}"
    if kind != "weekly":
        return span
    return f"Week {week_no if week_no else s.isocalendar()[1]} · {span}"


def worst(skies):
    rank = {"sunny": 0, "cloudy": 1, "stormy": 2}
    return max(skies, key=lambda s: rank[s]) if skies else "sunny"


def wdays(a: dt.date, b: dt.date) -> int:
    """Working days after a, up to and including b."""
    n, x = 0, a
    while x < b:
        x += dt.timedelta(days=1)
        if x.weekday() < 5:
            n += 1
    return n


def wspan(a: dt.date, b: dt.date) -> int:
    """Working days from a to b, both included."""
    return (1 if a.weekday() < 5 else 0) + wdays(a, b)


def ledger(plan: dict, today: dt.date) -> dict:
    """The plan's ledger on one day, as its renderer derives it (REF-Plan section 4), folded by kind."""
    items, gates = plan.get("items", []), plan.get("gates", [])
    gate_ids = {g["id"] for g in gates}
    rows = []
    for i in items:
        win = bool(i.get("start") and i.get("end"))
        if i.get("status") == "superseded":
            if win: rows.append(("superseded", "tracks", i["id"], wspan(D(i["start"]), D(i["end"])), i["start"], i["end"]))
            continue
        if i.get("status") == "descoped":
            if win: rows.append(("descoped", "tracks", i["id"], -wspan(D(i["start"]), D(i["end"])), i["start"], i["end"]))
            continue
        if i.get("cause") and win:
            kind = ("spawned by " if i["cause"] in gate_ids else "added by ") + i["cause"]
            rows.append((kind, "tracks", i["id"], wspan(D(i["start"]), D(i["end"])), i["start"], i["end"]))
    for g in gates:
        if not g.get("due"):
            continue
        if g.get("closed"):
            if g["closed"]["date"] > g["due"]:
                rows.append(("gate missed", "gates", g["id"], wdays(D(g["due"]), D(g["closed"]["date"])), g["due"], g["closed"]["date"]))
        elif D(g["due"]) < today:
            rows.append(("gate missed", "gates", g["id"], wdays(D(g["due"]), today), g["due"], today.isoformat()))
    folded: dict[str, dict] = {}
    for kind, unit, iid, days, a, b in sorted(rows, key=lambda r: (r[4], r[2])):
        f = folded.setdefault(kind, {"kind": kind, "unit": unit, "count": 0, "days": 0, "from": a, "to": b, "ids": []})
        f["count"] += 1; f["days"] += days; f["ids"].append(iid)
        f["from"], f["to"] = min(f["from"], a), max(f["to"], b)
    out = sorted(folded.values(), key=lambda f: f["from"])
    return {"total": sum(f["days"] for f in out), "rows": out}


def derive(plan: dict, start: dt.date, end: dt.date, kind: str, issued: dt.date, *,
           author: str, audience: str, plan_file: str) -> dict:
    meta = plan.get("meta", {})
    items = plan.get("items", [])
    live = [i for i in items if i.get("status") not in ("descoped", "superseded")]
    gates = plan.get("gates", [])
    lanes = plan.get("lanes", [])
    log = plan.get("log", [])
    by_id = {i["id"]: i for i in items}

    # the work-order calendar: anchor and horizon come from the plan
    anchor = D(meta["anchor"]) if meta.get("anchor") else start
    hz_end = D(meta["horizon"][1]) if meta.get("horizon") else end
    week_no = (start - anchor).days // 7 + 1
    weeks_total = -(-((hz_end - anchor).days + 1) // 7)
    plan_week = kind == "weekly" and bool(meta.get("anchor")) and 1 <= week_no <= weeks_total
    ordinal = f"{week_no}/{weeks_total}" if plan_week else ""

    def gate_day(g): return g["closed"]["date"] if g.get("closed") else g.get("due")

    # RULE horizon: every gate and every milestone not descoped, grouped by date; a milestone sits in
    # its own lane, a gate in the lane of the first reference that has one; plus every live workstream
    
    def gate_lane(g):
        for r in g.get("refs", []):
            it = by_id.get(r)
            if it and it.get("lane"):
                return it["lane"]
        return ""
    # a superseded milestone stays on the calendar struck through, so work that was done and then
    # overtaken remains visible; a descoped one, never started, is not on it
    pts: dict[str, list] = {}
    for g in gates:
        if gate_day(g):
            pts.setdefault(gate_day(g), []).append({"kind": "gate", "id": g["id"], "lane": gate_lane(g),
                "status": "done" if g.get("closed") else "open", "critical": False})
    for m in items:
        if m.get("type") == "milestone" and m.get("due") and m.get("status") != "descoped":
            pts.setdefault(m["due"], []).append({"kind": "milestone", "id": m["id"], "lane": m.get("lane", ""),
                "status": {"ok": "done", "wait": "open", "block": "blocked", "superseded": "superseded"}.get(m["status"], "open"),
                "critical": bool(m.get("critical")) and m["status"] != "superseded"})
    # RULE label: a date's label is the short names of its marks, one line each
    def short_of(i): return (by_id.get(i) or {}).get("short") or next((g.get("short") or g["name"] for g in gates if g["id"] == i), i)
    def label_for(marks): return [short_of(m["id"]) for m in marks]
    horizon = {"start": anchor.isoformat(), "end": hz_end.isoformat(), "today": issued.isoformat(),
               "window": {"start": start.isoformat(), "end": end.isoformat()},
               "points": [{"date": d, "marks": pts[d], "label": label_for(pts[d])} for d in sorted(pts)]}

    # RULE gates: all of them, in date order; RULE milestones: all live ones, in due order
    gate_rows = [{"id": g["id"], "name": g.get("name", ""), "short": g.get("short", g.get("name", "")), "closer": g.get("closer", ""),
                  "due": g.get("due"), "closed": (g.get("closed") or {}).get("date")}
                 for g in sorted(gates, key=lambda g: gate_day(g) or "9999")]
    ms_rows = [{"id": m["id"], "name": m.get("name", ""), "short": m.get("short", m.get("name", "")), "owner": m.get("owner", ""), "due": m["due"],
                "status": m["status"], "critical": bool(m.get("critical")),
                "superseded": ((m.get("decision") or {}).get("date") if m["status"] == "superseded" else None)}
               for m in sorted((i for i in items if i.get("type") == "milestone" and i.get("due") and i.get("status") != "descoped"),
                               key=lambda i: i["due"])]

    # RULE checkpoint: the next gate day, the first date on or after `issued` on which an open gate falls
    # due. Everything open that is due that same day rides with it.
    open_gate_days = sorted(g["due"] for g in gates if not g.get("closed") and g.get("due") and D(g["due"]) >= issued)
    checkpoint = None
    if open_gate_days:
        cd = open_gate_days[0]
        due_that_day = [i for i in live if i.get("due") == cd and i.get("status") in OPEN]
        checkpoint = {
            "date": cd,
            "name": "",
            "gates": [{"id": g["id"], "name": g["name"], "closer": g.get("closer", "")}
                      for g in gates if not g.get("closed") and g.get("due") == cd],
            "items": [{"id": i["id"], "type": i.get("type"), "name": i.get("name", ""),
                       "owner": i.get("owner", ""), "status": i["status"],
                       "priority": i.get("priority"), "critical": bool(i.get("critical")), "lane": i.get("lane")}
                      for i in sorted(due_that_day, key=lambda i: ({"milestone": 0, "dependency": 1, "assumption": 2, "track": 3, "risk": 4}.get(i.get("type"), 9), i["id"]))],
        }

    ns, ne = issued + dt.timedelta(days=1), issued + dt.timedelta(days=7)

    # RULE decided: items whose decision.date falls in the window, gates closed in the window,
    # and items flipped to ok whose `when` names a date in the window
    decided = []
    for g in gates:
        if g.get("closed") and start <= D(g["closed"]["date"]) <= end:
            decided.append({"date": g["closed"]["date"], "id": g["id"], "name": g["name"],
                            "text": f"Gate closed by {g['closed'].get('who', g.get('closer', ''))}.", "kind": "gate"})
    for i in live:
        dec = i.get("decision")
        if dec and dec.get("date") and start <= D(dec["date"]) <= end:
            decided.append({"date": dec["date"], "id": i["id"], "name": i.get("name", ""),
                            "text": dec.get("text", ""), "kind": "decision", "who": dec.get("who", "")})
    decided.sort(key=lambda r: (r["date"], r["id"]), reverse=True)
    log_in = [r for r in log if r.get("date") and start <= D(r["date"]) <= end]

    # RULE blockers: items in block, plus open dependencies past due on the issue date
    blockers = []
    for i in live:
        blocked = i.get("status") == "block"
        overdue = (i.get("type") == "dependency" and i.get("status") == "wait" and i.get("due") and D(i["due"]) < issued)
        if blocked or overdue:
            blockers.append({"id": i["id"], "name": i.get("name", ""), "owner": i.get("owner", ""),
                             "lane": i.get("lane", ""), "priority": i.get("priority"), "due": i.get("due"),
                             "status": "blocked" if blocked else "overdue", "critical": bool(i.get("critical"))})
    blockers.sort(key=lambda b: (0 if b["status"] == "blocked" else 1, b["due"] or "9999", b["id"]))

    # RULE lane sky (seed): stormy when the lane holds a blocked critical item, a blocked blocker-priority
    # dependency, or an open critical item due on or before the checkpoint; cloudy when it holds any
    # blocked or overdue item, or a blocker-priority dependency due in the next seven days; sunny otherwise
    cp_day = D(checkpoint["date"]) if checkpoint else None
    lane_rows = []
    for l in lanes:
        mine = [i for i in live if i.get("lane") == l["id"]]
        storm, cloud = [], []
        for i in mine:
            st = i.get("status")
            if st == "block" and (i.get("critical") or i.get("priority") == "blocker"): storm.append(i["id"])
            elif i.get("critical") and st in OPEN and i.get("due") and cp_day and D(i["due"]) <= cp_day: storm.append(i["id"])
            elif st == "block": cloud.append(i["id"])
            elif i.get("type") == "dependency" and st == "wait" and i.get("due") and D(i["due"]) < issued: cloud.append(i["id"])
            elif i.get("type") == "dependency" and i.get("priority") == "blocker" and st == "wait" and i.get("due") and ns <= D(i["due"]) <= ne: cloud.append(i["id"])
        sky = "stormy" if storm else ("cloudy" if cloud else "sunny")
        seed = ("Decided by " + ", ".join(storm or cloud) + ".") if (storm or cloud) else "No open blocker in this lane."
        lane_rows.append({"id": l["id"], "name": l.get("name", l["id"]), "sky": sky, "decided_by": storm or cloud,
                          "note": f"[Author: one or two sentences. {seed}]"})

    asks = [{"owner": b["owner"], "ask": f"[Author: what is asked. Seed: unblock {b['id']}, {b['name']}.]",
             "by": b["due"] or ne.isoformat(), "refs": [b["id"]]} for b in blockers if b["status"] == "blocked"]

    ledger_rows = ledger(plan, issued)

    stats = {"gatesClosed": sum(1 for g in gates if g.get("closed")), "gatesTotal": len(gates),
             "blocked": sum(1 for i in items if i.get("status") == "block"),
             "open": sum(1 for i in items if i.get("status") == "wait"),
             "milestones": len(ms_rows)}
    title = meta.get("title", "the plan")
    lab = label(start, end, kind, week_no if plan_week else None)
    return {
        "meta": {"id": f"{meta.get('id','plan')}-status-{end.isoformat()}", "title": f"{title}: weekly status" if kind == "weekly" else f"{title}: status",
                 "eyebrow": meta.get("eyebrow", ""), "kind": kind,
                 "period": {"start": start.isoformat(), "end": end.isoformat(), "label": lab, "ordinal": ordinal},
                 "issued": issued.isoformat(), "author": author, "audience": audience, "state": "draft",
                 "plan": {"id": meta.get("id", ""), "title": title, "version": meta.get("version", ""), "file": plan_file},
                 "classification": meta.get("classification", "")},
        "outlook": {"sky": worst([l["sky"] for l in lane_rows]),
                    "headline": "[Author: one sentence stating the position.]",
                    "emphasis": "[Author: one short sentence on what is at stake, or empty.]"},
        "summary": [{"lead": "[Author: bold lead.]", "text": "[Author: two sentences.]"}],
        "lanes": lane_rows,
        "stats": stats,
        "horizon": horizon,
        "gates": gate_rows,
        "milestones": ms_rows,
        "checkpoint": checkpoint,
        "decided": decided,
        "logCount": len(log_in),
        "blockers": blockers,
        "asks": asks,
        "ledger": ledger_rows,
        "footer": f"Read from {title} {meta.get('version','')} on {issued.isoformat()}. The plan is the record; the small ids open its rows.",
    }


def render(dataset: dict) -> str:
    tpl = TEMPLATE.read_text(encoding="utf-8")
    body = json.dumps(dataset, indent=2, ensure_ascii=False).replace("</", "<\\/")
    return tpl.replace("{{TITLE}}", dataset["meta"]["title"]).replace("{{DATASET_JSON}}", body)


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--plan", required=True, type=Path)
    ap.add_argument("--week"); ap.add_argument("--month")
    ap.add_argument("--from", dest="from_"); ap.add_argument("--to")
    ap.add_argument("--issued"); ap.add_argument("--author", default=""); ap.add_argument("--audience", default="")
    ap.add_argument("--out", type=Path); ap.add_argument("--dataset-only", action="store_true"); ap.add_argument("--force", action="store_true")
    a = ap.parse_args()
    if not a.plan.is_file():
        print(f"error: plan not found: {a.plan}", file=sys.stderr); return 2
    plan = load_plan(a.plan)
    s, e, kind = window(a)
    issued = D(a.issued) if a.issued else dt.date.today()
    out_dir = a.out or a.plan.parent
    plan_file = a.plan.name if out_dir.resolve() == a.plan.parent.resolve() else ""
    ds = derive(plan, s, e, kind, issued, author=a.author, audience=a.audience, plan_file=plan_file)
    if a.dataset_only:
        print(json.dumps(ds, indent=2, ensure_ascii=False)); return 0
    target = out_dir / f"{ds['meta']['id']}.html"
    if target.exists() and not a.force:
        print(f"error: {target} exists (pass --force to re-feed a draft)", file=sys.stderr); return 2
    target.write_text(render(ds), encoding="utf-8", newline="\n")
    cp = ds["checkpoint"]
    print(f"Created {target}  ({ds['meta']['period']['label']}, issued {ds['meta']['issued']})")
    print(f"  gates {ds['stats']['gatesClosed']}/{ds['stats']['gatesTotal']} closed · milestones {ds['stats']['milestones']}"
          f" · checkpoint {cp['date'] if cp else 'none'} with {len(cp['gates']) if cp else 0} gates and {len(cp['items']) if cp else 0} items"
          f" · blockers {len(ds['blockers'])} · decided {len(ds['decided'])} · outlook seed {ds['outlook']['sky']}")
    print("Author the judgment fields in the status-data block, then set meta.state to \"issued\":"
          " outlook.headline and emphasis, summary, lanes[].note (and sky if the seed is wrong), asks.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
