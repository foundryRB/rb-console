---
name: write-status-report
description: "Produce a periodic status report per REF-StatusReport from a plan instrument: feed the plan's dataset for one reporting window (an ISO week, a calendar month, or two dates) through the deterministic from_plan.py, which derives the road ahead (every gate and milestone by date), the checkpoint, the blockers, what was decided, and the seeded lane skies into a draft rendered by the fixed printed-brief template; then author only the judgment fields (the outlook headline and emphasis, the position, the lane notes, the asks), verify, and issue. The period sibling of write-mom: the plan stays the record, the report is its read for one window."
galaxy: press
refs:
  - REF-StatusReport
  - REF-Plan
---

# Write status report

Invoked when an engagement that has a plan (`REF-Plan.md`) owes its readers a status for a period: a weekly, a monthly, or any two dates. Input: the plan file and the window. Output: one self-contained `<plan-id>-status-<end>.html` beside the plan, in `draft` until the author finishes the judgment fields and flips it to `issued`.

## Appearance

Read `THEMING.md` alongside the routed REF. Use the shipped template or complete selected slide theme for palette, artwork and typography. Material and decorative motion are authored choices; add no Glass/Solid or Motion controls to normal outputs. Verify Light/Dark, narrow layouts, print/export and reduced motion for the surfaces being changed.

## Pre-flight

1. Read `REF-StatusReport.md` whole; the derivation rules (§4) and the derived-versus-authored split (§2) govern everything below.
2. Locate the plan file and confirm it is the current version. A report fed from a stale plan states stale facts; publish the plan first if a newer dataset exists.
3. Check the plan carries a `short` on every gate and milestone (`REF-Plan.md` §3). Where one is missing, add it to the plan as a new version with a log row, then continue. Never type a short name into the report.
4. Confirm the window (`--week YYYY-Www`, `--month YYYY-MM`, or `--from` and `--to`), the issue date if it is not today, and who issues and who reads the report.
5. Check the shape is right: one session's after-record is a MoM (`write-mom`); a page someone keeps is a flyer; the position for a period is this.

## Steps

1. **Feed the report** (the `from_plan.py` beside this SKILL.md; it reads `templates/status-report.html`):
   ```bash
   python from_plan.py --plan <plan.html> --week 2030-W02 --issued <ISO> --author "<name>" --audience "<readers>"
   ```
   Writes `<plan-id>-status-<end>.html` beside the plan (or into `--out`), the factual collections derived per `REF-StatusReport.md` §4 and the judgment fields seeded in brackets. Refuses to overwrite; `--force` re-feeds a draft after a plan edit. `--dataset-only` prints the dataset for inspection. On Windows, run with `PYTHONUTF8=1` so the plan's middots survive.
2. **Read the derived blocks against the plan.** The feed is where a plan's defects surface: a gate whose name promises what its evidence does not reference, a milestone marked blocked with nothing blocking it, two dates on one item. Fix the plan, publish it, re-feed with `--force`. Never correct a fact in the report.
3. **Author the judgment fields** in the `status-data` block, and only those:
   - `outlook.headline`: one sentence stating the position, about twelve words, because it renders at display size in a narrow column; `outlook.emphasis`: one shorter sentence on what is at stake, or empty. Correct `outlook.sky` if the seed disagrees with the sentence.
   - `summary`: two to four entries of `{lead, text}`, the lead a bold half-sentence, the text one or two sentences. The first entry says what has been done so far; the rest say what is at stake next. Position and stakes, never effort.
   - `lanes[].note`: one sentence per lane; confirm or correct `sky`, keep `decided_by`.
   - `asks`: `{owner, ask, by, refs}`; consolidate the seeded one-per-blocker rows by owner, cut any the readers cannot act on, keep the dates and the ids.
   Bracketed seeds still on the page mean the report is unfinished.
4. **Verify** (`REF-StatusReport.md` §9): open the file in both themes, zero console errors, click an id (the plan opens at that row), read the road ahead for any overlapping label, print preview.
5. **Issue**: set `meta.state` to `"issued"`. Deliver the file and say where the dataset sits. The issued report stands; the next period gets its own file.

## Failure modes

- **The plan has no `plan-data` block.** The file is not a REF-Plan instrument; the feed reads nothing else. Point it at the plan.
- **The report is not beside the plan.** Ids render as text because `meta.plan.file` is empty; write the report into the plan's directory so every id links to its row.
- **The road ahead shows ids or full names.** The plan lacks `short` on some gates or milestones; add them to the plan, re-feed.
- **A derived block looks wrong.** The plan is wrong or stale. Edit the plan, publish, re-feed; the report is downstream of the record.
- **The seeded sky contradicts the headline.** One sentence, one sky, in agreement; change the sky to match what the sentence says, and say in the lane note why.
- **An ask has no by-date or no refs.** The feed dates asks to the blocker's due and refs its id; an ask the author adds carries both or becomes a position sentence.
- **The dataset fails to parse.** The page names the fault where the report would be; it is nearly always a quote inside a string that needs escaping as `\"`, or a comma after the last item.
- **An em-dash appears anywhere.** Hard rule (INT-SHAPE-002): none, in the dataset or in the template.

## See also

- `REF-StatusReport.md`. The pattern this skill instantiates.
- `bootstrap-plan`. The plan this report reads; a plan that does not exist yet is scaffolded there first.
- `write-mom`. The session sibling: a MoM digests one event, a status report one period.
