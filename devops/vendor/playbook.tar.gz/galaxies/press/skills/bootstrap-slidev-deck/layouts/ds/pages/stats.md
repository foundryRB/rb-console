---
layout: default
section: Section name
---

<!-- The numbers page. One number is the hero; the others support it. Each figure is a brand
     numeral over a mono label; keep the bare tile unless a plate is earned, since a grid of
     plates makes every figure look equally important. ds-stat--done and --wip recolour a figure
     into the good and warn roles. Every number here is one you can source out loud. -->

<div class="ds-eyebrow">Section · Numbers</div>

# What it costs, what it took

<div class="ds-lede">One line saying where these numbers come from, so nobody has to ask.</div>

<div class="ds-rule"></div>

<div class="grid grid-cols-3 gap-6 my-auto">
  <div class="ds-stat ds-rise">
    <div class="ds-stat-value">37</div>
    <div class="ds-stat-label">what it counts</div>
  </div>
  <div class="ds-stat ds-stat--hl ds-stat--hero ds-rise--2">
    <div class="ds-stat-value">5 + 4</div>
    <div class="ds-stat-label">the one that matters</div>
  </div>
  <div class="ds-stat ds-stat--done ds-rise--3">
    <div class="ds-stat-value">100%</div>
    <div class="ds-stat-label">what it counts</div>
  </div>
</div>

<div class="ds-note ds-rise--4">Where the figures come from, and the date they were true.</div>

<div class="ds-callout ds-rise--5">The claim the numbers support, <strong>not</strong> a restatement of the numbers.</div>
