---
layout: default
class: ds-bare ds-close
section: Close
---

<!-- The close: one line on the brand field. `ds-bare` drops the chrome (the mark, the head, the
     legal line; the field covers the stage) and `ds-close` has the chrome set the mark's symbol
     above the line, so the page itself is one element. Keep both classes. The ask, the contacts
     and the questions go on a content page before it; this one holds the screen while people
     talk. -->

<div class="ds-close-word">Thank you</div>
