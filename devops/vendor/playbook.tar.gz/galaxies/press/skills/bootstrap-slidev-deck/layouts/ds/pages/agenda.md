---
layout: default
section: Agenda
---

<!-- The agenda ledger: a brand numeral, the title, and a mono clause on the right carrying the
     substance, so a row without one is filler. Five rows is the comfortable maximum. Mark a
     live beat with ds-live-dot rather than saying "live" twice. -->

<div class="ds-eyebrow">Agenda</div>

# Today

<div class="ds-lede">What this deck walks through, in order.</div>

<div class="ds-rule"></div>

<div class="ds-agenda">
  <div class="ds-agenda-row ds-rise">
    <span class="ds-agenda-num">01</span>
    <span class="ds-agenda-t">First part</span>
    <span class="ds-agenda-s">what this part answers, in one clause</span>
  </div>
  <div class="ds-agenda-row ds-rise--2">
    <span class="ds-agenda-num">02</span>
    <span class="ds-agenda-t">Second part</span>
    <span class="ds-agenda-s">what this part answers, in one clause</span>
  </div>
  <div class="ds-agenda-row ds-rise--3">
    <span class="ds-agenda-num">03</span>
    <span class="ds-agenda-t">Third part</span>
    <span class="ds-agenda-s">what this part answers, in one clause</span>
  </div>
  <div class="ds-agenda-row ds-rise--4">
    <span class="ds-agenda-num">04</span>
    <span class="ds-agenda-t">The demo</span>
    <span class="ds-agenda-s"><span class="ds-live-dot mr-2"></span>a live beat, marked as one</span>
  </div>
  <div class="ds-agenda-row ds-rise--5">
    <span class="ds-agenda-num">05</span>
    <span class="ds-agenda-t">Close</span>
    <span class="ds-agenda-s">what you are asking the room for</span>
  </div>
</div>
