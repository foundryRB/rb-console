---
layout: default
section: References
---

<!-- References: three columns of sources in small type under mono column heads. The page makes
     the deck's claims checkable, so each head says what kind of source it holds. The closing note
     sits right-aligned, a sign-off under the columns. -->

<div class="ds-eyebrow">Sources</div>

# References

<div class="ds-rule"></div>

<div class="grid grid-cols-3 gap-6 text-xs ds-rise">
  <div>
    <div class="ds-ct">What we read</div>
    <ul>
      <li>Author, <em>Title</em></li>
      <li>Organisation, <em>Report</em> (year)</li>
      <li>Standard or specification</li>
    </ul>
  </div>
  <div>
    <div class="ds-ct">What we tried</div>
    <ul>
      <li><strong>Tool</strong>: what we took from it</li>
      <li><strong>Tool</strong>: what we left behind</li>
    </ul>
  </div>
  <div>
    <div class="ds-ct">What we run on</div>
    <ul>
      <li>The platform underneath</li>
      <li>The frameworks and runtimes</li>
      <li>The test and build chain</li>
    </ul>
  </div>
</div>

<div class="mt-auto text-right ds-rise--2">
  <div class="ds-note">The one-line rule these sources add up to.</div>
</div>
