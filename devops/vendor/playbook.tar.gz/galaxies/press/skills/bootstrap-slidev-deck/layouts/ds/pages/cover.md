---
layout: default
class: ds-cover
---

<!-- The cover. `ds-cover` is what the chrome reads: it keeps the mark top-left and drops the
     head and the legal line, so keep the class. Slot order: the corner brackets and the orbit
     (decorative, fixed), then a centred stack: the eyebrow, the title, the kicker, a short bar,
     one line of description; the mono foot line last. To paint the title's last word in the
     brand colour, wrap it: # Project <span class="ds-accent">X</span>. The ds-rise--N steps only
     stagger the arrival; the resting slide is the finished one. -->

<svg class="ds-corners" viewBox="0 0 980 551" aria-hidden="true">
  <path d="M20 61 V20 H61" /><path d="M960 61 V20 H919" /><path d="M20 490 V531 H61" /><path d="M960 490 V531 H919" />
</svg>

<svg class="ds-orbit" viewBox="0 0 980 551" aria-hidden="true">
  <defs><radialGradient id="ds-orbit-grad" cx="50%" cy="50%" r="60%"><stop class="ds-orbit-stop-a" offset="0" /><stop class="ds-orbit-stop-b" offset="1" /></radialGradient></defs>
  <ellipse class="ds-orbit-glow" cx="490" cy="207" rx="230" ry="158" />
  <circle class="ds-orbit-ring1" cx="490" cy="207" r="92" />
  <circle class="ds-orbit-ring2" cx="490" cy="207" r="69" />
  <circle class="ds-orbit-ring3" cx="490" cy="207" r="46" />
  <g class="ds-orbit-sat"><rect x="533.6" y="204.7" width="4.6" height="4.6" /><rect x="441.8" y="204.7" width="4.6" height="4.6" /></g>
  <circle class="ds-orbit-core-glow" cx="490" cy="207" r="14" />
  <circle class="ds-orbit-core" cx="490" cy="207" r="5.4" />
</svg>

<div class="ds-eyebrow ds-rise">Eyebrow · Category</div>

# Presentation title

<div class="ds-kicker ds-rise--2">Presentation subtitle</div>

<div class="ds-bar ds-rise--3"></div>

<div class="ds-desc ds-rise--4">One-line description of the initiative</div>

<div class="ds-cover-foot">Team · Date</div>
