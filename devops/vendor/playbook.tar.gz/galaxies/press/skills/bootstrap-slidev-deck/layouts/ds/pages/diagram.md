---
layout: default
section: Section name
---

<!-- A flow: steps joined by marching connectors, the step in focus on the brand band
     (ds-flow-step--on). The connectors are the only part that moves. Four steps is the
     comfortable maximum on one row. -->

<div class="ds-eyebrow">Section · Flow</div>

# From source to outcome

<div class="ds-lede">One line naming what moves through the flow.</div>

<div class="ds-rule"></div>

<div class="ds-flow my-auto ds-rise">
  <div class="ds-flow-step"><div class="ds-flow-t">Define</div><div class="ds-flow-s">the intent and its evidence</div></div>
  <svg class="ds-flow-arrow" viewBox="0 0 36 10" aria-hidden="true"><path class="ds-svg-flow" d="M0 5 H28" /><path class="ds-svg-mark" d="M28 1 L36 5 L28 9 Z" /></svg>
  <div class="ds-flow-step ds-flow-step--on"><div class="ds-flow-t">Build</div><div class="ds-flow-s">the shared contract</div></div>
  <svg class="ds-flow-arrow" viewBox="0 0 36 10" aria-hidden="true"><path class="ds-svg-flow" d="M0 5 H28" /><path class="ds-svg-mark" d="M28 1 L36 5 L28 9 Z" /></svg>
  <div class="ds-flow-step"><div class="ds-flow-t">Verify</div><div class="ds-flow-s">the result, before adoption</div></div>
</div>

<div class="ds-callout ds-rise--2">Each transition has an <strong>owner</strong> and a <strong>visible gate</strong>.</div>
