---
layout: default
section: Section name
---

<!-- The ordinary content page, and the one to read before writing others. Grammar: a mono
     eyebrow behind a brand square, the title, a one-line lede, the rule (a full-bleed hairline
     with its brand segment), the argument (here three numbered cards with an icon tile each),
     then a centred callout holding the one sentence the room should leave with. The chrome adds
     the mark, the head (the deck title, this page's `section:`, the page number) and the legal
     line; a page never draws those.

     The rules that cost the most to rediscover:
     1. No inline styles, no <style> block, no class the layout does not define, one-off figure
        heights included: those are modifiers in style.css (ds-fig--h20 / --h58 / --h96 / --flush).
     2. No literal colours. Draw with the ds-svg atoms so a figure restyles with the identity.
     3. Typography inside SVG by class only (ds-svg-t / -b / -s / -m / -tag / -num): a font-size
        attribute is captured by UnoCSS attributify and renders on the rem scale.
     4. Cards never move; ds-card--lift is the pointer hover, and ds-rise--N only staggers the
        arrival.
     5. Ambient motion lives in connective tissue only (ds-svg-flow, -halo, -ring, the stage).
     6. A dash loop's offset is an exact multiple of its dash period, or the loop snaps.
     7. The callout never wraps to three lines; if it does, the sentence is too long. -->

<div class="ds-eyebrow">Section · Eyebrow</div>

# Page title

<div class="ds-lede">One line that frames the page. One line, not two.</div>

<div class="ds-rule"></div>

<div class="grid grid-cols-3 gap-4">
  <div class="ds-card ds-card--lift ds-rise">
    <div class="ds-card-ico"><svg viewBox="-12 -12 24 24" aria-hidden="true"><circle class="ds-svg-ico" r="10" /><circle class="ds-svg-ico" r="5.5" /><circle class="ds-svg-ico--fill" r="1.4" /></svg></div>
    <div class="ds-card-num">01</div>
    <div class="ds-card-t">Card one</div>
    <div class="ds-card-d">First line of description, second line of description.</div>
  </div>
  <div class="ds-card ds-card--lift ds-rise--2">
    <div class="ds-card-ico"><svg viewBox="-12 -12 24 24" aria-hidden="true"><circle class="ds-svg-ico" cx="-8" cy="6" r="2.2" /><circle class="ds-svg-ico" cx="8" cy="6" r="2.2" /><circle class="ds-svg-ico" cy="-8" r="2.2" /><path class="ds-svg-ico" d="M-6.4 4.8 L-1.6 -6.4 M6.4 4.8 L1.6 -6.4 M-5.8 6 H5.8" /></svg></div>
    <div class="ds-card-num">02</div>
    <div class="ds-card-t">Card two</div>
    <div class="ds-card-d">First line of description, second line of description.</div>
  </div>
  <div class="ds-card ds-card--lift ds-rise--3">
    <div class="ds-card-ico"><svg viewBox="-12 -12 24 24" aria-hidden="true"><rect class="ds-svg-ico" x="-7" y="-7" width="14" height="14" rx="1" /><rect class="ds-svg-ico" x="-3" y="-3" width="6" height="6" rx="0.5" /><path class="ds-svg-ico" d="M-3 -7 V-10 M3 -7 V-10 M-3 7 V10 M3 7 V10 M-7 -3 H-10 M-7 3 H-10 M7 -3 H10 M7 3 H10" /></svg></div>
    <div class="ds-card-num">03</div>
    <div class="ds-card-t">Card three</div>
    <div class="ds-card-d">First line of description, second line of description.</div>
  </div>
</div>

<div class="ds-callout ds-rise--4"><strong>Centred callout</strong>, the default pull-quote pattern. Keyword phrases render <strong>bold</strong>, the connective tissue stays regular weight.</div>
