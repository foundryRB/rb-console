---
layout: default
class: ds-section
section: Section name
---

<!-- The section divider: the corner brackets, a ghost numeral on the right, the mono eyebrow,
     the title, one line, the brand segment. The chrome stays on (the mark, the head, the legal
     line). Add `ds-section--center` to the class for the centred variant. Dividers let a long
     deck breathe and read as noise in a short one: add them once the running order settles. -->

<svg class="ds-corners" viewBox="0 0 980 551" aria-hidden="true">
  <path d="M20 61 V20 H61" /><path d="M960 61 V20 H919" /><path d="M20 490 V531 H61" /><path d="M960 490 V531 H919" />
</svg>

<div class="ds-section-num" aria-hidden="true">01</div>

<div class="ds-eyebrow ds-rise">Section · 01</div>

# Section name

<div class="ds-lede ds-lede--lg ds-rise--2">One line saying what this part answers.</div>

<div class="ds-rule ds-rule--short ds-rise--3"></div>
