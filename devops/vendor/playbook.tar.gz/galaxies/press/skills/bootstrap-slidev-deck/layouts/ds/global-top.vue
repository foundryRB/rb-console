<!-- The deck shell's chrome, rendered over every slide (Slidev registers it by filename).

     It places the identity's STAGE under every slide and its MARK top-left, and draws the
     HEAD top-right (the deck title over the section and the page number) and the LEGAL line
     bottom-left. The stage and the mark are the identity's, stamped between their PRESS
     markers; everything outside the markers is the layout's.

     A page's frontmatter `class` drives it:
       (none), ds-section   the mark, the head and the legal line
       ds-cover             the mark alone; the cover draws its own foot line
       ds-bare              no chrome
       ds-bare ds-close     the CLOSE MARK: the mark's symbol alone, centred on the brand field

     The deck title is the deck's own headmatter `title`, the section is the page's `section:`,
     and the legal line names whoever the mark names (its accessible label). The slide is read
     from the slide context's nav, which is each page's own fixed nav while printing, so a PDF
     export carries the head on every page. -->
<template>
  <div class="ds-stage" aria-hidden="true"><!-- PRESS stage -->
<div data-stage="field" aria-hidden="true"><span data-stage="glow-a"></span><span data-stage="glow-b"></span><span data-stage="glow-c"></span><span data-stage="grid"></span><span data-stage="motes"><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span></span><span data-stage="vignette"></span></div>
<!-- /PRESS stage --></div>
  <div v-if="isClose || !isBare" ref="brand" :class="{ 'ds-close-mark': isClose, 'ds-brand': !isClose }"><!-- PRESS mark -->
<span class="mark" role="img" aria-label="RB · Software Engineering" style="display:inline-flex;align-items:stretch;height:2em;line-height:1;white-space:nowrap"><svg class="mark-tile" viewBox="0 0 120 120" aria-hidden="true" style="width:2em;height:2em;flex:none;color:#f2f4f8;color:light-dark(#25282B,#f2f4f8)"><rect x="6" y="6" width="108" height="108" rx="18" fill="none" stroke="currentColor" stroke-width="8"/><text x="60" y="77" text-anchor="middle" font-family="system-ui,-apple-system,Segoe UI,sans-serif" font-size="48" font-weight="800" fill="currentColor">RB</text></svg><span aria-hidden="true" style="width:1px;flex:none;margin:.237em 0 .237em .737em;background:rgba(255,255,255,.18);background:light-dark(rgba(37,40,43,.18),rgba(255,255,255,.18))"></span><span class="mark-descriptor" style="display:flex;flex-direction:column;justify-content:center;margin-left:.579em"><b style="font-size:.584em;font-weight:700;letter-spacing:.07em;color:#f2f4f8;color:light-dark(#25282B,#f2f4f8)">Software Engineering</b><i style="margin-top:.714em;font:normal 600 .442em/1 ui-monospace,'SF Mono',Menlo,Consolas,'Liberation Mono',monospace;letter-spacing:.238em;text-transform:uppercase;color:#6c7480;color:light-dark(#7E7E7E,#6c7480)">RB</i></span></span>
<!-- /PRESS mark --></div>
  <div v-if="running" class="ds-head">
    <div class="ds-head-title">{{ title }}</div>
    <div class="ds-head-meta">
      <span v-if="section" class="ds-head-section">{{ section }}</span>
      <span class="ds-head-num">{{ page }}</span>
    </div>
  </div>
  <div v-if="running" class="ds-legal">
    <span class="ds-legal-mark"></span>
    <span>{{ legal }}</span>
  </div>
</template>
<script setup>
import { computed, onMounted, onUnmounted, ref, unref, watch } from 'vue'
import { useSlideContext } from '@slidev/client'

const { $slidev } = useSlideContext()
const route = computed(() => unref($slidev.nav.currentSlideRoute))
const frontmatter = computed(() => route.value?.meta?.slide?.frontmatter ?? {})
const pageClasses = computed(() => String(frontmatter.value.class ?? '').split(/\s+/))
const isCover = computed(() => pageClasses.value.includes('ds-cover'))
const isBare = computed(() => pageClasses.value.includes('ds-bare'))
const isClose = computed(() => pageClasses.value.includes('ds-close'))
const running = computed(() => !isCover.value && !isBare.value)

const title = computed(() => $slidev.configs.title ?? '')
const section = computed(() => frontmatter.value.section ?? '')
const page = computed(() => String(unref($slidev.nav.currentPage) ?? '').padStart(2, '0'))

// The legal line: the mark's own name for its owner, then the classification.
const brand = ref(null)
const owner = ref('')
watch(brand, (el) => {
  if (el) owner.value = el.querySelector('[aria-label]')?.getAttribute('aria-label') ?? ''
}, { flush: 'post' })
const legal = computed(() => [owner.value, 'Confidential'].filter(Boolean).join(' · '))

// The palette block reads `data-theme`; Slidev's appearance is a class on the root.
const root = () => document.documentElement
const syncVisibility = () => { root().dataset.hidden = String(document.hidden) }
const syncTheme = () => { root().dataset.theme = root().classList.contains('dark') ? 'dark' : 'light' }
const appearance = new MutationObserver(syncTheme)
onMounted(() => {
  syncVisibility(); syncTheme()
  document.addEventListener('visibilitychange', syncVisibility)
  appearance.observe(root(), { attributes: true, attributeFilter: ['class'] })
})
onUnmounted(() => { document.removeEventListener('visibilitychange', syncVisibility); appearance.disconnect() })
</script>
