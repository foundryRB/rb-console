#!/usr/bin/env python3
"""Scaffold a new Slidev deck.

See SKILL.md. Idempotent. Skips existing files. Refuses to overwrite a non-empty target.

Usage:
  python bootstrap.py --target <path> --title "<Deck Title>" [--layout <name>] [--mode dark|light]
  python bootstrap.py --target <path> --title "<Deck Title>" \
      --palette <design-systems>/<id>/identity.json
  python bootstrap.py --target <path> --title "<Deck Title>" \
      --theme-css <path/to/style.css> --theme-prefix <prefix>
  python bootstrap.py --list-layouts
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import re
import shutil
import sys
from pathlib import Path
from typing import NamedTuple



SKILL_ROOT = Path(__file__).resolve().parent
LAYOUTS_DIR = SKILL_ROOT / "layouts"
DEFAULT_LAYOUT = "ds"
DEFAULT_MODE = "dark"

# The identity stamp, one implementation shared with the maintenance script that bakes this
# organisation's own identity into the layouts (press_identity.py, this folder). A deck made
# for another identity takes that identity from its folder in the design hub when it is made.
_spec = importlib.util.spec_from_file_location("press_identity", SKILL_ROOT / "press_identity.py")
press_identity = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(press_identity)

# A layout is a FOLDER, not a stylesheet. It ships its own templated pages, the chrome
# component its CSS styles, and the dependencies it needs; taking only style.css hands
# over the tokens and leaves the pages behind, and leaves the chrome classes styling
# markup that exists nowhere. The identity is stamped into the layout's own slots: the
# palette block, the faces inside it, the stage and the mark between their markers.
PAGE_ORDER = ["cover", "agenda", "section", "content", "stats", "references", "thanks-qa"]

# Placeholders a layout's templates carry, substituted on scaffold. Best effort:
# a layout that words them differently simply keeps its own text.
TITLE_PLACEHOLDERS = ("Presentation title", "Deck title")


class Theme(NamedTuple):
    """Where a layout came from and what it ships."""
    css: Path
    prefix: str
    dir: Path | None = None       # None for --theme-css (a bare stylesheet)
    meta: dict | None = None

    def pages(self) -> list[Path]:
        """Its templates, canonical order first, then anything else alphabetically."""
        if self.dir is None or not (self.dir / "pages").is_dir():
            return []
        found = {p.stem: p for p in sorted((self.dir / "pages").glob("*.md"))}
        ordered = [found.pop(n) for n in PAGE_ORDER if n in found]
        return ordered + sorted(found.values())


# --------------------------------------------------------------------------
# File templates
# --------------------------------------------------------------------------

PACKAGE_JSON_TMPL = """{{
  "name": "{slug}",
  "private": true,
  "description": "{description}",
  "scripts": {{
    "dev": "slidev slides.md --open",
    "build": "slidev build slides.md",
    "export": "slidev export slides.md --output {slug}.pdf",
    "export:standalone": "node export-standalone.mjs"
  }},
  "dependencies": {{
    "@slidev/cli": "^0.49.0",
    "@slidev/theme-default": "latest",
    "playwright-chromium": "^1.49.0"
  }}
}}
"""


SLIDES_MD_TMPL = """---
theme: default
colorSchema: {mode}
title: "{title}"
info: |
  ## {title}
titleTemplate: "%s"
download: true
exportFilename: {slug}
drawings:
  persist: false
transition: slide-left
mdc: true
---

# {title}

<div class="{prefix}-divider mt-4"></div>

<div class="{prefix}-footer">
  <span><span class="{prefix}-brand">DECK</span> {title}</span>
  <span>Cover</span>
</div>

---
src: ./pages/01-example.md
---
"""


EXAMPLE_PAGE_TMPL = """---
layout: default
---

# Example page

<div class="{prefix}-divider"></div>

<div class="text-sm mb-3">
This is an example page. Replace with your own content.
</div>

<div class="grid grid-cols-2 gap-6 text-xs mt-4">
<div>

#### Left column

- Bullet one
- Bullet two
- Bullet three

</div>
<div>

#### Right column

| Key | Value |
|---|---|
| Foo | one |
| Bar | two |

</div>
</div>

<div class="{prefix}-alert mt-4">

Note: theme utility classes live in <code>style.css</code>. Never inline-style a page.

</div>

<div class="{prefix}-footer">
  <span><span class="{prefix}-brand">DECK</span> {title}</span>
  <span>Example</span>
</div>
"""


GITIGNORE_TMPL = """node_modules/
dist/
.slidev/
.standalone-build/
*.log
.DS_Store
"""


README_TMPL = """# {title}

Slidev presentation scaffolded by `bootstrap-slidev-deck`.

## Quickstart

```bash
npm install
npm run dev      # http://localhost:3030
```

## Scripts

| Command           | Action                                  |
|-------------------|-----------------------------------------|
| `npm run dev`     | Local dev server with live reload       |
| `npm run build`   | Static build (output in `dist/`)        |
| `npm run export`  | Export to PDF (requires Chromium)       |
| `npm run export:standalone` | One self-contained `.html` (offline, no server) |

## Structure

```
.
├── slides.md        # Cover (inlined) + page imports
├── style.css        # The layout's stylesheet, the identity stamped in
├── global-top.vue   # The layout's chrome: the stage and the mark
├── pages/           # One file per slide
├── public/          # Images, fonts, and other static assets
└── export-standalone.mjs  # Opt-in single-file HTML export
```

## Authoring rules

See the playbook's `REF-Slidev.md` for the full pattern. The short version:

- One page per file under `pages/`. Numbered prefix preserves order.
- The pages you started with came from the layout: they are its templates, and they use only classes it defines. Rename them as they become real pages.
- Each page uses theme utility classes (prefixed `{prefix}-`) plus Slidev's tailwind utilities (`grid`, `gap-*`, `text-xs`).
- All visual rules live in `style.css`. **Never** add `style="..."` attributes or `<style>` blocks inside page Markdown, and never use a class the theme does not define. That is what keeps the deck re-skinnable.
- The cover lives in `slides.md` itself (Slidev's first slide is the file's own frontmatter slide). Its `class:` is what `global-top.vue` reads to hide the chrome on a cover; keep it.
- Add new pages by creating `pages/<NN>-<slug>.md` and adding a matching `src:` import block in `slides.md`.

## Scaffolded by

`bootstrap-slidev-deck` skill. See the playbook's `skills/bootstrap-slidev-deck/SKILL.md`.
"""


# --------------------------------------------------------------------------
# Helpers
# --------------------------------------------------------------------------


def _write(path: Path, content: str) -> bool:
    """Write content if file doesn't exist. Returns True if written."""
    if path.exists():
        print(f"  SKIP (exists): {path}")
        return False
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")
    print(f"  WRITE: {path}")
    return True


def _copy(src: Path, dst: Path) -> bool:
    """Copy src to dst if dst doesn't exist."""
    if dst.exists():
        print(f"  SKIP (exists): {dst}")
        return False
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(src, dst)
    print(f"  WRITE: {dst}  (copied from {src.name})")
    return True


def slugify(name: str) -> str:
    out: list[str] = []
    prev_dash = False
    for c in name.lower():
        if c.isalnum():
            out.append(c)
            prev_dash = False
        elif not prev_dash:
            out.append("-")
            prev_dash = True
    return "".join(out).strip("-")


def list_layouts() -> list[str]:
    """The layouts this skill ships, by folder name."""
    return sorted(d.name for d in LAYOUTS_DIR.iterdir() if d.is_dir() and (d / "style.css").is_file())


def resolve_theme(layout_name: str | None,
                  theme_css: Path | None,
                  theme_prefix: str | None) -> Theme:
    """Resolve a layout to its folder (or a bare stylesheet). Validates inputs."""
    if theme_css is not None:
        if layout_name is not None:
            raise SystemExit("error: --layout and --theme-css are mutually exclusive")
        if theme_prefix is None:
            raise SystemExit("error: --theme-css requires --theme-prefix")
        css_path = theme_css.resolve()
        if not css_path.is_file():
            raise SystemExit(f"error: theme CSS not found: {css_path}")
        return Theme(css=css_path, prefix=theme_prefix)

    name = layout_name or DEFAULT_LAYOUT
    theme_dir = LAYOUTS_DIR / name
    if not (theme_dir / "style.css").is_file():
        available = ", ".join(list_layouts()) or "(none)"
        raise SystemExit(f"error: layout '{name}' not found. Available: {available}")
    meta_path = theme_dir / "meta.json"

    meta: dict = {}
    if meta_path.is_file():
        try:
            meta = json.loads(meta_path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            meta = {}

    final_prefix = theme_prefix or meta.get("prefix") or "u"
    return Theme(css=theme_dir / "style.css", prefix=final_prefix, dir=theme_dir, meta=meta)


# --------------------------------------------------------------------------
# Handing over a theme's own pages
# --------------------------------------------------------------------------

_FRONTMATTER = re.compile(r"\A---\r?\n(.*?)\r?\n---\r?\n?", re.DOTALL)


def _split_page(text: str) -> tuple[str, str]:
    """(frontmatter, body) for a page file. Frontmatter is '' when absent."""
    m = _FRONTMATTER.match(text)
    return (m.group(1), text[m.end():]) if m else ("", text)


def _retitle(text: str, title: str) -> str:
    for ph in TITLE_PLACEHOLDERS:
        text = text.replace(ph, title)
    return text


def compose_slides(theme: Theme, pages: list[Path], title: str, slug: str,
                   mode: str = DEFAULT_MODE) -> tuple[str, list[tuple[Path, str]]]:
    """Build slides.md plus the (source, destination-name) list for pages/.

    Slidev's first slide IS slides.md's own frontmatter slide, so a theme's cover.md
    cannot be imported - its body is inlined here and its `class:` carried onto the
    deck frontmatter (that class is what a theme's chrome reads to hide itself on a
    cover). Every other template is copied and imported in order.
    """
    cover_class = ""
    cover_body = f"# {title}\n"
    rest: list[tuple[Path, str]] = []

    n = 0
    for page in pages:
        fm, body = _split_page(page.read_text(encoding="utf-8"))
        if page.stem == "cover":
            cover_body = _retitle(body.strip(), title) + "\n"
            m = re.search(r"^class:\s*(.+)$", fm, re.MULTILINE)
            cover_class = m.group(1).strip() if m else ""
            continue
        n += 1
        rest.append((page, f"{n:02d}-{page.stem}.md"))

    head = [
        "---",
        "theme: default",
        f"colorSchema: {mode}",
        f'title: "{title}"',
        "info: |",
        f"  ## {title}",
        'titleTemplate: "%s"',
        "download: true",
        f"exportFilename: {slug}",
        "drawings:",
        "  persist: false",
        "transition: slide-left",
        "mdc: true",
    ]
    if cover_class:
        head.insert(2, f"class: {cover_class}")
    head.append("---")

    imports = "".join(f"\n---\nsrc: ./pages/{dst}\n---\n" for _, dst in rest)
    return "\n".join(head) + "\n\n" + cover_body + imports, rest


def merge_dependencies(theme: Theme, base: dict) -> dict:
    """The theme's own dependencies on top of the base set (a layout that ships
    its own font packages needs them, or its @import resolves to nothing)."""
    pkg = theme.dir / "package.json" if theme.dir else None
    if pkg and pkg.is_file():
        try:
            base.update(json.loads(pkg.read_text(encoding="utf-8")).get("dependencies", {}))
        except (json.JSONDecodeError, OSError):
            pass
    return dict(sorted(base.items()))


# --------------------------------------------------------------------------
# Main
# --------------------------------------------------------------------------


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--target", type=Path, help="Target directory (created if missing).")
    ap.add_argument("--title", help="Deck title (cover + package.json description).")
    ap.add_argument("--layout", "--theme", dest="layout",
                    help=f"Layout name, one this skill ships. Default: '{DEFAULT_LAYOUT}'.")
    ap.add_argument("--theme-css", type=Path, help="External CSS to use instead of a named layout.")
    ap.add_argument("--theme-prefix", help="Class prefix used in scaffolded pages.")
    ap.add_argument("--palette", type=Path, metavar="IDENTITY.json",
                    help="Another identity to stamp into the deck, read from its folder in the design hub "
                         "(<design-systems>/<id>/identity.json). Without it the deck wears the identity "
                         "baked into the layout.")
    ap.add_argument("--mode", choices=("dark", "light"), default=DEFAULT_MODE,
                    help=f"The deck's appearance, its colorSchema. Default: {DEFAULT_MODE}.")
    ap.add_argument("--list-layouts", "--list-themes", dest="list_layouts", action="store_true",
                    help="List the layouts this skill ships and exit.")
    args = ap.parse_args()

    if args.list_layouts:
        layouts = list_layouts()
        print("\n".join(layouts) if layouts else "(no layouts found)")
        return 0

    if args.target is None or args.title is None:
        ap.error("--target and --title are required (unless --list-layouts)")

    target: Path = args.target
    if target.exists() and any(target.iterdir()):
        print(f"target exists and is non-empty: {target}", file=sys.stderr)
        return 2

    identity = None
    if args.palette is not None:
        if not args.palette.is_file():
            raise SystemExit(f"error: identity not found: {args.palette}")
        identity = press_identity.load_identity(args.palette.resolve())

    theme = resolve_theme(args.layout, args.theme_css, args.theme_prefix)
    pages = theme.pages()

    target.mkdir(parents=True, exist_ok=True)
    slug = slugify(args.title)

    print(f"Scaffolding Slidev deck at {target}")
    print(f"  title:    {args.title}")
    print(f"  slug:     {slug}")
    print(f"  layout:   {theme.dir or theme.css}  (prefix '{theme.prefix}-')")
    print(f"  identity: {identity['id']} (stamped)" if identity else "  identity: the layout's own")
    print(f"  mode:     {args.mode}")
    print(f"  pages:    {len(pages)} from the layout" if pages else "  pages:    1 generated example (the layout ships none)")

    deps = merge_dependencies(theme, {
        "@slidev/cli": "^0.49.0",
        "@slidev/theme-default": "latest",
        "playwright-chromium": "^1.49.0",
    })
    _write(target / "package.json", json.dumps({
        "name": slug,
        "private": True,
        "description": args.title,
        "scripts": {
            "dev": "slidev slides.md --open",
            "build": "slidev build slides.md",
            "export": f"slidev export slides.md --output {slug}.pdf",
            "export:standalone": "node export-standalone.mjs",
        },
        "dependencies": deps,
    }, indent=2) + "\n")

    # The stylesheet carries the identity baked into the layout; another identity is stamped
    # over it here, its stage between the markers and its palette and faces in the block.
    css = theme.css.read_text(encoding="utf-8")
    if identity is not None:
        css = press_identity.stamp_css(css, identity, with_stage=True, print_light=False)
    _write(target / "style.css", css)

    if pages:
        # The layout's own templates ARE the deck's starting pages.
        slides, copied = compose_slides(theme, pages, args.title, slug, args.mode)
        _write(target / "slides.md", slides)
        for src, dst in copied:
            _write(target / "pages" / dst, _retitle(src.read_text(encoding="utf-8"), args.title))
    else:
        _write(target / "slides.md", SLIDES_MD_TMPL.format(
            title=args.title, slug=slug, prefix=theme.prefix, mode=args.mode,
        ))
        _write(target / "pages" / "01-example.md", EXAMPLE_PAGE_TMPL.format(
            title=args.title, prefix=theme.prefix,
        ))

    # The chrome component the layout's CSS styles. Without it those rules target markup
    # that exists nowhere, which is how a deck loses its mark and its stage silently. Another
    # identity's deck takes that identity's stage and mark; where the hub projects no mark
    # for it, the slot is empty, never this organisation's.
    if theme.dir and (theme.dir / "global-top.vue").is_file():
        chrome = _retitle((theme.dir / "global-top.vue").read_text(encoding="utf-8"), args.title)
        if identity is not None:
            chrome = press_identity.stamp_markup(chrome, identity, keep_mark_when_absent=False)
        _write(target / "global-top.vue", chrome)

    # The single-file exporter ships as a real .mjs beside the layouts rather than a
    # string in here: it is a program, and it wants to stay lintable and testable.
    _copy(SKILL_ROOT / "templates" / "export-standalone.mjs", target / "export-standalone.mjs")

    _write(target / ".gitignore", GITIGNORE_TMPL)
    _write(target / "README.md", README_TMPL.format(
        title=args.title,
        prefix=theme.prefix,
    ))

    # A theme's own public/ is brand payload it DOES carry: the marks its pages place
    # in content (a speechmark tile, a flag). Leaving them behind is silent - the page
    # that references one renders a broken image.
    public = target / "public"
    public.mkdir(exist_ok=True)

    theme_public = theme.dir / "public" if theme.dir else None
    if theme_public is not None and theme_public.is_dir():
        for src in sorted(f for f in theme_public.rglob("*") if f.is_file()):
            _copy(src, public / src.relative_to(theme_public))

    if not any(public.iterdir()):
        _write(public / ".gitkeep", "")

    # Payload the theme does not carry (a licensed face, say): say so loudly, because
    # the failure is otherwise silent (fallback fonts, a broken image). The note stands
    # on its own - a theme that carries its payload still has terms to state about it.
    requires = (theme.meta or {}).get("requires") or {}
    assets = requires.get("assets") or []
    note = requires.get("note")
    if assets or note:
        print()
    if assets:
        print(f"  THIS LAYOUT NEEDS {len(assets)} FILE(S) IT DOES NOT SHIP:")
        for a in assets:
            print(f"    public{a}")
    if note:
        print(f"  NOTE: {note}")

    print()
    print("Next steps:")
    print(f"  cd {target}")
    print("  npm install")
    print("  npm run dev      # http://localhost:3030")
    print("  npm run build    # static build")
    print("  npm run export   # PDF export")
    print("  npm run export:standalone   # one self-contained .html")
    return 0


if __name__ == "__main__":
    sys.exit(main())
