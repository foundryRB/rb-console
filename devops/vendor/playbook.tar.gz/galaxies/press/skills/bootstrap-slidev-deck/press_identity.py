"""The identity stamp every press template takes: the palette block, the faces, the stage and the mark,
each from the identity's folder in the design hub (`<design-systems>/<id>/`).

The maintenance script `scripts/sync_press_palette.py` stamps the authored templates with the
organisation's own identity, and the deck scaffold stamps a deck it makes with another identity
when asked (`--palette`). Both run this file, so there is one stamp. Skills ship as
self-contained folders, which is why it lives beside the scaffold that needs it at make time.

The block's marker is neutral (/* PRESS palette */): it travels inside every artifact a template
emits, so it names the mechanism and not the organisation. A block written under the earlier
marker is replaced on the next run."""
from __future__ import annotations

import json
import re
from pathlib import Path

# The name each template's tokens hang off, mapped to the identity role that fills it. Roles
# the identity does not name (categorical lane colours, say) stay the instrument's own.
ROLES = {
    "desk": "canvas", "bg": "canvas", "paper": "surface", "sheet": "surface",
    "surface": "surface", "raised": "raised", "ink": "ink", "ink-2": "muted",
    "muted": "muted", "dim": "muted", "faint": "muted", "quiet": "muted",
    "line": "line", "line-2": "line", "rule": "line", "steel": "link",
    "steel-2": "link", "highlight": "link", "accent": "link", "link": "link",
    "accent-soft": "raised", "chip-bg": "raised", "band": "raised", "brand": "brand",
    "blueprint": "raised", "ok": "good", "sun": "good", "good": "good",
    "mid": "warn", "due": "warn", "cloud": "warn", "warn": "warn",
    "hot": "bad", "late": "bad", "storm": "bad", "bad": "bad",
    "sans": "sans", "serif": "sans", "mono": "mono", "disp": "sans", "body": "sans",
    "font-sans": "sans", "font-display": "sans", "font-mono": "mono",
    "paper-ink": "ink", "paper-dim": "muted", "paper-line": "line",
    "paper-panel": "surface", "paper-acc": "link", "panel": "surface",
    "panel-2": "raised", "edge": "line", "edge-2": "line", "band-ink": "ink",
    "band-muted": "muted", "crit": "bad", "focus": "focus", "action-ink": "action-ink",
    # The deck layout's tokens: the identity's roles under its class prefix.
    "ds-canvas": "canvas", "ds-surface": "surface", "ds-raised": "raised", "ds-ink": "ink",
    "ds-muted": "muted", "ds-line": "line", "ds-action-ink": "action-ink", "ds-link": "link",
    "ds-good": "good", "ds-warn": "warn", "ds-bad": "bad", "ds-focus": "focus",
    "ds-sans": "sans", "ds-mono": "mono", "ds-radius": "radius", "ds-brand": "brand",
}
STAGE_CSS = re.compile(r'/\* PRESS stage \*/.*?/\* /PRESS stage \*/', re.S)
STAGE_HTML = re.compile(r'<!-- PRESS stage -->.*?<!-- /PRESS stage -->', re.S)
MARK_HTML = re.compile(r'<!-- PRESS mark -->.*?<!-- /PRESS mark -->', re.S)
BLOCK = re.compile(r'/\* (?:PRESS|PSA) palette \*/.*?/\* /(?:PRESS|PSA) palette \*/\s*', re.S)  # PSA: the earlier marker


def load_identity(identity_json: Path) -> dict:
    """The identity as the stamp reads it: its palettes per mode, and the pieces the design hub
    projects beside `identity.json` (faces, stage, mark), each empty when the identity has none."""
    folder = identity_json.parent
    generated = folder / "generated"

    def piece(name: str) -> str:
        path = generated / name
        return path.read_text(encoding="utf-8") if path.exists() else ""

    return {
        "id": folder.name,
        "palettes": json.loads(identity_json.read_text(encoding="utf-8"))["modes"],
        "faces": piece("faces.css"),
        "stage_css": piece("stage.css"),
        "stage_html": piece("stage.html"),
        "mark_html": piece("mark.html"),
    }


def braces(text: str, escaped: bool) -> str:
    """Text bound for a template rendered with str.format (`escaped`), its braces doubled."""
    return text.replace('{', '{{').replace('}', '}}') if escaped else text


def update(source: str, palettes: dict, escaped: bool, scope: str = '', faces: str = '',
           print_light: bool = True, workshop: bool = False) -> str:
    """The palette block, rewritten: light on the bare root, dark under the system preference
    or an explicit `data-theme`, and print on the light palette for a document (`print_light`);
    a presented deck keeps its chosen appearance in its export, so it passes False."""
    source = BLOCK.sub('', source)
    # A template carries its tokens inside <style>; a stylesheet IS the styles,
    # and the block goes last so it outranks the sheet's own declarations.
    close = '</style>' if '</style>' in source else ''
    styles, rest = source.split(close, 1) if close else (source, '')
    names = set(re.findall(r'var\(--([\w-]+)', source))
    # Keep one maintained definition for each brand role. Other roles, such as
    # categorical lane colours, remain owned by the instrument.
    for name in ROLES:
        styles = re.sub(rf'--{re.escape(name)}\s*:[^;{{}}]+;', '', styles)
    styles = re.sub(r'^[ \t]+$', '', styles, flags=re.M)
    styles = re.sub(r'\n{3,}', '\n\n', styles)
    source = styles + close + rest

    def values(mode: str) -> str:
        p = palettes[mode]
        return f'color-scheme:{mode};' + ''.join(f'--{k}:{p[v]};' for k, v in ROLES.items() if k in names and v in p)

    light, dark = f':root{scope},:root[data-theme="light"]{scope}', f':root[data-theme="dark"]{scope}'
    css = ('/* PRESS palette */\n' + faces + light + '{' + values('light') + '}\n'
           '@media(prefers-color-scheme:dark){:root:not([data-theme="light"])' + scope + '{' + values('dark') + '}}\n'
           + dark + '{' + values('dark') + '}\n')
    if workshop:
        css = ('/* PRESS palette */\n' + faces + ':root{' + values('light') + '}\n'
               + '.room{' + values('dark') + '}\n')
    elif print_light:
        css += '@media print{' + light + ',' + dark + ',:root:not([data-theme="light"])' + scope + '{' + values('light') + '}}\n'
    css = braces(css + '/* /PRESS palette */\n', escaped)
    source = source.replace(close, css + close, 1) if close else source.rstrip('\n') + '\n' + css
    # The email projection has inline styles, always using the Light palette.
    if 'function emailBody()' in source:
        for name, role in {'INK':'ink','MUTED':'muted','RULE':'line','ACCENT':'link','DUE':'warn','LATE':'bad'}.items():
            source = re.sub(rf'var {name} = "[^"]*";', f'var {name} = {json.dumps(palettes["light"][role])};', source)
    return source


def stage(source: str, css: str, markup: str) -> str:
    """The identity's stage between the frame's markers: its CSS in the style, its element
    opening the body. Empty markers for an identity without a stage."""
    source = STAGE_CSS.sub(lambda _: '/* PRESS stage */\n' + css + '/* /PRESS stage */', source)
    return STAGE_HTML.sub(lambda _: '<!-- PRESS stage -->\n' + markup + '<!-- /PRESS stage -->', source)


def mark(source: str, markup: str, keep_when_absent: bool) -> str:
    """The identity's mark between the chrome's markers. An identity the hub projects no mark for
    either keeps what the slot carries (the organisation's own, at maintenance time) or empties it
    (another identity's deck never wears this organisation's mark)."""
    if not markup and keep_when_absent:
        return source
    return MARK_HTML.sub(lambda _: '<!-- PRESS mark -->\n' + markup + '<!-- /PRESS mark -->', source)


def stamp_css(source: str, identity: dict, *, scope: str = '', escaped: bool = False,
              faces: bool = True, with_stage: bool = False, print_light: bool = True,
              workshop: bool = False, rename_stage: bool = False) -> str:
    """A stylesheet, or a template carrying its styles, stamped with the identity."""
    if with_stage:
        css = identity["stage_css"]
        if workshop or rename_stage:
            # The template's own markup uses .stage (the workshop renderer's presentation
            # mode, a flyer author's figure), so the stage takes a class of its own.
            css = re.sub(r'(?<![\w-])\.stage(?![\w-])', '.press-stage-decoration', css)
        css = braces(css, escaped)
        source = STAGE_CSS.sub(lambda _: '/* PRESS stage */\n' + css + '/* /PRESS stage */', source)
    return update(source, identity["palettes"], escaped, scope, identity["faces"] if faces else '', print_light, workshop)


def stamp_markup(source: str, identity: dict, *, keep_mark_when_absent: bool, workshop: bool = False,
                 escaped: bool = False, rename_stage: bool = False) -> str:
    """Markup carrying the stage and mark slots (a page frame's body, a deck's chrome), stamped."""
    markup = identity["stage_html"]
    if workshop or rename_stage:
        markup = re.sub(r'class="stage"', 'class="press-stage-decoration"', markup)
    markup = braces(markup, escaped)
    source = STAGE_HTML.sub(lambda _: '<!-- PRESS stage -->\n' + markup + '<!-- /PRESS stage -->', source)
    return mark(source, braces(identity["mark_html"], escaped), keep_mark_when_absent)
