---
name: bootstrap-slidev-deck
description: Scaffold a new Slidev deck with the REF-Slidev page-based layout, from the layout the skill owns (its pages, its chrome, its motion) with an identity stamped in - this organisation's, baked into the layout, or another identity's read from its folder in the design hub when the deck is made (--palette). Produces package.json, slides.md (the cover inlined + page imports), style.css, global-top.vue, pages/ and public/, and ships an opt-in single-file HTML export. Caller runs `npm install && npm run dev`.
galaxy: press
refs:
  - REF-Slidev
---

# Bootstrap Slidev Deck

Invoked when the user wants to start a new Slidev presentation, or scaffold one inside an existing project. This skill produces a *working* skeleton. `npm install && npm run dev` should yield a live preview at `http://localhost:3030`. Sane defaults; user customizes from there.

Reference implementation: any existing deck following `REF-Slidev.md` §4 (page-based layout). The skill scaffolds the same shape from its own layout.

## Appearance

Read `THEMING.md` alongside the routed REF. The layout carries this organisation's palette, faces, stage and mark, so the skill alone makes a branded deck; a deck made for another identity takes that identity from the design hub (below). Material and decorative motion are authored choices; add no Glass/Solid or Motion controls to normal outputs. Verify Light/Dark, narrow layouts, print/export and reduced motion for the surfaces being changed.

## Pre-flight

1. **Read** `REF-Slidev.md` for layout rules, CSS-only theming, and class-system conventions.
2. **Confirm target path** with the user. Empty directory or new directory to be created.
3. **Confirm title, identity and mode**. Title goes into `slides.md` and `package.json`; the identity is the layout's own unless the deck is made for another one, whose `identity.json` in the design hub is passed as `--palette`; the mode (`dark` by default, or `light`) is the deck's `colorSchema`.

## What it produces

```
<target>/
├── package.json           # @slidev/cli + whatever the layout itself needs
├── slides.md              # the layout's cover, inlined + imports for its pages
├── style.css              # the layout's stylesheet, the identity stamped in
├── global-top.vue         # the layout's chrome: the identity's stage and mark, the head, the legal line
├── pages/                 # the layout's own templates, numbered in order
├── public/                # the layout's own marks, when it ships any (else empty + .gitkeep)
├── export-standalone.mjs  # opt-in single-file HTML export
├── .gitignore             # node_modules, dist, .slidev, .standalone-build
└── README.md              # quickstart + structure
```

## Layouts and the identity

**A layout is a folder, not a stylesheet.** Copying only `style.css` hands over the tokens and leaves the pages behind, and leaves the chrome rules styling markup that exists nowhere, so a deck loses its mark and its stage with no error. The skill takes the whole layout:

| The layout ships | What the skill does with it |
|---|---|
| `style.css` | copied to the deck root, the identity stamped in when the deck is made for another one |
| `meta.json` | `prefix` names the class namespace; `requires.assets` is printed as a warning (payload the layout does not carry, so the deck owner must supply it), and `requires.note` always prints, carrying whatever terms attach to the payload the layout does carry |
| `pages/*.md` | **become the deck's starting pages**, numbered in canonical order (`cover`, `agenda`, `section`, `content`, `diagram`, `stats`, `references`, `thanks-qa`, then anything else alphabetically) |
| `global-top.vue` | copied, so the chrome classes the CSS styles actually exist; it carries the stage and the mark, and draws the head (the deck's headmatter `title` over the page's `section:` and its number, read from each page's own nav so a PDF export keeps it) and the legal line |
| `package.json` | its `dependencies` merge into the deck's, when the layout ships one |
| `public/` | its tree is copied into the deck's `public/`, skipping anything already there |

`cover.md` is special: Slidev's first slide *is* `slides.md`'s own frontmatter slide, so the cover cannot be imported. Its body is inlined into `slides.md` and its `class:` carried onto the deck frontmatter, and that class is what the chrome reads to drop the head and the legal line on a cover. A page's `class:` drives the chrome the same way: `ds-section` keeps all of it, `ds-bare` drops it, and `ds-bare ds-close` sets the mark's symbol alone on the close.

Titles substitute on scaffold: the literals `Presentation title` and `Deck title` in the layout's templates become the deck's real title. The chrome's head reads the deck's headmatter `title`, so a retitled deck needs no edit there.

**The layout carries no identity of its own; the identity is stamped into its slots.** The palette block at the end of `style.css` (both appearances, the faces inlined in it), the stage between the `PRESS stage` markers in `style.css` and `global-top.vue`, and the mark between the `PRESS mark` markers in `global-top.vue` are the slots, and `press_identity.py` (this folder) is the one stamp that fills them:

- **This organisation's identity is baked in at maintenance time.** `scripts/sync_press_palette.py --palette <the identity's identity.json>` stamps the layout the way it stamps every other press template, so a deck made with no further input is correctly branded with nothing installed and nothing reachable. `--check` verifies the layout is current.
- **Another identity is stamped when the deck is made.** `--palette <design-systems>/<id>/identity.json` reads that identity's folder in the design hub (its `identity.json`, and the `generated/` pieces the hub projects beside it: `faces.css`, `stage.html`, `stage.css`, `mark.html`) and stamps the deck's own copy of the layout. The deck keeps what it wears and nothing else keeps a copy. Where the hub projects no mark for that identity, the mark slot is left empty: a deck made for another identity never wears this organisation's mark.
- **An identity the hub does not hold yet** is iterated on the deck itself: its palette block, faces, stage and mark are the deck's own once scaffolded. When the look is worth keeping, the hub's harvest path captures it as that customer's design system, and later work stamps from there.

The mode is the deck's `colorSchema` in `slides.md`; the chrome mirrors Slidev's appearance class onto the `data-theme` attribute the palette block reads, so the chosen appearance holds in the browser, in the build and in the export. A presented deck keeps its chosen appearance in its PDF export: unlike a document, its palette block carries no print rule.

The layouts carry their self-containment gate, `layouts/check-layouts.mjs`: every class a page or the chrome uses is one the stylesheet defines, and every chrome class the stylesheet styles is produced by the chrome. Run it after changing a layout; the repo's tests run it where node is available.

To list the layouts: `python bootstrap.py --list-layouts`.

### One-off stylesheets

For a single deck's private stylesheet, skip the layout entirely: pass `--theme-css <path>` plus `--theme-prefix <prefix>`. The skill copies the CSS verbatim into the deck and generates one example page; the user owns it.

## Steps

1. **Run the scaffolder** (Python helper at `<this-skill>/bootstrap.py`):
   ```bash
   python bootstrap.py --target <path> --title "<Deck Title>" [--mode dark|light]
   ```
   For another identity, read from the design hub:
   ```bash
   python bootstrap.py --target <path> --title "<Deck Title>" \
     --palette <design-systems>/<id>/identity.json
   ```
   Or with an external CSS:
   ```bash
   python bootstrap.py --target <path> --title "<Deck Title>" \
     --theme-css <path/to/style.css> --theme-prefix <prefix>
   ```
2. **Install dependencies**:
   ```bash
   cd <target> && npm install
   ```
3. **Verify**:
   ```bash
   npm run dev      # http://localhost:3030
   npm run build    # static build
   npm run export   # PDF export (requires playwright-chromium)
   npm run export:standalone   # one self-contained .html (see below)
   ```
4. **Surface to user**:
   - "Slidev deck scaffolded. Run `npm install` then `npm run dev`. Add pages under `pages/` and import them in `slides.md`. Layout classes live in `style.css`; never inline styles in page Markdown."

## Self-contained HTML export

`npm run export:standalone` produces **one** `.html` carrying the entire deck: no server, no sibling `assets/` folder, opens offline by double-click. It is for handing a deck to someone who will not run Node, and for keeping a fixed record of what was actually presented.

It is opt-in and never part of `npm run build`, for the same reason PDF export is not (`REF-Slidev.md` §10, anti-pattern 10). The deck's own files are never touched: the whole thing happens in a throwaway `.standalone-build/`.

Four things have to be true for a Slidev build to survive `file://`, and missing any one of them fails *silently* (a blank page, or fallback fonts, or Slidev's own 404):

| What the script does | Why it is needed |
|---|---|
| inlines every `public/` asset as a `data:` URI | Vite does not process `public/`. `/fonts/x.ttf` survives the build verbatim and resolves against the **filesystem root** over `file://` |
| folds one JS chunk and one CSS file into the HTML | an external `<script type="module">` is CORS-blocked over `file://`, and the deck renders blank. Slidev sets `manualChunks`, which fights `inlineDynamicImports`, so it is cleared in an `outputOptions` hook |
| sets `routerMode: hash` | the history-mode router cannot match a `file://` path |
| kills the CDN favicon in the `<head>` **and** in the bundle | Slidev's runtime re-applies it, so patching the head alone still costs a network call on open |

By default it then proves the claim: it loads its own output in headless Chromium with every non-`file:` request aborted, and reports what rendered and how many network calls were attempted. **Zero is the passing number.** It walks every slide, not just the cover, because an asset that is referenced but absent (a video never recorded, say) only surfaces when the slide holding it mounts; each one is named. A deck that fails to render exits non-zero rather than leaving you a broken file that looks fine on disk.

| Flag | Purpose |
|---|---|
| `--out <file>` | output path (default `<name>.html` from `package.json`) |
| `--max-asset-mb <n>` | per-asset inlining cap, default 8 |
| `--skip-large` | leave oversized assets external, accepting a non-self-contained file |
| `--no-verify` | skip the headless check |
| `--keep` | keep `.standalone-build/` for inspection |
| `--force` | proceed even though the deck has its own Vite config |

## Page authoring rules (per REF-Slidev §5 and §6)

- One page per file in `pages/<NN>-<slug>.md`. Numbered prefix preserves order alongside `slides.md` imports.
- Every page begins with a `layout: default` frontmatter block and an H1 or the layout's title element.
- **Use only classes the layout defines.** The layout's own templates in `pages/` are the reference for what its pages look like; follow those, not a remembered shape.
- All visual rules live in `style.css`. Pages use only layout utility classes plus Slidev's tailwind utilities (`grid`, `gap-*`, `text-xs`, etc.).
- No `style="..."` attributes anywhere. No `<style>` blocks inside pages. If a needed style doesn't exist, add a class to `style.css`.
- `layouts/check-layouts.mjs` verifies this mechanically for the layout: run it after adding classes.

## CLI options

| Flag | Default | Purpose |
|---|---|---|
| `--target <path>` | required | Target directory (must be empty or non-existent) |
| `--title "<text>"` | required | Deck title (cover slide + package.json description) |
| `--layout <name>` | `ds` | The layout, one this skill ships |
| `--palette <identity.json>` | none | Another identity to stamp into the deck, read from its folder in the design hub |
| `--mode dark\|light` | `dark` | The deck's appearance (its `colorSchema`) |
| `--theme-css <path>` | none | External CSS file to use instead of a layout. Mutually exclusive with `--layout`. Requires `--theme-prefix` |
| `--theme-prefix <p>` | from the layout's meta.json | Class prefix used in scaffolded pages (e.g. `ds`) |
| `--list-layouts` | flag | Print the layouts this skill ships and exit |

## Failure modes

- **Target exists and is non-empty**. Surface; don't overwrite.
- **`--layout <name>` not found**. Surface the layouts this skill ships; exit non-zero.
- **`--palette <path>` not found**. Surface; the identity is a folder in the design hub, passed by its `identity.json`.
- **`--theme-css <path>` given without `--theme-prefix`**. Surface the missing flag; exit non-zero.
- **Both `--layout` and `--theme-css` given**. Reject; pick one.
- **Node.js not available**. Surface; can't validate the scaffold without it.
- **`export:standalone` hits an asset over the size cap**. It refuses rather than emit a file that is quietly not self-contained. A two-minute 1080p video is the usual cause (base64 adds about a third). Raise `--max-asset-mb` or pass `--skip-large` deliberately.
- **`export:standalone` on a deck with its own `vite.config.ts`**. It refuses without `--force`, because the standalone build replaces that config in its copy.
- **`export:standalone` reports network calls a scaffolded deck never asked for**. Slidev's default font provider is Google Fonts, so a deck that has not opted out fetches a stylesheet on open. The script reports it rather than silencing it, because forcing the opt-out would silently change the deck's typography. The fix belongs in the deck: put `fonts:` / `  provider: none` in `slides.md` frontmatter; the identity's own faces already travel inlined in the palette block.

## Anti-patterns

- Running `npm create slidev@latest` (interactive, fragile). We write files directly with vetted defaults.
- Adding plugins/integrations the user didn't ask for. Scaffold minimal; user adds.
- Inlining theme CSS into `slides.md` or page files. The stylesheet is one separate `style.css`.
- Folding the standalone HTML export into `npm run build`. It is a distribution step, not a build step; same reasoning as the PDF export.
- Restyling a deck by editing the layout's own rules, or typing a colour into a page. The identity is the palette block, the faces, the stage and the mark; another identity is a folder in the design hub stamped with `--palette`, and a look the hub does not hold yet is iterated in the deck's own slots and harvested from there.
- Baking an identity into the layout's pages or chrome. The layout carries slots; the stamp fills them, at maintenance time for this organisation and at make time for another.

## See also

- `REF-Slidev.md`. The pattern this skill instantiates.
- `THEMING.md`. The organisation's identity, its source in the design hub, and the script that stamps it into every press template, this layout included.
- `REF-CSD.md`. Trust Calibration applied to visual artifacts.
- `REF-Authoring.md` §2. Portability rules. The layout is generic and the identity is stamped; the skill itself works in any context.
- `bootstrap-starlight`. Sister skill scaffolding documentation sites with a similar structure.
