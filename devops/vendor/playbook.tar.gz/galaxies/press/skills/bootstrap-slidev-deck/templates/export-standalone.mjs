#!/usr/bin/env node
/**
 * Export this deck to ONE self-contained .html that opens offline by double-click.
 *
 * `slidev build` produces a multi-file site that needs a web server: opened over
 * file:// it shows Slidev's own 404 page, with no fonts and no images. Four things
 * have to change, and none of them is deck-specific:
 *
 *   1. public/ assets are inlined by hand. Vite never touches public/ - absolute
 *      paths like /fonts/x.ttf survive the build and resolve to the FILESYSTEM
 *      ROOT over file://. Every one becomes a base64 data: URI here.
 *   2. One bundle. Slidev sets manualChunks itself, which conflicts with
 *      inlineDynamicImports, so it is cleared in an outputOptions hook - merging
 *      Vite config is not enough.
 *   3. routerMode: hash. The history-mode router cannot match a file:// path.
 *   4. The jsdelivr favicon is neutralized in BOTH the <head> and the JS bundle,
 *      where Slidev's runtime re-applies it. Patch only the head and the file
 *      still makes a network call on open.
 *
 * The deck's own sources are never modified: everything happens in a throwaway
 * copy under .standalone-build/.
 *
 * Usage:  npm run export:standalone [-- --out deck.html] [--max-asset-mb 8]
 *                                   [--skip-large] [--no-verify] [--keep] [--force]
 */

import { execFileSync } from "node:child_process"
import fs from "node:fs"
import path from "node:path"
import process from "node:process"

const DECK = process.cwd()
const BUILD = path.join(DECK, ".standalone-build")

const MIME = {
    ".ttf": "font/ttf", ".otf": "font/otf", ".woff": "font/woff", ".woff2": "font/woff2",
    ".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".gif": "image/gif",
    ".webp": "image/webp", ".avif": "image/avif", ".svg": "image/svg+xml", ".ico": "image/x-icon",
    ".mp4": "video/mp4", ".webm": "video/webm", ".mp3": "audio/mpeg", ".wav": "audio/wav",
    ".pdf": "application/pdf", ".json": "application/json", ".txt": "text/plain",
}
const TEXT_EXT = new Set([".md", ".css", ".vue", ".ts", ".js", ".mjs", ".json"])
const SKIP_DIRS = new Set(["node_modules", "dist", ".standalone-build", ".slidev", ".git"])

// ---------------------------------------------------------------------------

const argv = process.argv.slice(2)
const flag = n => argv.includes(n)
const opt = (n, d) => { const i = argv.indexOf(n); return i >= 0 && argv[i + 1] ? argv[i + 1] : d }

const pkg = JSON.parse(fs.readFileSync(path.join(DECK, "package.json"), "utf8"))
const outFile = path.resolve(DECK, opt("--out", `${pkg.name || "deck"}.html`))
const maxAssetBytes = Number(opt("--max-asset-mb", "8")) * 1024 * 1024

const say = (...a) => console.log(...a)
const die = m => { console.error(`\nexport-standalone: ${m}\n`); process.exit(1) }

// A deck that already has its own Vite config would have it replaced in the build
// copy, silently changing how the deck builds. Refuse rather than guess.
const ownConfig = ["vite.config.ts", "vite.config.js", "vite.config.mjs"]
    .find(f => fs.existsSync(path.join(DECK, f)))
if (ownConfig && !flag("--force")) {
    die(`this deck has its own ${ownConfig}, which the standalone build would replace.\n`
        + `  Merge its build options into the generated config, then re-run with --force.`)
}

// --- 1. throwaway copy of the deck -----------------------------------------

fs.rmSync(BUILD, { recursive: true, force: true })
fs.mkdirSync(BUILD, { recursive: true })
for (const entry of fs.readdirSync(DECK, { withFileTypes: true })) {
    if (SKIP_DIRS.has(entry.name) || entry.name.endsWith(".html")) continue
    fs.cpSync(path.join(DECK, entry.name), path.join(BUILD, entry.name), { recursive: true })
}
// junction, not copy: node_modules is the one thing worth not duplicating, and
// 'junction' is the symlink flavour Windows allows without elevation.
fs.symlinkSync(path.join(DECK, "node_modules"), path.join(BUILD, "node_modules"),
    process.platform === "win32" ? "junction" : "dir")

// --- 2. inline every public/ asset -----------------------------------------

function walk(dir, base = dir, out = []) {
    if (!fs.existsSync(dir)) return out
    for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
        // Pruned during the descent, not filtered after: node_modules is a junction
        // here, and walking it is both pointless and a way to chase a link loop.
        if (SKIP_DIRS.has(e.name) || e.isSymbolicLink()) continue
        const p = path.join(dir, e.name)
        if (e.isDirectory()) walk(p, base, out)
        else out.push({ file: p, rel: path.relative(base, p).split(path.sep).join("/") })
    }
    return out
}

const assets = walk(path.join(BUILD, "public"))
    .filter(a => !a.rel.endsWith(".gitkeep"))
    .map(a => ({ ...a, webPath: "/" + a.rel, size: fs.statSync(a.file).size }))
    // Longest first: /fonts/a.ttf must not be rewritten by a shorter prefix.
    .sort((a, b) => b.webPath.length - a.webPath.length)

const large = assets.filter(a => a.size > maxAssetBytes)
if (large.length && !flag("--skip-large")) {
    die(`${large.length} asset(s) exceed --max-asset-mb ${maxAssetBytes / 1024 / 1024}:\n`
        + large.map(a => `    public${a.webPath}  (${(a.size / 1024 / 1024).toFixed(1)} MB)`).join("\n")
        + `\n  Base64 adds about a third to each. Either raise --max-asset-mb, or pass`
        + `\n  --skip-large to leave them external (the .html is then NOT self-contained).`)
}

const textFiles = walk(BUILD).filter(f =>
    TEXT_EXT.has(path.extname(f.rel))
    && !f.rel.startsWith("public/")
    && !path.basename(f.rel).startsWith("package"))

let rewrites = 0
const inlined = []
for (const a of assets) {
    if (a.size > maxAssetBytes) continue
    const uri = `data:${MIME[path.extname(a.rel).toLowerCase()] || "application/octet-stream"}`
        + `;base64,${fs.readFileSync(a.file).toString("base64")}`
    let hits = 0
    for (const t of textFiles) {
        const before = fs.readFileSync(t.file, "utf8")
        if (!before.includes(a.webPath)) continue
        fs.writeFileSync(t.file, before.split(a.webPath).join(uri))
        hits += before.split(a.webPath).length - 1
    }
    if (hits) { rewrites += hits; inlined.push(a) }
}
say(`  inlined ${inlined.length}/${assets.length} public asset(s), ${rewrites} reference(s)`)
for (const a of assets) {
    if (inlined.includes(a)) continue
    say(a.size > maxAssetBytes
        ? `  LEFT EXTERNAL (over the size cap): public${a.webPath}  <- breaks self-containment`
        : `  unreferenced, not inlined: public${a.webPath}`)
}

// --- 3. frontmatter: hash router, no PDF step ------------------------------

const slidesPath = path.join(BUILD, "slides.md")
const slides = fs.readFileSync(slidesPath, "utf8")
const fm = /^---\r?\n([\s\S]*?)\r?\n---/.exec(slides)
if (!fm) die("slides.md has no frontmatter block")
const body = fm[1].split(/\r?\n/).filter(l => !/^\s*(routerMode|download)\s*:/.test(l)).join("\n")
fs.writeFileSync(slidesPath,
    `---\n${body}\ndownload: false\nrouterMode: hash\n---` + slides.slice(fm.index + fm[0].length))

// --- 4. single-bundle Vite config ------------------------------------------

fs.writeFileSync(path.join(BUILD, "vite.config.ts"), `import { defineConfig } from "vite"

// Generated by export-standalone.mjs. Everything Vite can inline, it inlines, and
// the whole app lands in one chunk. Slidev sets manualChunks itself, which
// conflicts with inlineDynamicImports, so it has to be cleared in the
// outputOptions hook - merging config is not enough.
export default defineConfig({
    build: {
        assetsInlineLimit: 100 * 1024 * 1024,
        cssCodeSplit: false,
        chunkSizeWarningLimit: 100000,
    },
    plugins: [{
        name: "single-file-bundle",
        enforce: "post",
        outputOptions(options) {
            return { ...options, inlineDynamicImports: true, manualChunks: undefined }
        },
    }],
})
`)

// --- 5. build ---------------------------------------------------------------

// Slidev's JS entry, run by this same node. Not `npx`: on Windows that is a .cmd,
// which Node refuses to spawn without a shell (EINVAL) since 18.20/20.12/22.
const slidev = path.join(DECK, "node_modules", "@slidev", "cli", "bin", "slidev.mjs")
if (!fs.existsSync(slidev)) die("@slidev/cli not found in node_modules. Run `npm install` first.")

say("  building (this takes a minute) ...")
execFileSync(process.execPath, [slidev, "build", "slides.md", "--base", "./"],
    { cwd: BUILD, stdio: ["ignore", "ignore", "inherit"] })

// --- 6. fold the bundle into the HTML --------------------------------------

const dist = path.join(BUILD, "dist")
let html = fs.readFileSync(path.join(dist, "index.html"), "utf8")
const jsTag = /<script type="module"[^>]*src="\.\/(assets\/[^"]+)"><\/script>/.exec(html)
const cssTag = /<link rel="stylesheet"[^>]*href="\.\/(assets\/[^"]+)">/.exec(html)
if (!jsTag || !cssTag) die("could not find the built asset tags in dist/index.html")

let js = fs.readFileSync(path.join(dist, jsTag[1]), "utf8")
let css = fs.readFileSync(path.join(dist, cssTag[1]), "utf8")

// The default favicon is a CDN URL, set in the head AND re-applied at runtime from
// inside the bundle. Miss the second and the file still hits the network on open.
const CDN = /https:\/\/cdn\.jsdelivr\.net\/[^"'\s)]+favicon\.png/g
const icon = inlined.find(a => /logo|icon|favicon/i.test(a.rel) && /^\.(png|svg|ico)$/.test(path.extname(a.rel)))
const iconUri = icon
    ? `data:${MIME[path.extname(icon.rel)]};base64,${fs.readFileSync(icon.file).toString("base64")}`
    : "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg'/%3E"
// EVERY replacement below passes a FUNCTION, never a replacement string. A minified
// bundle contains `$&` and `$'` sequences, which String.replace expands as patterns:
// pass the bundle as a string and its own `$&`s become copies of the <script src=...>
// tag being replaced - corrupt JS, and an external fetch quietly restored.
js = js.replace(CDN, () => iconUri)
html = html.replace(/<link rel="icon" href="[^"]*">/, () => `<link rel="icon" href="${iconUri}">`)

// A literal </script or </style inside a string would close the tag early.
html = html
    .replace(jsTag[0], () => "<script type=\"module\">\n" + js.replaceAll("</script", "<\\/script") + "\n</script>")
    .replace(cssTag[0], () => "<style>\n" + css.replaceAll("</style", "<\\/style") + "\n</style>")

// Post-condition, checked before anyone is told this worked: nothing may still point
// at a built asset. Over file:// an external module is CORS-blocked and the deck
// renders as a blank page, which is silent unless something asserts it here.
const leftover = [...new Set(html.match(/(?:src|href)="\.?\/?assets\/[^"]+"/g) || [])]
if (leftover.length) {
    die(`the bundle is still referenced as an external file, so the export is broken:\n`
        + leftover.map(l => `    ${l}`).join("\n"))
}

fs.writeFileSync(outFile, html)
const mb = fs.statSync(outFile).size / 1024 / 1024
say(`\n  ${path.relative(DECK, outFile)}  ${mb.toFixed(2)} MB`)
if (mb > 25) say("  WARNING: over 25 MB. Browsers get sluggish; consider --max-asset-mb.")

// What is left that points outward. Links the audience clicks are fine; anything
// the page FETCHES on load is not, and the headless check below is what proves it.
const INERT = [/^https?:\/\/(www\.)?w3\.org/, /vuejs\.org\/error-reference/, /github\.com\/slidevjs/,
    /^https:\/\/sli\.dev/, /plantuml\.com/]
const links = [...new Set(html.match(/https?:\/\/[^\s"'<>)`]{4,90}/g) || [])]
    .filter(u => !INERT.some(re => re.test(u)))
if (links.length) {
    say(`\n  ${links.length} external link(s) remain (clicked, not fetched):`)
    for (const u of links.slice(0, 12)) say(`    ${u}`)
}

// --- 7. prove it needs nothing ---------------------------------------------

if (!flag("--no-verify")) {
    let browser
    try {
        const { chromium } = await import("playwright-chromium")
        const { pathToFileURL } = await import("node:url")
        browser = await chromium.launch()
        const page = await browser.newPage({ viewport: { width: 1280, height: 720 } })
        const blocked = [], failed = []
        page.on("requestfailed", r => failed.push(r.url()))
        // Anything that is not the file itself is refused outright. If the deck still
        // renders, it is genuinely offline - that is the whole claim being tested.
        await page.route("**", r => {
            const u = r.request().url()
            if (u.startsWith("file:") || u.startsWith("data:") || u.startsWith("blob:")) return r.continue()
            blocked.push(u); return r.abort()
        })
        const url = pathToFileURL(outFile).href
        await page.goto(url, { waitUntil: "load", timeout: 30000 })
        await page.waitForSelector("#slide-content, .slidev-layout, h1", { timeout: 20000 })
        await page.waitForTimeout(1500)
        const title = await page.title()
        const painted = await page.evaluate(() => document.getElementById("app")?.innerHTML.length ?? 0)

        // Every slide, not just the cover: an asset that is referenced but absent
        // only shows up when the slide holding it actually mounts. One `src:` import
        // per page, plus slides.md's own frontmatter slide.
        const slideCount = (fs.readFileSync(path.join(DECK, "slides.md"), "utf8")
            .match(/^src:\s*\.\//gm) || []).length + 1
        for (let n = 2; n <= slideCount; n++) {
            await page.goto(`${url}#/${n}`, { waitUntil: "load", timeout: 30000 })
            await page.waitForTimeout(700)
        }

        const missing = [...new Set(failed)].filter(u => !blocked.includes(u))
        say(`\n  verified offline: rendered "${title}" (${painted} chars of DOM), ${slideCount} slides walked`)
        say(`    network calls attempted: ${new Set(blocked).size}`)
        for (const u of missing) say(`    MISSING FILE: ${u}  (referenced, but not in public/)`)
        if (blocked.length) {
            for (const u of [...new Set(blocked)].slice(0, 5)) say(`    WOULD FETCH: ${u.slice(0, 100)}`)
            say("    ^ NOT self-contained: those are fetched when the file is opened")
            // Much the commonest cause, and not something this script may fix on its
            // own: forcing the opt-out would silently change the deck's typography.
            if ([...blocked].some(u => /fonts\.(googleapis|gstatic)\.com/.test(u))) {
                say("      Slidev fetches webfonts from Google unless the deck opts out. Add")
                say("        fonts:")
                say("          provider: none")
                say("      to slides.md frontmatter, and drop the faces you want into")
                say("      public/fonts/ referenced from style.css - those DO get inlined.")
            }
        }
    } catch (e) {
        say(`\n  VERIFY FAILED: ${e.message.split("\n")[0]}`)
        say("    The .html was written, but it did not render offline. Do not ship it.")
        process.exitCode = 1
    } finally {
        // Without this an orphaned browser keeps the process alive forever.
        await browser?.close()
    }
}

if (!flag("--keep")) fs.rmSync(BUILD, { recursive: true, force: true })
else say(`\n  build copy kept at ${path.relative(DECK, BUILD)}`)
