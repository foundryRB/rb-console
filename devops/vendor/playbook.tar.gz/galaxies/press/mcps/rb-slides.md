---
name: rb-slides
galaxy: press
refs:
  - REF-Slidev
---

# MCP: rb-slides

> Knock here to draft, argue, and version a Slidev deck, and to publish it through its gate into the git-backed library.

The slides engine's door. A deck lives ephemeral (expires once left untouched), draft (kept), or published (reached only through the publish gate); each version is immutable and the argument is recorded against the version it was made on.

## Doctrine

- Revise rather than overwrite: a revision starts the next version and never touches the ones before it, and restoring an earlier version copies it forward as a new one.
- An annotation stays on the version it was written against; an open annotation on the current version blocks the publish until it is resolved.
- Publish only when the gate holds: the argument recorded (an annotation, or two versions carrying notes), no open annotation on the current version, the theme check passing and a verified PDF export on the current version, and the entry fields set (audience, subject, presented date, what the deck argued). Read the gate first; a publish that misses any row is refused.
- Git is the library's record: a publish builds the deck and commits its source and its built site together. A published deck is never revised, edited, or deleted; a newer deck that supersedes it retires it.
