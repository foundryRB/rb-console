---
name: rb-plans
galaxy: press
refs:
  - REF-Plan
---

# MCP: rb-plans

> Knock here to create and steer a project plan: its dataset stored as immutable versions, items, decisions, status flips, and log rows written one at a time, and the self-contained file exported for the caller to save.

The plans engine's door. A plan is one `REF-Plan` dataset; every write through any of the engine's doors lands as the plan's next version, so a write here is visible in the cockpit and the API.

## Doctrine

- Nothing is edited in place: every earlier version stays readable, a correction is a further write, and a reversed decision is a new log row citing the old (`REF-Plan.md` §3).
- The engine serves the §3 schema unchanged and assigns the version stamp itself; a dataset that does not conform is refused with every reason.
- The engine checks the shape and that every edge resolves, not the order or the calendar: a re-anchor moves dates by calendar days. Run the `bootstrap-plan` audit over the exported file and land each finding as the next write before the plan goes to its readers.
- A session's capture lands here as decision fields, status flips, and log rows under the plan's item ids verbatim, each decision with the named person or role who took it.
- The export is the `bootstrap-plan` renderer's self-contained file for one version, returned for the caller to save; reads and exports never change the store.
