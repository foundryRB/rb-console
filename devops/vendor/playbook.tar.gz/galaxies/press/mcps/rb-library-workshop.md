---
name: rb-library-workshop
galaxy: press
refs:
  - REF-Flyer
---

# MCP: rb-library-workshop

> Knock here to draft, argue, and version one-page flyers; publishing exports the finalized file for the caller to commit into the git-backed library.

The flyer workshop's door. An artifact is a whole self-contained flyer that lives ephemeral (expires) or draft (kept); each revision is immutable and the argument is recorded on the version.

## Doctrine

- The workshop holds only in-progress work: publish is a read-only export that returns the finalized flyer and its slug for the caller's git commit; it never mutates the store.
- Draft where the argument belongs: revise and annotate in the workshop rather than re-drafting locally; the published file is byte-identical to the workshop version.
