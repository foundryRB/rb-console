---
name: rb-notes
galaxy: press
refs:
  - REF-MoM
---

# MCP: rb-notes

> Knock here to draft, argue, and version the minutes of a meeting until they are sent, and to find sent minutes in the library by who was there, when, or what they were about.

The notes engine's door. A note is one `REF-MoM` dataset in the workshop, ephemeral or draft, each revision an immutable version, until it is sent into the library.

## Doctrine

- Minutes that cover several sessions accumulate them in one note, never a second note beside it. Recording a further session into the unsent note appends its outcomes and actions, folding only action rows with the same owner and action, and mints no version: a revision before the send consolidates the note to the shape `REF-MoM.md` sets, its context, its outcomes (§2) and its actions (§3).
- Annotations are the team's argument: they attach to an unsent note's outcome or action row and never enter the sent artifact.
- Send freezes the note: only a draft with a version is sent, its artifact is rendered once and kept byte for byte, and only a send writes the library. A sent note is immutable; a correction is a follow-up note linked to it.
- The artifact, the email export, and its subject all come from the `write-mom` renderer over the dataset; the subject is derived, never typed.
- A link to a plan item holds the plan's item id and nothing else of the plan.
