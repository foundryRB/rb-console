---
name: vf-workshops
galaxy: press
refs:
  - REF-Workshop
---

# MCP: vf-workshops

> Knock here to author, revise, and run working sessions: each session dataset kept with every revision, each run's capture landed as the room records it, and the standalone file and the plan-shaped capture exported.

The workshops engine's door. A session is one `REF-Workshop` dataset on a shelf where it stands ephemeral, draft, or published; a run is a rehearsal or the session itself over one revision, with its own capture. Every door of the engine enters the same use cases, so a write here is visible in the UI and the API.

## Doctrine

- Every session write, a new session or a revision, is validated against the whole §3 schema, and a dataset that breaks a rule is stored by no door: the refusal names the rule, and the fix is the dataset.
- A revision is appended and never rewritten, and the shelf only moves forward: a correction is the next revision, never an edit to one already stored.
- Rehearse and run as separate runs: a rehearsal's capture never reaches the session that follows it, and a run's kind is fixed when it starts.
- Close a run when the room is done, never before: the close freezes its capture and its artifact, and every later write to that run is refused. The session stands as run (`REF-Workshop.md` §4).
- The capture reaches the plan through the plan export, each item under the plan's item id verbatim; land it in the plan through the plan's own door, never by retyping it.
- The export is the `bootstrap-workshop` renderer's standalone file for that revision, byte for byte; publishing writes it to the git-backed home and leaves every revision, run, and capture as it was.
