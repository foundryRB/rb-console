---
domain: framework
---

# REF: Commercial Brief (the First Page on a Request)

> Read this when a request, an opportunity or an idea needs its first page: a brief that plays back what was asked, shows how the thing works today and where it breaks, puts a proposed solution on the table, and names everything still open, so the requester can correct the understanding before anything is scoped. It is written from the request and the author's understanding alone; the page itself is a brief per `REF-Flyer.md`.

---

## 1. What a commercial brief is

A commercial brief is the first page written on a request: a customer's ask, an opportunity, an internal idea. Its reader is the person who asked, and whoever they pass the page to. They read it to answer three questions: was I understood, what would you do about it, and what do you still need from me.

- It comes first. It is written from the request and the author's understanding, before a scope, an estimate, a plan, or a design exists, and it needs none of them. Whoever scopes the work reads the brief; the brief never reads the scope.
- It commits to nothing. It carries no price, no effort figure, and no delivery date, and its masthead says it is a concept (§2). The proposal that follows a scope carries the commitments.
- It is made to be corrected. A wrong reading of the request costs least on this page, so the page shows its understanding plainly enough to be contradicted.
- It is a page. The frame, the identity, the figures, and the copy rules are a brief's, per `REF-Flyer.md` §1; this REF fixes only what the page says.

## 2. The spine

Under the masthead, four sections in a fixed order, each always present. A section the author cannot fill says what is missing and lists it in the open points.

| Section | The reader's question | Leads with |
|---|---|---|
| Masthead | What is this page? | The claim in the reader's own terms, then one status line: that it is a concept, its version, its date |
| Context | What did you hear? | The request restated item by item, in the requester's words |
| Problem | How does it work today, and where does it break? | A figure of today's path with each break marked (`REF-Flyer.md` §6) |
| Solution | What do you propose? | A figure of the parts and what moves between them, with a status channel separating what exists from what is to be built (`REF-Flyer.md` §6) |
| Open points | What is still unsettled, and what do you need from me? | The points grouped by kind, each with who closes it and, when one is known, a date; then, when there is one, the hand-over asked of the requester |

A commercial brief always carries the brief's contents (`REF-Flyer.md` §3): one entry for each section of the spine and for each optional section, in page order.

### Open points

An open point is something one named person can close. "To be discussed" and "pending alignment" are not open points. Each point is one of three kinds, and the page groups them by kind so the requester sees at once which are theirs.

| Kind | What it is | Written as |
|---|---|---|
| A question for the requester | Something only the requester, or a person they name, can answer | A question |
| A reading to confirm | An assumption (§4): the author has taken an answer as given | The answer assumed, as a statement, for the requester to confirm or correct. Never a question: a question hides what was assumed |
| The author's to work out | Something the author owes the page: the basis of a number, the limits of the proposal | What is to be worked out, under the author's name. It is never put to the requester |

- Check each question against what was heard before it goes on the list. A question the request already answers is not asked again.
- What the requester has to hand over is one action, never a scatter of questions: who hands what to whom, by when, and in what state. Under it, the items as a list a person can tick, each named as the requester would name it and saying what it holds. Where something asked for does not exist, the item names what exists in its place.

## 3. Optional sections

A section below is added only when the reader's question needs it, between the solution and the open points. Each is written from the same understanding as the spine and marked indicative.

| Section | Carries | Stops short of |
|---|---|---|
| Today and proposed | One row per dimension that changes, with who gains | A benefit with no mechanism behind it |
| How it would go | The phases in order, and what each one leaves working | Dates and durations |
| Commercial shape | The levers that move the cost, and the options on each | A price, an effort figure, a margin |
| What it could look like | A screen or a document sketched on the page's own tokens, labelled a sketch | A design |

Nothing in a brief is lifted from an estimate, a plan, or a prototype. A brief that waits for one of them has stopped being the first page.

## 4. Heard, assumed, proposed

Every statement in a brief is one of three kinds, and the reader can tell which without asking.

| Kind | What it is | Where it lives |
|---|---|---|
| Heard | The requester said or wrote it | Context, and the facts of the problem; kept in the requester's terms and traceable to the request or a session |
| Assumed | The author believes it and has not confirmed it | Wherever it is needed, under one marked treatment the legend declares (`REF-Flyer.md` §6), and again in the open points as a reading to confirm (§2) |
| Proposed | The author's judgment of what to do | Solution, and the optional sections |

- Context holds heard statements only. A restatement in the author's solution vocabulary has become a proposal.
- An assumption written as a fact is the defect this rule prevents: a reader cannot correct what they cannot see was guessed.
- A number is the requester's, quoted, or it is marked indicative.

## 5. Versions

A brief changes as the understanding does, and each change is a whole version of the page.

- An answered open point moves into the section it changes: the context gains what was heard, a figure is redrawn when the mechanism changed, and the point leaves the open list. Answers are never appended beneath the page they answer.
- The masthead's status line carries the version and its date. Where a flyer workshop is connected, the versions are kept there (`REF-Flyer.md` §9).
- The open list is the brief's own measure of readiness: what remains on it is what a scope would have to guess.

## 6. Cross-references

- `REF-Flyer.md`: the page a brief is written on. Frame, identity tokens, legend, figures, copy rules, and verification live there.
- `REF-Workshop.md`: a session is one way to answer open points; the open list supplies its questions.
- `REF-Delivery.md`: the delivery line that scopes the work. Its scope reads the brief.

## 7. Anti-patterns

| # | Anti-Pattern | Correct Approach |
|---|---|---|
| 1 | A section assembled from an estimate, a plan, or a prototype, or a brief held back until one exists | The brief comes first, written from the request and the author's understanding (§1, §3) |
| 2 | A price, an effort figure, or a delivery date on the page | Levers and order only, marked indicative; the proposal carries the commitments (§1, §3) |
| 3 | Context rewritten in the author's solution vocabulary | Context is what was heard, in the requester's terms (§4) |
| 4 | An assumption stated as a fact | Mark it, and list it in the open points as a reading to confirm (§2, §4) |
| 5 | Open points nobody can close: "to be discussed", "pending alignment" | Each names one person who can close it (§2) |
| 6 | A version that appends the answers beneath the previous page | Revise the sections the answers change, and shorten the open list (§5) |
| 7 | A problem or a solution told in prose with no figure, or a solution figure that does not separate what exists from what is to be built | One figure each, drawn per `REF-Flyer.md` §6, with the status channel (§2) |
| 8 | A spine section dropped because the author could not fill it | Keep the section, say what is missing, and list it in the open points (§2) |
| 9 | A hand-styled page with its own palette | The flyer frame and its tokens, scaffolded (`REF-Flyer.md` §3, §4) |
| 10 | An assumption listed as a question | State the answer assumed, for the requester to confirm or correct (§2) |
| 11 | A question put to the requester that the author has to answer, or that the request already answers | The first is the author's to work out, under the author's name; the second is not asked (§2) |
| 12 | Material asked for across several questions, or as "send what you have" | One action with who, to whom, by when and in what state, and a list of named items under it (§2) |
| 13 | Section links in the masthead, or no contents at all | The brief's contents, one entry per section (§2, `REF-Flyer.md` §3) |

---

## 8. Skills that instantiate this REF

Generated by `scripts/sync_backlinks.py` from skill frontmatter; do not edit by hand.

Skills whose frontmatter `refs:` includes `REF-CommercialBrief`:

- `write-commercial-brief` - Write or revise a commercial brief per REF-CommercialBrief, the first page on a request, from the request and the author's understanding before anything is scoped: sort what is in hand into heard, assumed and proposed, draw today's path and the proposed solution as figures, and fill the fixed spine (context, problem, solution, open points) on the brief bootstrap-flyer scaffolds, with every open point something a named person can close and the requester's hand-over as one action with its list.
