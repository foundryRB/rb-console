---
domain: framework
---

# REF: Flyer (Self-Contained HTML/CSS Sheets and Briefs)

> Read this when producing a single self-contained HTML/CSS page (a flyer), as a one-sheet leave-behind or as a longer brief a reader works through to discuss or decide: hostable and printable, the standalone sibling of the Slidev deck. AI hand-laying-out a page drifts, and a page can hold its frame and still show its reader nothing; the cure is the reader's question first, then a fixed desk/sheet skeleton, a locked token palette, a three-role type system, and figures that draw the mechanism.

---

## 1. Why a flyer (vs a Slidev deck)

A flyer and a Slidev deck (`REF-Slidev.md`) are the two shapes plaintext-source visual artifacts take here. Pick by consumption, not by content:

| You want | Reach for | Because |
|---|---|---|
| One page, read at a glance, that also prints clean | **Flyer, as a sheet** (this REF) | A single sheet of A4; no next-slide |
| A subject a reader works through to discuss or decide: several sections, a figure wherever a mechanism has to be seen | **Flyer, as a brief** (this REF, "Sheet and brief" below) | One scrolling page that paginates in print; as many figures as the question turns on |
| A sequence walked through in order | **Slidev deck** (`REF-Slidev.md`) | Progressive reveal, one idea per slide, presenter flow |

A flyer is a one-pager, a leave-behind, a spec sheet, a brief: the thing you hand someone, pin to a wall, or put on the table of a discussion. It is a single self-contained `.html` file with no build step, no framework, and no external requests, so it renders identically as a hosted page, as a saved file opened from disk, and as a printed document. That triple target (host, open, print) is the whole point; an artifact that needs a presenter clicking through it is a deck, not a flyer.

Same reasoning as `REF-Slidev.md` §1 for plaintext over PowerPoint: diffable source, no lock-in, reproducible (same file renders the same everywhere).

### Sheet and brief

A flyer has two lengths, and the reader's question picks between them before anything is scaffolded (§8, §10).

| | Sheet | Brief |
|---|---|---|
| The reader | glances, keeps, pins up | works through it, discusses, decides |
| Length | one A4 sheet; cut until it fits (§8) | the sections the question needs and no more; scrolls on screen, paginates in print (§7) |
| Figures | at most one (§6) | one in each section that has a mechanism to show (§6) |
| Contents | none; a sheet has nothing to navigate | once the page runs past about two screens, contents that stay on screen and mark the part being read (§3) |

Both wear the same identity and its tokens (§4), the same type roles (§5), the same legend and figure rules (§6), the same self-containment and ASCII encoding (§7), and the same copy rules (§8).

The test is what the reader asked to see. When holding one sheet would cut the figure, the table, or the decision list the reader came for, the page is a brief. A sheet that drops its subject to keep its format has failed at the one thing a page is for.

### When to reach for one

The trigger is not only an explicit request for a flyer. When a conversation produces something the reader will want to *keep*, a concept, a mental model, an architecture, a decision and its rationale, that durable one-pager is a flyer, and offering one is the same reflex as codifying a decision into a REF. Reach for this pattern proactively then, through the workshop of §9, rather than waiting to be asked or reaching for a generic page builder. A flyer is the right shape precisely when the value is a single page someone returns to.

## 2. The visual-validation problem

AI generates a page without rendering it, and a flyer's correctness is *visual*: does the grid hold, does the sheet stay on one page, does the palette read as one system. Left to lay out from scratch, AI produces inconsistent spacing, ad-hoc colors, and grids that scroll sideways on a phone. The cure is the same as `REF-Slidev.md` §2: constraints that participate in execution, not documentation. Here the constraint mechanism is a fixed skeleton plus a locked token set, authored once (§3 to §6) and only filled with content, never re-derived per flyer.

A second failure sits beside the first: a page can hold its frame perfectly and show its reader nothing. The frame is verified by rendering it; the content is verified against the reader's question (§10). Obeying the frame is never the goal, and no frame rule outranks what the reader came to see.

## 3. The desk and the sheet

Every flyer is a **sheet** centered on a **desk**, using the identity's surface and canvas tokens. The desk is the browser chrome; the sheet is the document. On screen the document frame aligns with its host's navigation and collection; in print the desk is stripped and only the sheet remains (§7).

```
.desk    full-viewport background in the canvas token, a responsive gutter,
         the page's font + ink color
  .sheet centered document in the surface token, bounded to one maximum width,
         a fine paper edge, one soft shadow, responsive padding
```

Fixed rules:

| Element | Rule | Why |
|---|---|---|
| `.desk` | fills the viewport in `--desk`, with a gutter that scales with the viewport | The mat the sheet rests on |
| `.sheet` | centered, full width up to one maximum | A bounded screen frame aligned with the collection and navigation |
| prose | a reading measure on direct section paragraphs, independent of the frame; figures, tables and grids use the full frame | Reading measure belongs to text, never to a figure |
| `.sheet` | one soft, low, single shadow and a fine edge in `--line` | Lifts the sheet off the desk; a paper edge, never a hard box |
| `.sheet` | padding that scales with the viewport | Breathing room |
| entry | one subtle entrance, gated by `prefers-reduced-motion` | A single tasteful entrance; nothing that distracts on reread |

The sheet holds a masthead, then stacked `section` blocks, then a footer. A host may place its navigation outside the document. Print rules reset the screen width and padding to the printable A4 area (§7).

**The template is the single home of the frame's values.** The maximum width, the measure, the paddings, the radius, the shadow, the motion, the breakpoints, and the print block live in the scaffold's template (`bootstrap-flyer`), beside the palette block the maintenance script embeds (§4). This REF states what the frame must do and restates none of its numbers, so a change to the look is a change to the template and to nothing else.

### A brief's contents

A reader working through a brief has to know where they are and reach any part of it in one step. Once a brief runs past about two screens it carries its contents on the page. A sheet never does: it is read at a glance and has nothing to navigate.

| Rule | Meaning |
|---|---|
| **Always on screen** | The contents stay in view while the page scrolls: a rail beside the sections where the window has room for both, a bar pinned to the top where it has not. The frame widens for the rail, so the figures keep their size. Links in the masthead scroll away with it and are not contents |
| **The part being read is marked** | One entry is current, taken from the scroll position, so it behaves the same when a host frames the page |
| **Sections, then their parts** | One entry per section, numbered as the section's eyebrow is; the rail lists the parts of a section under it, the bar lists sections only. An entry names what the reader finds there in a few words |
| **In step with the page** | Every entry points at an id on the page, and every section has an entry. A section that is cut takes its entry with it |
| **Never in print** | Paper has page order; the print block leaves the contents out (§7) |

The contents ship with the brief length of the scaffold (`bootstrap-flyer --brief`), with the widths at which the rail gives way to the bar. Marking the current entry is the one script a brief carries, inline (§7); with script off the entries are still links.

## 4. The token palette

The authored template carries the palette documented in `THEMING.md`. Palette values propagate at maintenance time; the template owns its layout and typography. The values below illustrate the semantic roles.

The entire visual system is a locked set of CSS custom properties in a single `:root` block. Author it once; every color, in every flyer, is one of these. No raw hex outside `:root` except inside the print block and inside color-mixed shadows.

| Token | Identity role |
|---|---|
| `--desk`, `--sheet`, `--blueprint` | Canvas, surface, raised surface |
| `--ink`, `--muted`, `--line` | Primary text, secondary text, boundary |
| `--steel`, `--steel-2`, `--highlight` | Accessible accent/link colour for the current appearance |
| `--brand` | Brand artwork, luminous decoration and action fills |
| `--grid`, `--tint` | Transparent mixes derived from the accent and surface |

Values never appear in this REF. They come from the identity source `THEMING.md` names, the maintenance script embeds them into the template's palette block, and its check mode fails on a stale block. A palette change edits the identity source and re-runs the script; no REF and no flyer's layout changes with it. The token names above are the contract between the template and the page's CSS, and they are all an author needs.

The thesis carries the strongest content emphasis. Repeated brand marks and peripheral decoration can use the accent while content hierarchy stays clear. Use accessible link colours for small text; the artwork colour is a separate role.

## 5. The three-role type system

Three font stacks, each with one job. All are system stacks or inlined data-URI faces: **no webfont CDN links** (the Artifact CSP blocks external hosts, §7; a `<link>` to a font CDN silently fails and the page falls back ugly).

| Role | Stack (`:root` token) | Used for | Voice |
|---|---|---|---|
| **Sans** | `--sans` from the maintained identity | Headings and body: the masthead name, section bodies, everything structural | Neutral, present, the document's own voice |
| **Thesis** | `--serif` compatibility role, mapped to the identity's sans stack | Exactly one italic thesis line | A single held note; the human aside |
| **Mono** | `--mono` from the maintained identity | Uppercase eyebrows, tool labels, spec-sheet marks, doc refs, the footer | The engineering annotation: the machine talking in the margins |

Rules:

- **Sans is the default** (`.desk { font-family: var(--sans) }`). Body and headings never switch stack.
- **The thesis is a typographic role**, using the identity's face with size, spacing and optional italic emphasis. A flyer may omit a thesis.
- **Mono is the annotation layer**, never the body. Eyebrows (`text-transform:uppercase; letter-spacing:.16em`), the tiny doc reference in the masthead corner, tool and component labels, the spec baseplate, and the footer are mono. It reads as the drafting notes around the document, not the document.

## 6. Layout and grid rules

Content is uppercase-mono eyebrows over a strong type scale, arranged in responsive grids. The mechanical rules:

| Rule | How | Why |
|---|---|---|
| Eyebrows label every section | mono, uppercase, `letter-spacing:.16em`, `--muted` or `--steel` | Orientation; the spec-sheet voice |
| Strong type scale | fluid sizes for the masthead name and thesis, fixed sizes below | Fluid hero, stable body |
| **Grids never scroll sideways** | every grid child gets `min-width:0`; grids collapse to fewer columns at breakpoints | `min-width:0` defeats the flexbox/grid min-content floor that forces horizontal overflow on phones |
| One figure, one claim | a sheet carries at most one figure; a brief carries one in each section that has a mechanism to show, never two in a section | A second claim is a second section, or on a sheet a second flyer |
| Consistent breakpoints | collapse multi-column grids at the template's narrow breakpoint and drop the corner doc-ref; single-column the tightest grids at its phone breakpoint; a wide figure scrolls inside its own panel, never the page | One page on a phone, still one page on A4 |
| `text-wrap:balance` on headings | on the masthead name and thesis line | Even ragged edges without manual breaks |

The masthead pattern: a mono doc-reference pinned top-right (`position:absolute`, hidden under ~640px), a mono eyebrow, the big sans name, a one-line sans lede, closed by a hard `1.5px solid var(--ink)` rule. Sections then stack with `margin-top:clamp(...)`. The footer is a mono identity strip over a `--line` rule.

### The legend rule

Every visual distinction on the page is a **semantic channel**: a border color, a dashed versus solid edge, a fill, a label slot, a trailing annotation. Each channel carries exactly one meaning, held consistently across the whole page. Write the legend before styling ("dashed top = automatic step", "the mono subtitle = the instrument you invoke", "molten = the one human act") and then obey it:

| Rule | Meaning |
|---|---|
| **Same kind of thing, same treatment** | Three cards describing three things of one kind get one style. Variation between siblings must mark a real difference in kind, never taste |
| **Same slot, same content kind** | If a subtitle slot holds a skill name in one box, it does not hold a command in the next and a free-text aside in the third. A slot whose content kind varies has no meaning; fix the content or cut the slot |
| **A distinction that encodes nothing is removed** | Decoration-only variation reads as meaning and misleads; uniform is correct when the things are uniform |
| **An annotation appears on all siblings or none** | A trailing label present on two boxes out of five makes the reader hunt for why; if the label kind does not apply to every sibling, it does not belong in that slot |

The reader never sees the legend; they infer it in seconds. If the inference breaks anywhere ("why is this one orange?", "why is this edge dashed?"), the page is wrong, not the reader. A figure that uses several channels at once (what runs against what is proposed, a record against a signal) prints its legend once, above the first figure.

### The figure draws the mechanism

A figure earns its place when it lets a cold reader see what prose would make them assemble: which parts exist, what moves between them, where the boundary sits, what is new. A panel of boxes holding sentences is a list with borders, and it shows nothing.

| Rule | Meaning |
|---|---|
| **Draw the parts and what moves between them** | Every box is a part the reader could point at in the real system; every arrow is labelled with what travels along it (`commits the record`, `reads over the API`, `publishes an event`). An unlabelled arrow says "related somehow" |
| **Inline SVG, native shapes** | `rect`, `line`, `polyline`, `path`, `text`, sized by `viewBox` and scaled by CSS, styled through the page's token classes so the figure follows light, dark and print. No image, no library, no script (§7) |
| **Lay it on a grid** | Shared baselines, even gaps, straight arrows wherever the layout allows; coordinates are computed, never eyeballed |
| **Words in a figure are labels** | A name and at most one short line per box. Sentences go to the caption under the figure, which states the one claim the figure makes |
| **A status channel when the page proposes change** | What runs today and what is to be built get two treatments, declared in the legend, so the reader sees the size of the proposal at a glance |
| **The trace test** | Take one question the page exists to answer ("how does this number reach the screen?") and follow it through the figure with a finger. If the path cannot be followed without the prose, the figure is not drawn yet |

Choose each figure from the reader's question: where the thing sits among its neighbours (context), what is inside it (structure), how one item travels through it (a numbered path), what it holds (a data model). A brief about an architecture usually needs more than one of these, and each takes its own section.

## 7. Self-contained and print

A flyer is one file that must survive three contexts: hosted behind a URL, opened from disk, and printed. Two constraints follow.

### CSP-safe and self-contained

The flyer must render with **zero external requests**, both because its production home enforces a strict Content-Security-Policy (it works as a claude.ai Artifact, whose CSP blocks every external host: CDN scripts, external stylesheets, remote fonts, remote images, `fetch`/XHR) and because a saved file opened offline has no network.

| Rule | Consequence |
|---|---|
| No `<link>` to external CSS or fonts | System font stacks only (§5), or faces inlined as `data:` URIs |
| No external `<script>`, no CDN | A sheet needs no JS; a brief's contents carry one inline script (§3). Anything else a flyer ever needs is inlined too |
| No remote `<img src>` | Embed as `data:` URI, or draw it in CSS/SVG |
| All CSS in one `<style>` block | The file is the deliverable; nothing to fetch |

If it would not render with the network unplugged, it is not a flyer.

### ASCII-only content (encoding)

Write every separator and symbol as an **HTML entity, never as a raw non-ASCII character**: use `&middot;` for the middot, `&#9660;` for a down-triangle, `&#10003;` for a check, `&#8594;` for a right arrow. Same triple-target reason: a served page may arrive with no declared charset (the Artifact wrapper does not guarantee one, and a static host serves the file byte-for-byte), so a raw UTF-8 middot (bytes `0xC2 0xB7`) is read as Latin-1 and renders as mojibake (an A-with-circumflex followed by the middot). An entity is pure ASCII and renders correctly with or without a charset, hosted, on disk, and in print. Keep the whole file ASCII.

### The print block

A flyer prints as a clean document: the desk is scaffolding for the screen and disappears on paper. The print block ships in the template (§3) and does four things:

| The print block | Why |
|---|---|
| sets `print-color-adjust: exact` | Browsers strip backgrounds by default; the token fills have to actually print |
| sets `@page` to A4 with a margin | The sheet is the paper |
| strips the desk and the sheet's frame, shadow, radius and motion | The on-screen document becomes a plain printed page |
| switches the palette to Light | Print is an opaque, still, Light projection |

A sheet also tightens its section margins and caps its thesis size there, so a screen-tuned page still fits one sheet. A brief paginates: its figures, tables and cards carry `break-inside: avoid` so none splits across pages, a heading stays with what it heads, the contents are left out, and nothing is tightened to chase a page count.

## 8. Content rules

The visual system is fixed; the discipline is in the words.

| Rule | Meaning |
|---|---|
| **The reader's question first** | Before the frame: who reads this, what must they be able to answer or decide afterwards, and what do they have to see for that. The list of things to see picks the length (§1) and the figures (§6) |
| **A sheet is one sheet** | If a sheet does not fit, cut, do not shrink. One thesis, a few supporting blocks, one figure, done. When the cut would remove what the reader asked to see, the page is a brief (§1), never a thinner sheet |
| **A brief is as long as its question** | Every section answers part of the question and leads with its figure or table; a section that answers nothing is cut. Length is never the goal in either direction |
| **Every block takes the form of its content** | A count is a number, a set is a row of labels, a range is a bar, a sequence is steps, a before and after is two columns, a list of things to hand over is a checklist. A table is for content that has rows and columns, and a paragraph for what none of these can carry. A figure or two above a page of paragraphs and tables is still a page of prose |
| **The figure carries the structure** (§6) | The visual shows the mechanism; prose annotates it and never repeats it |
| **Tool labels in lowercase mono** | Component and tool names are consistent lowercase in the mono stack (`estimatekit`, `protopane`, `playbook`), never Titlecased or restyled per section |
| **One strongest content emphasis** (§4) | The thesis leads; repeated brand marks and ambient decoration remain subordinate |
| **NO em-dashes, anywhere** | Hard rule. Recast every em-dash with a comma, a colon, a semicolon, or two sentences. This is a standing style rule, enforced playbook-wide by the intent tests (INT-SHAPE-002) |

The no-em-dash rule is absolute: not in headings, not in body, not in labels, not in the footer. When a dash is reaching for a dramatic pause, a period is almost always better; when it joins two clauses, a semicolon or colon does the job.

## 9. Deploy: a single static file

A flyer's production home is any host that serves static files behind auth: the file *is* the unit of deploy. There is no server-side rendering and no serve-time templating, so the same self-contained file from §7 is the release, byte-identical to its claude.ai Artifact preview. That target-independence is the point; the flyer is bound to no one host.

| Fact | Consequence for authoring |
|---|---|
| One `.html` per flyer | The file *is* the unit of deploy; name it for the flyer (`<slug>.html`) |
| Served as a static asset | No server-side rendering, no serve-time templating; the file ships as authored |
| Gated at the edge | Access is controlled by the host (e.g. a sign-in proxy in front of it), never in the page; the flyer carries no auth logic |
| Same Artifact-safe file | The identical file that renders as a claude.ai Artifact is the file that deploys; author once, host anywhere |

Because the deployed artifact and the Artifact preview are byte-identical, there is no separate production build: the self-contained file from §7 is the release.

A static host deployed on the Foundry follows `REF-AppContract.md` for application admission and its chosen authentication posture.

### Drafting through a workshop

A workspace may front the static host with a *flyer workshop*: an MCP that holds in-progress flyers as versioned, argued drafts and, on publish, exports one finalized flyer to the host above. When such a workshop is connected, draft and iterate there, each revision kept and the argument recorded, then publish through it; the published file is the byte-identical self-contained artifact of §7. When no workshop is present, scaffold and author the standalone file (§10) and deploy it directly. The workshop is one path to the same static file, never a second kind of artifact.

When a flyer workshop MCP is connected, it is the authoring tool and this REF's tokens (§4) are the identity: do not build the flyer through the generic claude.ai Artifact tool or the `artifact-design` skill. That path invents a fresh per-subject palette, the opposite of a locked-token system, and it lands the file outside the workshop's versioned, argued history. The claude.ai Artifact stays a valid *render* target for the byte-identical file (§7); it is not the way to author one here.

## 10. Generation flow

1. Name the reader and the question (§8): what they must be able to answer or decide from the page, and what they have to see for that. Each mechanism on that list is a figure (§6); the list picks sheet or brief (§1).
2. Scaffold the skeleton (skill `bootstrap-flyer`): the `:root` token block (§4), the desk/sheet frame (§3), the print block (§7), a sample masthead, and one section. For a brief, scaffold the brief length (`--brief`): the same frame with the contents (§3), sections that lead with a figure, and print rules that paginate. Never hand-lay-out the frame.
3. Draw the figures first, then fill the fixed structure around them: masthead name and lede, section eyebrows and bodies, one thesis line, and clear accent hierarchy. Prose annotates a figure; it never stands in for one.
4. Distill (§8): a sheet to one page, a brief to the sections its question needs. Cut until it fits; do not scale down to cram, and do not cut what the reader asked to see.
5. Verify the frame: open the file (renders offline, glyphs not mojibake?), print-preview (a sheet on one A4 page, a brief with no figure split across pages and no contents, colors intact?), and narrow the viewport (no sideways scroll?). On a brief, scroll it at a wide and at a narrow window: the contents stay on screen and mark the part being read (§3).
6. Verify the content: run the trace test on every figure (§6), then read the page cold against the question from step 1. If the question cannot be answered from the page alone, the page is not done, whatever the frame checks say.
7. Ship: the same file deploys to any static host behind auth (§9).

This mirrors `REF-Slidev.md` §8: mechanical structure is auto-trusted (the skeleton and tokens are fixed), semantic content is human-reviewed (the words, the figures, the distillation, the one molten point).

## 11. Cross-references

- `REF-Slidev.md` - the sequential-presentation sibling; a flyer is the single-page, printable counterpart. Same plaintext-source, template-first reasoning.
- `REF-AppContract.md` - application admission and authentication obligations for a static host deployed on the Foundry.
- `REF-Documentation.md` §7 - visual-first: lead with the diagram, prose annotates. A flyer is that principle as a single artifact.

## 12. Anti-patterns

| # | Anti-Pattern | Correct Approach |
|---|---|---|
| 1 | Hand-laying-out the desk/sheet frame per flyer | Scaffold it once (`bootstrap-flyer`); fill content into the fixed skeleton |
| 2 | Raw hex colors sprinkled through the CSS | Every color is a `:root` token (§4); add a token, never a one-off hex |
| 3 | Competing primary emphases | One strongest content point; decoration stays peripheral (§8) |
| 4 | A `<link>` to a webfont CDN | System font stacks (§5) or inlined `data:` faces; the CSP blocks external hosts |
| 5 | Any external request (script, stylesheet, remote image) | Fully self-contained; embed as `data:` URI or draw in CSS/SVG (§7) |
| 6 | A grid that scrolls sideways on a phone | `min-width:0` on grid children; collapse columns at breakpoints (§6) |
| 7 | Two or more figures on one sheet, or two in one section of a brief | One figure, one claim: a sheet carries one, a brief one per section (§1, §6) |
| 8 | Shrinking type to fit more onto the page | Cut content until it fits one sheet; do not scale down (§8) |
| 9 | No print block, or a print that keeps the desk | Ship the `@page` / `print-color-adjust` block; strip the desk on paper (§7) |
| 10 | An em-dash anywhere in the copy | Recast with a comma, colon, semicolon, or two sentences (§8). Hard rule |
| 11 | Tool names Titlecased or restyled per section | Consistent lowercase mono labels (§8) |
| 12 | Picking the length from habit: a sheet stretched past one page, or a brief where a glance would do | The reader's question picks it (§1): a glance is a sheet, a discussion is a brief, a presenter's sequence is a Slidev deck |
| 13 | A raw non-ASCII glyph in the copy (a bare middot, triangle, or arrow) | Use its HTML entity (`&middot;`, `&#9660;`, `&#8594;`); a served page with no charset renders raw bytes as mojibake (§7) |
| 14 | Styling variation that encodes nothing: an accent border here, a dashed edge there, a subtitle slot holding a different kind of content per box | Write the legend first; one meaning per channel, one treatment per kind, one content kind per slot (§6) |
| 15 | Authoring a flyer through the generic claude.ai Artifact tool or the `artifact-design` skill (a fresh per-subject palette) | The identity is this REF's locked tokens (§4); when a flyer workshop MCP is connected, author and version there (§9). The Artifact is a render target, not the authoring path |
| 16 | A figure that is a panel of boxes holding sentences, or arrows with no labels | Draw the parts and label what moves between them; run the trace test (§6) |
| 17 | Cutting the figure, the table, or the decision list the reader asked for so the page holds one sheet | The reader's question picks the length; that page is a brief (§1, §8) |
| 18 | Starting from the scaffold and filling whatever fits | Start from the reader and the question; the list of things they must see comes before the frame (§8, §10) |
| 19 | Restating the template's values (widths, paddings, hex colours, the print CSS) in this REF or in notes beside a flyer | The template is their single home and the identity source is the palette's; the REF states the rule (§3, §4) |
| 20 | A brief of several screens with no contents, or with section links in the masthead that scroll away with it | Contents that stay on screen and mark the part being read, scaffolded with the brief length (§3) |
| 21 | Contents on a sheet | A sheet is read at a glance and has nothing to navigate (§1, §3) |
| 22 | A brief with a figure or two and every other block a paragraph or a table | Each block takes the form of its content: a number, labels, a bar, steps, two columns, a checklist (§8) |

---

## 13. Skills that instantiate this REF

Generated by `scripts/sync_backlinks.py` from skill frontmatter; do not edit by hand.

Skills whose frontmatter `refs:` includes `REF-Flyer`:

- `bootstrap-flyer` - Scaffold a new HTML/CSS flyer per REF-Flyer, a one-sheet leave-behind or a longer brief for discussion: a single self-contained <flyer-name>.html carrying the token :root block, the desk/sheet skeleton, a print block, and a sample masthead plus one section.
- `write-commercial-brief` - Write or revise a commercial brief per REF-CommercialBrief, the first page on a request, from the request and the author's understanding before anything is scoped: sort what is in hand into heard, assumed and proposed, draw today's path and the proposed solution as figures, and fill the fixed spine (context, problem, solution, open points) on the brief bootstrap-flyer scaffolds, with every open point something a named person can close and the requester's hand-over as one action with its list.
