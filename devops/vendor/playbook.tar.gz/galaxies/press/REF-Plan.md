---
domain: framework
---

# REF: Plan (Data-Driven Project-Plan Instruments)

> Read this when producing a project plan: a single self-contained HTML instrument whose substance is one embedded dataset of typed, dated, linked items (dependencies, assumptions, risks, milestones, workstreams, gates, decisions), projected by a fixed inline renderer with one form per content type: dependency tables, a milestone rail, a schedule chart, assumption statements, a gate ladder, and an append-only decision log. The steering instrument of an engagement, and the system of record its sessions write back into.

---

## 1. What a plan is (vs a flyer, a deck, a workshop)

Each artifact kind here is derived from its use-case and carries its own form and identity; none is a restyling of another. Pick by consumption:

| You want | Reach for | Because |
|---|---|---|
| One page, read at a glance, that also prints clean | Flyer (`REF-Flyer.md`) | A single sheet; no state, no sequence |
| A sequence walked through in order | Slidev deck (`REF-Slidev.md`) | Progressive reveal, presenter flow |
| A live, timeboxed session run with a room | Workshop (`REF-Workshop.md`) | A runsheet and room screens, with decision capture |
| The instrument a project is steered by across its life | **Plan** (this REF) | Typed, dated, linked items; state that survives every meeting |
| Where the plan stands for one period, read in a minute | Status report (`REF-StatusReport.md`) | One page per reporting window, derived from the plan; the plan stays the record |

A plan is not a document about the project; it is the project's working state made legible. Its substance is items with owners, dates, statuses, and edges between them; its boards and charts are views of that substance. One plan per engagement: it is the system of record, every working session over it (a workshop, a steering meeting) lands its outcomes back into it, and every status report over it is a projection of its state for one period.

Boundary with the delivery line's records: the `.delivery/` files of `REF-Delivery.md` are the line's internal, machine-checked records of one run. A plan is the shared surface a customer and a team steer by, often before any line runs. The plan cites the line's records; it never replaces them.

## 2. The one rule: the dataset is the artifact

The failure mode of every hand-made plan is a fork: the deck says one thing, the tracking sheet another, the minutes a third, each maintained by hand until they disagree. The cure is structural:

**One embedded dataset; every pixel a projection.** The plan file carries its whole model in one `<script type="application/json">` block, and a fixed inline renderer projects it into every view. Nothing the dataset states is ever also written by hand in the markup; nothing derivable is ever authored.

| Authored (judgment) | Derived (never hand-written) |
|---|---|
| Item names, bodies, notes; the focus line | Every table, rail, and chart, grouped and filtered |
| Owners, statuses, dates, priorities, edges | The timeline: bar geometry, month ticks, the today line |
| Decisions, verbatim, with who and when | Counts and rollups: the stat strip, per-section tallies |
| The critical flag | The gate ladder rendering, the log table |

Re-anchoring the calendar is a data edit plus a log row, not forty markup edits. A second grouping of the same items is a render option, not a second board maintained in parallel.

## 3. The plan model

The dataset is one JSON object with these collections. The field names are the contract the plans engine serves (§8); keep them stable.

```
meta      id, title, eyebrow, lede, version, date, focus, anchor,
          horizon [start, end], classification, sources[]
lanes     [{id, name}]           the swim lanes, in fixed order: as many as the
                                 engagement has, an optional lane among them when
                                 optional work exists
items     [{id, type, name, short, body, note, owner, lane, priority,
            status, when, due, start, end, parent, needs[],
            critical, cause, decision {date, who, text}}]
gates     [{id, name, short, evidence, closer, refs[], closed {date, who, where}}]
log       [{date, refs[], text, who}]
```

Item rules:

| Field | Rule |
|---|---|
| `id` | Stable, mono, a class prefix + ordinal (`DEP-001`, `ASM-03`, `M2`, `TRK-07`, `RSK-02`). Immutable across versions; a descoped item keeps its id and gains `status: "descoped"` |
| `short` | Milestones and gates: a label of at most twenty characters for calendars and charts (`Demo to the sponsor`, `UC1 accepted`), where the full `name` would collide. Optional; a projection that needs it falls back to `name` |
| `type` | One of `dependency`, `assumption`, `risk`, `milestone`, `track`. The classic project canon by its existing names; no invented kinds. Work with a start and an end is a `track`; a `milestone` is a date closed on evidence; a delivery highlight is a `log` row |
| `lane` | A lane id from `lanes`. A lane name may carry a short form before a middot separator (`Build · the delivering side`): pills, chips, and the legend show the short form, the schedule's group headers the whole name |
| `priority` | Dependencies only: `blocker`, `high`, `medium`, `low`, `optional`. A blocker renders as a filled badge, the rest outlined; optional work carries the optional priority and lives on the optional lane |
| `status` | `ok` (agreed, granted, closed), `wait` (open, pending), `block` (blocked, refused, critical attention), and two terminal states: `descoped`, work never started, and `superseded`, work done or under way and then overtaken, whose window counts as lost and whose `decision` dates the day it was overtaken. A descoped track keeps the window the plan gave it when that work is gone, and the ledger counts it as effort released; it drops the window when the work continues under another id, and an exploration that never had a window stays invisible. No fourth live status; a richer lifecycle belongs in a tracker |
| `cause` | On a track that exists only because of another id: the gate whose miss spawned it, or the decision that added it to scope. The ledger counts the track's window as effort, spawned or added |
| `when` vs `due`/`start`/`end` | `when` is the display text ("by 2030-01-15", "at the raise"); `due` and `start`/`end` are ISO dates and exist only when a real date exists. A live milestone always carries one, since a milestone is a date closed on evidence; an event nobody can date yet waits in a note or a log row until it can be. The timeline and the tables' due column consume only the ISO fields (a workstream shows its window, a decided item its decision date); `when` opens with the row as its one line of prose |
| `note` | The one free slot per type, labeled by the renderer: a dependency's note, an assumption's "if it does not hold", a risk's mitigation |
| `parent` | Sub-item edge (a sub-dependency names its parent) |
| `needs` | Ordering edges, by id (items or gates): what releases this item |
| a gate | A date, not a task: on its `due` the named evidence is granted or it is not, and past that day an open gate moves every date behind it one for one, a delay chargeable to whoever holds the gate. Gates may share a day; the schedule draws one line per gate day carrying every id on it. Nothing needs a separate checkpoint kind |
| `critical` | Authored boolean marking the critical path (Gall's law: the flag is the simple thing that works) |
| `decision` | Present once decided: date, who, the decision verbatim. Its absence *is* the undecided state |

State rules: the `log` is append-only (a reversed decision is a new row citing the old); a log row's `refs` name the ids it touches, or `PLAN` when the row is about the plan itself (a publish, a re-anchor); every date is absolute; every owner is a named role or person, never "the client"; a date re-anchor is a data edit recorded as a log row; a delivery highlight is a log row citing its ids, never an item.

## 4. The projections

The renderer is fixed; these are its projections, and the load-bearing rule is that **each content type gets the form its facts want**. A dependency is columnar facts, so it renders as a table row; a schedule is geometry, so it renders as a chart; milestones are dates, so they render as a rail. One component stretched over every type is how a plan turns into an unreadable tile wall.

| Content | Projection |
|---|---|
| Header | The masthead band: version stamp, the fixed focus line saying what the engagement is, and derived stat tiles (items tracked, open, blocked, decided, the ledger's total days, the next live milestone with days remaining) |
| Milestones | A date-ordered rail of compact date cards (lane stripe, critical badge), plus diamond markers on the schedule |
| Schedule | A chart over `meta.horizon` gridded by week in hairlines and by month in heavier neutral lines, the month named at each: tracks as bars in lane color, milestones as diamonds, critical items outlined, one dashed line per gate day carrying the ids that fall due on it (green once every gate on it has closed, critical-hued once one is past due; the label answers hover with every gate on that day, id, name, date and closer, and a click opens the gate's row), weekends shaded so a gap between two stations reads as the weekend it is, a today line computed at render time carrying its date, and a legend that names every mark on the chart, the critical outline included. Two toggles above the chart show or hide milestones and gates, and a switch chooses which of the two draws the lines while the other draws the diamonds (gate days as lines by default). Whichever kind is the line has no rows: it is what the work runs up to. Nothing else is drawn: no colored months, no line per critical item. The chart scrolls inside its own container; the page never scrolls sideways |
| Dependencies | One table holding every dependency, ordered by id, with columns for id, the item (the name line; opened: description, note, edges, and the decision once taken), owner, lane, priority badge, due, and status chip; sub-dependencies indented under their parent. The lane pill is the only grouping |
| Assumptions | Numbered statements, each one line when closed (id, statement, owner, status chip); opened: the statement's body, then its "if it does not hold" consequence in a tinted strip |
| Workstreams, risks | Compact tables, each row its name line when closed; opened: the workstream's description and edges, the risk's statement and mitigation |
| Gates | Under one line stating what a gate is and a count of closed gates, the ordered ladder: id, name, what closes it (evidence, never a date), who closes it, its recorded closure or its visible openness |
| Decision log | The append-only rows, newest first and stable within a date whatever the array order, grouped by day and closed to one line per day: the date, the number of rows, the ids they touch, and the versions they published. A click opens the day: rows about items in full, and rows about the instrument itself (refs of `PLAN` only) folded once more behind their own line. The record keeps every row; the page reads one line per day until asked |
| Ledger | The last section, derived and never filtered: every superseded track by its window, every track with a `cause` by its window, spawned by a missed gate or added by a scope decision, every descoped track that kept its window by that window as a negative, and every gate past its day by the working days since, until it closes and then by the days between its day and its closing. Rows of one kind fold to one line carrying their count, span, and sum, opened with a click. One total of days at the foot, and the same number as a tile in the masthead; the kinds tell effort from delay row by row. Overdue items and moved milestones are symptoms of a missed gate and are not counted again; a point item, whatever its status, has no days of its own |

Under every section head there is the head, its count, and the data. No section carries a sentence explaining what it is: what a milestone or a gate means is this REF's job, and a reader of the page has the data in front of them.

Three mechanics hold across the projections:

- **Rows close to their name line.** Dependency, workstream, and risk rows and assumption statements render closed, a caret before the name; a click opens the detail in place. A whole table scans in one screen and any row opens without leaving it. Tables lay out with fixed column widths, so opening a row never reflows the columns around it.
- **Every id is a link.** Every item or gate id appearing in prose, edges, gate refs, log refs, and the schedule's labels, bars, and diamonds renders as an in-page link to the item's anchored row; the targeted row highlights and opens. The link pattern is derived from the dataset's own ids at render time (`textContent`-safe, per §6), so the renderer carries no id vocabulary.
- **Filters compose from one state.** Lane pills, status pills, priority pills, and an owner select derived from the data cut the tables, the rail, and the chart together. The pills are sets: a click toggles a value in or out, several may be on at once (blocker and high together is "high and above"), and All clears the set, an empty set meaning no cut on that axis. `descoped` and `superseded` items are hidden under every filter state except their own pills, and section counts report them separately.

Semantic channels hold across every projection and each carries one meaning: lane is a swatch plus its name, status is a status-hue chip plus its word, a blocker priority is a filled badge with its word, and a `critical` item carries the critical hue plus a label, never color alone.

## 5. The identity

The plan's own visual identity: a working document with an instrument's chrome. An ink masthead band carries the title, version stamp, focus line, and stat tiles; a sticky bar under it holds the section anchors and the lane and status filter pills; the projections follow as full-width panels (content to ~1280px).

Palette and typography follow `THEMING.md`. The template's maintained palette block owns the concrete canvas, panel, band, ink, muted, boundary, accent and status values. Light is the bare `:root`; Dark follows `prefers-color-scheme` unless an explicit `data-theme` selects either appearance. Print uses Light.

Lane colours remain a separate categorical set in the template, assigned by fixed lane order and carrying their names. Status colours remain reserved for decided, open and blocked, each with its word. Validate contrast and categorical separation when changing either set; a sixth lane needs a sixth validated token. The masthead uses its own band ink and muted roles.

Display and body use the identity's sans stack; identifiers, chips, dates and ticks use its mono stack. A face the identity carries travels inside the file, inlined; a stack whose first family the identity carries no face for falls back to the system fonts it names. Solid schedule and table surfaces preserve legibility; expressive decoration belongs outside the data.

The page around the plan stands on the identity's stage: its ambient ground, drawn by the identity's own recipe and stamped into the renderer's one page frame, fixed behind the opaque panels so it shows only around them. It follows the reader's appearance, stops for reduced motion, leaves for reduced transparency and high contrast where the identity says so, pauses on a hidden page, and never prints. An identity without a stage leaves the plain ground.

## 6. The runtime rules

One `.html` file; no build step; no external requests. Three rules govern the runtime:

- **Inline, framework-free JS.** The renderer lives in one inline `<script>`; render-on-load from the dataset; a `<noscript>` line names the file as a data-driven plan.
- **`textContent` only.** Data enters the DOM exclusively via `textContent` / `createElement`, never `innerHTML`. This closes injection and makes escaping a non-issue.
- **Declared encoding.** `<meta charset="utf-8">` is the file's first line, so glyphs survive a static host that serves bytes without headers and a file opened from disk.

## 7. Print

The printed plan is the steering-pack handout: A4 landscape suits the schedule. The sticky bar is hidden; table rows, gate rows, assumption blocks, and rail cards carry `break-inside:avoid`; the chart's scroll container becomes `overflow:visible`.

## 8. Versions, write-back, and the engine

A plan is re-published whole, never patched invisibly: `meta.version` bumps on every publish, prior versions are kept, and between two versions the decision log is the human-readable diff while the dataset diff is the mechanical one.

A working session over the plan is its own artifact (`REF-Workshop.md`). It consumes plan item ids into its blocks, and its captured outcomes land back here as `decision` fields, status flips, and log rows in the next version. The plan is the record; the session is an event on it.

The plans engine, `rb-plans`, stores and versions plan datasets: every write lands as a new, immutable version, and every earlier version stays readable. Three doors enter its one write path: a UI that renders this cockpit and edits the plan with no agent, an HTTP API serving the dataset, and an MCP door that takes items, decisions, status flips, and log rows and exports the self-contained file (`mcps/rb-plans.md`). The dataset schema of §3 is the contract the engine serves, unchanged: it assigns `meta.version` itself, adds no other field and drops none, and refuses a dataset that does not conform, naming every reason. The artifact stays the render: the cockpit and the export project the dataset through the one `bootstrap-plan` renderer.

## 9. Generation flow

1. Scaffold (skill `bootstrap-plan`): the full renderer, the token system, and a small example dataset. **The author edits only the dataset**; the renderer and frame are the fixed skeleton and are never hand-laid-out per plan.
2. Author the model: items with real ids, owners, lanes, dates, edges; the gates; the focus line.
3. Audit the dataset mechanically (the skill's `audit.py`): every reference resolves, no live date falls on a weekend, nothing starts before what it needs is done, no gate still ahead falls due before its evidence, every live milestone carries a date, every milestone and gate carries a short name. A finding is a dataset edit and a re-run, never a note in prose; a plan that fails its audit is not published.
4. Verify: open the file (every projection renders, zero console errors), flip the theme, narrow to phone width (only the chart's and the tables' own containers scroll), print-preview.
5. Publish and steer (the skill's `publish.py`): sessions run over the plan; outcomes land in the dataset; the publish step bumps the stamp, prepends the log row, re-renders the file from the skill's current template so every plan carries the one renderer, refuses while the audit has findings, and writes the next version beside the old with the old moved to the archive. A renderer change reaches an existing plan by publishing it again with a log row saying so; nobody re-lays a plan out by hand.

## 10. Content rules

| Rule | Meaning |
|---|---|
| Verbatim ids, absolute dates, named owners | Never "next week", never "the client" |
| Dates land on working days | A due or an end never falls on a weekend, and neither does a start; day arithmetic that lands there moves a due or an end to the Friday before and a start to the Monday after. A calendar that dates a milestone to a Saturday is one nobody checked |
| Edges resolve and order holds | Every id an edge, a reference, or a log row names exists in the dataset; nothing starts before what it `needs` is done; a gate still ahead never falls due before the evidence it closes on. The audit (§9) enforces all three, so a dangling id or an impossible order is a defect, never a footnote. A gate past its day and still open is a miss, not an impossible order: its evidence closes after it by definition, the ledger counts the days, and the audit leaves it alone, so the gate keeps naming the work that closes it |
| Decisions written as decisions | "X grants Y by 2030-01-15", with who and when, in the data |
| A fixed focus | `meta.focus` states what the engagement is, in at most two sentences: the parties, what is delivered, the window, as the contract states it. Written once and left alone. What was added later under change control is a decision in the log and items in the plan, never a rewrite of the focus, so that a scope which can still drop out never reads as the contract; and what is live, what is red, and what falls due next are the stat tiles' and the status report's to say, because a focus that carries status drifts the week it is written |
| Highlights are log rows | A delivery highlight, a publish, a re-anchor: a `log` row citing its ids, never a new item type |
| A window is a track | Work with a start and an end is a `track`; a `milestone` is a single date closed on evidence, and the audit refuses a live one that carries none |
| Every item owned | An item nobody owns is not an item; it is a risk, and belongs typed as one |
| Delays are counted, never absorbed | A gate keeps its day and is missed, and the ledger counts its days; an overdue item keeps its need date and a moved milestone says in its `when` where it was, symptoms the ledger does not count twice; work a miss spawns or a decision adds is a track naming its `cause`; overtaken work is `superseded` with its window; removed work is `descoped` with the window it had, so the trade-off between what was added and what was taken out is a number (§4). A date edit that makes a miss disappear is the defect |
| Lowercase mono tool labels | `estimatekit`, `protopane`; never Titlecased, never restyled |
| NO em-dashes, anywhere | Hard rule (INT-SHAPE-002), in markup, JS, and JSON strings alike |

## 11. Cross-references

- `REF-Workshop.md` - the session instrument that consumes plan items and writes decisions back; the two share the item-id vocabulary and nothing else.
- `REF-StatusReport.md` - the periodic digest projected from this plan for one reporting window; the plan is the record, the report is its read for the people steering by it.
- `REF-Flyer.md` / `REF-Slidev.md` - the sibling artifact kinds for one-glance pages and presented sequences; each carries its own identity.
- `REF-Delivery.md` - the delivery line whose records a plan cites; the plan is the steering surface, `.delivery/` is the run's internal record.
- `REF-DataPack.md` - the same data-first doctrine for tabular corpora; a plan is that doctrine applied to project state.
- `REF-Documentation.md` §7 - visual-first: the boards and the timeline are this artifact's diagrams.

## 12. Anti-patterns

| # | Anti-Pattern | Correct Approach |
|---|---|---|
| 1 | Hand-writing plan content in markup (cards, bars, counts as HTML) | The dataset is the artifact; every view is a projection (§2) |
| 2 | A second source of truth beside the dataset (a tracking sheet, a deck with its own dates) | One model; other artifacts cite it or are generated from it |
| 3 | Renumbering or reusing item ids between versions | Ids are immutable; descoped items keep theirs (§3) |
| 4 | Editing a published version in place | New version beside the old; the log carries the why (§8) |
| 5 | Decisions recorded as prose paragraphs or minutes | The `decision` field and the append-only log (§3, §8) |
| 6 | `innerHTML` with data, or a CDN script in the renderer | `textContent` only; inline, framework-free JS (§6) |
| 7 | A canvas-drawn or image timeline | DOM-projected geometry from the dataset: inspectable, printable, themed by tokens (§4) |
| 8 | Status color on card fills or prose; a status or critical mark as color alone | Chips and the critical edge only, always carrying their word (§4, §5) |
| 9 | Lane hues cycled, generated, or reused for status | Fixed lane order onto `--lane-N`; status hues reserved; palette changes re-validated (§5) |
| 10 | A session's outcomes living only in its own artifact or in minutes | Outcomes land back in the plan as data: decisions, status flips, log rows (§8) |
| 11 | A plan the engine holds, changed outside its doors (an exported file patched by hand, a dataset edited beside the store) | Write through the engine's doors; every write lands as the next version, and the export is its render (§8) |
| 12 | A plan doing a flyer's job (one glance), a deck's (a pitch), or a workshop's (a live session) | Pick the shape by consumption (§1) |
| 13 | One component stretched over every content type (a uniform card grid) | Each type gets the form its facts want: tables for dependencies, a rail for milestones, a chart for the schedule (§4) |
| 14 | A focus line that editorializes ("what we protect", "leave the room with...") | The focus is two sentences of dates and facts; commentary belongs in no artifact a customer reads (§10) |
| 15 | Dependencies split into grouped tables (by phase, optional, platform-provided) | One table ordered by id; the lane pill is the grouping; optional work lives on an optional lane (§4) |
| 16 | A delivery highlight typed as an item, or a window of work typed as a milestone | Highlights are log rows; a window is a track (§3, §10) |
| 17 | An id vocabulary hard-coded in the renderer's link pattern | The pattern derives from the dataset's ids at render time (§4) |
| 18 | A gates section headed by a slogan | One line stating what a gate is, plus the closed count (§4) |
| 19 | A missed gate moved to the date its evidence now promises | The gate keeps its day and the miss goes to the ledger; the evidence keeps its need date and reads overdue (§3, §10) |
| 20 | Work that was done and then overtaken marked `descoped` | `superseded`, with its window and the decision that overtook it, so its days count (§3) |

---

## 13. Skills that instantiate this REF

Generated by `scripts/sync_backlinks.py` from skill frontmatter; do not edit by hand.

Skills whose frontmatter `refs:` includes `REF-Plan`:

- `bootstrap-plan` - Scaffold a new data-driven project-plan instrument per REF-Plan: a single self-contained <plan-name>.html carrying one embedded dataset (items, gates, log) and the fixed renderer with one projection per content type (masthead band with stat tiles, milestone rail, month-gridded schedule chart with gate rows, checkpoint and today lines, one id-ordered dependency table with priority badges and sub-dependency indentation, one-line assumption statements, workstream and risk tables, gate ladder, day-grouped newest-first decision log, a ledger of effort and delay derived from the same dataset), rows closed to their name line, every id in prose linked to its row, lane, status, priority, and owner filters composing from one state, themed light and dark with machine-validated lane and status palettes.
- `bootstrap-workshop` - Scaffold a new typed working-session instrument per REF-Workshop: a single self-contained <session-name>.html carrying one session dataset of typed activities (frame, collect, walk, sort, assign, close) and the fixed renderer that gives each type its own full-screen working surface, records outcomes live on the surface (persisted locally, exported at the close), and gates the facilitator script behind the presentable room view.
- `write-status-brief` - Produce an executive brief per REF-StatusReport from an issued status report: feed the report's dataset through the deterministic from_status.py, which copies the verdict and the road ahead, folds the lanes into at most three by the fold the author declares, and seeds the one line of need from the asks due by the checkpoint, rendered by the fixed one-screen template; then author only the lane notes and the need sentence, verify, and issue.
- `write-status-report` - Produce a periodic status report per REF-StatusReport from a plan instrument: feed the plan's dataset for one reporting window (an ISO week, a calendar month, or two dates) through the deterministic from_plan.py, which derives the road ahead (every gate and milestone by date), the checkpoint, the blockers, what was decided, and the seeded lane skies into a draft rendered by the fixed printed-brief template; then author only the judgment fields (the outlook headline and emphasis, the position, the lane notes, the asks), verify, and issue.

---

## 14. Agents that orbit this REF

Generated by `scripts/sync_backlinks.py` from agent frontmatter; do not edit by hand.

Agents whose frontmatter `refs:` includes `REF-Plan`:

- `facilitator` - Prepares and runs a live, timeboxed working session over the plan: the runsheet, the room screens, and the decision capture that lands back in the plan; hand it a session to prepare or a capture to land.
- `project-manager` - Steers an engagement by its plan: authors and audits the plan dataset, issues the period's status report and its executive brief, and writes the MoM of a session; hand it a plan to publish, a period to report, or a session to digest.
