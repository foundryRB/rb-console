# Press styling

This organization's Press templates carry the Vodafone Portugal Digital Engineering palette and typography, and the flyer masthead carries its lockup. Each instrument owns its layout, content structure, renderer, print rules and interactions in its existing template.

## Composition and appearance

Flyers use a bounded 1120px screen frame, the wordmark, open side fields and sparse fading particles. Prose keeps its own readable measure. Workshop covers and slide covers carry expressive motion; script, schedule, table, MoM and report surfaces prioritize reading. A plan's page stands on the identity's stage, around its opaque panels and never over its data. Print and email are opaque, still Light projections. Email paints an explicit white outer ground for mail-client isolation.

Glass and motion are choices in the authored template. Design-system demonstrations may expose material and motion controls; ordinary outputs use the chosen treatment and respect reduced-motion, reduced-transparency and hidden-page behaviour. Light/Dark is an appearance preference, not a brand switcher. Keep corporate artwork and theme-specific composition in each consumer's existing files.

## Source files

- Colour and typography source: the design hub's `design-systems/vodafone-digital-engineering/identity.json` (the ProtoPane repository carries the identities it serves).
- Template palettes: run `python scripts/sync_press_palette.py --palette <the identity's identity.json>` after editing that source, then review the rendered instruments. `--check` verifies the embedded palette blocks. The script runs during maintenance; installed skills emit their own self-contained templates.
- Faces: an identity with faces of its own has the design hub's `generated/faces.css` beside its `identity.json`, and the same script embeds it in every template's palette block, inlined, so each artifact wears the face and fetches nothing. A plan carries it in its page frame, not in the renderer's sheet, which an application that renders plans also loads beside faces of its own. Without it, the stacks fall back to the system fonts they name.
- Stage: an identity whose recipe draws one has the design hub's `generated/stage.html` and `stage.css` beside its `identity.json`, and the same script stamps both into the plan's page frame (`bootstrap-plan/renderer/plan-page.html`) between its `PRESS stage` markers. Without them the markers stay empty and the plan stands on its plain ground.
- Layout and decoration: edit the particular instrument's template or bootstrap source. Use its semantic CSS variables and reusable selectors rather than literal colours in individual content sections.
- Slide composition: each catalog theme owns `style.css`, `global-top.vue` and `pages/`. The Slidev scaffold's default is `psa`; an explicit `--theme` selects another catalog theme.

Flyers, plans, workshops, status reports, status briefs and MoMs use their existing semantic roles with this identity's values. HTML documents follow the system Light/Dark preference; print and email use the Light palette. Dense data and email retain their format-specific presentation.

Notes and articles retain semantic Markdown. Their publishing renderer or site's stylesheet owns their appearance. For an HTML note, use the flyer's typography and semantic colour roles in its own stylesheet; keep page content free of inline brand colours. A renderer that has not adopted these styles remains a rollout task.

For another organization's copy, edit its concrete palette, logo assets, typography and relevant layout CSS in source, then regenerate the palette projections and release the affected repositories. Review composition as part of that work.

Application UI adoption is a separate rollout. Existing frozen artifacts retain their approved appearance until deliberately regenerated.
