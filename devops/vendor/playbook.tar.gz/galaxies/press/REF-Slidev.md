---
domain: framework
---

# REF: Slidev (Plaintext Slide Decks)

> Read this when generating Slidev slide decks. Slidev (`@slidev/cli`) renders Markdown into interactive presentations. AI generating Slidev from scratch produces ugly, oversized slides because it can't render-to-verify; the cure is **templates with visual constraints baked in**. AI fills slots, never lays out from scratch.

---

## 1. Why Slidev (vs PowerPoint / Google Slides)

Same reasoning as `REF-DataPack.md` §2 for TSV vs Excel: plaintext source (diffable), templating, no lock-in, reproducible (same `slides.md` + theme = identical deck anywhere). PowerPoint is opaque to AI without conversion; Google Slides has API limits.

## 2. The visual-validation problem

AI generates without rendering, and Slidev's correctness is *visual* (does it fit?): slides overflow vertical bounds, density varies, code blocks run too tall. The CSD principle applies - constraints participate in execution, not documentation. Templates are the constraint mechanism.

## 3. Template-first generation

1. **Select a theme** (a `style.css`) that already encodes visual constraints (height-aware, density-bounded, brand-coherent).
2. **Compose pages** from the theme's utility classes only; never inline styling.
3. **Validate** post-generation: render and eyeball, or run a deterministic linter.

The theme owns layout primitives; the page owns content. They compose without AI laying out HTML/CSS by guess.

## 4. Project layout (default, page-based)

One file per slide, imported via `slides.md`. The theme is one `style.css`:

```
<deck-name>/
├── package.json        # @slidev/cli dependency, dev/build/export scripts
├── slides.md           # cover slide + frontmatter; imports each page
├── style.css           # the theme (one file, hand-authored)
├── pages/              # one Markdown file per slide: 01-<slug>.md, ...
└── public/             # static assets (referenced as /name.png)
```

`slides.md` is cover + imports:

```markdown
---
theme: default
title: "<Deck Title>"
download: true
exportFilename: <slug>
mdc: true
---

# Title slide

---
src: ./pages/01-<slug>.md
---
```

Each `pages/<NN>-<slug>.md` declares its own `layout:` frontmatter and uses **only classes its theme defines**. There is no universal page skeleton: what a page is made of is the chosen theme's business, and its own templates (§6) are the reference.

## 5. CSS-only theming

A theme is one CSS file **plus the pages that demonstrate it**. The stylesheet is the single source of visual truth; the theme's own `pages/` templates, its chrome component where it has one, and the dependencies it needs travel with it, because a stylesheet handed over alone gives you the colours and leaves the layouts behind. Pages reference theme classes; never inline styles.

| Rule | Why |
|---|---|
| All visual rules in `style.css` | Single source of theme truth; swap themes by replacing one file |
| No inline `style="..."` attributes in pages | Defeats theming; AI keeps drifting them |
| No `<style>` blocks inside `pages/<NN>.md` | Same; also breaks Slidev's MDC parser in edge cases |
| Theme classes are utility-shaped | Page MD reads as "what content goes where", not "how it looks" |
| CSS variables for brand tokens | `--<prefix>-primary` etc.; theme swaps stay one-CSS-file changes |
| Constants for spacing, font sizes | Makes density-budgets enforceable in CSS |

When tempted to write `style="margin-top: 2rem"`, the answer is a `<prefix>-spaced` utility class in `style.css`, or Slidev's tailwind-equivalent utility (`mt-6`).

## 6. Class system convention

Every theme uses one short prefix (e.g. `vf-`, `k-`) for its utility classes - avoids collisions and signals which theme a page targets.

A prefix is a **namespace, not a vocabulary**: two themes can share `k-` and mean different things by it, so a page written against one renders unstyled against the other. Sharing class *names* where the concept is shared is what makes a deck re-skinnable; what each theme decides is which of them it implements.

Common classes, and what they mean **where a theme has them**. None is mandatory: a theme that has no footer should not define an empty one, and its templates should not reach for it.

| Class | Purpose |
|---|---|
| `<prefix>-divider` | Brand-colored thin rule under a heading |
| `<prefix>-footer` | Bottom-of-slide identity strip |
| `<prefix>-brand` | Inline span for the brand wordmark in the footer |
| `<prefix>-alert` | Callout box for warnings |
| `<prefix>-note` | Subtle, low-emphasis caption text |
| `<prefix>-card` | Generic card, brand-coherent background and padding |
| `<prefix>-stat` (+ value/label) | KPI tile with a number and a label |
| `<prefix>-flow` (+ step/arrow) | Horizontal pipeline / sequence diagram |
| `<prefix>-section-title` | Sub-header inside a multi-column grid |

Layout primitives (`grid`, `gap-*`, `text-xs`, `mt-*`) come from Slidev's built-in tailwind; brand/visual primitives from the theme.

**A theme ships its own templates.** One page per role it supports (a cover, an agenda, a section divider, a content page, and whatever else it does well), using only what it defines, so "use the theme" means layouts and not just colours. The layouts' own check enforces this mechanically (`check-layouts.mjs`, beside them): every class a theme's templates use must be defined in its own stylesheet, and every chrome class its stylesheet styles must be produced by its own component. The slides workshop's `slidev-themes/check-themes.mjs` is one such gate.

## 7. Constraints to bake into themes

Enforce in theme CSS or a deterministic post-render check:

| Constraint | Why |
|---|---|
| Max title length | Long titles wrap unpredictably |
| Max body content (lines or chars) | Prevents vertical overflow |
| Image max-height (via CSS rule) | Prevents image dominance |
| Code block max-lines | Code overflow is the most common failure |
| List bullet count cap | After 7 plus-or-minus 2 bullets, slides degrade |
| Reserved footer space | Don't let content run into footer |

## 8. Generation flow (CSD-aligned)

1. Source content lives in the deck's `content/` (advanced layout) or as (page-title, bullets) pairs (default).
2. AI selects layout per slide by content type; fills slots using only theme classes, NEVER inline styling.
3. Optional: post-generation linter (deterministic checks per §7).
4. Human reviews final visual quality (one-pass render check, not byte-level).

This is CSD's Trust Calibration: mechanical constraints auto-trusted via lint; semantic content human-reviewed.

## 9. Cross-references

- `REF-CSD.md` - methodology (Trust Calibration, Synthesis Governance for visual artifacts).
- `REF-DataPack.md` - same pattern at the data layer; a Slidev deck can be a view over a Data Pack.
- Slidev official docs: https://sli.dev (syntax, themes, components).

## 10. Anti-patterns

| # | Anti-Pattern | Correct Approach |
| - | ------------ | ---------------- |
| 1 | AI hand-writes HTML/CSS for layout inside pages | Theme `style.css` utility classes; pages contain content, not layout |
| 2 | Inline `style="..."` attributes in page Markdown | Add a utility class to `style.css`; reference by name |
| 3 | `<style>` blocks inside `pages/<NN>.md` | Same fix as #2; theme owns visual rules |
| 4 | Generating a full deck without a render check | Run `npm run dev` once before declaring done; or a layout linter |
| 5 | Inline images without max-height CSS | Theme sets image bounds; page sets src/alt only |
| 6 | Code blocks longer than slide height | Theme caps line count; spillover means refactor or split |
| 7 | Everything inline in `slides.md` | Use `pages/` and `src:` imports per §4 |
| 8 | Treating Slidev as just "Markdown" | It's Markdown plus Vue plus CSS plus theme. Patterns matter. |
| 9 | One layout restyled in place for a brand | The identity is stamped into the layout's slots; another identity is a folder in the design hub, never an edit to the layout |
| 10 | Coupling PDF export into the automated deck build (e.g. `download: true` headmatter) | Build to static HTML; keep PDF a separate, opt-in export. Bundling it forces a headless-browser download into every build, which is slow and unreliable on a restricted CI runner (see `REF-AppContract.md` section 4) |

---

## 11. Skills that instantiate this REF

Generated by `scripts/sync_backlinks.py` from skill frontmatter; do not edit by hand.

Skills whose frontmatter `refs:` includes `REF-Slidev`:

- `bootstrap-slidev-deck` - Scaffold a new Slidev deck with the REF-Slidev page-based layout, from the layout the skill owns (its pages, its chrome, its motion) with an identity stamped in - this organisation's, baked into the layout, or another identity's read from its folder in the design hub when the deck is made (--palette).
