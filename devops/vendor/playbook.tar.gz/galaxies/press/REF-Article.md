---
domain: practice
---

# REF: Article Writing

> How to write and edit articles for publication. Read this before drafting, rewriting, or editing any article.

---

## 1. Voice and Tone

Articles and notes use semantic Markdown. Their publishing renderer applies the maintained identity described in `THEMING.md`, including typography, reading measure, code and table treatment, Light/Dark and print. Keep brand colours and decorative markup out of the article body. Verify a representative rendered article when changing its renderer.

- Calibrate voice from the author's **actually-published work**, not from drafts in the same folder. Notes that point at published URLs are pointers, not prose; fetch the real piece to sample the register. Drafts produce a misleading baseline.
- Write as the author, not as an assistant. First person, confident, direct.
- No hedging phrases ("it's worth noting") or performative transitions ("let's dive in").
- Vary sentence length; monotone rhythm is an AI tell.
- Prefer concrete over abstract. A specific example beats a general statement.

---

## 2. Structure

- Every idea appears exactly once.
- After drafting, make a repetition map: list each core idea and every section where it appears. If any idea appears more than once, decide where it belongs and remove it everywhere else.
- Sections should earn their existence. If two cover the same ground, merge them.
- Say the thing, then explain it. No long preambles before definitions.
- The opening must hook: a story, a number, or a provocation. Not context-setting.

---

## 3. AI Tells to Eliminate

Catch and remove these on every pass.

| Tell | Fix |
|------|-----|
| Em-dashes (`-`) | Use commas, periods, colons, semicolons, or parentheses |
| "Not A, not B, but C" rhetorical triple | Just state C directly |
| "Yes, [concession], but [real point]" | Drop the concession, state the point |
| Disguised bullet lists (parallel sentences, same structure) | Vary the structure or collapse into one statement |
| Defensive framing ("this isn't just X, it's Y") | Explain what Y is. Don't explain what it isn't |
| Preemptive counter-arguments before the claim | Make the claim first; address objections only if the reader is blocked without the answer |
| "Let me bring this back to what's practical" | Just be practical. No road signs |
| "The underlying principle:" followed by a bold sentence | Weave the principle into the paragraph |
| Consecutive paragraphs restating one idea with different examples | One paragraph. Pick the best example |
| Bookend summaries that repeat the introduction | The ending should advance, not recap |
| "In other words" / "Put differently" | If the first version was unclear, fix it. Don't say it twice |
| Contradictions from over-compression ("X is free. Vendors sell you X.") | Choose one framing |

For sentences that are about the subject yet say nothing new (narration beside a formula, table, or figure), apply the descriptor/narration test in `REF-Documentation.md` §8.6.1: replace narration with a descriptor, never blanket-delete short prose.

---

## 4. Editorial Process

When editing iteratively with the author:

1. **Don't weaken to fix.** Fix the problem without draining energy from surrounding sentences.
2. **Preserve what was strong.** Identify what made the original work; keep those elements in the rewrite.
3. **One concern per edit.** Don't smuggle in "improvements" when asked to fix a specific issue.
4. **When restoring earlier text**, use the actual earlier version, not a reconstruction from memory.
5. **If repeated edits have degraded a section**, offer to reset to a known-good version and apply only the needed fixes.

---

## 5. Paragraph-Level Rules

- A paragraph makes one point.
- Cut the last sentence of any paragraph if it merely restates the first.
- Don't preemptively defend claims. State the claim specifically enough that the counter-argument doesn't apply; if it's valid, acknowledge it in passing, in the same sentence, and move on.

---

## 6. References

References must be uniform in format within an article.

### Format

```
- Author(s) (Year). [*Title*](<url>).
```

- Every title is a link. No unlinked references when a URL exists.
- All entries follow the same format; no entry looks visually different (publisher present in all or none, self-citations formatted like everyone else's).

### Content

- Only cite works actually referenced or directly relevant. A references section is not a reading list.
- No editorial commentary on references; the article body explains why a reference matters.
- Order by relevance or alphabetically by first author; pick one and be consistent.
- For articles in a series, link other parts in a footer section, not in the references.

### Anti-Patterns

| Anti-Pattern | Fix |
|-------------|-----|
| One reference has a publisher, others don't | Make all entries uniform |
| Editorial annotations explaining each reference | Remove them; the body provides context |
| Self-citation formatted differently from other citations | Use identical format for all entries |
| References that aren't mentioned or used in the article | Remove them |
| Mixing linked and unlinked titles | Link all titles or none |

---

## 7. Anti-Patterns (Article-Level)

| # | Anti-Pattern | Fix |
|---|-------------|-----|
| 1 | Opening with a definition | Open with a story, number, or provocation. Define later |
| 2 | Repeating the thesis in every section's closing paragraph | State it once in the most powerful location. Trust the reader |
| 3 | Ending sections with "and that's why X matters" | End on the strongest concrete point. Don't editorialize |
| 4 | Every section the same length | Vary section length. Some ideas need two paragraphs, some need six |
| 5 | Callbacks to the same anecdote more than twice | One callback max. The reader remembers |
| 6 | Using the same sentence structure across consecutive paragraphs | Vary openings: question, statement, story, data |
| 7 | Adding caveats to every strong claim | Be direct. Caveats dilute. One caveat per article is enough |
