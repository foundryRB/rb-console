---
domain: framework
---

# REF: MoM (Minutes of a Working Session)

> Read this when producing a MoM (minutes of meeting) for a working session: one dataset carrying one screen of content a person who missed the room digests in a minute (a context paragraph, a handful of key outcomes, one consolidated action table), approved as content first and then projected twice from that same dataset, a themed HTML artifact carrying the dataset with a fixed renderer, and an email-safe export generated from it. The session capture keeps the full ledger; the MoM carries only what someone must act on.

---

## 1. What a MoM is

A MoM is the after-record of a working session, written for the people who were not in the room and for the attendees' future selves. It answers three questions in under a minute: what was the session, what came out of it, and who does what by when.

- It is not the capture: the session capture (a workshop export per `REF-Workshop.md`, or the plan per `REF-Plan.md`) keeps every item and verdict; the MoM links to it and repeats none of it wholesale.
- It is not a report: no methodology, no narration of how the session went, no re-argument of decisions.
- It is one screen: when a draft outgrows one screen, content moves back to the capture, not into more sections.
- It is data: the content lives as one dataset, and every render is a projection of it. The dataset is the artifact, the same doctrine as `REF-Plan.md` and `REF-Workshop.md`.

## 2. The dataset

The MoM ships as one dataset in a `<script type="application/json">` block inside the artifact HTML; the fixed inline renderer projects it. Editing the MoM is editing the dataset.

```
meta      id, eyebrow, title,
          sessions [{date (ISO), dateLabel, participants[]}]  one per session covered
context   one string: what the sessions were, what they walked, what state they left
          things in
outcomes  [{lead, detail}]  three to five; lead is one bolded sentence carrying the
          outcome, detail at most two supporting sentences
actions   [{owner, action, due, late}]  consolidated per owner and theme, never one row
          per ledger item; late marks a row carried past its date, unmet
footer    one line pointing at the full capture
```

`meta.sessions` usually holds one entry. It holds more when a MoM converges sessions that stacked up unsent (section 3), and the masthead then lists each date with the people who were in that room, because attendance differs per session.

The email's subject line derives from the dataset, never stored beside it: the word MoM, `meta.title`, and the sessions' labels, pipe-separated: `MoM | Dependency Workshop | 25 Aug 2026`.

## 3. Writing rules

| Rule | Meaning |
|---|---|
| Consolidate actions | Ledger items that share an owner and a theme merge into one row; the row names the theme and cites, in parentheses, the plan ids it moves, so the MoM and the plan reconcile mechanically |
| Open actions are checked, never auto-carried | Before the table goes out, every action an earlier MoM of the same engagement left open is read against it and against the plan, and the author is shown the ones that appear in neither: each is carried, re-dated, or dropped by the author's call, since the room may have overtaken it. The check is mechanical; the decision is the author's, and nothing is appended to a MoM without it |
| Dates are absolute | "End of week" becomes the actual date, resolved against the session date; project-relative dates (mid-project, end of project) stay as the capture states them |
| Dates are computed, not recalled | Every resolved date and every weekday name is worked out against a calendar, and a weekday that names a date must be that date's actual day. Calendar arithmetic carried in the head is the one error a reader trusts on sight and acts on: a due date landing on a day that does not exist as stated sends the owner to the wrong day |
| The audience's language | Notes taken in a working language are normalized to the audience's language; vernacular and typos are repaired silently |
| Outcomes are calls, not topics | Each outcome lead states something now true or now decided, never something discussed |
| Content before render | The operator approves the MoM's content; only approved content becomes the dataset and gets projected |
| One dataset, no siblings | The dataset's home is the artifact's JSON block; a copy maintained beside it is a fork. Extract it when a consumer needs it, never duplicate it |
| Sent is immutable | A sent MoM stands; a correction is a follow-up note, never an edit of the record |
| Unsent sessions converge | A MoM that has not gone out yet absorbs the next session rather than a second MoM being written beside it. Two documents where the later one overturns the earlier make the reader reconcile them; one document states the position and each superseded item is resolved in place rather than recorded and then contradicted. `meta.sessions` grows, the outcomes merge, and the action rows dedupe. Convergence ends at the send: once one has gone out, the next session is its own MoM |
| NO em-dashes, anywhere | Hard rule (INT-SHAPE-002), in the dataset and in both projections |

## 4. The projections

One file carries the dataset and both projections, so a MoM is one thing to keep and the person editing it has one place to type.

| Projection | Rules |
|---|---|
| The page | The dataset block plus a fixed framework-free inline renderer (data into the DOM via `textContent` only, a `<noscript>` line, no external requests). The author edits only the dataset, so the renderer parses it inside a guard and states what is wrong with it where the document would be: a hand-written dataset fails on a quote that wants escaping or a comma after the last item, and a page that answers that with blankness sends its author hunting. The identity below; both themes (the complete light palette on bare `:root`, the dark tokens under `prefers-color-scheme` guarded against an explicit light stamp, and again under an explicit dark stamp); one centered column carrying every element, prose and rules and tables sharing its edge; the actions table scrolls in its own container |
| The email | Built from the same dataset by the page, on a control that copies and puts nothing on screen. It writes both clipboard flavors: the markup a mail client renders, and a plain-text rendition (the title, the sessions, then `CONTEXT`, `KEY OUTCOMES` as dashes, `ACTIONS` as owner, action, and due) so a paste into a plain field gives words. The clipboard API goes first because it is exact about each flavor; where a frame refuses it, the markup is staged in a node parked off-screen, selected, copied, and removed inside the same click. Mail clients run no script and drop stylesheets, so what it builds is table layout, every style inline, system font stack (Calibri, Segoe UI, Arial), light palette only whatever the page's theme, one 640px table on a full-width ground painted white by both `bgcolor` and an inline background. The control carries the subject line beside it and does not print |

A second file holding the email is the fork this structure exists to prevent: it would have to be regenerated by hand every time a word changes, which is the drift the one-dataset rule forbids (section 3).

Two details decide whether either projection reads as considered. One measure governs the page: a per-element width narrower than the column leaves prose ending short of the rule above it, which looks like breakage rather than intent. And the email's ground is its own: markup copied as a fragment carries the styles of whatever it was selected inside, so a page in its dark theme tints the memo's edges unless the email paints white underneath itself.

The identity (the page):

The page uses the maintained palette and typography described in `THEMING.md`: canvas/surface, ink/muted/line, accessible accent, and distinct due/late roles. Titles and prose use the identity's sans face; dates and identifiers use its mono face. The concrete values live in the template's palette block. Fonts are system stacks, with no external request.

The identity (the email). It carries the page's palette into a form a mail client renders, and the page's typographic roles do not survive the crossing: one system face does all the work, and hierarchy comes from size, weight, and space.

| Role | Value |
|---|---|
| Ground | `#ffffff`, on a full-width table under the 640px one |
| Ink, muted, rule | The maintained identity's Light ink, muted and line roles |
| Accent, due | Light link for the eyebrow/outcome bar; warning for due and bad for late |
| Masthead | Eyebrow 11px letter-spaced caps, title 26px bold, one session line each at 13px, a 2px rule under the block |
| Section headings | 12px letter-spaced caps in the muted tone, carrying their space above (26px to 30px) rather than a rule beneath: a rule under every heading crowds a memo this short |
| Outcomes | A 3px accent bar, 14px of gutter, the lead bold and the detail after it, 14px between items |
| Actions | Column labels 11px caps over a 2px rule, rows on hairlines, owner bold and unwrapped, due unwrapped in the due tone |

## 5. Generation flow

1. Read the session capture whole: a workshop export, plan rows, or raw notes.
2. Draft the content per section 2 and section 3: resolve the dates, consolidate the actions, write the context paragraph last so it states what the session actually left behind.
3. Review the content with the operator; iterate until approved. Render nothing yet.
4. Encode the approved content as the dataset and inject it into the fixed renderer. That one file is the MoM: it renders the page and builds the email from the same block.
5. Deliver it, and say where the dataset sits and which control exports the email, so changing a word later needs nobody's help. The MoM stands as sent.

## 6. Cross-references

- `REF-Workshop.md`: the session whose capture feeds the MoM; the capture is the record, the MoM is its digest. The two share the dataset-plus-fixed-renderer doctrine.
- `REF-Plan.md`: where the ledger lives on; the MoM's action rows are the plan's items and dates, consolidated.
- `REF-StatusReport.md`: the period digest of the plan; a MoM digests one session, a status report one reporting window, and neither writes the plan.
- `REF-Flyer.md`: the one-pager sibling for concepts; a flyer carries an idea, a MoM records a session.

## 7. Anti-patterns

| # | Anti-Pattern | Correct Approach |
|---|---|---|
| 1 | Re-dumping the ledger: one MoM row per captured item | Consolidate per owner and theme; link the capture (sections 2, 3) |
| 2 | An action without an owner, or owned by "the team" | Every row names a person, or the explicit All (section 2) |
| 3 | Relative dates left relative | Resolve against the session date (section 3) |
| 4 | A weekday name that is not that date's actual day, in `meta.dateLabel` or in a due | Compute both against a calendar and check they agree before the content is approved (section 3) |
| 5 | Rendering before the content is approved | Content first; the projections are mechanical (sections 3, 5) |
| 6 | Content hand-authored in a projection's markup | The dataset carries the content; the renderer and the email generation carry none (sections 2, 4) |
| 7 | The email shipped as a second file beside the page | The page builds the email from the dataset on a control; a separate file has to be regenerated by hand for every word changed (section 4) |
| 8 | A second copy of the dataset maintained beside the artifact | The JSON block is the home; extract, never fork (section 3) |
| 9 | A per-element width narrower than the column, so prose ends short of the rule above it | One measure governs the sheet, and every element shares its edge (section 4) |
| 10 | Web CSS in the email projection: classes, external fonts, a dark theme | Inline styles, tables, system stack, light only (section 4) |
| 11 | The email pushed to the clipboard with the markup as its plain-text twin | Write a plain-text rendition as the second flavor, so a paste into a plain field gives words rather than tags (section 4) |
| 12 | The email previewed on the page: a panel, or a frame rendering it | It is a thing to paste, not a thing to look at there, and a strict artifact CSP renders a framed preview blank anyway. The control copies and says so (section 4) |
| 13 | A dataset that fails to parse answering with a blank page | The renderer guards the parse and names the fault where the document would be (section 4) |
| 14 | Editing a sent MoM to reflect later corrections | A follow-up note carries the correction (section 3) |

---

## 8. Skills that instantiate this REF

Generated by `scripts/sync_backlinks.py` from skill frontmatter; do not edit by hand.

Skills whose frontmatter `refs:` includes `REF-MoM`:

- `write-mom` - Produce a MoM per REF-MoM from a working session's capture (a workshop export, plan rows, or raw notes): draft the one-screen content (context paragraph, three to five key outcomes, one consolidated Owner/Action/Due table with dates resolved absolute against the session date), review it with the operator as plain content before any render, then encode it as the MoM dataset and emit the two projections in one pass from the skill's templates, the themed HTML artifact carrying the dataset with its fixed renderer and the email-safe HTML export with its derived pipe-separated subject line.

---

## 9. Agents that orbit this REF

Generated by `scripts/sync_backlinks.py` from agent frontmatter; do not edit by hand.

Agents whose frontmatter `refs:` includes `REF-MoM`:

- `project-manager` - Steers an engagement by its plan: authors and audits the plan dataset, issues the period's status report and its executive brief, and writes the MoM of a session; hand it a plan to publish, a period to report, or a session to digest.
