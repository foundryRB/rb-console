---
domain: framework
---

# REF: StatusReport (Periodic Status Reports over a Plan)

> Read this when producing a status report: one self-contained HTML page, issued per reporting period (a week, a month, a quarter), that says where an engagement stands for the people steering by it. Its dataset is derived from the plan (`REF-Plan.md`) for one window by a feed script whose every rule is stated here, then finished by the author's judgment (the outlook, the position, the lane notes, the asks), and projected by a fixed renderer as a printed brief: a verdict, the position, the lanes, the road ahead, the checkpoint, the asks, what was decided. An executive brief (§11) folds the same period onto one screen.

---

## 1. What a status report is (vs a plan, a MoM, a flyer)

Each instrument here is derived from its use-case and carries its own form and identity; none is a restyling of another. Pick by consumption:

| You want | Reach for | Because |
|---|---|---|
| The instrument a project is steered by across its life | Plan (`REF-Plan.md`) | Typed, dated, linked items; the system of record |
| The after-record of one session for the people who missed it | MoM (`REF-MoM.md`) | Context, outcomes, and actions of one event |
| One page, read at a glance, kept and pinned | Flyer (`REF-Flyer.md`) | An idea, a model, a decision; no period, no state |
| Where the engagement stands for one period, read in a minute | **Status report** (this REF) | A dated read of the plan for one window, with a verdict |
| The same period for the readers who steer by the verdict alone, read in ten seconds | **Executive brief** (§11) | The status report's verdict, at most three lanes, one line of need, the calendar |

A status report is a *read* of the plan, not a second plan. It carries the verdict for the period, the position in a few sentences, one weather word per lane, the road ahead, the next checkpoint, what the readers are asked to do, and what the plan recorded as decided. It repeats none of the plan's model wholesale, and every id on it links back to the plan's row. One report per period, issued and kept; the sequence of reports is the engagement's history as its stakeholders saw it.

## 2. The one rule: derived from the plan, finished by judgment

A hand-written status drifts from the plan within a week: a date typed from memory, a blocker the plan already closed, a milestone the plan re-anchored. The cure is the doctrine of `REF-Plan.md` §2 applied across two instruments:

**The facts are derived; only the judgment is authored.** A feed step reads the plan's dataset for the window and writes the report's factual collections by the rules of §4; the author writes only what a plan cannot know. Two agents feeding the same plan for the same window get the same facts, and a weaker agent cannot invent a milestone, a date, or a checkpoint, because none of those fields are typed.

| Derived from the plan (never hand-written) | Authored (judgment) |
|---|---|
| The road ahead: every gate and every milestone, by date, with the plan's short names | The outlook: the sky word, one headline sentence, one emphasis sentence |
| The checkpoint: the next day the plan names, or the next day a gate falls due, with everything the plan dates to it | The position: two to four short paragraphs, each a bold lead and one or two sentences; the first says what has been done so far, the rest what is at stake next |
| The lane skies (seeded) and the ids that decided each | Each lane's note, one sentence; the sky, corrected where the author knows better |
| The blockers: items in `block`, plus open dependencies past due | The asks: owner, ask, by, refs; seeded one per blocker, consolidated by the author |
| Decided this period: decision records and gate closures dated inside the window | The state: `draft` until the judgment is finished, then `issued` |

A fact the report needs that the plan lacks is a plan edit first (a short name, a checkpoint, a status flip, a log row), then a re-feed. Typing it into the report forks the record. A derived fact the author disagrees with is a plan correction, never a report edit; the feed is how a status report finds a plan's defects.

## 3. The dataset

The report ships as one dataset in a `<script type="application/json">` block inside the artifact; the fixed inline renderer projects it. Editing the report is editing the dataset.

```
meta        id, title, eyebrow, kind (weekly | monthly | custom),
            period {start, end, label, ordinal}, issued, author, audience,
            state (draft | issued), plan {id, title, version, file}, classification
outlook     {sky, headline, emphasis}         sky is sunny | cloudy | stormy
summary     [{lead, text}]                    two to four paragraphs
lanes       [{id, name, sky, decided_by[], note}]
stats       {gatesClosed, gatesTotal, blocked, open, milestones}
horizon     {start, end, today, window {start, end},
             points [{date, marks [{kind, id, lane, status, critical}]}]}
gates       [{id, name, short, closer, due, closed}]
milestones  [{id, name, short, owner, due, status, critical}]
checkpoint  {date, name, gates [{id, name, closer}],
             items [{id, type, name, owner, status, priority, critical, lane}]}
decided     [{date, id, name, text, kind, who}]
logCount    number of plan log rows inside the window
blockers    [{id, name, owner, lane, priority, due, status, critical}]
asks        [{owner, ask, by, refs[]}]
ledger      {total, rows [{kind, unit, count, days, from, to, ids[]}]}
footer      one line naming the plan, its version, and the issue date
```

| Field | Rule |
|---|---|
| `meta.period` | `start` and `end` ISO, inclusive; `label` the human form (`Week 3 · 31 August to 6 September 2030`), the week counted from the plan's `meta.anchor`; `ordinal` the week's place in the plan's horizon (`3/12`), derived from `meta.anchor` and `meta.horizon` of the plan |
| `meta.issued` | The issue date, ISO. The checkpoint, the blockers, and the lane skies are computed against it |
| `meta.plan.file` | The plan's file name beside the report; every id links to `<file>#item-<id>`. Absent, ids render as text |
| `outlook.sky` | `sunny`, `cloudy`, `stormy`; the word always renders beside its glyph and in its hue, never the hue alone. `headline` is one sentence stating the position, about twelve words because it renders at display size in a narrow column; `emphasis` one shorter sentence on what is at stake, rendered in the sky's hue, or empty |
| `lanes` | The plan's lanes, same ids, same order, same names. `decided_by` is the feed's evidence for the seeded sky and stays when the author overrides the sky |
| `horizon.points` | One entry per date that carries a gate or a milestone; `marks` name each with its kind, its lane (a gate takes the lane of its first reference that has one), its status (`done`, `open`, `blocked`), and the plan's critical flag |
| `checkpoint` | The next gate day: `gates` are the gates due on it, `items` everything else open the plan dates to it. It carries no name beyond its date |
| `asks` | Every ask names a person or role, a date, and the ids it clears; an ask without a by-date is a wish |
| `ledger` | The plan's ledger on the issue date (`REF-Plan.md` §4), folded by kind, with its total; derived, never typed |
| `state` | `issued` is immutable; a correction is the next period's report |

## 4. The derivation rules

The feed derives every factual collection from the plan dataset (`REF-Plan.md` §3) by these rules, and nothing else:

| Collection | Rule |
|---|---|
| `horizon.points` | Every gate (dated by its `due`, or by `closed.date` once closed) and every milestone that carries a date, superseded ones included and struck, descoped ones absent, grouped by date, ascending, each date carrying its `label`: the short names of its marks, one line each. Work that was done and then overtaken stays on the calendar struck through; hiding it makes the weeks it filled read as empty |
| `gates`, `milestones` | All of them, in date order; `short` falls back to `name` |
| `checkpoint` | The first date on or after `issued` on which an open gate falls due: the next gate day. `gates` are the open gates due that day; `items` are the items in `wait` or `block` whose `due` is that day, milestones first, then dependencies, assumptions, workstreams, risks |
| `decided` | Items whose `decision.date` falls inside the window, and gates whose `closed.date` does, newest first |
| `logCount` | Plan log rows dated inside the window; the count is shown, the rows are not, since the plan's log is the plan's |
| `blockers` | Items in `block`, plus dependencies in `wait` whose `due` is before `issued` (flagged overdue); blocked first, then by due |
| lane `sky` (seed) | `stormy` when the lane holds a blocked critical item, a blocked blocker-priority dependency, or an open critical item due on or before the checkpoint; `cloudy` when it holds any blocked or overdue item, or a blocker-priority dependency due within seven days of `issued`; `sunny` otherwise. `decided_by` lists the ids |
| `outlook.sky` (seed) | The worst lane sky |
| `asks` (seed) | One per blocked item: its owner, a placeholder ask naming the id, its due date, the id as ref |
| `stats` | Gates with a `closed` record over all gates; items by status |
| `ledger` | The plan's ledger rows as its renderer derives them on the issue date: superseded tracks by their window, tracks with a `cause` by their window, descoped tracks that kept a window as a negative, gates past their day by the working days since; folded by kind, each fold carrying its count, span, days, and ids |

The seeds are where the author starts, not where the report ends: a lane can be stormy with no blocker in the data (a date the author knows will slip) and sunny with one (a blocker with a decision already scheduled). The author corrects the sky and writes the note; the ids stay.

## 5. The projections

The renderer is fixed. One reading page, content to ~1080px, top to bottom:

| Block | Projection |
|---|---|
| Top line | The eyebrow and the audience on the left; the issue date and the author on the right; one rule under both |
| The verdict | The period as a large display numeral (`Week 3`) with its ordinal; the headline in the display face at display size, the emphasis in the sky's hue; beside them the sky glyph and the sky word; no counts, since the page shows no ladder or list the counts could be checked against |
| The position | The summary paragraphs as prose, each opening on its bold lead; beside them the lanes, one row each: glyph, name, sky word, note |
| The road ahead | One axis over the plan's horizon, ticked by week, the current week banded, a dashed line at today. One dot per date that carries a gate or a milestone, labelled with the date's `label`, the labels taking the first free level above or below the axis so none collide; done dates green, critical dates in the sky's critical hue. Under it, every week of the horizon from the first, past weeks muted, each listing its gates and milestones: symbol, name, closer or owner, id, date and status word. A week with neither says so in one line, so slack in the plan is visible rather than ambiguous; a week that has dated work but no milestone is a plan gap, and the fix is a milestone in the plan |
| The next gate day | The day named by its date, then two lists: the gates due (name, closer) and everything else the plan dates to that day (name, owner, status word) |
| The asks | One row per ask in date order, then by owner, whatever order the dataset holds them: the owner in the display face at display size, the ask, the ids, the date in the critical hue when it is the checkpoint's |
| Decided this period | The decision records and gate closures as one list, each on its bold name, with the count of plan log rows in the window |
| The ledger | One list, a line per kind: the count, the span, the days, the ids; the total in the head. The plan's ledger, read on the issue date |
| Footer | The plan named and linked, the issue date, the classification |

Nothing is a card, a chip, or a tile. Blocks separate by hairlines and whitespace; an empty collection renders one line saying so, never a blank panel. Semantic channels each carry one meaning: the sky is a glyph, a word, and a hue together; a gate is a diamond and a milestone a dot in the lists; a critical or blocked row carries the critical hue and its word.

## 6. The identity

A reading brief uses the maintained identity in `THEMING.md`. The template's palette block owns paper, band, ink, muted, rule and link roles. Storm/cloud/sun map to bad/warning/good and keep their glyph and word; critical/open/done share those semantic roles. Titles, period numerals, ask owners and prose use the identity's sans stack, with hierarchy carried by size and weight. Body text is 17px, at least 15px in lists.

Both appearances are designed: Light on bare `:root`, Dark through the system preference unless `data-theme` explicitly selects one. Print uses Light. System font stacks render offline. Hairlines and whitespace separate the report's prose and lists; the reading surface is opaque.

## 7. Runtime rules and print

One `.html`; `<meta charset="utf-8">` first; inline framework-free JS; data into the DOM via `textContent` and `createElement` only; a `<noscript>` line; no external requests. The renderer parses the dataset inside a guard and names the fault where the page would be, since the dataset is edited by hand. Date arithmetic rounds to whole days so a daylight-saving hour inside the horizon cannot add a week.

Printed, the report is the page on A4 portrait: white ground, the same order, sections unbroken across pages. Two pages is acceptable when the checkpoint is long; a third means the judgment text is too long, and the fix is cutting it.

## 8. Cadence, versions, and the record

One report per period, named for the plan and the window's end (`<plan-id>-status-<end>.html`), kept beside the plan and beside the reports before it. An issued report is immutable: the next period's report carries any correction, stating it as fact. Re-feeding a draft is free and expected; the author runs the feed again after a plan edit and keeps the judgment fields.

The report never writes back into the plan. What the feed reveals while writing it (a gate whose name promises what its evidence does not, a milestone marked blocked with nothing blocking it, a milestone with no short name) is a plan edit and a log row, then a re-feed; the report is downstream of the record, always.

## 9. Generation flow

1. **Feed** (skill `write-status-report`): point the feed at the plan file and the window; it writes the report with the derived collections filled and the judgment fields seeded, in `draft`.
2. **Read the derived blocks against the plan.** Where the plan is wrong or thin, edit the plan (short names, a checkpoint, a status), publish it, re-feed.
3. **Author the judgment**: the headline and emphasis, the position, the lane notes, the asks; correct any seeded sky.
4. **Verify**: open the file in both themes, zero console errors, an id opens the plan at its row, the road ahead has no overlapping label, print preview.
5. **Issue**: set `meta.state` to `issued`; the file is sent as it stands, and the next period gets its own file.

## 10. Content rules

| Rule | Meaning |
|---|---|
| Verbatim ids, absolute dates, named owners | The plan's ids and dates as they are; "the client" and "next week" never appear in the dataset; the renderer may say "this week" because it computes it |
| One sky, one sentence | The headline is one sentence of about twelve words stating the position; the sky word is the summary of that sentence, and the two never disagree |
| The position states position, not effort | Two sentences per paragraph at most. The first paragraph says what has been done so far, in facts; the rest what is at stake next; how hard anyone worked belongs in no steering report |
| Short names are plan data | A calendar label the plan does not carry is not typed into the report; the plan gains a `short` and is re-fed |
| The gate day is plan data | The next gate day is the gates' own due dates; the report names it by its date and never coins a word for it |
| Asks are requests with a date | Owner, what is asked, by when, the ids it clears; a fact the reader should merely know is a position sentence |
| Empty is a fact | A block with nothing in it says so in one line |
| NO em-dashes, anywhere | Hard rule (INT-SHAPE-002), in the dataset and in the renderer |

## 11. The executive brief

A second read of the same period, for the readers who steer by the verdict alone: one screen carrying the status report's verdict, at most three lanes, one line of need, and the road ahead below the fold. It is fed from the issued status report, never from the plan, so the brief and the report cannot disagree about the period: the verdict, the skies, and the calendar are the report's, copied; the fold of the lanes, the wording of the notes, and the need sentence are the author's.

```
meta        the status report's, with id <status-id>-exec, title "<plan title>: executive brief",
            source {id, title, issued, file} naming the status report it reads, state (draft | issued),
            audience only when the author names one
outlook     the status report's, verbatim
lanes       [{id, name, sky, from[], decided_by[], note}]    at most three
need        {text, refs[]}                                   one sentence
horizon, gates, milestones, ledger   the status report's, verbatim
footer      one line naming the status report and the plan
```

| Collection | Rule |
|---|---|
| `outlook` | Copied from the status report. The brief states no position the report does not |
| `lanes` | At most three. The author declares the fold: each brief lane reads one or more of the report's lanes (`from`); its sky is the worst of its sources, `decided_by` their union, its name the first source's unless the fold names it. When the report carries three lanes or fewer and no fold is declared, all of them, in order. A lane the readers do not steer by is left out, and leaving it out is the judgment |
| `lanes[].note` | Seeded from the sources' notes; authored to one sentence |
| `need` | Seeded from the asks due on or before the checkpoint, each with its owner and date; authored to one sentence with absolute dates, naming an owner only where the reader is expected to act on that owner. `refs` is the union of those asks' refs, cut with the sentence to the ids it clears, so every id on the line opens the plan |
| `horizon`, `gates`, `milestones`, `ledger` | Copied from the status report; the calendar reads the same three collections in both instruments, and the ledger's total sits under the sky word |

The projection wears the report's identity (§6) over four blocks: the top line and the verdict as in §5; the lanes as the centre, one column each, glyph, name, sky word, note; the need as one line in the display face with its ids; the road ahead as the axis and its key alone. The footer links the status report and the plan. Printed, it is one A4 page.

One brief per status report, named `<plan-id>-status-<end>-exec.html` beside it, issued after the report and never before; a report re-fed in draft has its brief re-fed. An issued brief is as immutable as its report.

## 12. Cross-references

- `REF-Plan.md` - the record this report reads; §3 carries the `short` field this report consumes and the gate rule the next-gate-day block projects, and every id here links to its rows.
- `REF-MoM.md` - the digest of one session; a MoM digests an event, a status report a period, and neither writes the plan.
- `REF-Workshop.md` - the session instrument whose capture lands in the plan; the report picks it up as decisions in the next window.
- `REF-Flyer.md` - the one-glance sibling for concepts; a flyer carries an idea, a status report a dated position.

## 13. Anti-patterns

| # | Anti-Pattern | Correct Approach |
|---|---|---|
| 1 | Status facts typed from memory beside the plan | Derived from the plan by the feed; a wrong fact is a plan edit and a re-feed (§2, §4) |
| 2 | The report as a second plan: every item re-listed, the schedule chart redrawn | The road ahead is dates and short names; the plan carries the chart, the tables, the log (§1, §5) |
| 3 | A calendar labelled with full names and ids | The plan's `short` names, one dot per date, labels on free levels (§5) |
| 4 | A sky as color alone, or a headline that contradicts it | Glyph, word, and hue together; one sentence, one sky, in agreement (§5, §10) |
| 5 | A lane sky left at its seed without reading it | The seed is the start; the author confirms or corrects each lane and writes the note (§4) |
| 6 | An ask without an owner, a date, or the ids it clears | Owner, ask, by, refs: or it is a position sentence (§10) |
| 7 | A checkpoint or a milestone name the plan does not carry | Plan data first, then the feed (§10) |
| 8 | Editing an issued report | The next period's report carries the correction (§8) |
| 9 | Writing back into the plan from the report | The plan is edited first, the report re-fed; the report is downstream (§8) |
| 10 | Cards, chips, stat tiles, mono labels: the dashboard look | A printed brief: prose, lists, hairlines, whitespace (§5, §6) |
| 11 | `innerHTML` with data, or a CDN script | `textContent` only; inline, framework-free JS (§7) |
| 12 | Effort narrated as status | Position and stakes; effort belongs in no steering report (§10) |
| 13 | An executive brief fed from the plan, or carrying its own verdict | Fed from the issued status report; the verdict, the skies, and the calendar are copied (§11) |
| 14 | Four lanes in the brief, or a note that runs to a paragraph | At most three lanes, one sentence each; the fourth is folded in or left out (§11) |

---

## 14. Skills that instantiate this REF

Generated by `scripts/sync_backlinks.py` from skill frontmatter; do not edit by hand.

Skills whose frontmatter `refs:` includes `REF-StatusReport`:

- `write-status-brief` - Produce an executive brief per REF-StatusReport from an issued status report: feed the report's dataset through the deterministic from_status.py, which copies the verdict and the road ahead, folds the lanes into at most three by the fold the author declares, and seeds the one line of need from the asks due by the checkpoint, rendered by the fixed one-screen template; then author only the lane notes and the need sentence, verify, and issue.
- `write-status-report` - Produce a periodic status report per REF-StatusReport from a plan instrument: feed the plan's dataset for one reporting window (an ISO week, a calendar month, or two dates) through the deterministic from_plan.py, which derives the road ahead (every gate and milestone by date), the checkpoint, the blockers, what was decided, and the seeded lane skies into a draft rendered by the fixed printed-brief template; then author only the judgment fields (the outlook headline and emphasis, the position, the lane notes, the asks), verify, and issue.

---

## 15. Agents that orbit this REF

Generated by `scripts/sync_backlinks.py` from agent frontmatter; do not edit by hand.

Agents whose frontmatter `refs:` includes `REF-StatusReport`:

- `project-manager` - Steers an engagement by its plan: authors and audits the plan dataset, issues the period's status report and its executive brief, and writes the MoM of a session; hand it a plan to publish, a period to report, or a session to digest.
