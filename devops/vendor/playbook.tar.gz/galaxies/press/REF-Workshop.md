---
domain: framework
---

# REF: Workshop (Typed Working-Session Instruments)

> Read this when producing a workshop or any live, timeboxed working session: a single self-contained HTML instrument carrying one session dataset of typed activities, rendered as full-screen working surfaces the room decides on, with outcomes captured live on the surface and exported to the plan. Two audiences, strictly separated: the room's surfaces open by default; the facilitator's script is gated.

---

## 1. What a workshop is

A workshop is a sequence of **activities in which a group does work on a shared surface**, run toward named outcomes inside timeboxes. That definition carries the whole architecture:

- It is not a deck: a deck advances a narrative at an audience; a workshop's screen is a surface the room works *on*, and the work leaves marks.
- It is not a plan: the plan (`REF-Plan.md`) is the standing record; a workshop is one event over it, consuming its items and returning decisions.
- It is not a document: a room cannot work a scrolling page, and a wall of identical tiles carries no work at all.

Two audiences share one instrument and must never see each other's layer: **the room** (participant-facing surfaces, participant-facing language only) and **the facilitator** (objective, spoken openers, stall fallbacks, watch-outs). The room's cover is what the file opens on; the script is reached deliberately. An internal objective on a room surface is a defect, not a style choice.

## 2. The architecture: typed activities

The unit of a workshop is the **activity**, and activities are **typed**. A type is a triple: a data contract, a room surface, and a capture shape. The type decides the layout, which is why no two kinds of work look alike on screen:

| Type | The work | The surface | The capture |
|---|---|---|---|
| `frame` | Context set so later blocks read; no decisions | A few large panels, the inactive ones dimmed | None |
| `collect` | A decided thing gets its missing facts | A spec sheet: the known headline plus labeled slots, typed into live | The slot values |
| `walk` | Statements validated one by one | One statement at a time, large, with verdict buttons; a verdict may open fields (action, owner, date); a progress trail of stamps | A verdict per statement, with its fields |
| `sort` | Items triaged into named outcomes | A queue, the current item center-stage in full, buckets that items land in and pick up fields from | A bucket per item, with its fields |
| `assign` | Names put against fixed things | A roster: rows with typed name fields; fixed rows shown dimmed so the ladder reads whole | A name per editable row |
| `close` | Everything recorded, read back | A generated read-back grouped by activity, unresolved items glaring, with the export | The export itself |

**Extension rule:** a new type is earned by a real session needing work no existing type carries, and it lands as the full triple, contract, surface, and capture, added to the renderer and to this table in the same change. A session never hand-builds a one-off screen; if the work does not fit a type, the type system grows.

## 3. The session model

The session ships as one dataset in a `<script type="application/json">` block; the fixed inline renderer projects it. Editing the session is editing the dataset.

```
meta        id, title, eyebrow, session, date, duration (minutes), version,
            classification, question, objective
activities  [{id, kind, name, mins, question,
              script {goal, run[], say[], watch},
              <the kind's own content, per the contracts below>}]
```

Per-kind content contracts:

| Kind | Content |
|---|---|
| `frame` | `panels [{name, phase, line, done, dim}]` |
| `collect` | `item {id, badge, title, known}` + `slots [{k, label, hint}]` |
| `walk` | `prompt` + `verdicts [{k, label, tone, fields[]}]` + `items [{id, stmt, detail}]` |
| `sort` | `buckets [{k, label, tone, fields[]}]` + `items [{id, name, ask, owner, when}]` |
| `assign` | `rows [{id, name, evidence, editable, ph or who}]` |
| `close` | Nothing; it derives everything from the recorded state |

Rules:

- **`meta.question` is the room's line; `meta.objective` is the facilitator's** and renders only in the script. The same split governs every field: `question`, names, statements, and asks are participant-facing; everything under `script` is internal.
- **Timeboxes are honest and sum to `meta.duration`**; the rundown offsets derive from them. The close activity's minutes are never the ones that get cut; a `watch` or `fallback` names what gets cut instead.
- **Item ids are the plan's ids, verbatim**, whenever a plan exists, so capture lands without translation.
- **A field holds one fact, and presentation is composed at render.** A `sort` item carries `owner` and `when` as separate values, never one display string with a separator in it; the renderer joins them and can weight them apart, which a stored composite forbids. The same rule governs every field the dataset holds.
- **Verdict and bucket tones** come from the outcome trio (`ok`, `mid`, `hot`) and always render with their word, never as color alone.
- A `sort` queue or `walk` trail beyond about eight to ten items is two activities.

## 4. Live capture: the surface is the record

The screen is not a display; outcomes are recorded **on it, during the session**: slots typed, verdicts stamped, items landed in buckets, names entered. The runtime keeps that state locally (it survives a refresh and needs no network), the script view shows it inline under each item, the read-back generates itself from it, and the close activity exports it as text for landing in the plan. A capture that lives on paper beside the screen, or in minutes after it, is the failure this artifact kind exists to end.

After the session the workshop artifact stands as run; its export lands in the plan as decision fields, status flips, and log rows (`REF-Plan.md` §8), and a follow-up session is a new instrument. The sync is two-way by construction: items in are the plan's items; outcomes back become the plan's next version.

## 5. The identity

Two surfaces, one instrument: **the stage and the script**.

| Surface | Tokens | Role |
|---|---|---|
| Stage (the room) | the identity's Dark roles: canvas for the ground, surface and raised for panels, line for edges, ink, muted for dim and faint | A dark stage reads on a TV in a lit room; the current item is dominant, the queue peripheral |
| Outcome tones | `ok`, `mid`, `hot`: the identity's good, warn and bad roles, each with a deep fill variant owned by the template | The only strong color on stage is recorded work: stamps, landed buckets, open items glaring in the read-back. Always with their word |
| Script (the facilitator) | the identity's Light roles: surface for paper and panels, line for edges, ink, muted for dim, link for the inked accent | The printable internal layer, badged internal in its masthead |

The type dictates the layout; the palette only marks state. A page of same-shaped boxes is the tell that a type is missing. Stage and script are two usage views: the stage uses the maintained Dark palette and the script uses Light, independently of the viewer's appearance preference (`THEMING.md`). Covers and activity names use the identity's sans display role; prose uses its sans body role; identifiers, offsets and timeboxes use mono. System font stacks keep the instrument offline. Ambient cover motion stays behind content, pauses when hidden and stops for reduced motion and print.

## 6. The runtime rules

One `.html`, `<meta charset="utf-8">` first, inline framework-free JS, data into the DOM via `textContent` and real inputs only, a `<noscript>` line, no external requests beyond the font host. The stage adds keyboard handling (arrows step items then activities, escape returns to the cover, one deliberate key opens the script) and local state persistence, and nothing else: no timer, no network call, nothing that can fail live in front of a customer. Because state lives with the browser context, the session runs from one kept-open tab or the downloaded file.

## 7. Print

Printing always yields the script, whole: the rundown, every activity with its spoken lines, fallbacks, and items, and the recorded state inline as it stands. The stage never prints. The printed script is the facilitator's paper; the capture export is the record.

## 8. The engine

The workshops engine, `vf-workshops`, is the library shelf for sessions. It stores each session dataset with every revision kept, appended and never rewritten, and a session stands ephemeral, then draft once a revision is saved, then published once an export is published. It holds the runs over a revision too: a rehearsal or the session itself, each with its own capture, landed as the room records it and frozen at the close.

Three doors adapt one core, and every door enters the same use cases: a UI where a person authors and edits a session and runs the two projections, no agent required; an HTTP API serving the dataset; and an MCP door for creating and revising sessions, running them, and landing captures (`mcps/vf-workshops.md`).

The §3 schema is the contract the engine serves: every session write, a new session or a revision, validates against the whole of it, and a dataset that breaks a rule is stored by no door. The artifact stays the render: the engine's export is the standalone file the `bootstrap-workshop` renderer produces for that revision, byte for byte, and a run's plan export carries its capture under the plan's item ids, verbatim, for landing in the plan (§4).

## 9. Generation flow

1. Scaffold (skill `bootstrap-workshop`): the full typed renderer, the stage and script tokens, and a small example session exercising every type. **The author edits only the dataset.**
2. Author the session: activities of the right types, honest timeboxes, participant-facing questions, the facilitator layer under `script`, items citing the plan's ids, verdicts and buckets named for the outcomes the session must produce.
3. Verify: the file opens on the cover with zero console errors; every surface is walked and worked (type, stamp, land, name); the state survives a refresh; the script shows the recorded state; print yields the script.
4. Run the session from the stage; record on the surface; export at the close; land the capture in the plan.

## 10. Content rules

| Rule | Meaning |
|---|---|
| Room language is the participants' language | Questions and asks as the room hears them; stances, tactics, and objectives live under `script` only |
| Spoken lines are written to be spoken | First person, plain words, one breath each |
| Every decide activity names its outcome vocabulary | The buckets and verdicts are the decision space; "discuss" is not an outcome |
| Facts match the plan | Ids, owners, dates, and specifications are the plan's, verbatim; a correction lands in both or it is a fork |
| NO em-dashes, anywhere | Hard rule (INT-SHAPE-002), in markup, JS, and JSON strings alike |

## 11. Cross-references

- `REF-Plan.md` - the system of record: items in, capture back; the two share the item-id vocabulary and nothing else.
- `REF-Slidev.md` - the presented sibling: a narrative at an audience. A workshop surface is worked; a slide is watched.
- `REF-Delivery.md` - the lifecycle whose gates a session may put names against; a gate closed in a room still closes where the work lives.

## 12. Anti-patterns

| # | Anti-Pattern | Correct Approach |
|---|---|---|
| 1 | The internal layer reachable by accident: the script as the landing view, objectives or stances on room surfaces | The cover is the landing view; the script is gated and badged internal (§1, §3) |
| 2 | Uniform tiles as the room surface, whatever the work | The activity type dictates the layout; a missing fit grows the type system (§2) |
| 3 | A one-off hand-built screen for one session | A new type lands as contract, surface, and capture, in the renderer and §2's table together |
| 4 | Presentation-only screens with capture on paper or in minutes | Outcomes are recorded on the surface, live, and exported (§4) |
| 5 | Editing the workshop artifact after the session to reflect outcomes | The capture lands in the plan; the workshop stands as run (§4) |
| 6 | Item ids or facts that diverge from the plan | The plan's ids and facts, verbatim; corrections land in both (§10) |
| 7 | An outcome tone as color alone, or spent on decoration | Tones mark recorded work and carry their word (§5) |
| 8 | A runtime that can fail in front of the room: timers, network calls, external state | Keyboard, surfaces, local state, export; nothing else (§6) |
| 9 | Timeboxes that do not sum, or a read-back that gets cut | The rundown derives from honest minutes; the close spends the buffer, never loses it (§3) |
| 10 | Following the viewer's theme | Dark stage and paper script, explicitly, on every ground (§5) |

---

## 13. Skills that instantiate this REF

Generated by `scripts/sync_backlinks.py` from skill frontmatter; do not edit by hand.

Skills whose frontmatter `refs:` includes `REF-Workshop`:

- `bootstrap-plan` - Scaffold a new data-driven project-plan instrument per REF-Plan: a single self-contained <plan-name>.html carrying one embedded dataset (items, gates, log) and the fixed renderer with one projection per content type (masthead band with stat tiles, milestone rail, month-gridded schedule chart with gate rows, checkpoint and today lines, one id-ordered dependency table with priority badges and sub-dependency indentation, one-line assumption statements, workstream and risk tables, gate ladder, day-grouped newest-first decision log, a ledger of effort and delay derived from the same dataset), rows closed to their name line, every id in prose linked to its row, lane, status, priority, and owner filters composing from one state, themed light and dark with machine-validated lane and status palettes.
- `bootstrap-workshop` - Scaffold a new typed working-session instrument per REF-Workshop: a single self-contained <session-name>.html carrying one session dataset of typed activities (frame, collect, walk, sort, assign, close) and the fixed renderer that gives each type its own full-screen working surface, records outcomes live on the surface (persisted locally, exported at the close), and gates the facilitator script behind the presentable room view.
- `write-mom` - Produce a MoM per REF-MoM from a working session's capture (a workshop export, plan rows, or raw notes): draft the one-screen content (context paragraph, three to five key outcomes, one consolidated Owner/Action/Due table with dates resolved absolute against the session date), review it with the operator as plain content before any render, then encode it as the MoM dataset and emit the two projections in one pass from the skill's templates, the themed HTML artifact carrying the dataset with its fixed renderer and the email-safe HTML export with its derived pipe-separated subject line.

---

## 14. Agents that orbit this REF

Generated by `scripts/sync_backlinks.py` from agent frontmatter; do not edit by hand.

Agents whose frontmatter `refs:` includes `REF-Workshop`:

- `facilitator` - Prepares and runs a live, timeboxed working session over the plan: the runsheet, the room screens, and the decision capture that lands back in the plan; hand it a session to prepare or a capture to land.
