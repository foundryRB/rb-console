---
domain: pkm
---

# REF: Foreign Brain (AI-Augmented Second Brain)

> The architectural pattern for an AI-augmented Personal Knowledge Management system: capture is loose and human-authored, output is structured and AI-maintained, trust is earned via deterministic checks rather than line-by-line review. Read this when designing or maintaining a Foreign Brain instance.

---

## 1. The core idea

A **Second Brain** (Forte) is your trusted external memory: structured, navigable, queryable. The naive AI extension would have AI write into the Second Brain directly - but AI output isn't trusted by default, and a Second Brain you can't trust is no Second Brain at all.

The **Foreign Brain** insight: AI contributions to the structured layer are *foreign* by nature (not your direct authorship). They become **trusted** - never *native* - through deterministic testing + an audit trail written back into the source files themselves (not into tooling-only side-channels). Trust is gained the same way any production system gains trust: automated invariants and readable provenance - never via "review every word the AI wrote." No Git layer is required for this; the source-file audit footer carries the load instead.

This is the same principle as Time-to-Trusted-Output for production code: trust through automation, not approval gauntlets.

---

## 2. Two layers - capture vs. digest

A Foreign Brain has exactly two layers:

**Inbox layer** - your input space.
- Free prose, brain dumps, voice transcripts, web clips, drafts, anything in any form.
- Multiple ingestion types coexist; new forms can be added at any time.
- Zero schema. Creative liberty preserved.
- One canonical example: a `daily/YYYY-MM-DD.md` journal entry. Other examples: clipped articles, conversation transcripts, photos with captions.

**Augmented layer** - your Second Brain.
- Structured frontmatter, type-aware notes, queryable via Dataview / Tasks plugins / similar.
- AI maintains it; you consult it.
- Organized via a methodology like PARA (Projects / Areas / Resources / Archive).

**Direction of flow:** Inbox → AI digest → Augmented. The user thinks and writes; structure happens around them. The user never types frontmatter; never files notes by hand; never reorganizes. AI does that.

### Layer separation - the navigation rule

**Inbox is a chronological archive of raw human input. PARA is the Foreign Brain.** They are not the same surface, even though both live as `.md` files in the same vault.

- **Graph view, backlinks, hub aggregation, and wikilink discovery anchor on PARA only.** Opening a hub like `[[Lara]]` should surface curated PARA notes about Lara, not raw journal entries that happened to mention her.
- **Inbox/Processed files contain no wikilinks** (other than what the human originally wrote). Digest does NOT enrich source files with `[[link]]` annotations - that pollutes the graph with raw inputs and conflates "I once wrote this thought" with "this is curated knowledge."
- **PARA notes that derive from journal entries attribute in prose** ("from journal 2026-01-11") rather than via wikilink (`[[2026-01-11]]`). Plain-text attribution keeps the journal out of the navigation graph while preserving traceability.
- **Search remains the cross-layer bridge** - full-text search reaches Inbox/Processed; navigation does not. This is intentional.

If someone wants the chronological view ("what was I thinking on date X?"), they search or open the Processed file directly. They don't navigate there from the graph.

---

## 3. PARA mapping

The Augmented layer is organized via PARA:

| Folder | Means |
|---|---|
| `01 Projects/` | Active outcomes with end criteria |
| `02 Areas/` | Ongoing responsibilities (no end date) |
| `03 Resources/` | Reference material |
| `04 Archive/` | Inactive - anything `status: archived` |

A note's `status` field drives its folder. Status transitions trigger automatic file moves. **Default for new content is Area, not Project** - projects need an end criterion; ongoing operations are Areas.

---

## 4. Inverted audit - wetware survives the digest

The audit trail goes on the **source** file, not on the target. When the digest processes an Inbox file, it appends a `<!-- DIGEST CHANGELOG -->` HTML comment to the source listing every operation performed on the Augmented layer because of that file. Then the source moves to `00 Inbox/Processed/` (immutable).

Why footer-on-source rather than comment-on-target:

- **Many-to-one models naturally** - one Inbox file may produce many hub edits; the source's footer enumerates them all.
- **Hubs stay clean** - no audit comments cluttering the consultation surface.
- **Reverse query is the common case** - "what did this thought produce?" Open the processed file. Forward query ("where did this synthetic statement come from?") is debug-level, served by grepping audit footers across `Processed/`.
- **Manual review is trivial** - open processed file, read prose + footer, done.

The Inbox is **immutable after digest**. Files in `Processed/` never get modified. If the user wants to add new thinking, write a new Inbox entry.

---

## 5. Trust mechanism - automation, not review

Two deterministic gates make the Augmented layer trustworthy:

| Gate | What | Run when |
|---|---|---|
| **Validator** | Walks the vault, asserts schemas + cross-references + naming + status/folder consistency. Pass/fail. | After every digest; on demand |
| **Audit footer** | Every digest writes a changelog to the source file before moving it to Processed; the footer enumerates every synthetic edit (which hub, which section, what was added) | Implicit in digest |

No Git layer is part of this pattern - the audit lives **in the source file**, not in Git history. Recovery from a bad digest is footer-driven: read the footer in the Processed file, undo each listed edit by hand in the affected hub. The Inbox source survives intact in `Processed/`, so wetware is never lost.

No content gates. No AI-written-X-needs-human-approval. Trust comes from the safety net (validator + readable footer), not from inspection.

A Vault Health dashboard (Dataview queries) surfaces drift passively inside the editor - orphaned hubs, archived items in active folders, broken wikilinks, etc.

---

## 6. Task management - three buckets

The Augmented layer holds tasks; the dashboard surfaces them in three buckets, never as a tag firehose:

- **Actions** - executable now, no unmet dependencies. Today's view.
- **Blocked** - waiting on a date or another task. Visible-but-inert; hidden from Actions until ready. Use Tasks plugin `🆔 id` + `⛔ id` syntax for cross-task dependencies.
- **Decisions** - items requiring thinking. **Not tasks.** Listed separately. Surfaced in conversation if parked too long.

Tasks live in their natural hub (the area or project file that owns them); the dashboard queries across hubs via tags + status. AI never adds AI-agency items to the user's task list - those are silent operations; if a record is needed, it goes in the digest's audit footer, not the user's task list.

---

## 7. Note kind, frontmatter, and the folder-as-truth principle

**Folder is the single source of truth for what kind of note something is.** A file in `02 Areas/People/` is a person. A file in `01 Projects/` is a project. Don't duplicate the kind into a `type:` frontmatter field - that's redundant data prone to drift (Top Violation #1: don't duplicate without mechanical sync).

Frontmatter holds only fields that *drive behavior*, not fields that describe what the file already is by virtue of where it sits.

| Note location | Required frontmatter | Why |
|---|---|---|
| `01 Projects/<name>.md` | `status: active\|archived`, `created: YYYY-MM-DD` | Status drives folder moves on archival; created drives age-based queries |
| `02 Areas/<name>.md` | `status: active\|archived` | Folder moves on archival |
| `02 Areas/People/`, `Places/`, `Brands/` | (none) | Entity hubs don't archive; their existence is the signal |
| `03 Resources/<name>.md` | `status: active\|archived` (optional) | Most resources don't archive; add status only if a resource ever retires |
| `00 Inbox/daily/YYYY-MM-DD.md` | `date: YYYY-MM-DD` | Drives chronological queries |
| `00 Inbox/<other>.md` | (none) | Inbox is loose; digest extracts whatever is there |

Anything beyond this is content, not metadata. Do NOT add fields "in case we need them later." If a query is needed later, the folder location plus full-text search covers ~all cases without a frontmatter shadow-system.

The validator (I2) enforces `status` ↔ folder consistency: `status: active` must live under `01 Projects/`, `02 Areas/`, or `03 Resources/`; `status: archived` must live under `04 Archive/`. The validator does NOT enforce a `type:` field because there isn't one.

---

## 8. Hubs, Phantoms, and the registry

### Hub / Stub / Phantom - commitment levels, not file states

When you write `[[X]]` in any prose, you're declaring "this is a graph node." The next question is: *how much do you want to invest in X being a real knowledge node?* The answer maps to one of five commitment levels:

| Choice | Investment | Meaning | Pick when |
|---|---|---|---|
| **Hub** | High | "X matters and I have content about it." File exists, has substance. Visiting teaches the visitor something. | You can write substantively about X right now. |
| **Stub** | Low | "X matters, but I have nothing to write yet." File exists, minimal content (a line or two). | X is a recurring entity (a person, a brand) and you want the graph node to exist for backlinks to accumulate against. |
| **Approved Phantom** | None (deliberate) | "I'll mention X, but I don't want a graph node." No file. Registered in `Hub.md`. | Archived-only entities, doc examples, out-of-scope mentions. Stubbing would falsely suggest X is part of the active graph. |
| **Untriaged Phantom** | None (accidental) | "I haven't decided." No file. Counts as drift. | Default state when you write `[[X]]`; the validator surfaces these for triage. |
| **Delete (the wikilink)** | Negative | "The wikilink shouldn't exist." Mention becomes plain text or the source goes. | Typos, mentions that don't deserve graph status at all (just a word, not an entity). |

The triage decision answers a single question: **am I investing in this entity becoming a node?** Hub/Stub = yes (high/low). Approved Phantom = no, but the link is fine. Delete = no, and the link shouldn't exist either. Drift = haven't decided yet.

```
                  Untriaged Phantom (raw)
                           │ triage = "am I investing?"
       ┌───────────────────┼───────────────────┬───────────────────┐
       ▼                   ▼                   ▼                   ▼
    Delete         Approved Phantom         Stub                  Hub
   (no, kill      (no investment,         (yes, low          (yes, high
    the link)      registered)             investment)         investment)
```

This commitment framing is load-bearing because:
- **Auto-stubbing every phantom** = every casual mention becomes a thin file = graph noise + false coverage.
- **Never stubbing anything** = important recurring entities stay phantom = navigation never resolves, future content has nowhere to land.
- **Refusing to triage** = drift accumulates, forgotten mentions clutter validation reports.

### `Hub.md` registry

A vault's `Hub.md` is the single source of truth for the navigation surface:

- **Top-level navigation** (manual list: dashboard, MOC pages, Inbox)
- **PARA listings** - Dataview queries grouped by sub-folder, mirroring the folder tree (drift-proof: new sub-folders auto-appear)
- **Approved Phantoms** - a flat table of `| Wikilink | Reason |` pairs

The validator (I10) reads `Hub.md` and enforces:
- Every wikilink in the vault resolves to an existing file OR appears in the Approved Phantoms table - otherwise it's "wandering" (drift, surfaces in I6).
- Every Approved-Phantom row's wikilink does NOT resolve to a file - otherwise the entry is stale (the phantom became real; promote it out of the table).

This is the duplication-must-be-mechanically-checked principle in practice: the table mirrors a vault state (which wikilinks have no files), and the validator keeps them aligned.

### Hub-creation rules

1. **One hub per concern.** If two hubs would substantively overlap, merge them or split via the core+specialization pattern.
2. **Default to Area, not Project.** Projects need an end criterion; ongoing operations are Areas (see §3).
3. **Retiring a hub** = flip `status: active → archived`. The digest/validator move the file to `04 Archive/` per the naming convention below. Don't manually move; let the status-driven move happen.
4. **No hand-curated lists in Hub.md.** Use `GROUP BY file.folder` Dataview queries instead. Manual lists drift on every new file.

### Archival naming convention

When a file's `status` flips to `archived`, it moves to `04 Archive/<Kind> - <original name>/` (or just `04 Archive/<Kind> - <original name>.md` if no asset folder). The `<Kind>` prefix is mandatory so the archive skims cleanly:

- `Project - <original name>` for archived projects (e.g., `Project - House Purchase + Move`)
- `Area - <original name>` for retired areas (rare; areas usually stay active)
- `Resource - <original name>` for archived resources (e.g., `Resource - Stumble Guys`)

Tags are **preserved** through archival - don't strip them on move. This keeps Dataview queries finding archived content. Validator I9 warns when archived items violate the naming convention.

---

## 9. Capture forms (intake creativity)

The Inbox layer accepts any form:

- Dated journal entries (`daily/YYYY-MM-DD.md`)
- Web clips (`<clip-name>.md`)
- Voice transcripts
- Drafts in progress
- Meeting notes (with transcript + synthesis)
- Decision logs (context / options / chosen / why / revisit-when)
- Quick uncategorized thoughts

Templates are scaffolds, not enforced shapes. They guide structure; deviating is fine. The digest reads everything regardless.

---

## 10. AI digestion - the maintenance contract

The user invokes `digest` at will. The digest skill:

1. Reads all unprocessed Inbox files
2. Extracts decisions, tasks, people, places, brands, project mentions
3. Routes each item to the right hub in the Augmented layer
4. Auto-stubs new wikilinks (keeping the graph real, not phantom)
5. Writes the changelog footer to each source file
6. Moves source files to `Processed/`
7. Runs the validator

The digest never:

- Modifies hub items already present (only adds new)
- Deletes content from source files (only appends footer + moves)
- Re-extracts from already-Processed files (immutable)
- Generates synthesis content (only structured extraction)
- Makes decisions for the user (flags, doesn't act)

---

## 11. Frictionless workflow

1. User writes Inbox content (any form, whenever)
2. User invokes `digest` at will
3. AI extracts, structures, files, audits (footer back to source)
4. AI surfaces findings next conversation (validator failures, parked decisions, overdue tasks)
5. User consults the dashboard to plan their day
6. Anything wrong: open the relevant `Processed/` file, read its audit footer (it lists every synthetic edit), and undo them by hand in the affected hub. The Inbox source is preserved either way.

Runtime user flow is read-only (dashboards, hubs) or append-only (Inbox). Both instant. No manual review steps in the user-facing path.

---

## 12. Anti-patterns

| # | Anti-Pattern | Correct Approach |
| - | ------------ | ---------------- |
| 1 | Asking the user to confirm AI writes - including during conversational design changes, not just during digest | Trust via validator + audit footer, not approval gauntlet. Once direction is agreed, execute the full set of edits and report what changed; reserve confirmation only for genuine forks (irreversible operations, undecided design splits, scope expansion beyond what was discussed). |
| 2 | Provenance markers in note bodies | Audit lives in footer-on-source; user notes stay clean |
| 3 | Quarantine zone requiring manual promotion | Adds friction; defeats automation premise |
| 4 | Pre-classifying captures | Capture is loose by intent; classify on digest, not on input |
| 5 | Manually filing notes by status flip | Status field drives folder; let scripts move files |
| 6 | Bundling independent items behind one gate | Each task gets its own dependency; one block doesn't stall the rest |
| 7 | Phantom wikilinks treated as bugs | Phantoms are aspirational; auto-stub on digest, not preemptively |
| 8 | Hand-curated MOCs / aggregators | Drift trap; use Dataview / Tasks queries - auto-generated |
| 9 | Templates with mandatory headings | Scaffolds, not contracts; user can ignore sections |
| 10 | Project for everything active | "Active" ≠ Project; default to Area, promote only when bounded |

---

## 13. Cross-machine portability

A Foreign Brain instance typically lives on cloud-synced storage so the user can think and consult from multiple machines. The cross-project workspace (where playbook + repos live) does not - it's local checkouts, with paths that differ per machine. This places the same constraint on vault content that AI-PLAYBOOK.md Top Violation #3 places on the playbook itself: **vault `.md` files (and any auto-loaded memory layer if it also syncs) must not contain absolute machine-specific paths.** Drive letters mapped per-machine, OS user homes, anything that drifts on sync - drift waiting to happen on every PC the user touches.

The portable patterns:

- **Convention-named drive mount** - each machine binds the workspace to the same drive letter (Windows: `subst W: <local-workspace-path>` persisted via scheduled task at logon; POSIX: symlink at a known mount point persisted via shell rc). Vault content uses the convention letter directly. Lowest friction once set up; one-line per-PC bootstrap. Recommended.
- **Environment-variable placeholder** - vault refs use `$WORKSPACE_ROOT/...`; AI expands at runtime. Cross-OS portable but requires AI to translate every reference; Obsidian can't navigate them as links.
- **Bare references + bootstrap discovery** - vault content references just filenames (`AI-PLAYBOOK.md`, `REF-Foreign-Brain.md`); CLAUDE.md (the bootstrap entry the AI reads first) tells AI how to locate the workspace via env var, convention, or interactive prompt. Most flexible, highest cognitive load.

Acceptable absolute paths in vault content:

- The vault root itself, *if* the cloud-sync client mounts it at the same path across the user's fleet (verify before relying on it; if even one machine differs, this no longer holds).
- `~/.claude/...` - runtime convention common to every Claude install (per REF-Authoring.md §2).

Bootstrap responsibility - CLAUDE.md (vault root, the entry AI reads first on every session) must verify the workspace is reachable on this machine before any operation that depends on the playbook or workspace repos. Verification = checking the playbook file exists at the expected location. If the check fails, AI stops and instructs the user to mount the workspace; no work proceeds without the playbook loaded.

Enforcement - the vault's own validator (mirroring the playbook's INT-PORT-001) scans editable `.md` files for forbidden absolute-path patterns, allowlists permitted conventions (vault root if applicable, runtime convention, drive-letter mount), and fails on drift. New machine-specific paths can never be reintroduced silently.

---

## 14. Skills that instantiate this REF

Generated by `scripts/sync_backlinks.py` from skill frontmatter; do not edit by hand.

Skills whose frontmatter `refs:` includes `REF-Foreign-Brain`:

- `archive` - Archive a project / area / resource in a Foreign Brain vault - set frontmatter status, move file or folder to `04 Archive/<Kind> - <name>/`, add archive date + revive instructions, prune Hub.md, run validator.
- `archive-section` - Extract a completed sub-section from an Area note in a Foreign Brain vault into its own dated archive file under `_Archive/`, preserving in-vault history without polluting the live note.
- `conversation-open` - Run at the start of every session in a Foreign Brain vault.
- `digest` - Process unprocessed Inbox files in a Foreign Brain vault - extract decisions, tasks, people, places, brands into PARA hubs; write audit footer back to source; move source to Inbox/Processed; run validator.
