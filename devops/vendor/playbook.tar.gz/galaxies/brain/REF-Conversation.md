---
domain: practice
---

# REF: Conversation (the helpers the operator turns on it)

> The pattern for conversation helpers: small skills the operator invokes on the conversation itself rather than on the work it is about. Read this when writing or running one; the runbooks live in the skills.

---

## 1. The subject

A conversation helper acts on the conversation the operator is having: its state, its content, and the decisions it carries. A skill that acts on the work (a repo, a vault, a document) leaves an artifact there; a helper leaves a record the operator reads, and the work is untouched until the operator acts on that record.

- **The subject is fixed first**, by the operator, and everything the helper asks or finds is tested against it (§3).
- **A helper runs on the operator's word.**
- **A helper serves any session.** It reads whatever environment the session has (a vault, a repo, a document, the transcript alone) and owes the same record in each (§5).
- **A helper is generic by construction.** It homes on this REF and cites no sun outside this galaxy: a helper that takes its doctrine from a lifecycle, a loop, or a stack serves only sessions inside that one, and every load of it carries that sun along. What is specific to one environment is a short marked section in the skill body, never a citation, and a helper that grows specific to one environment moves out, to that environment's sun. Driving another galaxy's skill from a step is not a citation.

## 2. The contract

| Rule | What it means |
| ---- | ------------- |
| Read before asking | A fact is read from the environment (the files, the history, the transcript); only a decision is asked, and a question a file could have answered is withdrawn |
| The record is the whole output | The helper builds nothing and edits nothing; what it decides, it decides in the record, for the operator to act on |
| Offer, do not act | Filing, committing, and landing happen on the operator's word, after the record exists, as a separate act |
| End explicitly | The record says whether it is complete, and names what remains when it is not, so an omission is a decision and not an accident |

## 3. Asking

- **A helper that asks runs only where a human can answer.** An unattended run has no operator, so a helper whose value is the question refuses before its first question rather than blocking the run.
- **One question per turn.** A batch yields one answer and discards the rest, and a later answer can invalidate an earlier one before it was heard.
- **Recommendation first.** A question carries the recommended answer and its tradeoff, then the alternatives, each with what it costs.
- **Confirmation is reserved for genuine forks** (`REF-Foreign-Brain.md` §12 row 1); everything else is decided in the record and reported.
- **Parked, or raised once.** For a helper that asks, a noticing outside the subject goes on a parked list and reaches the operator once, with the record; a noticing that is itself a genuine fork may be raised once, as a single question whether to widen the subject, and only the operator widens it. A helper whose subject is the whole session has nothing outside it.

## 4. The record and its durable home

A session's findings outlive the session only in a durable home, and memory is never one (`AI-PLAYBOOK.md`, universal violation 6). A helper that leaves a remainder names its home; "remember this" is not a home.

| Finding | Durable home |
| ------- | ------------ |
| A decision about the work | The work's own design record, plan, or decision log |
| A lesson that applies beyond this work | The corpus, through its own reviewed change, never an edit made in passing |
| Work still owed | A ticket on the repo that owns it |
| A change made but not kept | A commit, or the explicit choice to discard it |
| An item the operator waived | The waiver itself, in the record, so the outcome stays auditable |

**A remainder belongs to this session.** It is something the session produced, changed, or blocked. A pre-existing open item the session never touched is not one, however real it is, and an inherited item earns a line only when its status changed.

## 5. Context

The environment changes what a helper reads, never what it owes. A helper names the contexts it reads, and every category of its record is reported, "none" and "not applicable" included, rather than skipped or invented. The transcript is the context every session has, and a generic helper degrades to it.

## 6. Ranking and ruling

A record that ranks its items keeps one rule; a record that rules on a proposal keeps three more.

- **Weight by consequence.** Order and prominence follow the cost of being wrong, never the count: the irreversible and the outward-facing first, the cosmetic last.
- **Premise before remedy.** The problem is verified real and still open before the fix is weighed.
- **Need before size.** When something already meets the need, the ruling is no, however often the class recurs; what survives is the smallest change at the point where the problem is still observable.
- **A ruling names its revisit trigger.** A dropped item records the concrete event that would revive it, so nothing is lost and revival arrives with a real instance to size it.

## 7. Anti-patterns

| # | Anti-pattern | Correct approach |
| - | ------------ | ---------------- |
| 1 | Homing a helper on a sun outside this galaxy (a lifecycle, a loop, a stack) | Home here; environment-specific notes are a marked section in the skill body (§1) |
| 2 | Batching questions | One per turn (§3) |
| 3 | Asking what a file answers | Read first (§2) |
| 4 | Sliding into the act | The record is the output; the act is separate, on the operator's word (§2) |
| 5 | The thin sweep ("seems fine") | Every category reported, "none" included (§5) |
| 6 | The padded sweep (carry-overs the session never touched) | A remainder belongs to this session (§4) |
| 7 | Memory as the carrier of a pending item | Name a durable home now (§4) |
| 8 | Confirming what the record already decides | Reserve confirmation for genuine forks (§3) |
| 9 | Stopping without naming the remainder | End explicitly (§2) |
| 10 | Asking inside an unattended run | Refuse before the first question (§3) |
| 11 | Ruling on a remedy before its premise | Premise before remedy (§6) |
| 12 | Ruling from surface features (widespread, recurring, expensive, proposed twice) | Need before size: where the need lives decides (§6) |

---

## 8. Skills that instantiate this REF

Generated by `scripts/sync_backlinks.py` from skill frontmatter; do not edit by hand.

Skills whose frontmatter `refs:` includes `REF-Conversation`:

- `condense` - Say the topic under discussion again, shorter and structured, for the same reader: the answer first, structure only where there are parallel items, every caveat that would flip a conclusion kept, and a closing line naming what was compressed so the operator can ask for any part back at full length.
- `conversation-close` - Run before archiving a conversation: summarize what was decided and produced, then sweep for everything still pending - open questions, promised-but-undone work, uncommitted or unpushed changes, decisions not yet in their durable homes - each with where it should go.
- `earn-it` - Fight a set of proposed actions (changes, additions, rules, tickets, todo items) so only what is really worthwhile survives: verify each premise against the evidence and the history, ask whether the need is already met, size a survivor to the smallest change where the problem is still observable, and hand back one ruling per item: take, drop with its revisit trigger, already done, or wrong home.
- `grill-me` - Interview the operator about a plan or design decision before anything is built: one question per turn, each answer closing or opening branches of the decision, until no decision remains that the implementer would have to make alone.
- `poke-holes` - Stress-test the approach under discussion with fresh eyes: write it down as a one-page artifact (the claim, the reasoning, the assumptions, the alternatives already rejected), name the standard it must satisfy, hand it to a clean-context reviewer that shared none of the producing context, and return the findings with a three-state read (holds, holds under named conditions, does not hold) beside the assumptions that would have to be true.
- `skill-issue` - Help a colleague out of an IT problem (a command that errors, a login that fails, a connector that will not connect, an install that misbehaves, an agent that did the wrong thing): read the error before asking, prove the cause, hand the fix and walk them through it, then rule a verdict that is funny and fair (User skill issue, Playbook issue, Agentic issue, Machine issue, Platform issue, Upstream issue, It was DNS, Cosmic ray) and names where the fix lands so the next colleague is spared.
