---
name: archive-section
description: Extract a completed sub-section from an Area note in a Foreign Brain vault into its own dated archive file under `_Archive/`, preserving in-vault history without polluting the live note. For whole file/folder archival use the sibling `archive` skill.
galaxy: brain
refs:
  - REF-Foreign-Brain
---

# Archive Section

Invoked when the user wants to prune a completed sub-section from an Area note. Areas don't fully archive (they're ongoing standards), but they accumulate frozen sub-efforts that should leave the live note without losing in-vault history. Encodes the contract from Vault-Operations §6 "Section extraction from Area notes" so each extraction produces a co-located, queryable, validator-clean snapshot.

For whole-file/folder archival (Projects, retired Areas, deprecated Resources), use the sibling [`archive`](../archive/SKILL.md) skill.

## Pre-flight

1. **Read** `<vault>/_System/Vault-Operations.md` §6 to confirm the convention is still in force (file is the source of truth, not training data).
2. **Read** the kind off the source note's folder (`REF-Foreign-Brain.md` §7). The §6 convention is Area-targeted (`02 Areas/`); for a note outside `02 Areas/`, confirm with the user before proceeding (mechanics work identically but PARA semantics differ).
3. **Confirm** with the user if any of the following:
   - The target section contains unchecked tasks (`- [ ]`). Partial archival of in-flight work risks dropping live tasks.
   - The target section is referenced via anchor link (`[[<SourceNote>#<Section>]]`) anywhere in the vault. Those links will break after extraction.
   - The destination file already exists.

## Inputs

The user supplies:
- **Source note** path (e.g., `02 Areas/Personal Management/Admin.md`).
- **Section heading** to extract (e.g., `### Backups`).

Optional:
- **Extraction date** (defaults to today, ISO `YYYY-MM-DD`).
- **Section slug override** (defaults to the heading text with spaces replaced by `-`, original case preserved).

## Steps

1. **Compute paths**:
   - Source folder: parent dir of the source note.
   - Source stem: filename without `.md`.
   - Section slug: heading text with spaces replaced by `-`, original case preserved (e.g., `KeePass migrations` becomes `KeePass-Migrations`).
   - Destination: `<source-folder>/_Archive/<source-stem>-<section-slug>-<YYYY-MM-DD>.md`.
   - If `_Archive/` doesn't exist under the source folder, create it.

2. **Anchor-link safety**: grep for `[[<source-stem>#<section-heading>]]` (case-insensitive, allow whitespace variants) across the vault. If matches are found, surface to user and confirm before proceeding.

3. **Create the archive file** with this exact shape:

   ```markdown
   ---
   status: archived
   created: <YYYY-MM-DD>
   source: "[[<SourceStem>]]"
   ---
   # <SectionHeading>

   Extracted from [[<SourceStem>]] on <YYYY-MM-DD>. Completion dates inline below.

   <original bullets verbatim>
   ```

   Preserve `✅` dates, tags (`#action`, `#topic/*`), wikilinks, priority markers (`🔺`, `🔼`), `🆔`/`⛔` task-plugin syntax. All verbatim.

4. **Edit the source note**: delete the section block (heading + bullets + one trailing blank line). No breadcrumb is left behind (`_Archive/` is greppable).

5. **Run validator**: `python -m pytest <vault>/_System/tests/test_vault_invariants.py --tb=short`. Capture pass/fail. If anything trips, surface with the I-number; do not silently revert.

6. **Report to user**: source note edited, new file path, validator status, any anchor-link warnings.

## Naming convention (mandatory)

- File: `<source-stem>-<section-slug>-<YYYY-MM-DD>.md`
- Date format: ISO `YYYY-MM-DD` (matches vault convention).
- Section slug: preserve case of original heading words; replace spaces with `-`.

Examples:
- `Admin.md` + `### Backups` + 2026-05-09 → `Admin-Backups-2026-05-09.md`
- `Admin.md` + `### KeePass migrations` + 2026-05-09 → `Admin-KeePass-Migrations-2026-05-09.md`

## Failure modes

- **Section contains unchecked tasks** (`- [ ]`): don't archive blindly. Ask the user whether to (a) move the whole section anyway (full archive of an incomplete effort) or (b) split, archiving only the completed bullets and leaving open ones in the source note.
- **Section has nested H4+ sub-sections**: archive the whole H3 block including nested children. Don't split by sub-heading.
- **Multiple sections to archive in one go**: run once per section. Each gets its own dated file (per-section files, not a rolling `<source>-completed.md` rollup).
- **Source note isn't an Area**: confirm with user. The §6 convention is Area-targeted; mechanics work identically for Projects/Resources but PARA semantics differ.
- **Anchor wikilinks exist** to the section: surface and confirm; don't auto-rewrite. The user decides whether to update inbound links.
- **Validator fails after extraction**: do NOT silently revert. Surface failure with I-number.
- **Section is empty or trivial**: confirm with user. May be cheaper to delete than to extract.

## What archive-section does NOT do

- Does NOT delete content. Sections move; nothing is lost.
- Does NOT modify the bullets or sub-content. Verbatim copy.
- Does NOT update `Hub.md`. The pruned source note stays a live hub citizen.
- Does NOT change the source note's `status:` or any other frontmatter.
- Does NOT roll multiple extractions into one file. One file per extraction.
- Does NOT handle whole-file/folder archival. Use the sibling [`archive`](../archive/SKILL.md) skill.
- Does NOT auto-rewrite anchor wikilinks. The user is responsible for inbound link updates.
