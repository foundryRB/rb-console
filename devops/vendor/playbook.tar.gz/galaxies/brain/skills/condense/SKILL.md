---
name: condense
description: "Say the topic under discussion again, shorter and structured, for the same reader: the answer first, structure only where there are parallel items, every caveat that would flip a conclusion kept, and a closing line naming what was compressed so the operator can ask for any part back at full length. Introduces no claim the original did not carry. Asks nothing, so it runs anywhere."
galaxy: brain
refs:
  - REF-Conversation
---

# Condense

Invoked when the operator wants what was just said again, shorter: "condense that", "the short version", "say it in two lines". The pain it answers: a hundred lines of technical prose where two sentences would do. Principle: **the same content for the same reader, in fewer words; nothing that changes the answer is dropped.** A restatement is a record of the conversation's own content (`REF-Conversation.md` §1), so the helper contract of §2 applies: the restatement is the whole output, and it decides nothing.

## Pre-flight

1. **Fix the topic** (`REF-Conversation.md` §1): the last answer, or the thread the operator names. The transcript is the whole context (§5); nothing outside it is read.
2. **Asks nothing**, so it runs attended or unattended alike (`REF-Conversation.md` §3).

## Steps

1. **State the answer first**, in one to three sentences: the conclusion the original reached, in the same terms.
2. **Add structure only where there are parallel items**: a short list or a table for several things of one kind, prose for everything else.
3. **Keep every caveat that would flip a conclusion; drop detail that would not.** The test for each clause of the original: if a reader acted on the restatement without it, would they act differently? Keep it if yes.
4. **Keep the technical term only where the plain word loses precision.** The reader is the same reader; the level does not change, only the length.
5. **Close by naming what was compressed**, in one line, so the operator can ask for any part back at full length. The skill ends here.

## Failure modes

The generic failures are `REF-Conversation.md` §7: sliding into the act (4), stopping without naming the remainder (9). Specific to this runbook:

- **A load-bearing caveat dropped**: the restatement is shorter and wrong. Step 3's test is the guard; a shorter record that changes the answer is not shorter.
- **Re-explaining at a lower level instead of shorter**: the reader did not change, and condescension is a new content. Same terms, fewer words.
- **Structure as padding**: a table for two items, headings over three sentences. Structure only for parallel items (step 2).
- **A restatement longer than the original**: the topic was already short; say so and stop.
- **A new claim**: the restatement introduces nothing the original did not carry. If the original was wrong, the restatement is wrong the same way, and that is correct behaviour; testing the content is another helper's job.
