---
name: grill-me
description: "Interview the operator about a plan or design decision before anything is built: one question per turn, each answer closing or opening branches of the decision, until no decision remains that the implementer would have to make alone. Runs only where a human can answer; an unattended run refuses before its first question."
galaxy: brain
refs:
  - REF-Conversation
---

# Grill me

Invoked when the operator wants to be interviewed about a task, plan, or design decision rather than have the assistant guess, pick defaults, or start building on an incomplete understanding ("grill me on this", "interview me before you build", "don't assume, ask"). Principle: **every decision the implementer would otherwise make alone is asked, one at a time, until none remain.** The end condition: no decision is left for the implementer to make alone (`REF-Conversation.md` §2, end explicitly). The interview is a stance held for the rest of the conversation, not a question list played once. It keeps the helper contract of `REF-Conversation.md` §2 and the asking rules of §3.

## Pre-flight

1. **Refuse where no human can answer** (`REF-Conversation.md` §3): this skill ends before its first question.
2. **Fix the subject** in one sentence drawn from the operator's own words: what is being decided (`REF-Conversation.md` §1).
3. **Explore before asking** (`REF-Conversation.md` §2): the repo, its decision records and config, any plan or scratch the work keeps, the notes the subject touches.

## Steps

1. **Lay out the decision tree.** From the subject, list every decision the implementer would have to make: what gets built, for whom, on what, with which constraints, and what done means. Order it by the cost of assuming wrongly (`REF-Conversation.md` §6, weight by consequence).
2. **Ask one question per turn**: the most consequential open decision, recommendation first (`REF-Conversation.md` §3). Use the harness's structured question tool when one exists, one plain question otherwise. A question whose relevance depends on another answer waits for that answer.
3. **After each answer, recompute.** Record the decision with its reason. Mark which branches the answer closed and which it opened; re-test the remaining questions against the subject. A noticing outside the subject is parked, or raised once when it is itself a genuine fork (`REF-Conversation.md` §3).
4. **Stop when the tree is closed**, or when the operator stops it, naming what remains unasked (`REF-Conversation.md` §2).
5. **Close with the record.** Play back every decision and its reason as one list, and name the durable home it lands in (`REF-Conversation.md` §4). Present the parked list once. The skill ends here.

## Failure modes

The generic failures are `REF-Conversation.md` §7: batching (2), asking what a file answers (3), sliding into the act (4), stopping without naming the remainder (9), asking unattended (10). Specific to this runbook:

- **Silent assumption on a genuine fork**: picking a default mid-interview on a decision that is a genuine fork (`REF-Conversation.md` §3) defeats the skill; such a fork is asked, inside the subject or as the one widening question step 3 allows.
- **Scope creep**: the questioning mind over-generates adjacent concerns, future-proofing, avenues the operator never raised. What fails the subject is parked or raised once (`REF-Conversation.md` §3), by step 3.
- **A question whose relevance depends on an answer not yet given**: it waits (step 2); asked early, it is answered against a decision that a later answer overturns.
