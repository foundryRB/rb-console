---
name: sweep-memory
description: "Sweep every memory store a runtime keeps on this machine and rule on each line: keep what is still true and verified against the machine, delete what its task resolved, rehome what would hold on any machine. Reports the ruling per line and lands it on the operator's word; the index is regenerated from the files that survive."
galaxy: brain
refs:
  - REF-Continuity
---

# Sweep memory

Invoked when the operator asks what the memory layer is still carrying ("sweep memory", "is any of this still true?", "what is rotting in there?"). Principle: **the memory layer holds current state only**, so a sweep drains it rather than curating it (`REF-Continuity.md` §1, §3). The rehoming half is `carry-lessons`; this runbook rules on lines and hands that one whatever turns out to be portable.

## Pre-flight

1. **Enumerate the stores, do not assume one.** A runtime keeps one store per project root, and the store of the session in hand is one of many (`REF-Continuity.md` §3, anti-pattern 3). List them all before reading any.
2. **The files are the record.** Read the memory files themselves; the index is a projection to be regenerated at the end, never the thing swept (§3, anti-pattern 4).
3. **Confirm the scope with the operator** when the enumeration is large: every store, or the named ones.

## Steps

1. **Read every store's files**, per store. A store nobody opens is the one most likely to be stale, so an unopened store is a reason to read it, not to skip it.
2. **Rule on each line**, against the four rows of `REF-Continuity.md` §2. A line names what would retire it (§3); a line that names no such trigger is ruled on anyway, and the ruling says the trigger was missing.
   - **Still-open task**: keep, and verify the line is still true.
   - **Resolved task**: delete, in this pass (§1, universal violation 6).
   - **Portable finding**: rehome, then delete the line. Hand it to `carry-lessons` rather than routing it here.
   - **Corpus change**: propose it as the corpus's own reviewed change, never an edit made from inside this sweep (§2, anti-pattern 5).
3. **Verify every checkable claim against the machine** before keeping it (§3): a path exists, an account is still the active one, a port is open, a tool is still on `PATH`. A line asserting a fact nobody rechecked is loaded and believed by every session that follows, so an unverifiable claim is reported as unverifiable rather than kept on trust.
4. **Check the index against the files** (§3): a link to a file that no longer exists, an entry for a deleted memory, a file the index omits. The file wins; the index is rewritten from what survives.
5. **Report the ruling per line** before touching anything, grouped by store, each with its reason. A sweep that edits as it reads leaves no reviewable record of what it decided (§2).
6. **Land on the operator's word**, then regenerate each swept store's index from its surviving files.

## Failure modes

The generic failures are `REF-Continuity.md` §4. Specific to this runbook:

- **A line whose truth cannot be checked from here** (a remote credential, another machine's path): report it unverified with what would settle it; neither keep it silently nor delete it for being inconvenient.
- **A store for a project root that no longer exists**: the whole store is resolved state; propose the store's deletion rather than ruling line by line.
- **A line that is half state and half lesson**: split it. The machine-bound half stays as a line, the portable half goes to `carry-lessons` (`REF-Continuity.md` §1, the discriminator is the machine).
- **The operator waives a deletion**: record the waiver and the trigger that would revive the ruling, so the next sweep inherits the decision rather than re-proposing it.
