---
name: digest
description: Process unprocessed Inbox files in a Foreign Brain vault - extract decisions, tasks, people, places, brands into PARA hubs; write audit footer back to source; move source to Inbox/Processed; run validator.
galaxy: brain
refs:
  - REF-Foreign-Brain
---

# Digest

Invoked when the user wants to process pending Inbox content into the structured Augmented layer of a Foreign Brain vault. See `REF-Foreign-Brain.md` for the architectural pattern this Skill instantiates.

## Pre-flight

1. **Read** the vault's `_System/Architecture.md` (project-specific schemas, hub names, paths).
2. **Read** the vault's `Hub.md` (registry of declared hubs - your slot targets).

## Inputs

- Default: all files under `<vault>/00 Inbox/` NOT under `00 Inbox/Processed/`
- Optional: explicit file path or date range from user

## Steps

For each unprocessed Inbox file:

1. **Read** the file's full content.
2. **Extract actionable items** - decisions, tasks, deadlines, explicit project mentions - and slot them into PARA hubs (see Extraction Patterns below).
3. **Synthesize topical chunks into PARA** - the journal/reflection content gets distributed:
   - Identify topical themes in the prose (parenthood, career, persona work, projects, etc.).
   - For each theme, append a "Reflections - YYYY-MM-DD" section (or paragraph) to the relevant PARA note (Area / Project / Resource).
   - Begin each insertion with a plain-text attribution: `> from journal YYYY-MM-DD`.
   - The synthesis is *summarized + connected* - not a verbatim copy of the journal. Pull out the load-bearing observations + their reasoning; cross-link to other hubs where the chunk relates (`[[Lara]]`, `[[Time to Trusted Output]]`, `[[Career]]`, etc.).
   - If a relevant PARA hub doesn't exist, create one (e.g., `02 Areas/Career.md`) following the area template.
4. **Do NOT enrich the source Inbox file with wikilinks** - Inbox is raw archive; the layer-separation principle (REF-Foreign-Brain §2) keeps Inbox out of graph navigation. Original prose stays verbatim.
5. **Auto-stub** new wikilinks created in PARA per Auto-stub policy below.
6. **Write the audit footer** to the source file (see Audit Footer Format) listing each PARA insertion.
7. **Move source** to `00 Inbox/Processed/<filename>.md`. Rename to date-prefix if missing.

The point: PARA is the Foreign Brain. A journal entry's value is realized when its insights live where they're discoverable by topic - opening the Parenthood area shows reflections about parenthood; opening `02 Areas/Career.md` shows career thinking. The original Inbox file is preserved as raw chronological archive but NOT as part of the graph navigation surface.

### Reconcile existing state, don't punt

A journal usually reports the real world moving on, not just brand-new items: a tracked task got done, a planned approach was superseded, a blocker cleared, a device is now in use. Treat the structured layer as something to *reconcile*, not only append to:

- When the source states a tracked item's outcome with reasonable confidence, **update the existing item**: mark `[x]` with `✅ <date>` plus a one-line reason, cancel a superseded task (noting what replaced it), or annotate a partially-done one. Carry completion forward to its dependents' gates.
- **Reserve flagging for genuine ambiguity**: the source is unclear, or acting would assert something unstated (e.g. a note that one part of a bundled job is done says nothing about the other parts). Isolate the one real unknown; don't convert the whole reconciliation into a list of 'want me to mark this done?' questions handed back to the user. The footer logs every change and the Processed source plus validator make it reversible, so the bias is to reconcile.
- Record each state change in the footer as a `completed` / `cancelled` / `updated` line with its reasoning, so it stays auditable and undoable.

## Post-processing

1. **Run validator:** the vault's pytest invariant checker. From the vault root: `python -m pytest _System/tests/`. Capture pass/fail + specific failures.
2. **Report to user:** files processed, hubs touched, validator status, anything unusual.

---

## Extraction patterns

### Decisions

Triggers:
- Explicit tag: `#decide` or `#decision`
- Phrasing: "I decided", "going with", "the choice is", "settled on", "we picked"
- A bullet under a `## Decisions` heading

Hub destination: the **Decisions section** of the relevant Area hub. A decision no Area clearly owns has no clear slot (see Slot rules): flag it and leave it in the source. Never create an area only to hold a decision. A vault that keeps a place for such decisions names it in its `_System/Architecture.md`.

Format in hub:
```markdown
- <Decision text> - <one-line rationale if present in source>
```

### Tasks

Triggers:
- Tasks-plugin syntax `- [ ] ...` (already a task)
- Prose phrasing: "I need to", "TODO", "must", "should X by Y" (date triggers)
- Phone calls: "call X", "ask X" → tag with `#ctx/phone`
- Store visits: "buy from <Brand>" → tag with `#ctx/<brand-slug>`

Hub destination: the natural Area's task section. Project notes for project-specific tasks.

Format in hub:
```markdown
- [ ] <Task text> 📅 <due if present> 🔼 <priority if elevated> #ctx/<context-tag> 🆔 <id-if-others-depend-on-it> ⛔ <id-if-this-blocks-on-something>
```

Dependency syntax: when extracting "I need to do A before B," set A with `🆔 a-id` and B with `⛔ a-id`.

**Dates come from the source's words, never from the capture.** Write `📅` only when the source names the day the
task is due: a date ("by the 20th", "2026-09-20") or a phrase that resolves to one ("tomorrow", "by Friday", "end of
the month"). The same holds for `⏳` scheduled and `🛫` blocked until.

- A capture's filename and timestamp are when it was written, not when its tasks are due. Never carry that date into `📅`.
- "I need to do X" with no day named is a task with no due date. That is the common case, not a gap to fill.
- A task without `📅` is not a lesser task. Undated is where most of them belong.

### People / Places / Brands

Triggers:
- Wikilink syntax `[[Name]]` in source
- Capitalized proper nouns in context suggesting entity type

**Auto-stub policy** (per the phantom lifecycle in REF-Foreign-Brain §8):
- **People** - auto-stub. Career relationships matter long-term; backlink discoverability is high-value.
- **Brands (banks / utilities / telcos / recurring services)** - auto-stub.
- **Brands (clothing, perfumes, generic stores)** - leave as phantom; user triages later. These often don't warrant individual hubs (a `[[Clothing]]` topic hub may aggregate better than 10 brand stubs).
- **Places (specific locations user navigates to)** - auto-stub.
- **Places (named-but-not-navigated, e.g., neighborhoods only mentioned in restaurant context)** - leave as phantom.
- **Concepts / methodologies / archived projects** - leave as phantom; user adds to Approved Phantoms if intentional.

When in doubt: leave as phantom. Better to have wandering phantoms surfaced for triage than to over-stub.

Stub format (when auto-stubbing), written into the entity folder that names its kind (`People/`, `Places/`, `Brands/`; the folder is the kind and the stub carries no frontmatter, `REF-Foreign-Brain.md` §7):
```markdown
# <Name>

<one-line context from source if available>
```

If hub already exists, do NOT overwrite - just leave the wikilink resolving.

### Project mentions

Triggers:
- "Project: X" or "Started X" or "thinking about X"
- Reference to existing project: leave as wikilink, no action

For new projects: create the stub under `01 Projects/` with frontmatter `status: active`, `created: <today>`; the folder names the kind (`REF-Foreign-Brain.md` §7).

If unsure whether something is a project vs area: **default to area** (REF-Foreign-Brain §3 - projects need end criteria).

---

## Slot rules

The vault's `Hub.md` is the source of truth for routing. Consult it to find the right hub for each extracted item. General principles:

| Source signal | Destination type |
|---|---|
| Domain-specific item (house, finance, etc.) | Area hub for that domain |
| Article / writing idea | The vault's blogging hub (e.g., `02 Areas/Blogging/Blogging.md` if it exists) - its idea-backlog or drafts section |
| Restaurant mentioned | Resource hub for restaurants if exists |
| Person / Place / Brand | Entity stub in `02 Areas/{People,Places,Brands}/` |
| Already-known project mention | That project's note |

If no clear slot: flag in the report and leave the item in source for next-pass review. The audit footer should still record that the file was processed (with a note like `- (no extraction for "<item>" - no clear slot)`) so the un-slotted item is grep-able.

---

## Audit footer format (inverted audit)

Append to source file BEFORE move:

```markdown

<!-- DIGEST CHANGELOG <ISO-8601 UTC timestamp>
- <hub-path>#<section>: added "<extracted text>"
- <hub-path>#<section>: completed "<task>" ✅ <date> (why the source confirms it)
- <hub-path>#<section>: cancelled "<task>" (what superseded it)
- <hub-path>#<section>: updated "<modified item>"
- Created stub: <path>
- Moved <path> from <old> to <new>  (if any file moves)
-->
```

Each line is one operation. Multiple operations on the same hub get their own line. Grep-able by hub-path or operation type.

---

## File move

After footer is written:
- `00 Inbox/<file>.md` → `00 Inbox/Processed/<file>.md`
- `00 Inbox/daily/<file>.md` → `00 Inbox/Processed/<file>.md`
- If filename lacks date prefix: rename `<original>.md` → `<YYYY-MM-DD>-<original>.md`
- Files in `Processed/` are **immutable**. Never modify after move.

---

## Edge cases

- **File appears empty / no extraction possible** → still write footer (`<!-- DIGEST CHANGELOG ... no extractions -->`), still move to Processed. Marks the file as seen.
- **Conflicting decisions** (source says "decided X" but hub already has "decided Y" for same thing) → don't overwrite. Add new entry with timestamp; flag for user review.
- **Wikilink to existing note whose folder says another kind** (e.g., `[[X]]` sits under `01 Projects/`, source treats it as a person) → flag, don't move.
- **Daily file with very old date** (>30 days behind today) → process, but flag in report - might indicate skipped digests or out-of-band edits.
- **User adds content to a Processed file** → validator should detect mtime change in `Processed/` and surface as warning. Tell user: write a new Inbox entry instead.

---

## What digest does NOT do

- Does NOT silently rewrite or overwrite the user's already-recorded decisions or prose (it appends and reconciles state; it does not revise their wording or erase prior thinking)
- Does NOT delete content from source files (only appends footer + moves)
- Does NOT re-extract from already-Processed files (immutable)
- Does NOT invent dates: a task whose source names no day gets no `📅`, `⏳` or `🛫`
- Does NOT invent decisions for the user, but DO reconcile the task/plan *state* the source reports (see "Reconcile existing state, don't punt" above); flag only genuine ambiguity rather than punting a list of confirm-this questions

---

## Failure modes

- **Ambiguous extraction** (can't tell if item is decision/task/note) → leave in source as-is, mention in report
- **No clear hub for item** → flag in report, ask user where to slot
- **Validator fails after digest** → report failures; do NOT auto-fix without user awareness
