---
name: conversation-open
description: Run at the start of every session in a Foreign Brain vault. Surface overdue tasks, parked decisions, upcoming deadlines, and pending Inbox items proactively before any other conversation.
galaxy: brain
refs:
  - REF-Foreign-Brain
---

# Conversation-Open

Invoked implicitly at the start of every session in a Foreign Brain vault. Principle: **surface, don't park** - items that have been waiting come to the user proactively, not by their having to remember.

See `REF-Foreign-Brain.md` for the architectural pattern (especially §6 task buckets and §10 frictionless workflow).

## Pre-flight

1. **Detect context** - if not working in a Foreign Brain vault (no `_System/Architecture.md` or no PARA folders present), skip this routine.
2. **Read** `_System/Architecture.md` for vault-specific schemas if not already in context.

## Steps

### 1. Run vault tests

```bash
cd "<vault-root>" && python -m pytest
```

This single command runs vault structural invariants AND every Data Pack's tests in one pass. If FAIL: surface failures FIRST, before any other conversation. The user can't trust the system if invariants are broken.

Exclusions and discovery are configured via the vault's `pytest.ini` + `conftest.py`. Don't run separate validators or per-pack pytest invocations.

### 2. Check overdue tasks

Query (Dataview / Tasks plugin):

```
TASKS
WHERE !completed AND due < today
```

Surface count + list.

### 3. Check parked decisions

Query any `## Decisions` or `## Decisions to make` section across active Area / Project hubs. Items present > N days (default 7) without resolution → surface.

### 4. Check stale waiting tags

Tasks tagged `#waiting/decision` for > 14 days → "this has been parked, want to think about it now?"

### 5. Check upcoming deadlines

Tasks due in next 3 days → surface as a proactive heads-up (not nagging).

### 6. Check `#discuss` tags

Items tagged `#discuss` anywhere → bring up immediately.

### 7. Check unprocessed Inbox

Files in `00 Inbox/` (NOT under `Processed/`) - if any exist, mention: "X items pending digest. Want to run digest?"

### 8. Check wandering phantoms

Run validator with `--list-phantoms`. Phantoms above the warn threshold (default 50) need triage - surface count + top 5 by mention count: "Y wandering phantoms (top: [[X]] (5), [[Y]] (3), ...). Triage into delete / approved phantom / stub / hub when convenient."

If phantom count is below threshold, skip silently.

### 9. Greet with surfaced items, NOT generic

Wrong: "How can I help today?"
Right (example): "Quick state: validator clean. 2 overdue tasks. 7 decisions parked > 7 days. 3 unprocessed Inbox files. Where do you want to focus?"

---

## Tone

- Brief. List, not narrative.
- Group related items.
- Don't editorialize ("you should really...") - just surface.
- Don't apologize for the surfaced items being there - they exist, that's data.

---

## What NOT to surface

- Items already resolved in the last 24h (don't re-mention closure)
- Items the user explicitly snoozed (`#snooze/<date>` tag)
- AI-internal tasks (vault maintenance, link fixes done silently) - those are AI agency
- Items blocked on dependencies the user doesn't currently care about (Tasks plugin `⛔` syntax handles this - blocked items don't surface as actionable)

---

## Failure modes

- **No Foreign Brain vault loaded** → skip this routine; conversation-open is vault-context-only
- **Validator script not yet built** → note its absence in greeting; surface other items normally
- **First-ever session in vault** → skip routine, suggest running `digest` if Inbox has content
