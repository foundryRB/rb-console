---
name: skill-issue
description: "Help a colleague out of an IT problem (a command that errors, a login that fails, a connector that will not connect, an install that misbehaves, an agent that did the wrong thing): read the error before asking, prove the cause, hand the fix and walk them through it, then rule a verdict that is funny and fair (User skill issue, Playbook issue, Agentic issue, Machine issue, Platform issue, Upstream issue, It was DNS, Cosmic ray) and names where the fix lands so the next colleague is spared."
galaxy: brain
refs:
  - REF-Conversation
---

# Skill issue

Invoked when a colleague is stuck on an IT problem and wants out: a command that errors, a login that fails, a connector that will not connect, a tool that behaves from an older version, an agent that did something nobody asked for ("help, it's broken", "is this me or the tool?", "skill issue?"). Principle: **every colleague leaves with the fix, and every fix leaves with a verdict naming where it lands.** The verdict is the joke and the finding at once: one funny, fair line naming the cause, and a home (`REF-Conversation.md` §4) where the fix goes so the next colleague never meets the problem. It keeps the helper contract of `REF-Conversation.md` §2, asks by §3, and rules by §6.

## Pre-flight

1. **Fix the subject** (`REF-Conversation.md` §1): the problem in one sentence, from the colleague's words: what they ran, what they expected, what happened instead. The exact error text belongs to the subject; a paraphrase ("it doesn't work") earns one question asking for the text or a screenshot.
2. **Fix who is at the keyboard.**
   - **Live**: the colleague in their own session; probes run here.
   - **Relayed**: the operator brings a colleague's message; each probe becomes an ask the reply carries, and the record ends as a reply ready to paste, in the language the colleague wrote in.
   - **Unattended**: nobody can answer; the record is built from what can be read, asks nothing, and ends incomplete with the evidence it still needs (`REF-Conversation.md` §3).
3. **Read before asking** (`REF-Conversation.md` §2): the error, the transcript, the logs, the configuration, and the guidance the colleague followed (the skill, the runbook, the README). In a live session, read-only probes; a probe leaves the environment as found.
4. **Keep secrets out.** Ask for the error, never the credential. A probe reports whether a token exists, which account it belongs to, and when it expires, never its value; a secret pasted anyway is flagged for rotation and kept out of the record.

## Steps

1. **Locate the layer.** Start at the layer the error names (a refused authorization is identity, an unresolvable host is network, a missing command is install). With nothing to go on, walk outside in, cheapest probe first:

   | Layer | The question | Typical probe |
   | ----- | ------------ | ------------- |
   | Upstream | Is the service up? | Its status page or health endpoint |
   | Network | Can this machine reach it? | Name resolution, a plain request, the proxy and VPN state |
   | Identity | Is the caller who the service expects? | The signed-in account, the credential's presence, expiry, and scope |
   | Install | Is the tool there, current, and configured? | The version, the configuration, the installed copy against its source |
   | Procedure | Were the steps done as written? | The guidance beside what was actually run |
   | Agent | Did the agent do what its guidance says? | The skill or instructions beside the transcript |

2. **Prove the cause** (`REF-Conversation.md` §6, premise before remedy). Test each hypothesis with the cheapest probe that could prove it wrong. A cause is proven when a probe shows it or when the fix aimed at it works; a fix that works for no stated reason proves nothing.
3. **Hand the fix.** Numbered steps, each with the exact command or click and what success looks like, irreversible steps flagged before they run (`REF-Conversation.md` §6, weight by consequence). The colleague runs them; the agent runs them only on the colleague's word, as a separate act (`REF-Conversation.md` §2).
4. **Walk it through.** The colleague reports back at the first step whose result does not match its success line. That result is new evidence: return to step 1 with it. One question per turn (`REF-Conversation.md` §3).
5. **Rule the verdict** once the cause is proven, by the table under **The verdicts**. With nothing proven yet, the verdict is **Jury's still out**, with the next probe or the escalation.
6. **Close the record** in the form under **The record**, stating whether the problem is resolved. Offer to file the home (a ticket, a note to the team that runs the service); filing happens on the operator's word (`REF-Conversation.md` §2). Present noticings outside the subject once, as the parked list (`REF-Conversation.md` §3). The skill ends here.

## The verdicts

The verdict names where the fix lands, never who to blame. The taglines are examples; each verdict gets a fresh one, one line, about the problem.

| Verdict | Rules when | Example tagline | Home |
| ------- | ---------- | --------------- | ---- |
| **User skill issue** | The guidance was right and findable, and the step was skipped, mistyped, or run in the wrong place | The docs were right there, feeling ignored. | None beyond the fix: point at the line that was missed |
| **Playbook issue** | The written guidance (a REF, a skill, a runbook, a README) was wrong, stale, or silent where the colleague looked | The docs ghosted you. | A ticket on the repo that owns the guidance, naming the file, the section, and what it should say |
| **Agentic issue** | The agent had the guidance and did the wrong thing: misread it, invented a flag or a path, skipped a stated step, acted beyond the ask | The robot was confidently wrong. | Corrected in the session; recurring with the guidance in place, a ticket proposing a mechanical check, fought through `earn-it` before filing |
| **Machine issue** | The colleague's own machine: a stale install, a local setting, a proxy or certificate in the way, a local credential gone stale | Your laptop has opinions. | The fix on that machine; a managed setting nobody local owns goes to whoever manages the device |
| **Platform issue** | A shared service the team runs refused or broke: an outage, a credential rotated server-side, an expired certificate, a quota hit | The server is having a day. | A ticket for the team that runs it, with the exact error, the time, and the probe that proved it |
| **Upstream issue** | A third party outside the team broke: a vendor outage, a regression in a tool release | Not our circus, not our monkeys. | The vendor's status page or tracker; a workaround worth keeping is a Playbook issue of its own |
| **It was DNS** | Name resolution was the cause, and a probe proves it | It is always DNS. | The Platform issue home, for whoever owns the zone |
| **Cosmic ray** | It vanished on a retry and nothing explains it | A neutrino did it. Probably. | None; the revisit trigger is the exact error, captured the next time it happens (`REF-Conversation.md` §6) |

- **The benefit of the doubt goes to the colleague.** A User skill issue carries its receipt: the line of guidance that was missed, in the place they would have looked. No line to point at makes it a Playbook issue. The same test holds for the agent: guidance that never said the thing makes an Agentic issue a Playbook issue.
- **One primary verdict**, the one whose home spares the next colleague; a second cause rides along as a side: "Verdict: Playbook issue, with a side of user skill issue."
- **The joke comes after the help.** A stuck colleague gets the fix first; the verdict closes the record. A verdict that would sting where it is read (a public channel, a bad day) goes out plainly, without the tagline; relayed, the operator decides.

## The record

```
Problem: <one sentence, in the colleague's words>
Cause:   <what was wrong, with the probe or the line that proves it>
Fix:     <the steps that worked, or the steps to run>
Home:    <where the fix lands so the next colleague is spared, or "none">
Status:  <resolved | open: the next probe or the escalation>

Verdict: <verdict>. <tagline>
```

## When the session has the playbook toolchain

Environment notes (`REF-Conversation.md` §1) for sessions whose skills, agents, and connectors come from this playbook:

- **A skill or agent that is missing, or behaves from an older text**: the runtime copy is stale, and the `install-playbook` skill refreshes the whole set. User skill issue when the refresh is written where they looked, Playbook issue when it is not.
- **A connector that fails to connect**: the harness error names the layer. A rejected authorization header is a credential the server no longer accepts, fixed in that connector's configuration on the colleague's machine: Machine issue, or Platform issue when the server rotated it without notice.
- **A skill run that went wrong**: read the skill text beside the transcript before anything else. The skill said it and the agent did not: Agentic issue. The skill never said it: Playbook issue.

## Failure modes

The generic failures are `REF-Conversation.md` §7: asking what a file answers (3), sliding into the act (4), stopping without naming the remainder (9), ruling on a remedy before its premise (11). Specific to this runbook:

- **The reinstall reflex.** Reinstalling, rebooting, or clearing caches before the error is read destroys the evidence and teaches nothing; it is a step only when the diagnosis names it.
- **The vibe verdict.** A verdict ruled before the cause is proven is a guess with a punchline; Jury's still out is an honest verdict.
- **User skill issue without the receipt.** No missed line to point at, no User skill issue.
- **Roasting the person.** The tagline is about the problem, always; the colleague asked for help, not a review.
- **The questionnaire.** Five questions at once to a stuck colleague; one per turn, and only what a probe could not answer.
- **A secret in the record.** The error is evidence; the credential never is (pre-flight 4).
