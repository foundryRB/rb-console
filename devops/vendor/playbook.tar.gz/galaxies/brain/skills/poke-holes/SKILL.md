---
name: poke-holes
description: "Stress-test the approach under discussion with fresh eyes: write it down as a one-page artifact (the claim, the reasoning, the assumptions, the alternatives already rejected), name the standard it must satisfy, hand it to a clean-context reviewer that shared none of the producing context, and return the findings with a three-state read (holds, holds under named conditions, does not hold) beside the assumptions that would have to be true. Edits nothing and decides nothing; the operator does."
galaxy: brain
refs:
  - REF-Conversation
---

# Poke holes

Invoked when the operator wants the approach currently under discussion tested rather than agreed with: "poke holes in this", "what's wrong with this plan", "stress-test it". Principle: **find what breaks, with eyes that had no share in building it.** The session that argued the approach into existence re-reads its own assumptions and passes them, so the value is entirely in a second, clean pass; the skill's own work is getting the discussion into a form a clean pass can read. The record is the findings (`REF-Conversation.md` §2), ranked by consequence (§6).

## Pre-flight

1. **Fix the subject** (`REF-Conversation.md` §1): the approach under test, in the operator's words. Adjacent approaches and future-proofing are parked (§3).
2. **Confirm fresh eyes are obtainable**: a subagent this harness can spawn with a clean context, or a new session the operator opens with only the artifact and the standard. Without either, the skill stops at step 1 and hands the operator the artifact to carry to fresh eyes themselves.
3. **Asks nothing**, so it runs attended or unattended alike (`REF-Conversation.md` §3); the fresh-eyes spawn needs no human.

## Steps

1. **Write the approach down** as one artifact of a page at most: the claim, the reasoning, the assumptions it rests on, and the alternatives already rejected with why. A discussion that cannot be written in a page is not yet an approach; say so and stop at the page.
2. **Name the standard**: the routed REFs for the stack the approach touches, plus internal consistency (each step follows from the previous; no assumption contradicts another).
3. **Hand it to fresh eyes**: spawn a clean-context reviewer over the artifact and the standard, running the `adversarial-review` skill with `kind=plan`, findings only. Its own rules hold: evidence is what the reviewer actually read, and a finding it cannot cite is not a finding.
4. **Return the findings** ranked by consequence (`REF-Conversation.md` §6), with a three-state read: holds; holds under named conditions; does not hold. Beside it, the assumptions that would have to be true for the approach to work.
5. **Stop.** The operator decides. Nothing is edited, nothing is built, no gate is closed (`REF-Conversation.md` §2).

## Failure modes

The generic failures are `REF-Conversation.md` §7: sliding into the act (4), the balanced list is ruling from surface features (12). Specific to this runbook:

- **Self-review**: a "skeptical pass" in the producing context is the thing the primitive exists to refuse, and `adversarial-review` stops itself when it finds it is running there. Pre-flight 2 is the guard.
- **Restating the primitive**: the wrapper names `adversarial-review`; its steps live there.
- **The balanced list**: a cosmetic merit given the weight of a fatal defect hides the one line that matters. Rank by consequence (step 4).
- **A finding the reviewer cannot cite**: the primitive's evidence rule; drop it before returning.
- **The page that is not an approach**: three ideas and a preference are not a claim with reasoning. Step 1 ends there, and the operator gets the page back as the finding.
