---
name: conversation-close
description: "Run before archiving a conversation: summarize what was decided and produced, then sweep for everything still pending - open questions, promised-but-undone work, uncommitted or unpushed changes, decisions not yet in their durable homes - each with where it should go. Trusts nothing to memory. Ends SAFE TO ARCHIVE or NOT YET with the list."
galaxy: brain
refs:
  - REF-Conversation
---

# Conversation close

Invoked when the operator asks whether the conversation can be archived without losing anything ("are we done here?", "can I archive this?"). The end-of-session sibling of `conversation-open`. Principle: **everything pending surfaces in the reply**, so the archive decision depends on nothing outside it (`REF-Conversation.md` §4).

## Pre-flight

1. No reading beyond this conversation is required; the conversation itself and the working tree are the audit surface.
2. If the session touched one or more repos, ensure their working state is checkable (`git status`, `git log` against the upstream).

## Steps

1. **Summarize what this conversation produced**, compactly: decisions made, artifacts created or changed, work completed and verified. Lead with outcomes, not chronology.
2. **Sweep for remainders**, each category below explicitly, reporting "none" when clean (`REF-Conversation.md` §5). A remainder belongs to this session (`REF-Conversation.md` §4), and that scope includes items surfaced by an earlier sweep in this same conversation; when an inherited item earns a line, the line says what changed rather than restating the item.
   - **Open questions**: anything the operator asked that never got a final answer, or the assistant asked and the operator never resolved.
   - **Promised-but-undone work**: every "I'll", "next we", "later", "TODO" uttered in the conversation that no later message closed.
   - **Working-tree state**: uncommitted changes, unpushed commits, stashes, scratch files that carry unsaved substance (`git status` / `git log @{u}..` per touched repo).
   - **Decisions without a durable home**: anything agreed here that should live in a REF, a skill, an ADR, a ticket, or a repo's docs but has not landed there yet (`REF-Conversation.md` §4).
   - **External loose ends**: runs still executing, PRs awaiting review or merge, tickets this conversation opened or was meant to open.
3. **Assign each remainder its home** (`REF-Conversation.md` §4): a ticket to file, a commit to make, a REF or skill to rev, a follow-up conversation, named concretely.
4. **End with the verdict, exactly one of**:
   - `SAFE TO ARCHIVE`: every category above is clean or has reached its home; or
   - `NOT YET - <n> items`: the numbered list, each with its home, so the operator can either act or explicitly waive items.
5. **Offer, do not act** (`REF-Conversation.md` §2): the close is an audit, not a cleanup.

## Failure modes

The generic failures are `REF-Conversation.md` §7: the thin sweep (5), the padded sweep (6), memory as the carrier (7), sliding into the act (4). Specific to this runbook:

- **A remainder the operator waives**: record the waiver in the reply ("dropped by choice"), the home `REF-Conversation.md` §4 gives it.
- **Not in a repo, purely conversational session**: the working-tree category reports "not applicable"; the rest of the sweep still runs (`REF-Conversation.md` §5).
- **A verdict with no list behind it**: `NOT YET` always carries its numbered items, and `SAFE TO ARCHIVE` always follows a sweep that reported every category.
