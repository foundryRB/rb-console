---
name: carry-lessons
description: "Carry what a session learned to its durable home when the session was not a delivery line: separate the machine-bound from the portable, route each portable finding to the home REF-Conversation section 4 names, and file a corpus change as the corpus's own reviewed ticket rather than an edit made in passing. Proposes every act and lands it on the operator's word."
galaxy: brain
refs:
  - REF-Continuity
---

# Carry lessons

Invoked when a session learned something that outlives it and no lifecycle owns the learning ("file what we learned here", "does any of this belong in the corpus?"). Principle: **a finding that holds off this machine owes a durable home**, and memory is never one (`REF-Continuity.md` §2, `REF-Conversation.md` §4). The store-draining half is `sweep-memory`, which hands this runbook whatever it rules portable.

## Pre-flight

1. **Confirm no lifecycle owns this.** A learning loop bound to one lifecycle belongs to that lifecycle's sun (`REF-Continuity.md` §1): a delivery line's lessons are `reconcile-delivery`'s, a maintenance ticket's are the maintenance loop's. This runbook takes what is left: the session that was neither.
2. **Gather the candidate findings**: what this session established that it did not already know. A candidate is something the session proved, not something it merely read.
3. **Know where the corpus takes proposals.** Ask the corpus's own door for the repo that holds it rather than carrying a literal a rename would strand.

## Steps

1. **Apply the discriminator** to each finding (`REF-Continuity.md` §1): would it hold on another machine? A path, a credential situation, a tool that misbehaves on this box is machine-bound and stays a memory line. Everything else is a lesson and moves on to step 2.
2. **Route each lesson to the home** `REF-Conversation.md` §4 names, by kind: a decision about the work to the work's own design record, a lesson beyond the work to the corpus, work still owed to a ticket on the repo that owns it.
3. **Size the lesson before proposing it.** A finding survives as a corpus change only when the defect is in the corpus itself, so state the rule it collides with; a behavior the gates already catch is not a text change. Fight each candidate rather than filing it, and drop a loser with the event that would revive it.
4. **File a corpus change as a ticket**, never an edit (`REF-Continuity.md` §2, anti-pattern 5): the corpus reviews its own changes, and a lesson landed from inside the session that found it arrives unreviewed.
5. **Report every routing before acting**, each finding with its home and its reason, including the ones ruled machine-bound and the ones dropped.
6. **Land on the operator's word**, then delete each memory line whose finding reached its home (`REF-Continuity.md` §2): a line kept after its lesson landed is the same claim in two places, and the memory copy is the one nobody reviews.

## Failure modes

The generic failures are `REF-Continuity.md` §4. Specific to this runbook:

- **A lesson with no home in `REF-Conversation.md` §4**: that is a finding about the corpus's own coverage; propose the home as the change rather than inventing one.
- **A lesson a lifecycle already files**: it is that lifecycle's, not this one's (`REF-Continuity.md` §1). Say which loop owns it and stop.
- **The lesson is real but the remedy is oversized**: propose the smallest change where the problem is still observable, and say what the larger version would have cost.
- **Rehoming without deleting**: the memory line goes when its lesson lands (§2), and a line kept "until the ticket merges" names that merge as its retiring trigger (§3).
- **The operator declines a proposal**: record the decline and its revive trigger; the finding is ruled, not pending.
