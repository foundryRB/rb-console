---
name: earn-it
description: "Fight a set of proposed actions (changes, additions, rules, tickets, todo items) so only what is really worthwhile survives: verify each premise against the evidence and the history, ask whether the need is already met, size a survivor to the smallest change where the problem is still observable, and hand back one ruling per item: take, drop with its revisit trigger, already done, or wrong home. Acts on nothing; the operator lands the survivors."
galaxy: brain
refs:
  - REF-Conversation
---

# Earn it

Invoked when the operator hands the session a set of proposed actions and wants them fought rather than done: a list of todo items, a batch of tickets, a proposed rule, a change someone recommends, a lesson somebody wants written down ("earn it", "fight these", "do we really need any of this?"). Principle: **every proposal earns its place or is dropped with the reason and the event that would revive it.** The stance is aggressive by design; the prior is that the observation behind a proposal is usually true and the remedy usually oversized. It keeps the helper contract of `REF-Conversation.md` §2 and rules by §6.

## Pre-flight

1. **Fix the subject**: the set under judgment, item by item, in the operator's words (`REF-Conversation.md` §1). Nothing outside the set is ruled on; a noticing is parked (§3).
2. **Read each item whole**, with its thread: a ticket with its comments, a proposal with the evidence it cites, a rule with the text it would change. Scoping, corrections, and prior rulings tend to live in the comments, and a bare read hides them.
3. **Confirm what a ruling authorizes.** Nothing (`REF-Conversation.md` §2): the operator lands the survivors through whatever loop owns the target, and the ruling is written so that loop can take it as its input.

## Steps

1. **Verify the premise** (`REF-Conversation.md` §6). For each item:
   - **Is the problem real?** Check the cited evidence against the artifact, not the narrative. A proposal whose incident cannot be reproduced from what it cites is ruled on that finding.
   - **Is it still open?** Read the target's current state and its history (`git log -- <target>` when the target is a file). Things get fixed under another name between proposal and judgment, and the proposer's "have I seen this before?" is usually right.
   - **Is the mechanism claim true?** A proposal usually explains why the problem happened; test that explanation against the thing itself. A check said to accept something silently may refuse loudly; a rule said to be missing may already be stated a section away. A check on an artifact cannot catch a misreading of it: when the incident was the reporter reading a correct file wrongly, the proposed check would have been green at the time.
   - **Does the remedy do what it claims?** When the remedy is a command or a configuration, probe it, leaving the environment as found. A setting that a two-minute probe shows does nothing is dropped with the probe attached.
   - **Which direction does it push?** A proposal can loosen a standing rule while reading as a clarification. Read what the current text mandates, then decide whether the proposal strengthens or weakens it; a weakening does not survive as a clarification.
   - **Unbundle.** Severity language ("separately and more seriously") tends to attach an unrelated incident the remedy would not address. Rule on each concern by itself.
2. **Locate the need** (`REF-Conversation.md` §6). Exactly one of these holds for each item, and it decides the ruling:
   - **Something already meets the need.** An existing rule, a check already in place that catches the class every time, a test that already defends the claim. Drop: a sentence would not have prevented the behavior. A problem caught by the check designed for it, later than it theoretically could have been, is not a gap; it becomes one only when the late catch itself cost something real. If the class ever slips past the check, the revisit trigger is a mechanical check, never more text.
   - **The need is real and nothing meets it.** Take, at the smallest size, where the problem is still observable ("where is this still checkable?" decides the location, not "which step is conceptually responsible"). Prefer deleting the clause that causes the problem over adding one that corrects it, and a check over a sentence when a tool can hold the rule. When the rule was already written and the incident still happened, that is evidence for the check, not for more words.
   - **The proposal generalizes a practice that worked.** Nothing broke; this is advocacy for a mandate from one data point. Drop. An absent convention is a free option; the one exception is a template or generator that emits the opposite of the practice, which is fixed at the template.
   - **The proposal is residue of a fix that already landed.** Deleting the residue is the whole action; drop the proposal and name the deletion.
   - **The need lives somewhere else.** A lesson about one machine, one environment, or a choice its owner does not own: wrong home, and the ruling names the right one.
3. **Size the survivors.** The tell of an oversized remedy is needing an exception for a false positive the remedy itself created: a check that polices a choice its owner does not own grows exceptions until it checks nothing. Trim to the facts the owner actually holds, or drop.
4. **Refuse two remedies regardless of who asks.** A durable artifact never codifies an evasion or workaround technique (rewording to slip past a classifier, for instance); the need is real and its home is wherever the obstacle is tuned. And nothing survives that would mark a false report as completed: a proposal whose premise the judgment refuted closes as not done, with the evidence.
5. **Hand back one ruling per item**, in consequence order (`REF-Conversation.md` §6), each one of:
   - **Take**, with the minimal form and its location;
   - **Drop**, with the reason and the revisit trigger (`REF-Conversation.md` §6);
   - **Already done**, with the pointer;
   - **Wrong home**, with the home named.

   Then the parked list, once. The operator acts; the skill ends here.

## When the subject is a ticket

The same rulings, written where the loop that owns the ticket will read them: the ruling and its evidence as a comment on the thread, so a drop keeps the assembled evidence and its revisit trigger where the next reader looks. A take is the loop's input; a drop closes as declined and an already-done item closes with its pointer, each on the operator's word. The thread is read with its comments (pre-flight 2) and the target's history is read before the premise is judged (step 1).

## Failure modes

The generic failures are `REF-Conversation.md` §7: sliding into the act (4), ruling before the premise (11), ruling from surface features (12). Specific to this runbook:

- **Crediting the remedy for the observation.** The observation is usually true; the ruling is about the remedy. Verify the premise, then judge the size.
- **A take that needs an exception on its first cut.** That is the sizing tell in step 3; trim or drop.
- **Judging a bundle as one item.** Unbundle first (step 1); one ruling per concern.
- **Softening the drop to spare the proposer.** A drop without its revisit trigger loses the evidence and invites the same proposal back unsized.
