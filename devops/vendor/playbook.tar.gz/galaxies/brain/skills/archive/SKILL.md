---
name: archive
description: Archive a project / area / resource in a Foreign Brain vault - set frontmatter status, move file or folder to `04 Archive/<Kind> - <name>/`, add archive date + revive instructions, prune Hub.md, run validator.
galaxy: brain
refs:
  - REF-Foreign-Brain
---

# Archive

Invoked when the user wants to archive an existing project, area, or resource. Encodes the deterministic steps that the vault's I9 invariant + Hub.md archival convention require, so nothing gets dropped on the floor.

For partial archival (extracting a completed sub-section out of a still-live Area note into `_Archive/`), use the sibling [`archive-section`](../archive-section/SKILL.md) skill. This skill handles whole files/folders only.

## Pre-flight

1. **Read** `<vault>/Hub.md` to identify the archival convention currently in force (the rule may evolve; trust the file, not training data) and to know whether the target is a declared hub.
2. **Read** the kind off the PARA folder the target sits under, at any depth (`REF-Foreign-Brain.md` §7): `01 Projects/` is a project, `02 Areas/` an area, `03 Resources/` a resource. That kind is the `<Kind>` prefix of the archive entry.
3. **Confirm** with the user if any of the following is true:
   - The target is an entity hub (a note under a `People/`, `Places/` or `Brands/` folder, at any depth; entity hubs don't archive, §7), or sits outside the three PARA folders (a file at the vault root)
   - `status:` is already `archived` (likely a no-op; ask before re-running)
   - The destination folder under `04 Archive/` already exists

## Inputs

The user supplies a path. It may be:
- A single `.md` file (e.g., `01 Projects/Foo.md`)
- A folder containing the hub `.md` plus assets (e.g., `01 Projects/ArcStasher/`)
- An area or resource at any depth (e.g., `02 Areas/Foo.md`, `03 Resources/Foo/`)

Optional: a one-line **reason** for archival, and **revive criteria** (when/why this might be brought back). If not given, generate a plausible default and surface it in the report so the user can edit.

## Steps

For the target item:

1. **Update frontmatter** - set `status: archived`. If the item was a project without `status:` set, add it. Every other field travels as found (`created`, tags, an app-assigned `id`).
2. **Update title** - append ` (archived)` to the H1 title if not already present.
3. **Add archive metadata to body** - at the top of the body (right after the H1), insert or update an "Archived YYYY-MM-DD" line:

   ```markdown
   Archived <YYYY-MM-DD>: <reason>. Revive (move back to `<original-location>`) if/when <revive criteria>.
   ```

   If the body already has an archive line, update its date + revive path; don't duplicate.

4. **Move the entry** to `04 Archive/<Kind> - <name>/`:
   - If the source is a folder, rename + move the folder.
   - If the source is a standalone `.md`, decide based on whether assets (PDFs, images, sub-folders) live alongside - if yes, create a folder; if no, the renamed `.md` can sit at the archive root with the `<Kind> - <name>.md` filename.
   - The `<name>` portion preserves the original stem (case + spaces preserved).
5. **Update Hub.md** - if the archived item was listed in any of these sections, remove the line:
   - "Top-level navigation" / "Personal Management" / "Other Areas" / Data Packs
   - Any explicit People / Places / Brands declaration (only relevant if those sections are still hand-declared)
   Dataview-driven sections (Resources, Projects, People/Places/Brands when on auto-list) need no edit - `status: archived` plus the move out of the source folder is enough.
6. **Tags preserved** - do NOT strip `#area/*`, `#topic/*`, etc. from the body. Dataview queries against tags should keep finding archived content.
7. **Run validator** - `python -m pytest <vault>/_System/tests/test_vault_invariants.py --tb=short`. Capture pass/fail. If I9 trips, the move/rename was wrong - fix before reporting success.
8. **Report to user** - what moved, the new path, whether Hub.md was edited, validator status.

## Naming convention (mandatory)

Per Hub.md's archival convention, every archived entry MUST be prefixed by its capitalized kind, read off the source folder:

| Source folder | Folder / file pattern |
|---|---|
| `01 Projects/` | `Project - <Name>` |
| `02 Areas/` | `Area - <Name>` |
| `03 Resources/` | `Resource - <Name>` |

The validator (I9) enforces this for all three kinds.

## Failure modes

- **Already archived** (`status: archived` + already under `04 Archive/`) → no-op; report and exit.
- **Folder holding another item's hub** (a second project or area hub beside the target's own, not a child note of the target) → don't archive blindly; ask the user which item is being archived and whether the other travels with it.
- **Archived item is referenced as a wikilink elsewhere** → links continue to resolve as long as the filename stem is unique. If the rename creates ambiguity (two `Resource - X.md` in archive), append a year/disambiguator and update inbound wikilinks.
- **Item is in the Hub.md "Approved Phantoms" list** → that's a phantom, not a real file; archiving doesn't apply. Tell the user.
- **Validator fails after archive** → do NOT silently revert; surface the failure with the I-number so the user can decide.

## What archive does NOT do

- Does NOT delete files. Archival is reversible by design.
- Does NOT modify content beyond title + archive metadata line. The original notes inside stay verbatim.
- Does NOT remove backlinks or wikilinks from other notes. Backlinks become "to archived content" links - that's intentional.
- Does NOT rewrite frontmatter beyond `status:`. Every other field travels as found.
- Does NOT auto-archive related items (e.g., a project's child notes). Each archive call targets one entry.
