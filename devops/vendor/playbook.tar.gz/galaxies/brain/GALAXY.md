# Galaxy: brain

> The operator's own side of the work: the AI-augmented Second Brain (how a personal knowledge vault is built and tended: PARA structure, digestion, archival), the conversation helpers the operator invokes on the session itself rather than on the work it is about, and the state that outlives a session. Enter here when the subject is the operator rather than a codebase: a vault of notes with an owner's life attached, where the discipline is layer separation, deliberate digestion, and history preserved by archival rather than deletion; the conversation itself, where the discipline is the helper contract of `REF-Conversation.md` §2; or what sessions leave behind, where the discipline is draining the memory layer and owing the corpus its lessons (`REF-Continuity.md` §1).

## Galaxy at a glance

| | |
| --- | --- |
| **Galaxy** | brain |
| **Subject** | The operator's own side of the work: the AI-augmented Second Brain (a personal knowledge vault: PARA structure, digestion, archival), the conversation helpers the operator invokes on the session itself rather than on the work it is about, and the state that outlives one session. |
| **Owner** | The org's resident knowledge-management expert, who stands behind the vault pattern, the conversation helpers, and what carries between sessions |
| **Anchor REF** | `REF-Foreign-Brain.md` |
| **Routing doc** | This file (`GALAXY.md`) |

---

## Project Context

The subject is the operator's own side of the work, and it has three suns. `REF-Foreign-Brain.md` is the vault: one person's externalized memory, an Inbox of raw captures, a PARA-structured Augmented layer the graph navigates, and an Archive that keeps history alive; the AI works it through its rituals (open the session by surfacing what is due, digest the Inbox into structure, archive what has completed). `REF-Conversation.md` is the conversation: the small helpers the operator invokes on the session itself rather than on the work it is about, each leaving a record the operator reads and each serving any session: a vault, a repo, a document, or plain conversation. `REF-Continuity.md` is what carries between sessions: the memory layer a machine accrues and the lessons a session owes the corpus, swept on the operator's word at any moment rather than at a session boundary.

---

## Task Routing - load only what you need

| Task | Read these REFs |
| ---- | --------------- |
| Building or maintaining an AI-augmented Second Brain (PKM vault) | `REF-Foreign-Brain.md` |
| Opening a session in a vault (surface overdue tasks, parked decisions, deadlines, pending Inbox) | `REF-Foreign-Brain.md` (+ skill `conversation-open`) |
| Processing pending Inbox captures into the PARA layer (decisions, tasks, people, places, brands) | `REF-Foreign-Brain.md` (+ skill `digest`) |
| Archiving a completed project, area, or resource, or extracting a finished sub-section from a live note | `REF-Foreign-Brain.md` (+ skills `archive`, `archive-section`) |
| Being interviewed about a plan or design decision before anything is built, one question at a time, until no decision is left to the implementer | `REF-Conversation.md` (+ skill `grill-me`) |
| Closing a conversation without losing anything: what was produced, what is still pending, and where each remainder goes | `REF-Conversation.md` (+ skill `conversation-close`) |
| Fighting a set of proposed actions (todo items, tickets, rules, recommended changes) so only what is really worthwhile survives | `REF-Conversation.md` (+ skill `earn-it`) |
| Having the topic under discussion said again, shorter and structured, for the same reader, with nothing that changes the answer dropped | `REF-Conversation.md` (+ skill `condense`) |
| Stress-testing the approach under discussion with fresh eyes: written down, handed to a clean-context reviewer, findings back with a three-state read | `REF-Conversation.md` (+ skill `poke-holes`) |
| Helping a colleague out of an IT problem (an error, a failed login, a connector that will not connect, an agent that did the wrong thing): the cause proven, the fix walked through, and a verdict naming where the fix lands | `REF-Conversation.md` (+ skill `skill-issue`) |
| Writing a new conversation helper, or judging whether one belongs here | `REF-Conversation.md` §1 and §2 |
| Sweeping the memory layer a machine has accrued: what is still true, what its task resolved, what is a lesson belonging elsewhere | `REF-Continuity.md` (+ skill `sweep-memory`) |
| Carrying what a session learned to its durable home when the session was not a delivery line | `REF-Continuity.md` (+ skill `carry-lessons`) |
| Writing a new continuity helper, or judging whether one belongs here | `REF-Continuity.md` §1 and §2 |

## Available Skills (invocable)

Master copies live in `skills/<name>/SKILL.md` in this galaxy. Install or refresh runtime copies with `python scripts/install_playbook.py` from the repo root. Each skill's description lives in its `SKILL.md` frontmatter, declared to the runtime at load; this registry indexes the master copy and the REFs that ground it. The table is generated by `scripts/sync_registry.py` from that frontmatter; do not edit it by hand.

| Skill | Master | Refs |
|---|---|---|
| `archive` | `skills/archive/SKILL.md` | `REF-Foreign-Brain` |
| `archive-section` | `skills/archive-section/SKILL.md` | `REF-Foreign-Brain` |
| `carry-lessons` | `skills/carry-lessons/SKILL.md` | `REF-Continuity` |
| `condense` | `skills/condense/SKILL.md` | `REF-Conversation` |
| `conversation-close` | `skills/conversation-close/SKILL.md` | `REF-Conversation` |
| `conversation-open` | `skills/conversation-open/SKILL.md` | `REF-Foreign-Brain` |
| `digest` | `skills/digest/SKILL.md` | `REF-Foreign-Brain` |
| `earn-it` | `skills/earn-it/SKILL.md` | `REF-Conversation` |
| `grill-me` | `skills/grill-me/SKILL.md` | `REF-Conversation` |
| `poke-holes` | `skills/poke-holes/SKILL.md` | `REF-Conversation` |
| `skill-issue` | `skills/skill-issue/SKILL.md` | `REF-Conversation` |
| `sweep-memory` | `skills/sweep-memory/SKILL.md` | `REF-Continuity` |

**If you encounter a Skill listed here but not invocable**, the runtime may not have it installed. Run `python scripts/install_playbook.py --only <name>` from the repo root, or report to user.

---

## Brain Violations - Check EVERY Change

The universal violations (duplication, em-dashes, portability, change-narration) live in `AI-PLAYBOOK.md` and apply here too. These are the galaxy's own cross-cutting mistakes; verify **none** of them apply before completing any task:

1. **Wiring the Inbox into the graph.** The Inbox is the raw archive layer; its prose stays verbatim and carries no wikilinks. Enrichment happens in the Augmented layer the digest writes, so the graph navigates structure, never raw capture (`REF-Foreign-Brain.md` §2).
2. **Calling an area a project.** A project has end criteria; an ongoing responsibility is an area. When unsure, default to area, because a project that cannot end clogs every review that walks the open projects (`REF-Foreign-Brain.md` §3).
3. **Deleting where the vault archives.** Completed work moves to the Archive with its date and revive instructions, and hub links are pruned; deletion erases in-vault history the owner may need to revive. The archive skills are the only exit for live content.
4. **Homing a helper on a sun outside this galaxy.** A session helper homes on `REF-Conversation.md`, a continuity helper on `REF-Continuity.md`, and neither cites a sun outside this galaxy (`REF-Conversation.md` §1, `REF-Continuity.md` §1).
