---
domain: architecture
---

# REF: Clean Architecture (Hexagonal / Ports & Adapters)

> Master REF for hexagonal architecture. References layer-specific REF documents for detail.

---

## 1. The Dependency Rule

Dependencies flow **inward only**: Adapters → Application → Domain.

```
┌──────────────────────────────────────────────┐
│  Inbound Adapters (CLI, HTTP, UI)            │
│    ↓ depends on                              │
│  ┌────────────────────────────────────────┐  │
│  │  Application Layer                     │  │
│  │    Inbound Ports   ← adapters call     │  │
│  │    Use Cases       ← implement ports   │  │
│  │    Outbound Ports  ← use cases call    │  │
│  │  ┌──────────────────────────────────┐  │  │
│  │  │  Domain Layer                    │  │  │
│  │  │    Model (entities, VOs, enums)  │  │  │
│  │  │    Services (stateless logic)    │  │  │
│  │  │    Exceptions (error hierarchy)  │  │  │
│  │  │    Constants (ubiquitous lang)   │  │  │
│  │  └──────────────────────────────────┘  │  │
│  └────────────────────────────────────────┘  │
│  Outbound Adapters (persistence, writers)    │
│    ↑ implements outbound ports               │
└──────────────────────────────────────────────┘
```

**Nothing in an inner layer imports from an outer layer.** Domain never imports application. Application never imports adapters. The only exception: the **Container** (composition root) wires everything together.

**Topology decides how many deployables carry the hexagon, never whether the domain stays isolated.** An application is one of two shapes:

- **Client-server.** The core is a service publishing a contract, and the interface is a separate project consuming it over a network hop. The service hosts no interface of its own; `REF-Frontend.md` governs the client.
- **Standalone.** The core and its interface ship as one artifact. The interface reaches the core by a call rather than a hop, which makes it an inbound adapter of this hexagon, alongside the CLI.

The question that decides which: can the interface be deployed and versioned separately from the core? A core answering yes publishes its contract and stops there.

---

## 2. Self-Documenting Structure

The directory tree is the first document anyone reads.

- **Directories are categories, not containers** - a folder name describes *what kind of thing* lives inside (`domain/exceptions/`, not `domain/stuff/`).
- **The top two levels should read like a table of contents.**
- **Structure must survive refactors without docs updates** - if a README folder-listing needs maintaining, delete the listing; the tree is the doc.
- **If a file needs inline section comments to orient the reader, split it** until file names carry that meaning.

---

## 3. Layer Responsibilities

| Layer             | Responsibility                                              | REF Document            |
|-------------------|-------------------------------------------------------------|-------------------------|
| **Domain**        | Business entities, value objects, enums, pure logic, exceptions | `REF-Domain.md`       |
| **Application**   | Inbound ports, outbound ports, use cases                    | `REF-UseCase.md`, `REF-InboundPort.md`, `REF-OutboundPort.md` |
| **Inbound Adapter** | CLI, HTTP - translate external input into port calls       | `REF-InboundAdapter.md` |
| **Outbound Adapter** | Persistence, writers - implement outbound ports           | `REF-OutboundAdapter.md` |

Cross-cutting concerns:
| Concern           | REF Document              |
|-------------------|-----------------------------|
| Exception handling | `REF-ExceptionHandling.md` |
| Python tooling     | `REF-Python.md`           |
| Testing            | `REF-Tests.md`            |
| Documentation      | `REF-Documentation.md`    |

---

## 4. Folder Structure

```
<package>/
├── container.py                         # Composition root (DI)
├── logging.py                           # Centralized logging config
├── domain/
│   ├── constants.py                     # Ubiquitous language constants
│   ├── model/
│   │   ├── __init__.py                  # Barrel - re-exports all types
│   │   ├── aggregates/                  # Aggregate roots
│   │   ├── entities/                    # Identity-based domain objects
│   │   └── value_objects/               # frozen dataclasses, enums, NewTypes
│   ├── services/                        # Stateless domain services
│   └── exceptions/                      # Exception hierarchy
├── application/
│   ├── ports/
│   │   ├── inbound/                     # @runtime_checkable Protocols
│   │   └── outbound/                    # Protocols for infra contracts
│   └── use_cases/                       # Implement inbound ports
├── adapters/
│   ├── inbound/
│   │   ├── cli/                         # argparse adapter
│   │   └── http/                        # FastAPI adapter
│   └── outbound/
│       ├── persistence/                 # Database / file repository
│       ├── payments/                    # Payment gateway adapter
│       └── notifications/               # Email / SMS adapter
└── tests/
    ├── conftest.py                      # Shared fixtures
    ├── unit/                            # Pure logic, no I/O
    └── integration/                     # Real adapters, tmp_path
```

---

## 5. The Container (Composition Root)

The `Container` class in `engine/container.py` is the **only place** where all layers are wired together.

Rules:
- The Container instantiates **outbound adapters** once (shared instances).
- Factory methods return **inbound port types** - never concrete use case classes.
- Every factory uses `_check(instance, PortType)` to verify the use case satisfies the port protocol at runtime - catching signature drift immediately.
- Both CLI and HTTP adapters use the same Container.
- The Container is the only file allowed to import from all layers simultaneously.

```python
def create_order(self) -> CreateOrderPort:
    return _check(
        CreateOrder(
            repository=self._order_repo,
            payment_gateway=self._payment_gateway,
            notification_service=self._notification_service,
        ),
        CreateOrderPort,
    )
```

---

## 6. Import Rules by Layer

| From \ To          | Domain | Application | Inbound Adapter | Outbound Adapter |
|--------------------|--------|-------------|-----------------|------------------|
| **Domain**         | ✅     | ❌          | ❌              | ❌               |
| **Application**    | ✅     | ✅ (ports)  | ❌              | ❌               |
| **Inbound Adapter**| via `TYPE_CHECKING` | ✅ (ports only) | ✅ (own package) | ❌ |
| **Outbound Adapter**| ✅    | ✅ (ports for typing) | ❌     | ✅ (own package) |
| **Container**      | ✅     | ✅          | ❌              | ✅               |

Key principle: **adapters depend on ports, never on each other.**

---

## 7. One Class Per File

Every class lives in its own file - entities, VOs, enums, exceptions, ports (one Protocol per file), use cases, mappers (one function or related set per file). No "it's small enough" rationalizations. If a file has a `# --- Section ---` comment, it should be split.

**Adapter-internal types** (DTOs, constants, intermediate data shapes) are the one scoped exception: when private to an adapter package, they may be grouped by concern inside a `models/` sub-package. See REF-OutboundAdapter §10.

---

## 8. `__all__` and Re-exports

- Every module with public symbols declares `__all__`.
- Package `__init__.py` files either:
  - (a) contain only a docstring (no re-exports) - consumers import from specific files, or
  - (b) re-export via `__all__` for packages that form a public API (e.g., `domain/exceptions/__init__.py`).
- Choose (a) for ports (explicit dependency graphs). Choose (b) for exceptions (convenient catch-all imports).

---

## 9. Decision Guide: Where Does This Code Belong?

| Question | It belongs in… |
|----------|----------------|
| Has identity and lifecycle? | Domain Entity |
| Immutable descriptive data? | Value Object (`frozen=True` dataclass) |
| Defines what the app can do? | Inbound Port (Protocol) |
| Defines what the app needs from outside? | Outbound Port (Protocol) |
| Orchestrates domain + ports? | Use Case |
| Translates HTTP ↔ domain? | HTTP Adapter (route, DTO, mapper) |
| Translates CLI ↔ domain? | CLI Adapter (command, mapper, formatter) |
| Translates UI events ↔ domain? | UI Adapter, in a standalone application (§1) |
| Reads/writes files or calls external services? | Outbound Adapter |
| Pure business algorithm spanning entities? | Domain Service |
| Shared constant / identifier? | `domain/constants.py` |
| Complex parsing of external formats? | Outbound Adapter (parser) |

---

## 10. Anti-Patterns

| #  | Anti-Pattern                                    | Correct Approach                            |
|----|-------------------------------------------------|---------------------------------------------|
| 1  | Adapter imports domain types at runtime          | Use `TYPE_CHECKING` guard                   |
| 2  | Use case imports another use case                | Extract shared logic to domain service      |
| 3  | Domain imports from application or adapter       | Move the needed type into domain            |
| 4  | DTO with `from_domain()` method                  | Separate mapper function in `mappers/`      |
| 5  | Multiple classes in one file                     | One class per file, always                  |
| 6  | Container returns concrete use case type         | Return the inbound port Protocol type       |
| 7  | Adapter calls use case directly, bypassing port  | Always go through the port Protocol         |
| 8  | `Any` hiding a domain type in adapter code       | Explicit mapper → adapter DTO               |
| 9  | Centralizing domain logic into a shared library  | Each domain team publishes its own artifact  |
| 10 | A service publishing a contract also hosting a UI adapter | The interface is a separate deployable; the service publishes and stops (§1) |

---

## 11. Bounded Responsibility & Simplicity

**The principle: simple over complex. When responsibility grows, split into a sibling module - don't pile on.** A module (backend, frontend, library, service) does one bounded thing well.

Split-now heuristics:
- The README needs a second "what it does" paragraph - the second concern belongs in a sibling module.
- A new feature requires a new top-level concept (new bounded context, non-composing persistence model, new I/O surface) - that's a new module, not a new sub-package.
- Two parts of the module change for different reasons (e.g. `adapters/billing/` and `adapters/auth/` never co-evolve).
- You're writing inline comments to orient readers between sections - §2's rule at module scale.

Resist: "one more responsibility is faster" (produces the everything-project), premature feature flags/config knobs (add the knob when a second case demands it), and "we'll factor it out later" (later has more coupling to unwind - split when you notice).

Each module gets: a single sentence stating what it does and deliberately doesn't (the README opens with it), and boundary tests that break the build if the module depends on anything outside its bounded responsibility. When a new responsibility appears, ask "does this belong in a sibling module?" first - if yes, scaffold the sibling and stop. Cross-module coordination happens through published contracts (§12), never shared internals.

---

## 12. Multi-Team Shared Code: Ownership Boundaries

When multiple teams own separate bounded contexts, **do NOT consolidate domain logic into a single shared library** - it creates a serialized deployment chain (update shared lib → update consumer → redeploy) where teams queue behind each other for unrelated changes.

**The rule:** Each team owns and deploys their domain logic independently. Sharing happens through **published artifacts** (versioned JARs, packages), not a monolithic shared module.

| Code type | Shared library OK? | Reason |
|---|---|---|
| **Cross-cutting utilities** (ID formatting, date parsing, logging) | ✅ Yes | Truly generic, changes rarely, no domain knowledge |
| **Domain mappers** (DTO→entity, format conversions) | ❌ No | Domain-specific, changes frequently, owned by one team |
| **Adapter contracts** (port interfaces, event schemas) | ⚠️ Careful | OK if stable; publish as a thin contract JAR, not a fat shared lib |

**Pattern for reuse without coupling:** each domain team's pipeline publishes its own versioned mapper artifact (e.g. `team-a-mapper:1.2.3`, `team-b-mapper:0.8.1`). Consumers pin versions and update them independently. No team blocks another.

## 13. Template Files

Excel/document templates (`.xlsx`, `.pptx`) live at the project root under `templates/<format>/` (e.g., `templates/excel/`), injected into adapters via constructor DI - adapters do not resolve their own filesystem paths.

---

## 14. Skills that instantiate this REF

Generated by `scripts/sync_backlinks.py` from skill frontmatter; do not edit by hand.

Skills whose frontmatter `refs:` includes `REF-CleanArchitecture`:

- `bootstrap-account-spine-python` - Add the account spine to an existing Python hexagonal FastAPI backend per REF-Identity: an opaque non-derived user id, an accounts table carrying the federation link, digest-only sessions, one session-resolution choke point, a guess budget, and the credential rung named explicitly with --rung (no default, because a scaffold that picks the rung is advocacy with a code generator attached).
- `bootstrap-account-spine-typescript` - Add the account spine to an existing TypeScript backend (domain/ plus adapters/{http,pg}) per REF-Identity: an opaque non-derived user id, an accounts table carrying the federation link, digest-only sessions, one session-resolution choke point, a guess budget, and the credential rung named explicitly with --rung (no default, because a scaffold that picks the rung is advocacy with a code generator attached).
- `bootstrap-hexagonal-backend` - Scaffold a new Python FastAPI service in hexagonal (ports and adapters) architecture, conforming to REF-CleanArchitecture / REF-FastAPI / REF-Python.
- `bootstrap-hexagonal-typescript` - Scaffold a new TypeScript application in hexagonal (ports and adapters) architecture per REF-TypeScript: domain / application / adapters layers, ports as interfaces, a container.ts composition root, one exemplar use case wired end to end, and boundary tests asserting the dependency rule.
- `bootstrap-mcp-adapter` - Add an MCP inbound adapter to an existing hexagonal FastAPI backend: the tools-mirror-inbound-ports server module, streamable HTTP mounted on the same app, capability-derived tool registration, and a protocol-level integration test.
