---
domain: architecture
---

# REF: Plugin Architecture

> When asked to build a system where behavior is extensible via named, config-driven modules, follow these rules strictly.

---

## 1. When to Use This

Use when behavior must be **extensible without modifying host code**, which operations run (and with what parameters) is a **configuration decision**, operations share a **uniform contract**, and new operations are added by **dropping in a module/class** with no registration boilerplate.

Do **not** use for: a fixed operation set that will never change (direct calls), operations with fundamentally different signatures (strategy/adapter), or one-off extensibility (a callback parameter).

---

## 2. Core Concepts

### Plugin Contract

Every plugin exposes the **same entry point** with the same signature. The host code never knows which plugin it is calling.

**Python** - a module-level function:

```python
def apply(data: T, config: dict, context: Any) -> T:
    """One-line description. Config schema in module docstring."""
    ...
    return data
```

**Java** - an interface:

```java
public interface Plugin<T> {
    T apply(T data, Map<String, Object> config, PluginContext context);
}
```

| Parameter | Purpose |
|-----------|---------|
| `data` | The working set - what the plugin transforms. Type is consistent across all plugins. |
| `config` | Plugin-specific parameters. Comes from the configuration file, not code. |
| `context` | Read-only access to ambient state the plugin might need (loaded datasets, paths, etc.) |

### Plugin Resolution

A **resolver** maps a string name to a plugin implementation.

**Python** - `importlib`:

```python
def resolve(name: str) -> ModuleType:
    module = importlib.import_module(f"<package>.{name}")
    if not hasattr(module, "apply"):
        raise AttributeError(f"Plugin '{name}' has no 'apply' function")
    return module
```

**Java** - a `PluginRegistry` (name → `Plugin` map with `register()`/`resolve()`) or `ServiceLoader`.

Rules:
- Resolution is by **string name** - the caller doesn't import the plugin directly.
- Cache resolved plugins - resolution should happen once per name.
- Fail fast if a name doesn't resolve - `ImportError` / `IllegalArgumentException`, not a silent null.

### Configuration

Plugins are wired in a config file, not in code:

```yaml
plugins:
  - name: aggregate
    group_by: [category, region]
    sum_fields: [amount]
  - name: filter
    field: status
    condition: not_empty
```

| Rule | Rationale |
|------|-----------|
| Plugin name matches the module/class name | Convention over configuration - no mapping table needed |
| All parameters are in the config block | Plugins are fully parameterized from outside |
| Order in the list = execution order | Explicit, readable, diffable |
| Each entry is self-contained | A plugin entry has everything it needs - no cross-references between entries |

---

## 3. Plugin Implementation Rules

| Rule | Rationale |
|------|-----------|
| Named after the **operation**, not the domain entity | `aggregate.py`, not `product.py`. Operations are reusable; entity names are not |
| One plugin per module/class | Easy to find, easy to test |
| Module docstring documents the config schema | The plugin is self-documenting |
| Pure-ish: primary I/O is `data in → data out` | Side effects (logging, metrics) are fine, but the main job is transforming data |
| No awareness of other plugins | A plugin doesn't know if it runs first, last, or alone |
| No awareness of the host's orchestration | Pipeline, web handler, or CLI - the plugin just transforms data |
| Validate `config` early | Fail on missing required params at the start of `apply`, not halfway through |

---

## 4. Folder Layouts

**Python:**

```
plugins/
├── __init__.py       # resolve(name) function
├── aggregate.py      # Groups and sums rows
├── filter_rows.py    # Keeps/discards rows by condition
├── join.py           # Merges data from a secondary source
└── zero_pad.py       # Left-pads field values
```

**Java:**

```
plugins/
├── Plugin.java             # interface
├── PluginRegistry.java     # resolve(name) + registration
├── AggregatePlugin.java
├── FilterRowsPlugin.java
├── JoinPlugin.java
└── ZeroPadPlugin.java
```

---

## 5. Host Integration

The host code that executes plugins follows a simple loop:

```python
for entry in config.get("plugins", []):
    plugin = resolve(entry["name"])
    data = plugin.apply(data, entry, context)
```

(Java is the same loop over `registry.resolve(...)`.)

This loop can live inside a pipeline step, a request handler, a CLI command, a batch job - anywhere. The plugin architecture is **independent of the host's execution model**.

---

## 6. Testing

Each plugin is testable in isolation by calling `apply(data, config, context)` directly: data in, config, data out. No host mocking, no pipeline setup.

---

## 7. Anti-Patterns

| # | Anti-Pattern | Correct Approach |
|---|-------------|------------------|
| 1 | Naming plugins after entities (`product.py`, `order.py`) | Name after operations (`aggregate.py`, `join.py`) |
| 2 | Hardcoding plugin parameters in the module | All parameters come from the `config` dict |
| 3 | Plugins importing other plugins | Each plugin is independent; compose via config ordering |
| 4 | Wiring plugins in code (`if type == "x": use PluginA`) | Wire in the config file - the resolver handles lookup |
| 5 | Different signatures per plugin | Uniform contract: same `apply(data, config, context)` for all |
| 6 | Plugins with side effects as primary purpose (sending emails, writing files) | Plugins transform data. Side-effecting operations belong in adapters or dedicated steps |
| 7 | Registration boilerplate per plugin | Convention-based resolution: name = module/class name |
| 8 | Plugin aware of its position in the execution chain | Each plugin should work correctly regardless of ordering |
