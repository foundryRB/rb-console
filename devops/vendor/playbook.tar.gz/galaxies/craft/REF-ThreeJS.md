---
domain: framework
---

# REF: 3D Rendering with Three.js

> Read this REF when building browser 3D: visualizations, games, or immersive (WebXR) experiences with Three.js as the rendering layer.

---

## 1. Scope

Three.js is the rendering layer for interactive 3D in the browser: data visualizations with a spatial dimension, games, product configurators, and immersive (VR/AR) experiences. This REF owns everything from the canvas inward: renderer, scene graph, assets, the frame loop, XR.

It does **not** own the host application. The surrounding app (routing, state, UI chrome) follows `REF-Frontend.md` + `REF-React.md` as usual; the 3D view is one component of that app. Nor is it for 2D: charts and dashboards route to `REF-ObservableFramework.md`, flat diagrams to SVG. Pay for a WebGL context only when the third dimension carries meaning.

---

## 2. The render layer is a module, not a component

Write the 3D core as a **framework-agnostic TypeScript module** with an explicit lifecycle contract, and keep the host framework outside it:

```ts
export interface SceneApp {
    mount(container: HTMLElement): void;  // creates renderer + canvas, starts observing size
    start(): void;                        // begins the animation loop
    stop(): void;                         // halts the loop, keeps resources
    dispose(): void;                      // frees every GPU resource (see §6)
}
```

Rules:

- **The host is a thin shell.** In React, exactly one boundary component owns the `SceneApp` via a ref: create on mount, `dispose()` on unmount. Three.js objects never enter React state, props, or context; they are mutable GPU-backed handles, not data.
- **Data crosses the boundary as plain values.** The host pushes domain state in through methods (`app.setData(rows)`, `app.setSelection(id)`) and receives events out through callbacks. The module maps domain records to `Object3D`s internally (see §4).
- **react-three-fiber is the exception, not the default.** Reach for it only when the whole app is already React-declarative and the scene is UI-shaped (mostly static, driven by props). For games and XR, the imperative module keeps the frame loop, physics, and input in one place the reconciler can't preempt.

This boundary is what later lets the same scene serve a flat page and a VR headset (§9) without touching the host.

---

## 3. Renderer, camera, and the frame loop

One `WebGLRenderer` per canvas, configured once:

```ts
const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));  // cap: higher ratios cost quadratic fill for invisible gain
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;            // lit scenes; keep NoToneMapping for unlit/schematic viz
```

- **Drive the loop with `renderer.setAnimationLoop(callback)`, never raw `requestAnimationFrame`.** It is the same loop for flat rendering, but it is the only loop an XR session can take over (§9). Adopting it on day one makes VR a flag, not a rewrite.
- **All motion is delta-time scaled.** Read `clock.getDelta()` once per frame, pass `dt` down; nothing moves by a per-frame constant. Frame rate varies per machine and doubles inside a headset.
- **Resize via `ResizeObserver` on the canvas container**, not window events: update `camera.aspect`, call `camera.updateProjectionMatrix()`, then `renderer.setSize(width, height, false)` (the `false` leaves CSS in charge of layout).
- **Render on demand for static content.** A visualization that only changes on interaction should render inside an `invalidate()` pattern (dirty flag checked by the loop), not burn GPU on 60 identical frames. Games and XR render continuously.

---

## 4. Scene organization and units

- **Units are meters, Y is up.** Every asset, every constant, every physics value. On a flat screen an arbitrary scale survives; in VR (§9) the world presents at physical size and a 10x scale error is instantly nauseating.
- **One `Group` per logical entity**, named (`group.name = "..."`), children positioned relative to it. Transforms compose down the tree; move the group, never its children individually.
- **Game entities implement `update(dt: number)`** and register in one collection the loop iterates. No entity reaches into another's transform mid-frame; interactions go through explicit state.
- **Visualizations keep a `Map<DomainId, Object3D>`** owned by the module. Domain state never lives on materials or in `userData` scattered through the graph; `userData` carries at most the back-reference id for picking (§8).
- **Lights are scene furniture, budgeted.** Start with one ambient/hemisphere plus one directional; every additional shadow-casting light multiplies draw cost. Shadows only where the design needs them, with tight `shadow.camera` bounds.

---

## 5. Assets and loading

- **glTF (`.glb`) is the interchange format.** Load with `GLTFLoader`; wire `DRACOLoader` (mesh compression) and `KTX2Loader` (GPU texture compression) when asset weight matters. Author in Blender or export from CAD; never hand-build meshes that a DCC tool should own.
- **Wrap loaders in `async` functions and preload before first render.** A `LoadingManager` drives the progress UI. The first frame the user sees is complete or an intentional placeholder, never a scene popping in piecewise.
- **Assets are static files of the app**, versioned with it, served from the app's public directory. Texture dimensions are powers of two; budget the largest texture by the weakest target device (mobile GPUs and standalone headsets, not the dev workstation).
- **Reuse via `.clone()`** for many instances of a loaded model; the clone shares geometry and materials. For hundreds of copies, promote to `InstancedMesh` (§7).

---

## 6. Resource lifecycle: GPU memory is manual

Removing an object from the scene frees **nothing**. Geometries, materials, textures, and render targets each hold GPU buffers until `.dispose()` is called on them.

```ts
function disposeObject(root: THREE.Object3D): void {
    root.traverse((node) => {
        const mesh = node as THREE.Mesh;
        mesh.geometry?.dispose();
        const materials = Array.isArray(mesh.material) ? mesh.material : [mesh.material];
        for (const material of materials) {
            if (!material) continue;
            for (const value of Object.values(material)) {
                if ((value as THREE.Texture)?.isTexture) (value as THREE.Texture).dispose();
            }
            material.dispose();
        }
    });
    root.removeFromParent();
}
```

- The module's `dispose()` (§2) runs this over the scene, then `renderer.dispose()`.
- Anything created per data-refresh (a rebuilt viz layer, a despawned game wave) is disposed on replacement, not leaked behind a dropped reference.
- **Leak detection is a numbers check:** `renderer.info.memory` (geometries, textures) must return to baseline after a create/destroy cycle. Assert it in tests (§10).

---

## 7. Performance discipline

Measure before optimizing: `renderer.info.render.calls` per frame is the first number to read.

| Symptom | Fix |
|---|---|
| Hundreds of draw calls from repeated shapes | `InstancedMesh` (one call for N copies); per-instance transform via `setMatrixAt` |
| Many static meshes sharing a material | Merge into one geometry (`BufferGeometryUtils.mergeGeometries`) |
| GPU-bound on high-DPI displays | Pixel ratio cap (§3); drop it further inside XR sessions |
| Frame-time spikes with GC sawtooth | No allocations in the loop: module-scope scratch `Vector3`/`Quaternion`/`Matrix4`, reused every frame |
| Slow first interaction after load | Warm the pipeline: `renderer.compile(scene, camera)` after assets land |
| Large scene, everything drawn | Confirm frustum culling is intact (custom/instanced geometry needs a correct `boundingSphere`) |

- Vertex data changes set `attribute.needsUpdate = true` on the changed attribute only; never rebuild a geometry per frame.
- Post-processing (`EffectComposer`) doubles fill cost per pass; budget it like a feature, not a garnish.

---

## 8. Interaction and picking

- **Picking is a `Raycaster` pattern:** convert the pointer event to normalized device coordinates, `raycaster.setFromCamera(ndc, camera)`, then intersect a **curated list of pickable objects**, never a recursive walk of `scene.children` in a large scene. Resolve the hit back to the domain via the `Map` of §4.
- Distinguish drag from click by pointer travel distance, or orbiting the camera fires phantom selections.
- **Camera controls:** `OrbitControls` (damping enabled, `controls.update(dt)` in the loop) is correct for visualizations. Games write their own input mapping into entity state; controls never mutate the camera from outside the loop.
- Keyboard and pointer handlers attach to the canvas or its container, not `window`, and detach in `dispose()`.

---

## 9. WebXR: the same scene, immersive

VR/AR support is a property of a well-structured app, not a feature bolted on. The prerequisites are already this REF's rules: `setAnimationLoop` (§3), meters (§4), the framework-agnostic module (§2). What remains:

```ts
renderer.xr.enabled = true;
navigator.xr?.isSessionSupported("immersive-vr").then((ok) => {  // three/addons
    if (ok) container.appendChild(VRButton.createButton(renderer));  // mount only when a headset session exists
});
```

- **Never move the camera in XR; move a rig.** The headset owns the camera pose. Parent the camera to a `Group` (the rig/dolly) and implement locomotion (teleport, smooth motion) by moving the rig. Do this in flat mode too, so both modes share one movement code path.
- **Controllers:** `renderer.xr.getController(i)` gives a `Group` posed at each hand; `XRControllerModelFactory` (three/addons) renders the device model. `selectstart`/`selectend` events plus a ray from the controller reuse the exact §8 `Raycaster` picking.
- **Serving:** immersive sessions require a secure context. The deployed HTTPS app works as-is in a headset browser; during development, expose the dev server over HTTPS or use a desktop WebXR emulator extension.
- **Comfort is a hard requirement:** the scene renders twice per frame (one eye each) at the headset's native rate. Drop pixel ratio and shadow budget when `renderer.xr.isPresenting`; keep the frame budget with §7 tools. No camera motion the user did not initiate; prefer teleport or vignetted movement over smooth acceleration.
- **Degrade gracefully, invisibly:** gate the button on `navigator.xr.isSessionSupported('immersive-vr')` and mount it only when true. A permanently visible "VR NOT SUPPORTED" tile is UI noise; the flat experience is the default and the XR session is an enhancement of the same scene.

---

## 10. Testing

Split by what the code needs to run:

- **Pure logic is Three-free and unit-tested** (vitest): entity state machines, data-to-position mapping, camera path math. Keep it importable without a WebGL context so it runs in jsdom/node.
- **Scene structure tests** can run headless without rendering: construct the module, assert the graph (`scene.getObjectByName`), assert `renderer.info.memory` returns to baseline after `dispose()` (§6).
- **Rendering is e2e-tested in headless Chromium; WebGL works in CI on SwiftShader** with these launch flags (Playwright `launchOptions.args`):

```
--use-gl=angle
--use-angle=swiftshader
--enable-unsafe-swiftshader
--ignore-gpu-blocklist
```

- **The smoke spec asserts:** the canvas is visible with nonzero size, the page produced no console errors, and the critical asset requests returned 200. That catches a black screen, a failed shader compile, and a broken loader path, which is most of what breaks.
- **Make the first frame deterministic** (fixed camera, seeded or no randomness) if a spec ever reads pixels; prefer the structural assertions above.
- **Point the same specs at the deployed URL** via a base-URL environment override in the Playwright config, so post-deploy verification reruns the identical suite instead of a bare probe.

---

## 11. Space scenes: the celestial stack

When the scene is a universe (stars, galaxies, suns, worlds), reach for the established techniques; hand-rolled materials read as flat blobs and square dots:

- **Points need a sprite.** `PointsMaterial` without a radial-gradient canvas `map` draws hard squares. Sprite map + additive blending + `depthWrite: false`, sized small enough that flying inside the cloud stays clean. Dither every gradient texture (per-pixel alpha jitter) or additive stacking bands.
- **Output pipeline first:** `ACESFilmicToneMapping` on the renderer and an `OutputPass` closing the composer chain. Without it, bloom and color never balance and every fix fights the last one.
- **A sun is a shader, not a color.** fBm granulation with limb darkening, sunspots, and a white-hot core on the sphere; a tight chromosphere sprite; a SPIKED corona (a hundred-plus noisy radial rays, astrophoto style) and one anamorphic chromatic streak. Never the stock `Lensflare` hexagon ghosts; they read as 2005.
- **Worlds are generated cartography, with natural palettes.** Seeded 3D gradient noise sampled on the unit sphere (equirect UV sampling pinches at the poles), ridged multifractal mountains, domain warping, craters stamped into the HEIGHT FIELD so rims catch light, then hypsometric palettes per archetype (terran, desert, ice, volcanic, gas families, regolith). Never tint terrain with the app's UI colors; that is what makes planets look like fruit. Derive a Sobel normal map and a roughness map from the height field, add one shared tiling detail normal for close-ups, and generate asynchronously (one world per macrotask).
- **Light each world by its own sun.** A custom shader with the governing sun's direction as a uniform (updated as the body orbits): soft terminator, specular glint where the roughness map says sea, fresnel atmosphere in the body's accent color. A single global light rig makes every body flat.
- **Screen-filling additive glows wash the sky.** Nebulae and galaxy-bulge glows must fade with camera proximity or live outside the flight plane; inside one, the whole frame tints and no material fix will save it. Shape nebulae with fBm alpha, not radial blobs; add a milky-way band (a dense inclined star river) so the sky reads as a universe.
- **Follow orbiting subjects.** A fly-to must retarget its tween while in flight and, after arrival, translate camera, orbit target, and any reading panel by the subject's per-frame delta; otherwise the body drifts out of frame while being read.
- **Verify with pixels, not object counts.** Luma/hue snapshots and captured frames catch the washed-out scene that a "97 nodes rendered" assertion calls healthy.

---

## 12. Anti-Patterns

| # | Anti-Pattern | Correct Approach |
| - | ------------ | ---------------- |
| 1 | Three.js objects in React state/props/context | Framework-agnostic module behind one boundary component (§2) |
| 2 | `requestAnimationFrame` driving the loop | `renderer.setAnimationLoop` (§3); it is the XR-compatible loop |
| 3 | Motion by per-frame constants (`x += 0.01`) | Delta-time scaling from a single `Clock` (§3) |
| 4 | Removing objects from the scene as "cleanup" | Explicit `.dispose()` of geometry/material/texture (§6) |
| 5 | Arbitrary world units chosen per asset | Meters everywhere, Y-up (§4) |
| 6 | Allocating `Vector3`/arrays inside the frame loop | Module-scope scratch objects, reused (§7) |
| 7 | Raycasting recursively against `scene.children` | Curated pickable list resolved through the domain map (§8) |
| 8 | Moving the camera directly for locomotion | Camera rides a rig `Group`; locomotion moves the rig (§9) |
| 9 | Skipping 3D e2e because "CI has no GPU" | SwiftShader flags (§10); headless WebGL is CI-proven |
| 10 | Uncapped `devicePixelRatio` | Cap at 2 flat, lower in XR (§3, §9) |
| 11 | Domain state stored on materials/`userData` | `Map<DomainId, Object3D>` owned by the module (§4) |
| 12 | Hand-built meshes for authored content | glTF from a DCC tool; code builds only procedural geometry (§5) |

---

## 13. Cross-references

- `REF-Frontend.md` + `REF-React.md`: the host application around the canvas; TypeScript conventions.
- `REF-Tests.md`: test layering; §10 here is its 3D specialization.
- `REF-ObservableFramework.md`: when the "3D" ask is actually a chart, route there instead.
- `REF-Design.md`: visual identity (palette, typography) applies to 3D scenes and their UI chrome too.

---

## 14. Skills that instantiate this REF

Generated by `scripts/sync_backlinks.py` from skill frontmatter; do not edit by hand.

Skills whose frontmatter `refs:` includes `REF-ThreeJS`:

- `bootstrap-threejs-app` - Scaffold a new Three.js 3D app per REF-ThreeJS: Vite + TypeScript, a framework-agnostic SceneApp module (setAnimationLoop, delta-time motion, ResizeObserver resize, full dispose), OrbitControls demo content, an optional --xr variant (VRButton + camera rig, WebXR-ready), and a Playwright smoke e2e preconfigured with the CI SwiftShader flags.
