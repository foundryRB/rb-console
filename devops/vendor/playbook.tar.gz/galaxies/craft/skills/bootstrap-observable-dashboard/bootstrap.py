#!/usr/bin/env python3
"""Bootstrap an Observable Framework dashboard against an existing Data Pack.

See SKILL.md for invocation patterns. This script handles mechanical scaffolding;
the orchestrating AI confirms paths and surfaces follow-up `npm install` to the user.

Usage:
  python bootstrap.py --data-pack <pack-path> --target <dashboard-path> [--name <title>]
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

__all__ = ["main"]


# ----- templates -----

PACKAGE_JSON_TMPL = """\
{{
  "type": "module",
  "private": true,
  "scripts": {{
    "clean": "rimraf src/.observablehq/cache",
    "build": "observable build",
    "dev": "observable preview",
    "deploy": "observable deploy",
    "observable": "observable"
  }},
  "dependencies": {{
    "@observablehq/framework": "^1.13.2"
  }},
  "devDependencies": {{
    "rimraf": "^6.0.1"
  }},
  "engines": {{
    "node": ">=20.6"
  }}
}}
"""

CONFIG_JS_TMPL = """\
// Observable Framework config - {title}.
// Source of truth: TSVs in the Data Pack. Loaders in src/data/ pass them through at build time.

export default {{
  title: "{title}",
  root: "src",
  pages: [
    {{ name: "Summary", path: "/" }}
  ],
  theme: ["air", "alt"],
  header: "{title}",
  footer: "Auto-generated from the canonical Data Pack TSVs. Source of truth: the TSVs.",
  toc: false,
  pager: false,
  output: "dist",
  // On Windows, the bare `python` command hits the Microsoft Store App Execution
  // Alias and fails. The Python Launcher `py` is reliable across installs.
  // Override per-machine if `py` is unavailable on macOS/Linux.
  interpreters: {{
    ".py": ["py", "-3"]
  }}
}};
"""

GITIGNORE_TMPL = """\
node_modules/
dist/
src/.observablehq/cache/
.DS_Store
"""

README_TMPL = """\
# {title} (Dashboard)

Observable Framework dashboard reading the canonical Data Pack TSVs at
`{data_pack_display}`.

This project lives outside the Data Pack so `node_modules/` doesn't conflict with
active filesystem sync to cloud storage. See
`REF-ObservableFramework.md` §4 in the playbook for context.

## Run

```bash
npm install
npm run dev      # preview at http://localhost:3000
npm run build    # static site to dist/
```

## Architecture

- **Source of truth:** the TSVs in the Data Pack at the path above. This project never writes them.
- **Data loaders:** `src/data/*.tsv.py` are passthrough scripts Observable invokes at build/preview time. They `read_text` from the canonical path and write to stdout. Observable captures stdout as the in-build TSV. The pack path is an absolute literal at the top of each loader - search/replace if either folder moves.
- **Pages:** `src/index.md` is the entry. Add additional `.md` files under `src/` and register them in `observablehq.config.js`'s `pages` array.

## See also

- `REF-ObservableFramework.md` - the pattern this dashboard implements
- `REF-DataPack.md` - Data Pack contract the source repository follows
"""

LOADER_TMPL = '''\
#!/usr/bin/env python3
"""Observable data loader. Emits the canonical {tsv_name} at build time."""
import sys
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8")
DATA_PACK = Path(r"{data_pack}")
sys.stdout.write((DATA_PACK / "data" / "{tsv_name}").read_text(encoding="utf-8"))
'''

INDEX_MD_TMPL = """\
---
title: Summary
toc: false
---

# {title}

Source of truth: the TSVs in the Data Pack. This dashboard is a derived view, not authoritative.

```js
{loader_block}
```

```js
const num = v => Number(v) || 0;
```

<div class="grid grid-cols-{kpi_cols}" style="grid-auto-rows: 110px;">
{kpi_cards}
</div>

## Next steps

This is a scaffolded skeleton. Customise:

- Replace the per-table row-count cards above with KPIs that matter for this dataset.
- Add additional pages under `src/` and register them in `observablehq.config.js`'s `pages` array.
- Use `Plot.plot(...)` inside `<div class="card">${{resize((width) => Plot.plot({{...}}))}}</div>` for charts.
- Use `Inputs.search` / `Inputs.checkbox` / `Inputs.range` / `Inputs.toggle` declared with `view(...)` for interactive filters.

See `REF-ObservableFramework.md` §6 for page conventions and §9 for anti-patterns.
"""


# ----- helpers -----


def write_file(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")


def js_const_name(stem: str) -> str:
    """Convert a TSV stem (snake/kebab/space) to a JS-safe camel-ish identifier."""
    parts = []
    for chunk in stem.replace("-", "_").replace(" ", "_").split("_"):
        if not chunk:
            continue
        parts.append(chunk[0].lower() + chunk[1:] if parts else chunk.lower())
    name = "".join(parts) or "data"
    if name[0].isdigit():
        name = "t_" + name
    return name


def humanise(stem: str) -> str:
    """Convert a TSV stem to a Title Case label for display."""
    return " ".join(p.capitalize() for p in stem.replace("-", " ").replace("_", " ").split() if p)


def build_index_blocks(tsvs: list[str]) -> tuple[str, str, int]:
    """Return (loader_block, kpi_cards_html, num_cols)."""
    loader_lines = []
    card_lines = []
    for tsv_name in tsvs:
        stem = Path(tsv_name).stem
        var = js_const_name(stem)
        label = humanise(stem)
        loader_lines.append(
            f'const {var} = await FileAttachment("data/{tsv_name}").tsv({{typed: true}});'
        )
        card_lines.append(
            f'  <div class="card">\n'
            f'    <h2>{label}</h2>\n'
            f'    <span class="big">${{{var}.length}}</span>\n'
            f'    <div class="muted small">rows</div>\n'
            f'  </div>'
        )
    cols = min(max(len(tsvs), 1), 4)
    return "\n".join(loader_lines), "\n".join(card_lines), cols


# ----- core -----


def scaffold(data_pack: Path, target: Path, title: str) -> list[str]:
    """Scaffold the dashboard project. Returns the list of TSV names found."""
    if not data_pack.exists() or not data_pack.is_dir():
        sys.exit(f"Data Pack path does not exist or is not a directory: {data_pack}")

    data_dir = data_pack / "data"
    if not data_dir.is_dir():
        sys.exit(f"Data Pack has no data/ folder: {data_dir}")

    tsvs = sorted(p.name for p in data_dir.glob("*.tsv"))
    if not tsvs:
        sys.exit(f"Data Pack data/ has no .tsv files: {data_dir}")

    if target.exists() and any(target.iterdir()):
        sys.exit(f"target exists and is non-empty: {target}")

    # Files
    write_file(target / "package.json", PACKAGE_JSON_TMPL.format())
    write_file(target / "observablehq.config.js", CONFIG_JS_TMPL.format(title=title))
    write_file(target / ".gitignore", GITIGNORE_TMPL)
    write_file(
        target / "README.md",
        README_TMPL.format(title=title, data_pack_display=str(data_pack).replace("\\", "/")),
    )

    # Loaders
    pack_str = str(data_pack).replace("\\", "/")
    for tsv_name in tsvs:
        loader_path = target / "src" / "data" / f"{tsv_name}.py"
        write_file(loader_path, LOADER_TMPL.format(tsv_name=tsv_name, data_pack=pack_str))

    # Index page
    loader_block, kpi_cards, cols = build_index_blocks(tsvs)
    write_file(
        target / "src" / "index.md",
        INDEX_MD_TMPL.format(
            title=title,
            loader_block=loader_block,
            kpi_cards=kpi_cards,
            kpi_cols=cols,
        ),
    )

    return tsvs


# ----- CLI -----


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--data-pack", type=Path, required=True, help="path to the existing Data Pack root (containing data/*.tsv)")
    ap.add_argument("--target", type=Path, required=True, help="path where the dashboard project will be created")
    ap.add_argument("--name", type=str, default=None, help="dashboard title; defaults to Data Pack folder name")
    args = ap.parse_args()

    data_pack = args.data_pack.resolve()
    target = args.target.resolve()
    title = args.name or data_pack.name

    tsvs = scaffold(data_pack, target, title)

    print(f"Dashboard scaffolded at {target}")
    print(f"  Reading Data Pack: {data_pack}")
    print(f"  Loaders generated: {len(tsvs)} ({', '.join(tsvs)})")
    print()
    print("Next:")
    print(f"  cd {target}")
    print("  npm install")
    print("  npm run dev    # preview at http://localhost:3000")
    return 0


if __name__ == "__main__":
    sys.exit(main())
