---
name: bootstrap-observable-dashboard
description: Scaffold an Observable Framework dashboard project against an existing Data Pack. Generates a sibling project (outside the pack) with package.json, observablehq.config.js (Windows-safe Python interpreter override + UTF-8 loaders), one passthrough data loader per TSV in the pack, an index.md skeleton with KPI cards, and README. Caller runs `npm install && npm run dev` to verify.
galaxy: craft
refs:
  - REF-ObservableFramework
  - REF-DataPack
  - REF-CSD
---

# Bootstrap Observable Dashboard

Invoked when the user wants to add an interactive dashboard on top of an existing Data Pack. The Data Pack stays canonical; this skill produces a separate dashboard project that reads the pack's TSVs read-only. See `REF-ObservableFramework.md` for the pattern.

## Pre-flight

1. **Read** `REF-ObservableFramework.md` (full), `REF-DataPack.md` §7 (Views).
2. **Confirm Data Pack location** - the existing Data Pack the dashboard will read. Must contain `data/*.tsv` files.
3. **Confirm dashboard project location** - a sibling directory, *outside* any cloud-synced storage. If the Data Pack lives on a folder that's actively mirrored to a cloud service, the dashboard project MUST go elsewhere (REF §4 - `npm install` doesn't survive active sync).
4. **Verify Node.js available** - Observable Framework requires Node 20.6+. Surface to user if missing.
5. **Verify Python Launcher (`py`) available on Windows** - needed for `.py` data loaders to run. The fallback `python` hits the Microsoft Store alias and fails. On macOS/Linux, `py` may not be present and the user can edit the config to use `python3`.

## What it produces

```
<dashboard-target>/
├── package.json           # @observablehq/framework, npm scripts
├── observablehq.config.js # title, pages array, theme, .py interpreter override
├── README.md              # how to run; pointer to source Data Pack
├── .gitignore             # node_modules, dist, .observablehq/cache
└── src/
    ├── index.md           # placeholder summary page with KPI grid + counts per TSV
    └── data/
        └── <table>.tsv.py # one passthrough loader per TSV in the source pack
```

Caller next runs:

```bash
cd <dashboard-target>
npm install
npm run dev    # http://localhost:3000
npm run build  # static dist/
```

## Steps

1. **Run the scaffolder** (Python helper at `<this-skill>/bootstrap.py`):
   ```bash
   python bootstrap.py --data-pack <path-to-data-pack> --target <path-to-dashboard-project> [--name <site-title>]
   ```

   Arguments:
   - `--data-pack` (required) - absolute path to the existing Data Pack root (the folder containing `data/*.tsv`).
   - `--target` (required) - absolute path to the new dashboard project. Must not exist or be empty.
   - `--name` (optional) - site title shown in the dashboard header. Defaults to the Data Pack folder's name.

2. **Surface to user**:
   - Confirm the dashboard project was scaffolded.
   - Tell them: `cd <target> && npm install && npm run dev`.
   - Note that the loaders embed the Data Pack path as a literal - moving either folder breaks the build until the loaders are edited.

## Path-handling decision

The generated data loaders use **option 2 from REF §5** - an absolute path constant at the top of each loader, set to the Data Pack location resolved at scaffold time:

```python
DATA_PACK = Path(r"<absolute-path-to-pack>")
```

This is the right default for a single-user, single-machine setup. If the user later wants to share the dashboard or run it on another machine, REF §5 documents the env-var approach for that case - the migration is mechanical (search/replace one constant per loader).

## Failure modes

- **Target exists and is non-empty** - surface; don't overwrite.
- **Data Pack has no `data/` folder or no `*.tsv` files** - surface; this skill needs TSVs to scaffold loaders against. Suggest creating the pack first via `bootstrap-data-pack`.
- **Both Data Pack and target appear to be inside the same cloud-sync surface** - surface a warning during pre-flight. The dashboard's `node_modules/` will likely break consumer cloud-storage sync clients (REF §4). Detection is heuristic; don't try to be exhaustive - push the responsibility to the user via the pre-flight confirmation.
- **Node not available** - surface; can't validate the scaffold.

## Anti-patterns

- ❌ Nesting the dashboard inside `<pack>/views/dashboard/` when the pack is on cloud-synced storage. Use a sibling outside the sync surface (REF §4).
- ❌ Materialising the TSVs to SQLite / DuckDB / JSON as the dashboard's data layer. The pass-through loader is the only correct choice (REF §2, §9).
- ❌ Generating a dashboard that recomputes values already living in canonical Data Pack columns. The dashboard reads `Effective*` etc. and trusts the intent layer (REF §6, §9).
- ❌ Running `npm install` from this skill. The user runs it; the skill produces files only. `npm install` is heavy, machine-specific, and may interact with cloud sync - surfacing it as a separate manual step keeps the failure mode visible.

## See also

- `REF-ObservableFramework.md` - the pattern this skill instantiates
- `REF-DataPack.md` - Data Pack contract
- `bootstrap-data-pack` - sister skill for creating the source Data Pack itself
