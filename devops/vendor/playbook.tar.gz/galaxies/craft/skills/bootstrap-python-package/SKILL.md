---
name: bootstrap-python-package
description: Scaffold a new publishable-quality Python package conforming to REF-Python-Package. Produces full structural minimum (pyproject, LICENSE, CHANGELOG, README skeleton, CI, ruff/mypy configs, tests dir, examples dir, src layout with __version__ and py.typed marker).
galaxy: craft
refs:
  - REF-Python-Package
  - REF-Python
  - REF-Tests
  - REF-Documentation
---

# Bootstrap Python Package

Invoked when a new Python package needs to be created at publishable quality from day one.

## Pre-flight

1. **Read** `REF-Python-Package.md` - section by section is what this skill produces.
2. **Confirm with user**:
   - Package name (PyPI-style, kebab-case): e.g. `my-thing`
   - Module name (Python identifier, snake_case): e.g. `my_thing` (default = package name with `-` → `_`)
   - One-sentence description
   - Author name (and optionally email)
   - License (default MIT)
   - Initial version (default 0.1.0)
   - Python floor (default 3.10)
   - Is it a pytest plugin? (default no)
3. **Confirm target path** - where the package folder is created.

## Steps

Run the Python helper at `<this-skill>/bootstrap.py`:

```bash
python bootstrap.py \
  --target <parent-dir> \
  --package-name <name> \
  --module-name <module> \
  --description "<one sentence>" \
  --author "<name>" \
  [--email "<email>"] \
  [--license MIT] \
  [--python-floor 3.10] \
  [--pytest-plugin]
```

Generates:

```
<target>/<package-name>/
├── pyproject.toml              # full metadata, dev deps, classifiers, optional pytest11 entry
├── LICENSE                     # MIT (or other) with year + author
├── README.md                   # template with sections from REF-Python-Package §10
├── CHANGELOG.md                # Keep-a-Changelog, [Unreleased] + [0.1.0] stub
├── ruff.toml                   # standard rule set
├── mypy.ini                    # disallow_untyped_defs etc.
├── .github/workflows/test.yml  # matrix CI (Python 3.10/3.11/3.12/3.13) with ruff + mypy + pytest
├── .gitignore                  # standard Python ignores
├── <module_name>/
│   ├── __init__.py             # __version__ via importlib.metadata (single source of truth = pyproject)
│   ├── errors.py               # base domain exception per REF §5
│   ├── py.typed                # empty marker (PEP 561)
│   └── plugin.py               # only if --pytest-plugin
├── tests/
│   ├── __init__.py
│   └── test_smoke.py           # one trivial test confirming pytest discovers
└── examples/
    └── README.md               # placeholder - encourages adding realistic examples
```

After scaffolding, the user should:

```bash
cd <target>/<package-name>
pip install -e ".[dev]"
pytest tests/  # smoke test should pass
```

## Failure modes

- **Target exists and is non-empty** → confirm overwrite vs cancel; default cancel.
- **Module name not a valid Python identifier** → reject with clear error.
- **License other than MIT** → emit a placeholder LICENSE noting "fill in" + warn user; only MIT shipped pre-baked.

## Anti-patterns to avoid in scaffolding

- Generating `requirements.txt` (use pyproject `dependencies` per REF-Python-Package §3 anti-pattern #10).
- Generating `setup.py` (use `pyproject.toml` only).
- Empty CHANGELOG.md (always seed `[Unreleased]` + `[0.1.0]`).
- Missing `py.typed` marker (PEP 561 - required for type-aware consumers).
- Examples directory with no README explaining what to put there.

## See also

- `REF-Python-Package.md` - the quality bar this skill implements
- `bootstrap-pytest-intent` skill - for adding intent-testing to an existing project (different concern; this skill scaffolds the package itself)
