#!/usr/bin/env python3
"""Scaffold a new publishable-quality Python package conforming to REF-Python-Package.

See SKILL.md for inputs and the file layout produced. Idempotent only at the directory
level - refuses to overwrite an existing non-empty target.
"""

from __future__ import annotations

import argparse
import sys
from datetime import date
from pathlib import Path


# ----- file templates -----

PYPROJECT_TMPL = """\
[build-system]
requires = ["setuptools>=61.0"]
build-backend = "setuptools.build_meta"

[project]
name = "{package_name}"
version = "{version}"
description = "{description}"
readme = "README.md"
requires-python = ">={python_floor}"
license = {{text = "{license}"}}
authors = [
    {{name = "{author}"{author_email_part}}},
]
keywords = []
classifiers = [
    "Development Status :: 3 - Alpha",
    "Intended Audience :: Developers",
    "License :: OSI Approved :: MIT License",
    "Operating System :: OS Independent",
    "Programming Language :: Python :: 3",
    "Programming Language :: Python :: 3.10",
    "Programming Language :: Python :: 3.11",
    "Programming Language :: Python :: 3.12",
    "Programming Language :: Python :: 3.13",{plugin_classifier}
]
dependencies = []

[project.optional-dependencies]
dev = [
    "pytest>=7.0",
    "ruff>=0.1.0",
    "mypy>=1.0",
]

[project.urls]
Homepage = "https://github.com/<owner>/{package_name}"
Repository = "https://github.com/<owner>/{package_name}"
Issues = "https://github.com/<owner>/{package_name}/issues"
{pytest_plugin_entry}
[tool.setuptools.packages.find]
where = ["."]
include = ["{module_name}*"]
exclude = ["tests*", "examples*"]
"""

PYTEST_PLUGIN_ENTRY_TMPL = """\

[project.entry-points."pytest11"]
{module_name} = "{module_name}.plugin"
"""

LICENSE_MIT_TMPL = """\
MIT License

Copyright (c) {year} {author}

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
"""

README_TMPL = """\
# {package_name}

{description}

## What this package IS

- (fill in capabilities - bullet list)

## What this package is NOT

- (explicit non-goals, prevents misuse)

## Hidden assumptions

- Python >= {python_floor}
- (other runtime / fixture / OS requirements)

## Install

```bash
pip install {package_name}
# or for local development:
pip install -e .
```

## Usage

```python
# minimal end-to-end example here
```

## Roadmap

See `CHANGELOG.md` for shipped changes and planned work.
"""

CHANGELOG_TMPL = """\
# Changelog

All notable changes to {package_name} are documented here. Format follows [Keep a Changelog](https://keepachangelog.com/), versioning follows [SemVer](https://semver.org/).

## [Unreleased]

(planned changes go here)

## [{version}] - {today}

### Added

- Initial release.
"""

RUFF_TMPL = """\
target-version = "py{python_floor_short}"
line-length = 120

[lint]
select = [
    "E",    # pycodestyle errors
    "F",    # pyflakes
    "I",    # isort
    "B",    # flake8-bugbear
    "UP",   # pyupgrade
    "RUF",  # ruff-specific
]
ignore = [
    "E501",  # line-length handled by formatter
]

[lint.per-file-ignores]
"tests/*" = ["B011"]
"""

MYPY_TMPL = """\
[mypy]
python_version = {python_floor}
disallow_untyped_defs = True
warn_unused_ignores = True
warn_redundant_casts = True
warn_unreachable = True
no_implicit_optional = True
check_untyped_defs = True
"""

CI_TMPL = """\
name: tests

on:
  push:
    branches: [main]
  pull_request:
    branches: [main]

jobs:
  test:
    runs-on: ubuntu-latest
    strategy:
      matrix:
        python-version: ["3.10", "3.11", "3.12", "3.13"]

    steps:
      - uses: actions/checkout@v4

      - name: Set up Python ${{{{ matrix.python-version }}}}
        uses: actions/setup-python@v5
        with:
          python-version: ${{{{ matrix.python-version }}}}

      - name: Install package + dev deps
        run: |
          python -m pip install --upgrade pip
          pip install -e ".[dev]"

      - name: Lint (ruff)
        run: ruff check {module_name} tests

      - name: Type-check (mypy)
        run: mypy {module_name}

      - name: Run tests
        run: pytest tests/ -v
"""

GITIGNORE_TMPL = """\
__pycache__/
*.pyc
*.pyo
*.egg-info/
.pytest_cache/
.mypy_cache/
.ruff_cache/
build/
dist/
.venv/
venv/
.env
"""

INIT_TMPL = '''\
"""{description}"""

from __future__ import annotations

from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("{package_name}")
except PackageNotFoundError:
    __version__ = "0.0.0+unknown"

__all__: list[str] = ["__version__"]
'''

ERRORS_TMPL = '''\
"""Domain exceptions for {package_name}.

Define a base exception per package; raise specific subclasses. Avoids tying
callers to bare `Exception` / `RuntimeError` and lets them catch package errors
without catching unrelated bugs.
"""

from __future__ import annotations


class {error_class}(Exception):
    """Base exception for {package_name}."""


__all__ = ["{error_class}"]
'''

PLUGIN_TMPL = '''\
"""Pytest plugin entry point.

Auto-registered via the `pytest11` entry point in pyproject.toml. Override fixtures /
add hooks here. Pytest does not auto-collect tests from plugins - only fixtures and hooks.
"""

from __future__ import annotations
'''

TESTS_INIT = ""

SMOKE_TEST_TMPL = """\
\"\"\"Smoke test confirming pytest discovery + package import.\"\"\"

from __future__ import annotations


def test_package_imports() -> None:
    import {module_name}
    assert hasattr({module_name}, "__version__")
"""

EXAMPLES_README_TMPL = """\
# Examples

Add at least one realistic end-to-end example here. Each example should:

- Live in its own subdirectory: `examples/<example-name>/`
- Have its own README.md explaining what it demonstrates
- Be runnable as-is (no extra setup beyond `pip install -e ../..`)
- Cover a distinct use case (don't duplicate)

See REF-Python-Package §10 (README) - examples are part of the documentation surface.
"""


# ----- helpers -----


def write_file(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")
    print(f"  WRITE: {path}")


def is_valid_module_name(name: str) -> bool:
    return name.isidentifier() and not name.startswith("_")


def _error_class_name(module_name: str) -> str:
    """Convert snake_case module name to PascalCase + Error suffix.

    e.g. my_thing -> MyThingError
    """
    return "".join(part.capitalize() for part in module_name.split("_")) + "Error"


# ----- main -----


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--target", type=Path, required=True, help="parent dir under which the package folder is created")
    ap.add_argument("--package-name", required=True, help="PyPI-style package name (kebab-case)")
    ap.add_argument("--module-name", default=None, help="Python identifier (defaults to package name with - replaced by _)")
    ap.add_argument("--description", required=True)
    ap.add_argument("--author", required=True)
    ap.add_argument("--email", default=None)
    ap.add_argument("--license", default="MIT")
    ap.add_argument("--version", default="0.1.0")
    ap.add_argument("--python-floor", default="3.10")
    ap.add_argument("--pytest-plugin", action="store_true")
    args = ap.parse_args()

    module_name = args.module_name or args.package_name.replace("-", "_")
    if not is_valid_module_name(module_name):
        print(f"invalid module name: {module_name!r}", file=sys.stderr)
        return 2

    if args.license != "MIT":
        print(f"WARNING: only MIT license is shipped pre-baked; LICENSE will be a placeholder for {args.license}", file=sys.stderr)

    target = args.target / args.package_name
    if target.exists() and any(target.iterdir()):
        print(f"target exists and is non-empty: {target}", file=sys.stderr)
        return 2

    today = date.today().isoformat()
    year = date.today().year
    python_floor_short = args.python_floor.replace(".", "")
    author_email_part = f', email = "{args.email}"' if args.email else ""

    plugin_classifier = '\n    "Framework :: Pytest",' if args.pytest_plugin else ""
    pytest_plugin_entry = PYTEST_PLUGIN_ENTRY_TMPL.format(module_name=module_name) if args.pytest_plugin else "\n"

    print(f"Scaffolding {args.package_name} (module: {module_name}) at {target}")
    write_file(target / "pyproject.toml", PYPROJECT_TMPL.format(
        package_name=args.package_name,
        module_name=module_name,
        version=args.version,
        description=args.description,
        python_floor=args.python_floor,
        license=args.license,
        author=args.author,
        author_email_part=author_email_part,
        plugin_classifier=plugin_classifier,
        pytest_plugin_entry=pytest_plugin_entry,
    ))
    write_file(target / "LICENSE", LICENSE_MIT_TMPL.format(year=year, author=args.author) if args.license == "MIT" else f"PLACEHOLDER - fill in {args.license} terms\n")
    write_file(target / "README.md", README_TMPL.format(
        package_name=args.package_name,
        description=args.description,
        python_floor=args.python_floor,
    ))
    write_file(target / "CHANGELOG.md", CHANGELOG_TMPL.format(
        package_name=args.package_name,
        version=args.version,
        today=today,
    ))
    write_file(target / "ruff.toml", RUFF_TMPL.format(python_floor_short=python_floor_short))
    write_file(target / "mypy.ini", MYPY_TMPL.format(python_floor=args.python_floor))
    write_file(target / ".github" / "workflows" / "test.yml", CI_TMPL.format(module_name=module_name))
    write_file(target / ".gitignore", GITIGNORE_TMPL)
    write_file(target / module_name / "__init__.py", INIT_TMPL.format(description=args.description, package_name=args.package_name))
    write_file(target / module_name / "errors.py", ERRORS_TMPL.format(package_name=args.package_name, error_class=_error_class_name(module_name)))
    write_file(target / module_name / "py.typed", "")
    if args.pytest_plugin:
        write_file(target / module_name / "plugin.py", PLUGIN_TMPL)
    write_file(target / "tests" / "__init__.py", TESTS_INIT)
    write_file(target / "tests" / "test_smoke.py", SMOKE_TEST_TMPL.format(module_name=module_name))
    write_file(target / "examples" / "README.md", EXAMPLES_README_TMPL)

    print()
    print("Next steps:")
    print(f"  cd {target}")
    print("  pip install -e .[dev]")
    print("  pytest tests/")
    print(f"  ruff check {module_name} tests")
    print(f"  mypy {module_name}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
