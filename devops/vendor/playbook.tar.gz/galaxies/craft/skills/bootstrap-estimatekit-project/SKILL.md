---
name: bootstrap-estimatekit-project
description: "Create a new estimation project in a running estimatekit instance, then fill it from an engagement brief. The deterministic step scaffolds the project (a complete example whose sentinel-marked values the audit refuses until authored) over the instance API. Then AI authors the requirement, activity, assumption, architecture and per-phase pitch data from the brief, re-audits until clean, triggers generation (roadmap, Excel workbooks, the slide deck for the phase being sold), and hands back the deck URL and the workbook downloads. For the proposal phase, before a delivery exists."
galaxy: craft
refs:
  - REF-Estimation
---

# Bootstrap estimatekit project

Invoked when starting a project-estimation engagement: stand up a filled, audited, generated estimation project in a running estimatekit instance from a brief. The deterministic script scaffolds the project; AI authors the data against the model and conventions the instance's own guide states and the practice of `REF-Estimation.md`, then drives the audit-generate loop over the instance API.

The output is a living data set: the project stays on the instance and is re-edited and regenerated as the engagement's numbers move.

## Pre-flight

1. **Read** `REF-Estimation.md` for the estimating practice, and the instance's own guide (the estimatekit door serves it) for the data model, the files and their header rows, the audit, and the operations.
2. **Confirm a reachable instance** - the base URL of a running estimatekit (configured per environment; defaults to a local instance). Verify with `python bootstrap.py --dry-run --slug <slug> [--base-url <url>]`, which checks reachability and creates nothing. Instances fail closed on HTTP Basic auth: set `ESTIMATEKIT_AUTH_USER` and `ESTIMATEKIT_AUTH_PASSWORD` in the environment first (or `--base-url` a local instance running with auth disabled).
3. **Collect the brief from the user**:
   - The project slug (lowercase alphanumeric with dashes) and the client / engagement name.
   - The customer requirements: a BRD, a requirements list, or prose to derive one from.
   - The intended phasing (how many phases, what splits them) and team shape (streams, profiles, day rates) if known; otherwise propose them from the brief and confirm.
   - Known assumptions and risks, if any.
4. **Confirm Python is available** - the scaffolder uses only the standard library.

## What it produces

The deterministic script creates one project on the instance (persisted server-side):

```
<estimatekit instance>
└── project <slug>
    ├── project.yaml          (identity + branding, personalised from the slug)
    ├── data/                 (complete example data, every example value sentinel-marked)
    └── output/               (empty until generation)
```

It prints the slug, the summary, and the API paths for the next steps. AI then replaces the example data with the engagement's; that is not the script's job. The example is internally consistent, but the audit fails while any scaffold sentinel (`[EXAMPLE]`, `[PROJECT NAME]`, `[Client Name]`) remains - the sentinel failures are the authoring to-do list, and nothing scaffolded can ship.

## Steps

1. **Verify reachability** (and dry-run the inputs):
   ```bash
   python bootstrap.py --dry-run --slug <slug> [--base-url <url>]
   ```
2. **Scaffold the project** (Python helper at `<this-skill>/bootstrap.py`):
   ```bash
   python bootstrap.py --slug <slug> [--base-url <url>] [--force]
   ```
   Scaffolding an existing slug fails with a conflict unless `--force` is given; `--force` overwrites the example files but keeps files the templates do not provide. **Never `--force` over a populated project you did not just scaffold.** A filled project at an existing slug is very likely a prior delivery line's **frozen legacy estimate**, and forcing over it destroys the delivered line's record. For a follow-on or next-phase engagement the answer is **additive, not overwrite**: mint a **new phase** (the instance's phase mint, which adds its row to `02-phases.tsv`, its column to `03-matrix.tsv` and its sentinel-marked file set, leaving every prior phase intact), never a second project - one repo has exactly one, named for the repo. `--force` is only for re-copying the example scaffold over a project you own and are re-doing.
3. **Load the conventions** - ensure the instance's guide and `REF-Estimation.md` are in context.
4. **Update the identity** - read `project.yaml`, set the real name, client, description, and date, and write it back.
5. **Author the requirements first** - derive `data/requirements/01-brd.tsv` from the brief (categorized, stable requirement IDs), define the phases, assign requirements to phases in `03-matrix.tsv`. Read each scaffolded file before writing and keep its header row byte-identical (the estimatekit door's doctrine). The scaffold's two phases are example shape, not a default - define exactly the phases the engagement needs: mint any further phase, whose row and files arrive sentinel-marked and whose matrix column arrives empty, for you to mark the requirements the phase carries, and delete the `P<n>-*` files of phases you drop.
6. **Size the work per phase** - build activities referencing requirement IDs with effort in MD (`P<n>-build.tsv`), project-level activities, the resource plan with streams, profiles, rates, and monthly capacity, and the config parameters. Capacity must cover effort per stream or the audit fails.
7. **Record the assumptions** - with confidence and impact values from the project's defined scales, linked to requirement IDs.
8. **Author the architecture per phase** - the component inventory (`data/architecture/P<n>-components.tsv`), an overview diagram (`P<n>-overview.puml`) that depicts every component in that inventory, and the guidelines (`00-guidelines.tsv`), each row naming the phases it governs, or all of them for a principle of the platform. The audit's architecture checks require the per-phase pair for every defined phase, cross-check the diagram against the inventory, and hold the guidelines to defined phases with at least one governing each phase; the phase sweep refuses files of undefined phases - the scaffolded example diagram cannot ship.
9. **Author each phase's pitch** - `data/slides/P<n>-executive-summary.tsv` (context, rationale, highlights; the audit requires it with a context description) and `data/slides/P<n>-notes.tsv` (that phase's slide notes: on-slide notes, footer notes and speaker notes; optional). `project.yaml`'s description stays programme-level: it renders on the title slide of every phase's deck, under which the phase's own name and description appear.
10. **Audit after every editing pass** (`REF-Estimation.md` §7). Fix failures before continuing; do not batch the whole engagement between audits. Loop until the report says `passed: true`.
11. **Generate** the artifacts, naming the phase the deck sells. A single-phase project may name none; a project with several phases answers 422 listing them when the request names none.
12. **Surface to the user** - the deck's URL (the phase named at generation), the outputs listing, and the download links for the workbooks. Note that the project stays live on the instance for the next editing pass.

## Failure modes

- **Instance not reachable** - the script reports it and exits non-zero. Start estimatekit or correct the base URL; do not proceed.
- **401 from the instance** - auth is enabled (the deployed default): set `ESTIMATEKIT_AUTH_USER` and `ESTIMATEKIT_AUTH_PASSWORD`.
- **503 from the instance** - the instance itself has no credentials configured (it fails closed). Fix the deployment; this is not a client-side problem.
- **Scaffold conflict (409)** - the slug already exists. If it holds a prior delivery line's estimate, do **not** `--force` (it destroys a frozen legacy artifact): mint a new phase in that same project (additive), never a second project for the same repo. Use `--force` only to re-copy the example scaffold over a project you own and are re-doing (existing extra files survive).
- **Invalid slug (400)** - slugs are lowercase alphanumeric with dashes; the server validates and rejects anything else, including path separators.
- **Mint conflict (409)** - the phase id already has files. Mint the next free `P<n>`; never pass `force` over a phase you did not just mint, since it overwrites that phase's authored files with the example set.
- **Invalid phase id (400) from the mint** - phase ids are `P<n>` (`P3`, `P12`).
- **422 from generate listing the phases** - the project defines several phases and the body named none; pass `phase` with the one the deck sells.
- **422 from generate naming an unknown phase** - the body names a phase the phase table does not define; use one of the ids it lists.
- **422 from generate naming `P<n>-executive-summary.tsv`** - the phase being sold has no pitch yet; author it (step 9) and generate again.
- **Audit failures after authoring** - expected during the loop. Read each failing check's category and message (the instance's guide states what each category checks), fix the data file it points at, re-audit. Never generate-and-deliver over a failing audit.
- **Scaffold-sentinel failures late in the loop** - a `scaffold` category failure lists `file:line` for every `[EXAMPLE]` / `[PROJECT NAME]` / `[Client Name]` still on disk: example content you never authored. Author it for the engagement or delete the file (a dropped phase's files included); never strip the sentinel while keeping the example content, since the sentinel is the only machine-visible mark that the value is not the engagement's.
- **Generate reports a failed pipeline** - the response maps each pipeline to a boolean. A false usually means a data shape the writers cannot render; re-run the audit first, then inspect the failing pipeline's inputs.

## See also

- `REF-Estimation.md` - the estimating practice this skill applies; the estimatekit door's guide states the model and conventions it drives against.
- the protopane door - the sibling design-phase tool, driven in the same pattern (scaffold deterministically, author with AI) by `bootstrap-protopane-project`.
- the estimatekit project's `README.md` - how to run an instance.
