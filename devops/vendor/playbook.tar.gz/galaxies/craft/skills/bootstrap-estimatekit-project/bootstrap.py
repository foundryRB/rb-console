#!/usr/bin/env python3
"""Scaffold a new estimation project in a running estimatekit instance.

Deterministic scaffold step for the bootstrap-estimatekit-project skill: POST a
new project to the instance API, which copies the built-in example templates
(a complete data set whose sentinel-marked values the audit refuses until
authored). Prints the slug, the
project summary, and the API paths for the authoring loop. AI then replaces the
example data with the engagement's (see SKILL.md and REF-Estimation.md).

Scaffolding an existing slug fails with a conflict unless --force is given. Use
--dry-run to validate inputs and check reachability without creating anything.

Usage:
  python bootstrap.py --slug <slug> [--base-url <url>] [--force] [--dry-run]

The base URL defaults to the ESTIMATEKIT_BASE_URL environment variable, then to
a local instance. It is never hardcoded into shared content. Instances fail
closed on HTTP Basic auth: set ESTIMATEKIT_AUTH_USER and
ESTIMATEKIT_AUTH_PASSWORD for a secured instance.
"""

from __future__ import annotations

import argparse
import base64
import json
import os
import re
import sys
import urllib.error
import urllib.request

DEFAULT_BASE_URL = os.environ.get("ESTIMATEKIT_BASE_URL", "http://localhost:8000")
SLUG_RE = re.compile(r"^[a-z0-9][a-z0-9-]{0,63}$")


def request_json(method: str, url: str, body: dict | None = None) -> dict:
    """Send a JSON request and parse the JSON response (empty body tolerated).

    Sends HTTP Basic auth when ESTIMATEKIT_AUTH_USER and
    ESTIMATEKIT_AUTH_PASSWORD are set, so the scaffolder works against a
    secured instance (the deployed default: estimatekit fails closed).
    """
    data = json.dumps(body).encode("utf-8") if body is not None else None
    headers = {"Content-Type": "application/json"} if body is not None else {}
    # Edge WAFs (e.g. Cloudflare bot rules) reject Python's default
    # urllib User-Agent with 403, so every request names itself.
    headers["User-Agent"] = "estimatekit-bootstrap/1.0"
    user = os.environ.get("ESTIMATEKIT_AUTH_USER")
    password = os.environ.get("ESTIMATEKIT_AUTH_PASSWORD")
    if user and password:
        token = base64.b64encode(f"{user}:{password}".encode()).decode()
        headers["Authorization"] = f"Basic {token}"
    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    with urllib.request.urlopen(req, timeout=60) as resp:
        raw = resp.read().decode("utf-8")
    return json.loads(raw) if raw else {}


def main() -> int:
    ap = argparse.ArgumentParser(description="Scaffold an estimatekit estimation project.")
    ap.add_argument("--slug", required=True, help="Project slug (lowercase alphanumeric + dashes)")
    ap.add_argument(
        "--base-url",
        default=DEFAULT_BASE_URL,
        help="estimatekit instance base URL (or set ESTIMATEKIT_BASE_URL)",
    )
    ap.add_argument(
        "--force",
        action="store_true",
        help="Re-copy the example templates over an existing project with this slug",
    )
    ap.add_argument(
        "--dry-run",
        action="store_true",
        help="Validate inputs and instance reachability; create nothing",
    )
    args = ap.parse_args()

    base = args.base_url.rstrip("/")
    slug = args.slug.strip()
    if not SLUG_RE.match(slug):
        print(f"slug must be lowercase alphanumeric with dashes, got: {slug!r}", file=sys.stderr)
        return 2

    # Reachability check (authenticated). This is also the whole of --dry-run.
    try:
        existing = request_json("GET", f"{base}/api/projects/")
    except urllib.error.HTTPError as exc:
        if exc.code == 401:
            print(
                f"{base} requires auth. Set ESTIMATEKIT_AUTH_USER and ESTIMATEKIT_AUTH_PASSWORD.",
                file=sys.stderr,
            )
        elif exc.code == 503:
            print(
                f"{base} has no credentials configured and fails closed (503). "
                "Fix the deployment before scaffolding.",
                file=sys.stderr,
            )
        else:
            print(
                f"cannot reach estimatekit at {base}: HTTP {exc.code} {exc.reason}",
                file=sys.stderr,
            )
        return 2
    except urllib.error.URLError as exc:
        print(f"cannot reach estimatekit at {base} ({exc}). Is the instance running?", file=sys.stderr)
        return 2

    taken = slug in existing.get("projects", [])
    if args.dry_run:
        state = "EXISTS (needs --force)" if taken and not args.force else "available"
        print(f"OK: {base} reachable. Slug '{slug}': {state}.")
        return 0

    # Scaffold the project from the instance's built-in templates.
    try:
        created = request_json(
            "POST", f"{base}/api/projects/scaffold", {"slug": slug, "force": args.force}
        )
    except urllib.error.HTTPError as exc:
        if exc.code == 409:
            print(
                f"project '{slug}' already exists. Pick another slug, or pass --force "
                "to re-copy the example templates over it.",
                file=sys.stderr,
            )
        elif exc.code == 400:
            print(f"the server rejected the slug '{slug}' as invalid.", file=sys.stderr)
        else:
            print(f"scaffold failed: HTTP {exc.code} {exc.reason}", file=sys.stderr)
        return 2

    summary = request_json("GET", f"{base}/api/projects/{slug}/summary")
    print(f"Scaffolded project '{slug}' at {created.get('path', '(server-side)')}.")
    print(
        f"Summary: {summary.get('name', '?')} for {summary.get('client', '?')} - "
        f"{summary.get('phase_count', '?')} phase(s), "
        f"{summary.get('requirement_count', '?')} requirement(s)."
    )
    print()
    print("Next steps (AI authors the data, per the instance's guide and REF-Estimation.md):")
    print(f"  1. List the data files:     GET  {base}/api/projects/{slug}/files")
    print(f"  2. Read, then rewrite each: GET/PUT {base}/api/projects/{slug}/files/<path>")
    print("     (keep every TSV header row byte-identical; requirements first)")
    print(f"  3. Audit until clean:       POST {base}/api/projects/{slug}/audit")
    print(
        f"  4. Generate the artifacts:  POST {base}/api/projects/{slug}/generate"
        '  (body {"phase": "P<n>"}, the phase the deck sells)'
    )
    print(f"  5. Review the deck:         {base}/projects/{slug}/slides/")
    return 0


if __name__ == "__main__":
    sys.exit(main())
