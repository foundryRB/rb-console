---
name: bootstrap-account-spine-python
description: "Add the account spine to an existing Python hexagonal FastAPI backend per REF-Identity: an opaque non-derived user id, an accounts table carrying the federation link, digest-only sessions, one session-resolution choke point, a guess budget, and the credential rung named explicitly with --rung (no default, because a scaffold that picks the rung is advocacy with a code generator attached). Ships the guest + recovery-code rung; other rungs route to REF-Identity section 2."
galaxy: craft
refs:
  - REF-Identity
  - REF-CleanArchitecture
  - REF-FastAPI
  - REF-Python
  - REF-Tests
---

# Bootstrap account spine (Python)

Additive to an existing hexagonal FastAPI service. It writes the parts of an
identity that are the same whichever credential you chose, and the credential
module for the one you name.

## Pre-flight

1. **Choose the rung first, with `REF-Identity.md` section 2.** Recovery decides
   it, not stakes: for accounts that were never identity-proofed the conforming
   recovery set is closed to three, and "is there an email to recover against"
   and "does an operator exist" eliminate rungs outright. This script will not
   choose for you and has no default.
2. **Check the rung this generator emits covers your answer.** It emits
   `guest-recovery-code`. If section 2 routed you to a password, an IdP, magic
   link or passkeys, stop: that rung needs its own credential module, because
   the hashing differs by the credential's entropy and the routes differ by what
   the player presents. For OIDC, use the chosen identity provider's integration guide.
3. **Confirm the host is a hexagonal backend** with `domain/`, `application/`
   and `adapters/` under one package. The spine expects
   `<package>/domain/exceptions/app_error.py` and `<package>/logging.py` to
   exist; it refuses rather than emitting second copies of either.
4. **Read** `REF-Identity.md` sections 4 and 5 before reviewing the output: the
   generated code makes two choices that look wrong to anyone who has not read
   them (a fast digest rather than a KDF, and two columns nothing reads yet).

## Steps

1. **Generate**, from this skill's folder:

   ```sh
   python bootstrap.py --package <package> --rung guest-recovery-code --target <backend-dir>
   ```

   It writes the domain credential module and account entity, the two domain
   exceptions, the outbound port, the account service, the guess budget, the
   in-memory and Postgres repositories, the DTOs, and the router. It refuses to
   overwrite; pass `--force` only when you mean to.

2. **Wire the composition root.** Build the repository the same way the project
   selects its other backends (a DSN present means Postgres, absent means
   in-memory), construct `AccountService` and one `GuessBudget`, expose both as
   container accessors, and `await` the repository's `connect()` at startup so
   its schema is applied. Mount the router under the project's API prefix. Pass
   the application's own session lifetime to `AccountService`; the default is a
   floor, not a recommendation, and the stakes axis is what sets it
   (`REF-Identity.md` section 2).

3. **`AccountService.sweep()` is on offer, not owed.** It deletes guests whose
   sessions have all expired, which are unreachable by construction because a
   guest holds no credential but its session token. That makes it safe to run,
   and it bounds a table anyone can add rows to without a credential.

   It is still a background job, with a schedule and a grace window to own, so
   it is earned by a table that is actually growing rather than by one that
   might (craft violation #4, Gall's Law). Ship without it, watch the row
   count, and wire it on a repeating task when the count says so. Nothing else
   in the spine depends on it. Deleting the method is a fine answer too.

4. **Route every private surface through `resolve_session`.** That function is
   the choke point the whole model rests on. A handler that reads an identity
   from a body, a path, or a proxy header is the defect this spine exists to
   prevent, and it will pass every test that does not look for it.

5. **Attribute what the account owns.** Anywhere the app records something under
   a name a caller supplied, take the name from the resolved account instead and
   ignore the body's. Leaving the body trusted turns an anonymous write surface
   into an attribution-forgery one the moment accounts exist.

6. **Record the decision in an ADR**, in the same change. State the rung, the
   recovery rung beside it, and what is lost when an account is taken. An ADR
   that lands after the decision it records goes stale immediately.

7. **Run the gates**: the project's test suite, `python -m ruff check .`, and
   the intent audit if the project carries claims. Add claims for the account
   lifecycle, the session as sole authenticator, and attribution.

## What it deliberately does not do

- **Pick your rung.** See Pre-flight 1.
- **Emit a profile or any app data.** A profile hangs off an account; it is not
  part of an identity. Model it in the app.
- **Build federation.** The two link columns and the lookup by the pair are
  present and empty. No shared user table, no cross-app protocol, no hub: a
  standalone app must never depend on a federation that does not exist. The
  columns are there because adding them later is a live migration with an
  account-takeover window open across it.
- **Add sign-in UI.** The HTTP surface is the contract; the screens are the
  app's.

## Failure modes

- **`unknown rung`**: the generator emits one rung and you named another. This
  is the intended refusal, not a gap to work around. Route the choice through
  `REF-Identity.md` section 2, and if the answer really is another rung, write
  that credential module rather than bending this one.
- **`the spine is additive to a hexagonal backend`**: `app_error.py` or
  `logging.py` is missing. Scaffold the service first with
  `bootstrap-hexagonal-backend`, or add the two yourself.
- **`refusing to overwrite`**: the project already has a file at that path. The
  spine is additive; reconcile by hand rather than forcing, because a half-
  overwritten identity is worse than either version.
- **Tests pass but nothing is authenticated**: the router is mounted and the
  choke point is not used. Assert it directly: a request carrying a made-up
  token, a claimed user id, and a proxy header must each be unauthenticated.
