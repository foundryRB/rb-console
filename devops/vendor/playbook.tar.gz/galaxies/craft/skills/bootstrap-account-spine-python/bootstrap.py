"""Scaffold the account spine into an existing Python hexagonal FastAPI backend.

Writes the rung-independent spine (opaque user id, accounts table carrying the
federation link, digest-only sessions, one session-resolution choke point, a
guess budget) plus the credential module for the rung named on the command line.

`--rung` has no default, deliberately. A scaffold that picks the credential rung
makes that rung the house answer for every app that runs it, including the ones
whose stakes say otherwise, and it does so with working code that nobody argues
with. The rung is a decision `REF-Identity.md` section 2 routes; this script
refuses to make it for you.

Deterministic file-writing only: the caller wires the container, runs the gates,
and records the decision in an ADR (see SKILL.md).
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

TEMPLATES = Path(__file__).parent / "templates"

# Rungs this scaffold can emit. A rung absent from here is not unsupported by
# the corpus, it is unsupported by this generator: REF-Identity section 3 covers
# seven, and the others want their own credential module before they belong here.
RUNGS = {
    "guest-recovery-code": (
        "A guest is an account; registration upgrades it in place and mints a "
        "high-entropy recovery code, stored as a fast digest because it sits "
        "far above the 112-bit line (REF-Identity section 4)."
    ),
}

OTHER_RUNGS = (
    "password+session, OIDC against a hosted IdP, magic link, passkeys/WebAuthn, "
    "JWT bearer, device-bound anonymous"
)


# What the spine expects the host backend to already provide. It is additive to
# a hexagonal service (bootstrap-hexagonal-backend leaves both in place), and
# emitting its own copies would give the project two root error types and two
# logging helpers, which is the duplication the corpus bans outright.
PREREQUISITES = {
    "domain/exceptions/app_error.py": "the root AppError the spine's exceptions derive from",
    "logging.py": "the get_logger helper the service and adapters log through",
}


def check_prerequisites(package: str, target: Path) -> list[str]:
    missing = []
    for relative, why in PREREQUISITES.items():
        if not (target / package / relative).is_file():
            missing.append(f"  {package}/{relative}  ({why})")
    return missing


def render(package: str, target: Path, force: bool) -> list[Path]:
    written: list[Path] = []
    for template in sorted(TEMPLATES.rglob("*.tmpl")):
        relative = template.relative_to(TEMPLATES).with_suffix("")
        destination = target / package / relative
        if destination.exists() and not force:
            raise SystemExit(
                f"refusing to overwrite {destination}\n"
                "The spine is additive; move or delete the existing file, or pass --force."
            )
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_text(
            template.read_text(encoding="utf-8").replace("{{package}}", package),
            encoding="utf-8",
        )
        written.append(destination)
        # Every package directory on the way down needs to be importable.
        for parent in relative.parents:
            if parent == Path("."):
                continue
            init = target / package / parent / "__init__.py"
            if not init.exists():
                init.write_text('"""Package."""\n', encoding="utf-8")
                written.append(init)
    return written


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Add the account spine to an existing Python hexagonal FastAPI backend."
    )
    parser.add_argument(
        "--package",
        required=True,
        help="The backend's package directory name, e.g. myapp_backend",
    )
    parser.add_argument(
        "--rung",
        required=True,
        help=(
            "The credential rung. No default: choose it with REF-Identity section 2. "
            f"This generator emits: {', '.join(sorted(RUNGS))}."
        ),
    )
    parser.add_argument(
        "--target",
        default=".",
        help="Directory containing the package (default: the current directory)",
    )
    parser.add_argument("--force", action="store_true", help="Overwrite existing files")
    args = parser.parse_args()

    if args.rung not in RUNGS:
        print(
            f"unknown rung {args.rung!r}.\n\n"
            f"This generator emits: {', '.join(sorted(RUNGS))}.\n"
            f"REF-Identity section 3 covers the rest ({OTHER_RUNGS}); each needs its own\n"
            "credential module, because the hashing differs by the credential's entropy\n"
            "and the routes differ by what the player presents. Pick the rung with\n"
            "REF-Identity section 2 first: recovery decides it, not stakes.",
            file=sys.stderr,
        )
        return 2

    target = Path(args.target).resolve()
    if not (target / args.package).is_dir():
        print(
            f"no package directory at {target / args.package}.\n"
            "This scaffold is additive to an existing backend, not a new project.",
            file=sys.stderr,
        )
        return 2

    missing = check_prerequisites(args.package, target)
    if missing:
        print(
            "the spine is additive to a hexagonal backend, and this one is missing:\n"
            + "\n".join(missing)
            + "\n\nScaffold the service first (bootstrap-hexagonal-backend), or add these\n"
            "two yourself. The spine deliberately does not emit its own copies: a second\n"
            "root error type and a second logging helper is the duplication the corpus bans.",
            file=sys.stderr,
        )
        return 2

    written = render(args.package, target, args.force)
    print(f"Account spine written into {args.package} ({args.rung}):")
    for path in written:
        print(f"  {path.relative_to(target).as_posix()}")
    print(
        "\nStill yours (SKILL.md lists them):\n"
        "  1. Wire AccountService and GuessBudget into the container, and mount the router.\n"
        "  2. Connect the Postgres repository at startup so its schema is applied.\n"
        "  3. Route every private surface through AccountService.resolve_session.\n"
        "  4. Record the rung and its recovery rung in an ADR, with the reasoning.\n"
        "  5. Run the gates."
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
