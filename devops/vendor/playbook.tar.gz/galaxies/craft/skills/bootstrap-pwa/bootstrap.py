#!/usr/bin/env python3
"""Make an existing Vite/React MVVM frontend installable, per REF-PWA.

Two modes, because the manifest and the service worker are separate decisions
(REF-PWA section 2):

--manifest-only  the app's identity on the device and nothing else: the
                 manifest with a frozen id, the credentialed manifest link,
                 placeholder icons and screenshots, the iOS install hint, the
                 sign-out link, and a smoke test that asserts the manifest. No
                 worker, so no caching, no update policy and no offline state.
                 The floor for an app whose value is a live view of something
                 remote.

full (default)   the above plus the worker: a generated worker in prompt mode,
                 the auth-proxy navigation denylist, the kill switch one line
                 away, the `pwa` ViewModel domain that is the only code touching
                 the worker, the update banner, and the worker half of the smoke
                 test.

Both write new files only and refuse to overwrite; the edits to files the
project already owns are printed for the caller to make.

Usage:
    python bootstrap.py --dir <frontend> --name "<App Name>" --short-name <Short>
        [--manifest-only] [--id /] [--proxy-prefix /oauth2/] [--api-prefix /api/]
        [--shell-handle desktop]
"""

from __future__ import annotations

import argparse
import re
import struct
import sys
import zlib
from pathlib import Path

__all__ = ["main"]

PREFIX_RE = re.compile(r"^/[A-Za-z0-9._~/-]*/$")
HANDLE_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")

PWA_CONFIG_MANIFEST_ONLY_TS = """import type { VitePWAOptions } from 'vite-plugin-pwa';

/**
 * Manifest only: the app's identity on the device, no service worker (REF-PWA
 * section 2). Frozen from the first release: `manifest.id` and
 * `manifest.start_url` (REF-PWA section 3).
 *
 * To take the worker later, re-run bootstrap-pwa without --manifest-only and
 * read REF-PWA section 6 first: a worker is an ordinary change to add and a
 * hard one to remove, because installed clients hold it until something
 * unregisters it.
 */
export const pwaOptions: Partial<VitePWAOptions> = {
    // Nothing registers a worker: the manifest is the whole change. The worker the
    // plugin still emits at sw.js is a self-destroying one, which is inert here and
    // is what cleans installed clients up if this app ever drops back from a full
    // PWA to manifest only (REF-PWA section 6).
    injectRegister: null,
    selfDestroying: true,
    // The manifest request carries no cookies by default; behind an auth proxy it must.
    useCredentials: true,
    manifest: {
        id: '__ID__',
        name: '__NAME__',
        short_name: '__SHORT_NAME__',
        description: '__NAME__',
        start_url: '/',
        scope: '/',
        display: 'standalone',
        theme_color: '#0a0a0a',
        background_color: '#0a0a0a',
        icons: [
            { src: 'icons/icon-192.png', sizes: '192x192', type: 'image/png', purpose: 'any' },
            { src: 'icons/icon-512.png', sizes: '512x512', type: 'image/png', purpose: 'any' },
            {
                src: 'icons/icon-maskable-512.png',
                sizes: '512x512',
                type: 'image/png',
                purpose: 'maskable',
            },
        ],
        screenshots: [
            {
                src: 'screenshots/wide.png',
                sizes: '1280x720',
                type: 'image/png',
                form_factor: 'wide',
            },
            {
                src: 'screenshots/narrow.png',
                sizes: '720x1280',
                type: 'image/png',
                form_factor: 'narrow',
            },
        ],
    },
};
"""

PWA_CONFIG_TS = """import type { VitePWAOptions } from 'vite-plugin-pwa';

/**
 * The PWA's whole build-time contract (REF-PWA). Frozen from the first release:
 * `manifest.id`, `manifest.start_url`, `filename` and `scope` (REF-PWA section 2).
 */
export const pwaOptions: Partial<VitePWAOptions> = {
    // Prompt, never auto-update: auto-update reloads every open window (REF-PWA section 5).
    registerType: 'prompt',
    // The pwa ViewModel registers the worker through the plugin's virtual module.
    injectRegister: null,
    // The manifest request carries no cookies by default; behind an auth proxy it must.
    useCredentials: true,
    filename: 'sw.js',
    scope: '/',
    // The kill switch: uncomment, redeploy to the same sw.js, and every client
    // drops its caches and unregisters (REF-PWA section 5).
    // selfDestroying: true,
    includeAssets: ['icons/apple-touch-icon.png'],
    manifest: {
        id: '__ID__',
        name: '__NAME__',
        short_name: '__SHORT_NAME__',
        description: '__NAME__',
        start_url: '/',
        scope: '/',
        display: 'standalone',
        theme_color: '#0a0a0a',
        background_color: '#0a0a0a',
        icons: [
            { src: 'icons/icon-192.png', sizes: '192x192', type: 'image/png', purpose: 'any' },
            { src: 'icons/icon-512.png', sizes: '512x512', type: 'image/png', purpose: 'any' },
            {
                src: 'icons/icon-maskable-512.png',
                sizes: '512x512',
                type: 'image/png',
                purpose: 'maskable',
            },
        ],
        screenshots: [
            {
                src: 'screenshots/wide.png',
                sizes: '1280x720',
                type: 'image/png',
                form_factor: 'wide',
            },
            {
                src: 'screenshots/narrow.png',
                sizes: '720x1280',
                type: 'image/png',
                form_factor: 'narrow',
            },
        ],
    },
    workbox: {
        navigateFallback: 'index.html',
        // The auth proxy's own paths and the API never get the cached shell (REF-PWA section 6).
        navigateFallbackDenylist: [__DENYLIST__],
        cleanupOutdatedCaches: true,
    },
};
"""

PWA_STATE_MANIFEST_ONLY_TS = """export interface PwaState {
    started: boolean;
    installHintVisible: boolean;
}
"""

PWA_ACTIONS_MANIFEST_ONLY_TS = """import { create } from 'zustand';

import type { PwaState } from './pwa.state';

const INSTALL_HINT_DISMISSED_KEY = 'pwa.installHintDismissed';

interface PwaActions {
    start: () => void;
    dismissInstallHint: () => void;
}

function isIos(): boolean {
    const touchMac = navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1;
    return /iPad|iPhone|iPod/.test(navigator.userAgent) || touchMac;
}

function isStandalone(): boolean {
    const legacy = (navigator as Navigator & { standalone?: boolean }).standalone === true;
    return window.matchMedia('(display-mode: standalone)').matches || legacy;
}

function hintDismissed(): boolean {
    try {
        return window.localStorage.getItem(INSTALL_HINT_DISMISSED_KEY) === '1';
    } catch {
        return false;
    }
}

/**
 * Manifest only, so this domain owns the install hint and nothing else. It is
 * still the single place the rest of the app asks about its installed state, so
 * taking a service worker later changes this file and no view (REF-PWA section 10).
 */
export const usePwa = create<PwaState & PwaActions>()((set, get) => ({
    started: false,
    installHintVisible: false,

    start: () => {
        if (get().started) {
            return;
        }
        set({ started: true, installHintVisible: isIos() && !isStandalone() && !hintDismissed() });
    },

    dismissInstallHint: () => {
        try {
            window.localStorage.setItem(INSTALL_HINT_DISMISSED_KEY, '1');
        } catch {
            // Storage unavailable; the hint comes back next launch.
        }
        set({ installHintVisible: false });
    },
}));
"""

PWA_STATUS_MANIFEST_ONLY_TSX = """import { useEffect } from 'react';

import { usePwa } from '@/viewmodels/pwa';
import { InstallHint } from '@/views/molecules/InstallHint';

/** Mount once in the layout template: starts the PWA domain and shows the install hint. */
export const PwaStatus: React.FC = () => {
    const { start, installHintVisible, dismissInstallHint } = usePwa();

    useEffect(() => {
        start();
    }, [start]);

    if (!installHintVisible) {
        return null;
    }
    return (
        <div className="fixed inset-x-4 bottom-4 z-50 mx-auto flex max-w-md flex-col gap-2">
            <InstallHint onDismiss={dismissInstallHint} />
        </div>
    );
};
"""

PWA_STATE_TS = """export interface PwaState {
    started: boolean;
    updateReady: boolean;
    offlineReady: boolean;
    installHintVisible: boolean;
}
"""

PWA_ACTIONS_TS = """import { create } from 'zustand';

import type { PwaState } from './pwa.state';

const UPDATE_CHECK_INTERVAL_MS = 60 * 60 * 1000;
const INSTALL_HINT_DISMISSED_KEY = 'pwa.installHintDismissed';

interface PwaActions {
    start: () => Promise<void>;
    applyUpdate: () => Promise<void>;
    dismissInstallHint: () => void;
}

let updateWorker: ((reloadPage?: boolean) => Promise<void>) | null = null;

/** Register only over http(s) and outside the desktop shell (REF-PWA section 10). */
function canRegisterWorker(): boolean {
    const overHttp = window.location.protocol === 'http:' || window.location.protocol === 'https:';
    const insideShell = '__SHELL_HANDLE__' in window;
    return overHttp && !insideShell && 'serviceWorker' in navigator;
}

function isIos(): boolean {
    const touchMac = navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1;
    return /iPad|iPhone|iPod/.test(navigator.userAgent) || touchMac;
}

function isStandalone(): boolean {
    const legacy = (navigator as Navigator & { standalone?: boolean }).standalone === true;
    return window.matchMedia('(display-mode: standalone)').matches || legacy;
}

function hintDismissed(): boolean {
    try {
        return window.localStorage.getItem(INSTALL_HINT_DISMISSED_KEY) === '1';
    } catch {
        return false;
    }
}

export const usePwa = create<PwaState & PwaActions>()((set, get) => ({
    started: false,
    updateReady: false,
    offlineReady: false,
    installHintVisible: false,

    start: async () => {
        if (get().started) {
            return;
        }
        set({ started: true, installHintVisible: isIos() && !isStandalone() && !hintDismissed() });
        if (!canRegisterWorker()) {
            return;
        }
        const { registerSW } = await import('virtual:pwa-register');
        updateWorker = registerSW({
            onNeedRefresh: () => set({ updateReady: true }),
            onOfflineReady: () => set({ offlineReady: true }),
            onRegisteredSW: (_swUrl, registration) => {
                if (registration === undefined) {
                    return;
                }
                // An installed app rarely navigates, so ask for the new worker explicitly.
                const check = (): void => {
                    if (navigator.onLine) {
                        void registration.update();
                    }
                };
                window.setInterval(check, UPDATE_CHECK_INTERVAL_MS);
                document.addEventListener('visibilitychange', () => {
                    if (document.visibilityState === 'visible') {
                        check();
                    }
                });
            },
        });
    },

    applyUpdate: async () => {
        await updateWorker?.(true);
    },

    dismissInstallHint: () => {
        try {
            window.localStorage.setItem(INSTALL_HINT_DISMISSED_KEY, '1');
        } catch {
            // Storage unavailable; the hint comes back next launch.
        }
        set({ installHintVisible: false });
    },
}));
"""

PWA_INDEX_TS = """export type { PwaState } from './pwa.state';
export { usePwa } from './pwa.actions';
"""

UPDATE_BANNER_TSX = """interface UpdateBannerProps {
    onReload: () => void;
}

/** Shown when a new version waits; the user decides when to reload (REF-PWA section 5). */
export const UpdateBanner: React.FC<UpdateBannerProps> = ({ onReload }) => (
    <div
        role="status"
        data-testid="pwa-update-banner"
        className="flex items-center justify-between gap-3 rounded-md border bg-card px-4 py-3 text-sm shadow-lg"
    >
        <span>A new version is available.</span>
        <button
            type="button"
            onClick={onReload}
            className="rounded-md bg-primary px-3 py-1.5 text-xs font-medium text-primary-foreground"
        >
            Reload
        </button>
    </div>
);
"""

INSTALL_HINT_TSX = """interface InstallHintProps {
    onDismiss: () => void;
}

/** iOS has no install prompt; this hint is the install experience there (REF-PWA section 4). */
export const InstallHint: React.FC<InstallHintProps> = ({ onDismiss }) => (
    <div
        role="note"
        data-testid="pwa-install-hint"
        className="flex items-start justify-between gap-3 rounded-md border bg-card px-4 py-3 text-sm shadow-lg"
    >
        <span>
            Install this app: tap <strong>Share</strong>, then <strong>Add to Home Screen</strong>.
        </span>
        <button
            type="button"
            onClick={onDismiss}
            className="text-xs text-muted-foreground hover:text-foreground"
        >
            Dismiss
        </button>
    </div>
);
"""

SIGN_OUT_LINK_TSX = """import { cn } from '@/utils';

interface SignOutLinkProps {
    /** The auth proxy's sign-out route. */
    href?: string;
    className?: string;
}

/**
 * A plain full-page link, never a router link or a fetch: the route belongs to
 * the auth proxy, and a standalone window has no address bar to reach it
 * (REF-PWA section 6).
 */
export const SignOutLink: React.FC<SignOutLinkProps> = ({
    href = '__PROXY_PREFIX__sign_out',
    className,
}) => (
    <a
        href={href}
        data-testid="sign-out-link"
        className={cn('text-sm hover:text-primary', className)}
    >
        Sign out
    </a>
);
"""

PWA_STATUS_TSX = """import { useEffect } from 'react';

import { usePwa } from '@/viewmodels/pwa';
import { InstallHint } from '@/views/molecules/InstallHint';
import { UpdateBanner } from '@/views/molecules/UpdateBanner';

/** Mount once in the layout template: starts the PWA domain and shows its two prompts. */
export const PwaStatus: React.FC = () => {
    const { start, updateReady, installHintVisible, applyUpdate, dismissInstallHint } = usePwa();

    useEffect(() => {
        void start();
    }, [start]);

    if (!updateReady && !installHintVisible) {
        return null;
    }
    return (
        <div className="fixed inset-x-4 bottom-4 z-50 mx-auto flex max-w-md flex-col gap-2">
            {updateReady && <UpdateBanner onReload={() => void applyUpdate()} />}
            {installHintVisible && <InstallHint onDismiss={dismissInstallHint} />}
        </div>
    );
};
"""

PWA_SPEC_MANIFEST_ONLY_TS = """import { expect, test } from '@playwright/test';

// Runs against the BUILT app: point the Playwright webServer at
// `npm run build && npm run preview`. Manifest only, so there is no worker to
// assert and nothing here is engine-specific (REF-PWA section 12).

interface ManifestIcon {
    purpose?: string;
}

test('the manifest is credentialed, frozen and iOS-safe', async ({ page, request }) => {
    await page.goto('/');
    const link = page.locator('link[rel="manifest"]');
    await expect(link).toHaveAttribute('crossorigin', 'use-credentials');

    const href = await link.getAttribute('href');
    expect(href).not.toBeNull();
    const manifest = (await (await request.get(href ?? '')).json()) as {
        id: string;
        start_url: string;
        display: string;
        icons: ManifestIcon[];
        screenshots: unknown[];
    };
    expect(manifest.id).toBe('__ID__');
    expect(manifest.start_url).toBe('/');
    expect(manifest.display).toBe('standalone');
    const hasAnyIcon = manifest.icons.some(
        (icon) => icon.purpose === undefined || icon.purpose.split(' ').includes('any'),
    );
    expect(hasAnyIcon).toBe(true);
    expect(manifest.screenshots.length).toBeGreaterThan(0);
});

test('no service worker is registered', async ({ page }) => {
    await page.goto('/');
    await page.waitForTimeout(500);
    const registrations = await page.evaluate(async () => {
        if (!('serviceWorker' in navigator)) {
            return 0;
        }
        return (await navigator.serviceWorker.getRegistrations()).length;
    });
    expect(registrations).toBe(0);
});
"""

PWA_SPEC_TS = """import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';

import { expect, test } from '@playwright/test';

// Runs against the BUILT app (the worker exists only in a build): point the
// Playwright webServer at `npm run build && npm run preview`. Service workers
// are visible to Playwright on Chromium only (REF-PWA section 11).
test.skip(
    ({ browserName }) => browserName !== 'chromium',
    'service workers are Chromium-only in Playwright',
);

interface ManifestIcon {
    purpose?: string;
}

test('the manifest is credentialed, frozen and iOS-safe', async ({ page, request }) => {
    await page.goto('/');
    const link = page.locator('link[rel="manifest"]');
    await expect(link).toHaveAttribute('crossorigin', 'use-credentials');

    const href = await link.getAttribute('href');
    expect(href).not.toBeNull();
    const manifest = (await (await request.get(href ?? '')).json()) as {
        id: string;
        start_url: string;
        icons: ManifestIcon[];
        screenshots: unknown[];
    };
    expect(manifest.id).toBe('__ID__');
    expect(manifest.start_url).toBe('/');
    const hasAnyIcon = manifest.icons.some(
        (icon) => icon.purpose === undefined || icon.purpose.split(' ').includes('any'),
    );
    expect(hasAnyIcon).toBe(true);
    expect(manifest.screenshots.length).toBeGreaterThan(0);
});

test('the worker takes control and the shell survives the network going away', async ({
    page,
    context,
}) => {
    await page.goto('/');
    await page.evaluate(async () => {
        await navigator.serviceWorker.ready;
    });
    await page.reload();
    expect(await page.evaluate(() => navigator.serviceWorker.controller !== null)).toBe(true);

    await context.setOffline(true);
    await page.reload();
    await expect(page.locator('#root')).not.toBeEmpty();
    await context.setOffline(false);
});

test('the auth proxy and the API stay off the navigation fallback', () => {
    const worker = readFileSync(resolve(process.cwd(), 'dist', 'sw.js'), 'utf8');
    for (const prefix of [__PREFIX_LIST__]) {
        expect(worker).toContain(prefix);
    }
});
"""


def _png(width: int, height: int, rgb: tuple[int, int, int]) -> bytes:
    """A solid-colour PNG, enough for the manifest to validate until the real art lands."""

    def chunk(kind: bytes, data: bytes) -> bytes:
        body = kind + data
        return struct.pack(">I", len(data)) + body + struct.pack(">I", zlib.crc32(body) & 0xFFFFFFFF)

    row = b"\x00" + bytes(rgb) * width
    raw = zlib.compress(row * height, 9)
    header = struct.pack(">IIBBBBB", width, height, 8, 2, 0, 0, 0)
    return b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", header) + chunk(b"IDAT", raw) + chunk(b"IEND", b"")


def _regex_source(prefix: str) -> str:
    """The source of the anchored regex for a path prefix, as the worker file will carry it."""
    return "^" + prefix.replace("/", "\\/")


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--dir", type=Path, required=True, help="the frontend root (holds package.json and vite.config.ts)")
    ap.add_argument("--name", required=True, help="the app's display name")
    ap.add_argument("--short-name", required=True, help="the name under the icon (12 characters or fewer reads best)")
    ap.add_argument("--id", default="/", help="the manifest id, frozen from the first release (default: /)")
    ap.add_argument(
        "--manifest-only",
        action="store_true",
        help="the manifest half only: no service worker, so no caching, update policy or offline state",
    )
    ap.add_argument("--proxy-prefix", default="/oauth2/", help="the auth proxy's own path prefix (default: /oauth2/)")
    ap.add_argument("--api-prefix", default="/api/", help="the API's path prefix (default: /api/)")
    ap.add_argument("--shell-handle", default="desktop", help="window property a desktop shell exposes (default: desktop)")
    args = ap.parse_args()

    root: Path = args.dir
    if not (root / "package.json").is_file() or not any(root.glob("vite.config.*")):
        print(f"error: {root} is not a Vite frontend (no package.json or vite.config)", file=sys.stderr)
        return 2
    for label, prefix in (("--proxy-prefix", args.proxy_prefix), ("--api-prefix", args.api_prefix)):
        if not PREFIX_RE.match(prefix):
            print(f"error: {label} must start and end with a slash: {prefix!r}", file=sys.stderr)
            return 2
    if not HANDLE_RE.match(args.shell_handle):
        print(f"error: --shell-handle must be an identifier: {args.shell_handle!r}", file=sys.stderr)
        return 2
    for label, value in (("--name", args.name), ("--short-name", args.short_name), ("--id", args.id)):
        if "'" in value or "\\" in value or not value.strip():
            print(f"error: {label} must be non-empty, without quotes or backslashes: {value!r}", file=sys.stderr)
            return 2

    prefixes = [args.proxy_prefix, args.api_prefix]
    sources = [_regex_source(p) for p in prefixes]

    def fill(text: str) -> str:
        return (
            text.replace("__ID__", args.id)
            .replace("__NAME__", args.name)
            .replace("__SHORT_NAME__", args.short_name)
            .replace("__DENYLIST__", ", ".join(f"/{s}/" for s in sources))
            .replace("__PREFIX_LIST__", ", ".join("'" + s.replace("\\", "\\\\") + "'" for s in sources))
            .replace("__PROXY_PREFIX__", args.proxy_prefix)
            .replace("__SHELL_HANDLE__", args.shell_handle)
        )

    if args.manifest_only:
        text_files: dict[str, str] = {
            "pwa.config.ts": fill(PWA_CONFIG_MANIFEST_ONLY_TS),
            "src/viewmodels/pwa/pwa.state.ts": PWA_STATE_MANIFEST_ONLY_TS,
            "src/viewmodels/pwa/pwa.actions.ts": PWA_ACTIONS_MANIFEST_ONLY_TS,
            "src/viewmodels/pwa/index.ts": PWA_INDEX_TS,
            "src/views/atoms/SignOutLink.tsx": fill(SIGN_OUT_LINK_TSX),
            "src/views/molecules/InstallHint.tsx": INSTALL_HINT_TSX,
            "src/views/organisms/PwaStatus.tsx": PWA_STATUS_MANIFEST_ONLY_TSX,
            "e2e/pwa.spec.ts": fill(PWA_SPEC_MANIFEST_ONLY_TS),
        }
    else:
        text_files = {
            "pwa.config.ts": fill(PWA_CONFIG_TS),
            "src/viewmodels/pwa/pwa.state.ts": PWA_STATE_TS,
            "src/viewmodels/pwa/pwa.actions.ts": fill(PWA_ACTIONS_TS),
            "src/viewmodels/pwa/index.ts": PWA_INDEX_TS,
            "src/views/atoms/SignOutLink.tsx": fill(SIGN_OUT_LINK_TSX),
            "src/views/molecules/UpdateBanner.tsx": UPDATE_BANNER_TSX,
            "src/views/molecules/InstallHint.tsx": INSTALL_HINT_TSX,
            "src/views/organisms/PwaStatus.tsx": PWA_STATUS_TSX,
            "e2e/pwa.spec.ts": fill(PWA_SPEC_TS),
        }
    ink = (10, 10, 10)
    binary_files: dict[str, bytes] = {
        "public/icons/icon-192.png": _png(192, 192, ink),
        "public/icons/icon-512.png": _png(512, 512, ink),
        "public/icons/icon-maskable-512.png": _png(512, 512, ink),
        "public/icons/apple-touch-icon.png": _png(180, 180, ink),
        "public/screenshots/wide.png": _png(1280, 720, ink),
        "public/screenshots/narrow.png": _png(720, 1280, ink),
    }

    clashes = [rel for rel in (*text_files, *binary_files) if (root / rel).exists()]
    if clashes:
        print("error: refusing to overwrite:\n  " + "\n  ".join(clashes), file=sys.stderr)
        return 2

    print(f"Adding the PWA to {root}")
    for rel, content in text_files.items():
        path = root / rel
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8", newline="\n")
        print(f"  {path}")
    for rel, data in binary_files.items():
        path = root / rel
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)
        print(f"  {path}")

    sign_in = f"{args.proxy_prefix}start"
    print("\nEdits to files the project owns (make them by hand):")
    print("  1. npm install -D vite-plugin-pwa @playwright/test")
    if args.manifest_only:
        print("  2. vite.config.ts: import { VitePWA } from 'vite-plugin-pwa' and { pwaOptions } from './pwa.config';")
        print("     add VitePWA(pwaOptions) to plugins.")
        print("  3. tsconfig include: add pwa.config.ts next to vite.config.ts.")
        print("  4. index.html <head>: <link rel=\"apple-touch-icon\" href=\"/icons/apple-touch-icon.png\" />")
        print("     and <meta name=\"theme-color\" content=\"#0a0a0a\" />. The plugin injects the manifest link.")
        print("  5. Layout template: mount <PwaStatus /> once; place <SignOutLink /> where the user finds it.")
        print("  6. apiFetch: send Accept: application/json on every call; on 401,")
        print(f"     window.location.assign('{sign_in}?rd=' + encodeURIComponent(location.pathname + location.search)).")
        print("     No worker here, so no cached shell can swallow it, but a 401 still needs handling.")
        print("  7. Playwright: webServer runs 'npm run build && npm run preview'. Keep vitest off the")
        print("     Playwright specs: test.exclude: [...configDefaults.exclude, 'e2e/**'] in vite.config.ts.")
        print("  8. Wherever the build is served from: serve the manifest as")
        print("     application/manifest+json, declared for that ONE file. Then curl -I it on the")
        print("     deployed origin (REF-PWA 5).")
        print("  9. Replace public/icons and public/screenshots with the app's real art (REF-Design).")
        print("\nThen: npm run build && npx playwright test e2e/pwa.spec.ts")
        print("\nNo service worker was scaffolded (REF-PWA section 2). To take one later, re-run")
        print("without --manifest-only and read REF-PWA section 6 first: adding a worker is an")
        print("ordinary change, removing one after clients have installed is not.")
        return 0
    print("  2. vite.config.ts: import { VitePWA } from 'vite-plugin-pwa' and { pwaOptions } from './pwa.config';")
    print("     add VitePWA(pwaOptions) to plugins.")
    print("  3. src/vite-env.d.ts: add  /// <reference types=\"vite-plugin-pwa/client\" />")
    print("  4. tsconfig include: add pwa.config.ts next to vite.config.ts.")
    print("  5. index.html <head>: <link rel=\"apple-touch-icon\" href=\"/icons/apple-touch-icon.png\" />")
    print("     and <meta name=\"theme-color\" content=\"#0a0a0a\" />. The plugin injects the manifest link.")
    print("  6. Layout template: mount <PwaStatus /> once; place <SignOutLink /> where the user finds it.")
    print("  7. apiFetch (src/utils.ts): send Accept: application/json on every call; on 401,")
    print(f"     window.location.assign('{sign_in}?rd=' + encodeURIComponent(location.pathname + location.search)).")
    print("  8. Playwright: webServer runs 'npm run build && npm run preview'; specs that mock the")
    print("     network set serviceWorkers: 'block'. Keep vitest off the Playwright specs:")
    print("     test.exclude: [...configDefaults.exclude, 'e2e/**'] in vite.config.ts.")
    print("  9. Wherever the build is served from (web server, CDN, ingress): serve the manifest")
    print("     as application/manifest+json, declared for that ONE file and never as a")
    print("     server-wide type-map block, and /sw.js uncached. Then curl -I both on the")
    print("     deployed origin: nothing above this line exercises that server (REF-PWA 5).")
    print(" 10. Replace public/icons and public/screenshots with the app's real art (REF-Design).")
    print("\nThen: npm run build && npx playwright test e2e/pwa.spec.ts")
    return 0


if __name__ == "__main__":
    sys.exit(main())
