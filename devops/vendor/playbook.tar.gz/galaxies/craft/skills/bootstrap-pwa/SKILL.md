---
name: bootstrap-pwa
description: "Make an existing Vite/React MVVM frontend installable per REF-PWA, in either of its two modes: --manifest-only (the app's identity on the device, no service worker) or the full PWA (a generated worker in prompt mode, the update banner, the auth-proxy denylist, the kill switch, the shell guard). Both scaffold the manifest with a frozen id, the credentialed manifest link, the iOS install hint, the sign-out control and a Playwright smoke test. Composes with bootstrap-react-mvvm rather than scaffolding a frontend; caller wires the printed edits, then runs the build and e2e gates."
galaxy: craft
refs:
  - REF-PWA
  - REF-Frontend
  - REF-React
---

# Bootstrap PWA

Invoked when an existing Vite/React MVVM frontend should become installable on phones and desktops, and the addition should conform to `REF-PWA.md` from the first release. Deterministic scaffold for the new files; the edits to files the project already owns are printed and made by hand. It adds the PWA, it does not author the frontend.

It has two modes, because the manifest and the service worker are separate decisions (`REF-PWA.md` §2). `--manifest-only` gives the app its identity on the device (icon, name, standalone window) and nothing that can go stale. The default adds the worker, and with it offline launch, the update policy and every hazard §8 exists to manage.

## Pre-flight

1. **Read** `REF-PWA.md` (especially §2 the two decisions, §3 what is frozen from the first release, §5 serving the PWA's own files, §7 update and rollback, §8 the auth-proxy seam, §11 the boundary).
2. **Confirm the ask is a PWA.** A requirement for an App Store listing is a native shell project, not this skill (`REF-PWA.md` §6). An app that needs the local machine routes to `bootstrap-electron` (`REF-Electron.md` §1).
3. **Confirm the frontend exists** and follows `REF-Frontend.md`'s layout (`src/viewmodels/`, `src/views/`, the `@/` alias); run `bootstrap-react-mvvm` first if there is none.
4. **Pick the mode by asking what the app does with no network** (`REF-PWA.md` §2). An app whose value is a live view of something remote shows nothing useful offline and takes `--manifest-only`; an app the user reads, drafts in, or carries into bad signal earns the worker. Unsure means `--manifest-only`: adding the worker later is an ordinary change, removing it after clients have installed is not.
5. **Confirm with user, because these are frozen once a client installs** (`REF-PWA.md` §3): the app's display name and short name, and the manifest `id` (default `/`). Then, for the default mode, the two path prefixes the worker must never answer: the auth proxy's own prefix (default `/oauth2/`) and the API prefix (default `/api/`); read them from the project's deployment, never assume them.

## Steps

1. **Run the scaffolder** from this skill's folder:
   ```bash
   python bootstrap.py --dir <frontend> --name "<App Name>" --short-name <Short> \
       [--manifest-only] [--id /] [--proxy-prefix /oauth2/] [--api-prefix /api/] \
       [--shell-handle desktop]
   ```
   Both modes write `pwa.config.ts` (the plugin options, and the manifest with its frozen `id`, `any` and `maskable` icons, screenshots and the credentialed manifest link), the `pwa` ViewModel domain, `InstallHint`, `SignOutLink`, the connected `PwaStatus` organism, placeholder icons and screenshots, and `e2e/pwa.spec.ts`. The default mode adds the worker's options (prompt mode, the navigation denylist, the kill switch one commented line away), registration and the foreground and interval update checks inside the `pwa` domain, `UpdateBanner`, and the worker half of the smoke test. It refuses to overwrite.
2. **Make the printed edits** to the files the project owns: install `vite-plugin-pwa`, add `VitePWA(pwaOptions)` to `vite.config.ts`, the client types reference, the `apple-touch-icon` and `theme-color` tags, and mount `PwaStatus` once in the layout template with `SignOutLink` where the user finds it.
3. **Teach the API client the proxy's language** (`REF-PWA.md` §8): every call sends `Accept: application/json`, and a `401` becomes a full-page navigation to the proxy's sign-in route with the current location as its return target. Under the default mode, reloading the current route is not a fix, because the cached shell answers it.
4. **Keep the test layers apart** (`REF-PWA.md` §13): Playwright's web server runs the built app (`npm run build && npm run preview`), existing specs that mock the network set `serviceWorkers: 'block'`, and vitest excludes `e2e/**`.
5. **Prove it**: `npm run style`, `npm run build`, `npm run test`, then `npx playwright test e2e/pwa.spec.ts`. The smoke test asserts the credentialed manifest link, the frozen `id`, an `any` icon and a screenshot; under `--manifest-only` it also asserts that no worker is registered, and otherwise that the worker takes control, the shell renders with the network off, and both prefixes are on the denylist.
6. **Fix how the build is served, then check it on the deployed origin** (`REF-PWA.md` §5). Wherever the build is served from (a container's web server, a CDN, an ingress): the manifest goes out as `application/manifest+json`, declared for that one file and never as a server-wide type-map block, and `/sw.js` goes out uncached (the default mode only). Neither is covered by anything upstream: the smoke test drives a preview server that never reads that config. After the first deploy of each environment, `curl -I` both URLs and read the headers back. Do not request an asset's URL before the deploy that ships it, or the SPA fallback answers and an edge cache can hold that HTML under the asset's URL for hours.
7. **Replace the placeholder art** in `public/icons/` and `public/screenshots/` with the app's visual identity (`REF-Design.md`), keeping the `apple-touch-icon` in step with the `any` icon.

Web push is not scaffolded: it needs a backend sender and a subscription store. When the app takes it on, its client half goes inside the `pwa` ViewModel domain and follows `REF-PWA.md` §10. Push needs the worker, so an app on `--manifest-only` takes the worker first.

To move an app from `--manifest-only` to the full PWA later, re-run without the flag: the scaffolder refuses on the files that already exist, so take its output as the diff to apply by hand. Read `REF-PWA.md` §8 first when the app sits behind an auth proxy. The reverse move, dropping the worker, is why `--manifest-only` still ships a self-destroying `sw.js`: inert on an app that never had a worker, and what unregisters one on clients that did.

## Failure modes

- **A scaffolded path already exists**: the scaffolder refuses and names the clashes; the project already has a PWA layer or a name collision. Resolve it by hand, never by deleting the project's file.
- **The browser never offers install, with no error**: the manifest request was answered by the auth proxy's login redirect. Check the built `index.html` carries `crossorigin="use-credentials"` on the manifest link (`useCredentials` in `pwa.config.ts`), before reaching for an auth exemption (`REF-PWA.md` §8).
- **Installed with no icon, or in a browser window, on a platform that worked before the manifest shipped**: read the manifest's `Content-Type` on the deployed origin. A server whose type map has no `.webmanifest` sends `application/octet-stream`; Chromium parses it anyway and Safari does not, so every test stays green while the app loses both its icons and the engine default it had before a manifest was declared (`REF-PWA.md` §4, §5).
- **An icon 404s on the deployed origin but is present in the build**: an edge cache may be holding the SPA fallback from a request made before that file shipped. Purge the path, or wait out the TTL, and probe with a cache-busting query string next time (`REF-PWA.md` §5).
- **A signed-out user sits in a shell whose calls all fail**: a proxy or API prefix is missing from `navigateFallbackDenylist`, or the API client reloads the current route on `401` instead of navigating to the proxy's sign-in route.
- **vitest fails on `e2e/pwa.spec.ts`**: vitest collected a Playwright spec; add `e2e/**` to its `exclude`.
- **Existing Playwright specs stop intercepting requests**: the worker answers them before Playwright's routing sees them; set `serviceWorkers: 'block'` in those specs.
- **Users stay on an old version**: the update checks never ran because `PwaStatus` is not mounted, or the worker script is cached between browser and app. Mount it once in the layout; serve `/sw.js` uncached and confirm the header on the deployed URL, since a CDN's browser-cache floor can raise a zero TTL while leaving an explicit long one alone (`REF-PWA.md` §5).
- **A bad worker is in the field**: set `selfDestroying: true` in `pwa.config.ts` and redeploy to the same `sw.js`; never rename the file or move its scope to "start clean" (`REF-PWA.md` §7).
- **The desktop shell logs a registration error**: the shell exposes its handle under another name; pass it as `--shell-handle`, or fix `canRegisterWorker` in the `pwa` domain (`REF-PWA.md` §12).
