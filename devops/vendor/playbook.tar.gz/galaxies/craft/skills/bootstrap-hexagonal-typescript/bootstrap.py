"""Scaffold a TypeScript application in hexagonal (ports and adapters) form.

Writes the tree REF-TypeScript section 3 declares, with one exemplar slice wired
end to end and a boundary test asserting the dependency rule. The topology is a
required argument with no default: a scaffold that picks the topology decides the
application's shape on the author's behalf.

Usage:
    python bootstrap.py --target <parent-dir> --project-name <name> \
        --topology {client-server,standalone} --description "<one sentence>"
"""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

__all__ = ["main"]

NAME_PATTERN = re.compile(r"^[a-z][a-z0-9]*(-[a-z0-9]+)*$")


def _package_json(name: str, description: str) -> str:
    return json.dumps(
        {
            "name": name,
            "version": "0.0.0",
            "private": True,
            "type": "module",
            "description": description,
            "scripts": {
                "build": "tsc -b",
                "start": "tsx src/index.ts",
                "test": "vitest run",
                "lint": "tsc --noEmit",
            },
            "devDependencies": {
                "@types/node": "^24.0.0",
                "tsx": "^4.0.0",
                "typescript": "~5.9.0",
                "vitest": "^5.0.3",
            },
        },
        indent=4,
    )


TSCONFIG = """{
    "compilerOptions": {
        "target": "ES2020",
        "module": "ESNext",
        "moduleResolution": "bundler",
        "strict": true,
        "noUncheckedIndexedAccess": true,
        "esModuleInterop": true,
        "skipLibCheck": true,
        "outDir": "dist",
        "baseUrl": ".",
        "paths": {
            "@/*": ["./src/*"]
        }
    },
    "include": ["src", "tests"]
}
"""

VITEST_CONFIG = """import { defineConfig } from 'vitest/config';
import { fileURLToPath } from 'node:url';

export default defineConfig({
    resolve: {
        alias: {
            '@': fileURLToPath(new URL('./src', import.meta.url)),
        },
    },
});
"""

GITIGNORE = "node_modules/\ndist/\n*.tsbuildinfo\n"

ENTITY = """/** An item on the board, identified by id. */
export class Item {
    constructor(
        readonly id: string,
        readonly name: string,
        private done: boolean = false,
    ) {}

    /** Business rule: an item settles once, and settling it again is a no-op. */
    settle(): void {
        this.done = true;
    }

    isSettled(): boolean {
        return this.done;
    }
}
"""

ERRORS = """/** The domain's error hierarchy. An adapter maps these to its own vocabulary. */
export class DomainError extends Error {}

export class ItemNotFound extends DomainError {
    constructor(readonly id: string) {
        super(`no item with id ${id}`);
    }
}
"""

INBOUND_PORT = """import type { Item } from '@/domain/model/Item';

/** Inbound port: settle one item. */
export interface SettleItemPort {
    execute(id: string): Promise<Item>;
}
"""

LIST_PORT = """import type { Item } from '@/domain/model/Item';

/** Inbound port: list every item. */
export interface ListItemsPort {
    execute(): Promise<Item[]>;
}
"""

OUTBOUND_PORT = """import type { Item } from '@/domain/model/Item';

/** What the application needs from storage. Domain types only. */
export interface ItemRepository {
    findById(id: string): Promise<Item | null>;
    findAll(): Promise<Item[]>;
    save(item: Item): Promise<void>;
}
"""

SETTLE_USE_CASE = """import type { SettleItemPort } from '@/application/ports/inbound/SettleItemPort';
import type { ItemRepository } from '@/application/ports/outbound/ItemRepository';
import { ItemNotFound } from '@/domain/errors';
import type { Item } from '@/domain/model/Item';

export class SettleItemUseCase implements SettleItemPort {
    constructor(private readonly repository: ItemRepository) {}

    async execute(id: string): Promise<Item> {
        const item = await this.repository.findById(id);
        if (item === null) throw new ItemNotFound(id);
        item.settle();
        await this.repository.save(item);
        return item;
    }
}
"""

LIST_USE_CASE = """import type { ListItemsPort } from '@/application/ports/inbound/ListItemsPort';
import type { ItemRepository } from '@/application/ports/outbound/ItemRepository';
import type { Item } from '@/domain/model/Item';

export class ListItemsUseCase implements ListItemsPort {
    constructor(private readonly repository: ItemRepository) {}

    execute(): Promise<Item[]> {
        return this.repository.findAll();
    }
}
"""

MEMORY_ADAPTER = """import type { ItemRepository } from '@/application/ports/outbound/ItemRepository';
import { Item } from '@/domain/model/Item';

/** Replace with the real store; the port is what the application depends on. */
export class InMemoryItemRepository implements ItemRepository {
    private readonly items = new Map<string, Item>([
        ['1', new Item('1', 'first item')],
        ['2', new Item('2', 'second item')],
    ]);

    async findById(id: string): Promise<Item | null> {
        return this.items.get(id) ?? null;
    }

    async findAll(): Promise<Item[]> {
        return [...this.items.values()];
    }

    async save(item: Item): Promise<void> {
        this.items.set(item.id, item);
    }
}
"""

CONTAINER = """import type { ListItemsPort } from '@/application/ports/inbound/ListItemsPort';
import type { SettleItemPort } from '@/application/ports/inbound/SettleItemPort';
import { ListItemsUseCase } from '@/application/useCases/ListItemsUseCase';
import { SettleItemUseCase } from '@/application/useCases/SettleItemUseCase';
import { InMemoryItemRepository } from '@/adapters/outbound/memory/InMemoryItemRepository';

export interface Config {
    readonly port: number;
}

/** The composition root: the only module importing every layer. */
export class Container {
    private readonly repository = new InMemoryItemRepository();

    constructor(readonly config: Config) {}

    listItems(): ListItemsPort {
        return new ListItemsUseCase(this.repository);
    }

    settleItem(): SettleItemPort {
        return new SettleItemUseCase(this.repository);
    }
}
"""

HTTP_ADAPTER = """import { createServer, type Server } from 'node:http';
import type { Container } from '@/container';
import { ItemNotFound } from '@/domain/errors';

/** Inbound adapter: request in, port call, domain result to response. */
export function createHttpServer(container: Container): Server {
    return createServer((request, response) => {
        void handle(container, request.method ?? 'GET', request.url ?? '/')
            .then(({ status, body }) => {
                response.writeHead(status, { 'content-type': 'application/json' });
                response.end(JSON.stringify(body));
            })
            .catch(() => {
                response.writeHead(500, { 'content-type': 'application/json' });
                response.end(JSON.stringify({ error: 'internal error' }));
            });
    });
}

async function handle(
    container: Container,
    method: string,
    url: string,
): Promise<{ status: number; body: unknown }> {
    if (method === 'GET' && url === '/items') {
        const items = await container.listItems().execute();
        return { status: 200, body: items.map(toResponse) };
    }
    const settle = /^\\/items\\/([^/]+)\\/settle$/.exec(url);
    if (method === 'POST' && settle !== null) {
        try {
            const item = await container.settleItem().execute(settle[1]!);
            return { status: 200, body: toResponse(item) };
        } catch (error) {
            if (error instanceof ItemNotFound) return { status: 404, body: { error: error.message } };
            throw error;
        }
    }
    return { status: 404, body: { error: 'no such route' } };
}

function toResponse(item: { id: string; name: string; isSettled(): boolean }) {
    return { id: item.id, name: item.name, settled: item.isSettled() };
}
"""

CLI_ADAPTER = """import type { Container } from '@/container';
import { ItemNotFound } from '@/domain/errors';

/** Inbound adapter: argument vector in, port call, domain result to output. */
export async function runCli(container: Container, argv: readonly string[]): Promise<number> {
    const [command, argument] = argv;
    if (command === 'list') {
        for (const item of await container.listItems().execute()) {
            process.stdout.write(`${item.id}  ${item.name}  ${item.isSettled() ? 'settled' : 'open'}\\n`);
        }
        return 0;
    }
    if (command === 'settle' && argument !== undefined) {
        try {
            const item = await container.settleItem().execute(argument);
            process.stdout.write(`settled ${item.id}\\n`);
            return 0;
        } catch (error) {
            if (error instanceof ItemNotFound) {
                process.stderr.write(`${error.message}\\n`);
                return 1;
            }
            throw error;
        }
    }
    process.stderr.write('usage: list | settle <id>\\n');
    return 2;
}
"""

HTTP_INDEX = """import { Container } from '@/container';
import { createHttpServer } from '@/adapters/inbound/http/server';

const container = new Container({ port: Number(process.env.PORT ?? 8080) });
createHttpServer(container).listen(container.config.port);
"""

CLI_INDEX = """import { Container } from '@/container';
import { runCli } from '@/adapters/inbound/cli/runCli';

const container = new Container({ port: 0 });
process.exitCode = await runCli(container, process.argv.slice(2));
"""

USE_CASE_TEST = """import { describe, expect, it } from 'vitest';
import { SettleItemUseCase } from '@/application/useCases/SettleItemUseCase';
import type { ItemRepository } from '@/application/ports/outbound/ItemRepository';
import { Item } from '@/domain/model/Item';
import { ItemNotFound } from '@/domain/errors';

/** The port is substituted, so the use case runs with no I/O (REF-TypeScript section 8). */
class FakeItemRepository implements ItemRepository {
    constructor(private readonly items: Item[]) {}
    async findById(id: string) {
        return this.items.find((item) => item.id === id) ?? null;
    }
    async findAll() {
        return this.items;
    }
    async save() {}
}

describe('SettleItemUseCase', () => {
    it('settles an item that exists', async () => {
        const useCase = new SettleItemUseCase(new FakeItemRepository([new Item('1', 'first')]));
        expect((await useCase.execute('1')).isSettled()).toBe(true);
    });

    it('raises a domain error when the item is absent', async () => {
        const useCase = new SettleItemUseCase(new FakeItemRepository([]));
        await expect(useCase.execute('nope')).rejects.toBeInstanceOf(ItemNotFound);
    });
});
"""

BOUNDARY_TEST = """import { describe, expect, it } from 'vitest';
import { readFileSync, readdirSync, statSync } from 'node:fs';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';

/** The dependency rule, walked rather than trusted (REF-CleanArchitecture section 1).
 * Nothing in an inner layer imports an outer one; the container is the exception. */

const SRC = fileURLToPath(new URL('../src', import.meta.url));

function walk(dir: string): string[] {
    return readdirSync(dir).flatMap((name) => {
        const path = join(dir, name);
        return statSync(path).isDirectory() ? walk(path) : path.endsWith('.ts') ? [path] : [];
    });
}

function importsOf(file: string): string[] {
    return [...readFileSync(file, 'utf-8').matchAll(/from '([^']+)'/g)].map((match) => match[1]!);
}

describe('the dependency rule', () => {
    it('domain imports no outer layer', () => {
        for (const file of walk(join(SRC, 'domain'))) {
            for (const specifier of importsOf(file)) {
                expect(specifier, file).not.toMatch(/^@\\/(application|adapters)\\//);
                expect(specifier, file).not.toMatch(/^@\\/container/);
            }
        }
    });

    it('application imports no adapter', () => {
        for (const file of walk(join(SRC, 'application'))) {
            for (const specifier of importsOf(file)) {
                expect(specifier, file).not.toMatch(/^@\\/adapters\\//);
                expect(specifier, file).not.toMatch(/^@\\/container/);
            }
        }
    });

    it('an inbound adapter depends on ports, never on a use case', () => {
        for (const file of walk(join(SRC, 'adapters', 'inbound'))) {
            for (const specifier of importsOf(file)) {
                expect(specifier, file).not.toMatch(/^@\\/application\\/useCases\\//);
            }
        }
    });
});
"""


def _readme(name: str, description: str, topology: str, adapter: str) -> str:
    return f"""# {name}

{description}

It does this and deliberately nothing else; a second responsibility belongs in a
sibling module (`REF-CleanArchitecture.md` section 11).

## Shape

Hexagonal, per `REF-TypeScript.md` section 3. This is a **{topology}** application, so
its inbound adapter is `src/adapters/inbound/{adapter}/`.

```
src/domain/        entities, value objects, pure rules
src/application/   ports (inbound, outbound) and use cases
src/adapters/      inbound {adapter}, outbound memory
src/container.ts   composition root
```

## Running it

```bash
npm install
npm test          # use case with ports substituted, plus the boundary test
npm start
```

## The example slice

An `Item` domain (list, settle) wired end to end. It exists to show every layer.
Replace it with the real domain and delete the example files once your own use
cases exist.
"""


def _files(name: str, description: str, topology: str) -> dict[str, str]:
    adapter = "http" if topology == "client-server" else "cli"
    files = {
        "package.json": _package_json(name, description),
        "tsconfig.json": TSCONFIG,
        "vitest.config.ts": VITEST_CONFIG,
        ".gitignore": GITIGNORE,
        "README.md": _readme(name, description, topology, adapter),
        "src/domain/model/Item.ts": ENTITY,
        "src/domain/errors/index.ts": ERRORS,
        "src/application/ports/inbound/SettleItemPort.ts": INBOUND_PORT,
        "src/application/ports/inbound/ListItemsPort.ts": LIST_PORT,
        "src/application/ports/outbound/ItemRepository.ts": OUTBOUND_PORT,
        "src/application/useCases/SettleItemUseCase.ts": SETTLE_USE_CASE,
        "src/application/useCases/ListItemsUseCase.ts": LIST_USE_CASE,
        "src/adapters/outbound/memory/InMemoryItemRepository.ts": MEMORY_ADAPTER,
        "src/container.ts": CONTAINER,
        "tests/settleItem.test.ts": USE_CASE_TEST,
        "tests/boundaries.test.ts": BOUNDARY_TEST,
    }
    if topology == "client-server":
        files["src/adapters/inbound/http/server.ts"] = HTTP_ADAPTER
        files["src/index.ts"] = HTTP_INDEX
    else:
        files["src/adapters/inbound/cli/runCli.ts"] = CLI_ADAPTER
        files["src/index.ts"] = CLI_INDEX
    return files


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--target", required=True, help="parent directory the project folder is created in")
    parser.add_argument("--project-name", required=True, help="kebab-case project and folder name")
    parser.add_argument(
        "--topology",
        required=True,
        choices=["client-server", "standalone"],
        help="no default: the topology decides which inbound adapter the application exposes",
    )
    parser.add_argument("--description", required=True, help="one sentence: what it does")
    args = parser.parse_args()

    if not NAME_PATTERN.match(args.project_name):
        parser.error(f"project name must be kebab-case: {args.project_name}")

    root = Path(args.target).expanduser().resolve() / args.project_name
    written, skipped = 0, 0
    for relative, content in _files(args.project_name, args.description, args.topology).items():
        path = root / relative
        if path.exists():
            skipped += 1
            continue
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")
        written += 1

    print(f"{args.topology} application at {root}: {written} files written, {skipped} skipped")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
