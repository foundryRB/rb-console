---
name: bootstrap-hexagonal-typescript
description: "Scaffold a new TypeScript application in hexagonal (ports and adapters) architecture per REF-TypeScript: domain / application / adapters layers, ports as interfaces, a container.ts composition root, one exemplar use case wired end to end, and boundary tests asserting the dependency rule. Serves both topologies (REF-CleanArchitecture section 1): a client-server core exposes an http inbound adapter, a standalone application exposes a ui one. Composes with bootstrap-atomic-shadcn for a standalone app's view layer and bootstrap-electron for its desktop shell."
galaxy: craft
refs:
  - REF-TypeScript
  - REF-CleanArchitecture
  - REF-Tests
---

# Bootstrap hexagonal TypeScript

Invoked when a new TypeScript application is needed at REF-conformant quality from day
one: hexagonal layering, ports as interfaces, a `container.ts` composition root, and a
boundary test that fails the build when the dependency rule is broken. It is the
TypeScript counterpart of `bootstrap-hexagonal-backend` (Python and FastAPI).

The topology is a required argument with no default. A scaffold that picks it decides the
application's shape on the author's behalf, and the choice is the one decision the tree
cannot express twice.

## Pre-flight

1. **Read** `REF-TypeScript.md`, `REF-CleanArchitecture.md` (especially §1, the topology),
   and `REF-Tests.md`. The skeleton instantiates them.
2. **Settle the topology** against `REF-CleanArchitecture.md` §1. The question that decides
   it: can the interface be deployed and versioned separately from the core?
   - **Yes** it is `client-server`: the core publishes a contract and hosts no interface.
     The interface is a separate project (`bootstrap-react-mvvm`).
   - **No** it is `standalone`: core and interface ship as one artifact, and the interface
     is an inbound adapter of this hexagon.
3. **Confirm with user**: project name (kebab-case), the target parent directory, the
   topology, and a one-sentence description of what the application does.

## Steps

1. **Run the scaffolder** at `<this-skill>/bootstrap.py`:

   ```bash
   python bootstrap.py \
     --target <parent-dir> \
     --project-name <name> \
     --topology <client-server|standalone> \
     --description "<one sentence>"
   ```

   It writes the tree below. Idempotent: any file that already exists is skipped.

2. **Install and prove it**:

   ```bash
   cd <target>/<project-name>
   npm install
   npm run lint     # tsc --noEmit
   npm test         # the use case with ports substituted, and the boundary test
   npm start
   ```

3. **Replace the example slice** with the real domain, then delete the example files.

4. **For a standalone application, add the interface** as an inbound adapter under
   `src/adapters/inbound/ui/`: `bootstrap-atomic-shadcn` for the view layer
   (`REF-AtomicDesign.md`), then `bootstrap-electron` when it ships as a desktop app. The
   scaffolded CLI adapter stays or goes; both are inbound adapters of the same core.

## What it produces

```
<target>/<project-name>/
├── package.json               # type: module, tsx, vitest, tsc
├── tsconfig.json              # strict, ES2020, @/* path alias
├── vitest.config.ts           # the same alias for the suite
├── README.md                  # what it does and deliberately doesn't
└── src/
    ├── domain/
    │   ├── model/Item.ts             # entity carrying the one business rule
    │   └── errors/index.ts           # DomainError, ItemNotFound
    ├── application/
    │   ├── ports/inbound/            # SettleItemPort, ListItemsPort
    │   ├── ports/outbound/           # ItemRepository
    │   └── useCases/                 # SettleItemUseCase, ListItemsUseCase
    ├── adapters/
    │   ├── inbound/http/             # client-server: node:http, routes to port calls
    │   │   or inbound/cli/           # standalone: argv to port calls
    │   └── outbound/memory/          # InMemoryItemRepository
    ├── container.ts                  # factories return inbound port types
    └── index.ts                      # builds the container, starts the adapter
└── tests/
    ├── settleItem.test.ts     # use case with the outbound port substituted, no I/O
    └── boundaries.test.ts     # walks the import graph, asserts the dependency rule
```

## The example slice

An `Item` domain (list, settle) wired end to end. It exists to demonstrate every layer
and the boundary test; replace it with the real domain and delete the example files once
your own use cases exist.

## The boundary test is the point

The generated suite walks the import graph and fails when `domain/` imports `application/`
or `adapters/`, when `application/` imports an adapter, or when an inbound adapter reaches
past its port to a use case class. This is the category `REF-CleanArchitecture.md` §11
mandates. Extend it as layers are added; do not delete it as boilerplate.

## Failure modes

- **A target file already exists**: it is skipped (idempotent) and the rest are still
  written. Re-run safely.
- **Project name is not kebab-case**: rejected before anything is written.
- **`--topology` omitted**: rejected. There is no default, by design; settle it in
  pre-flight step 2.
- **The boundary test fails on first run**: an example file was moved between layers.
  Move it back or fix the import; the test names the file and the offending specifier.

## See also

- `REF-TypeScript.md` (the tree, ports, container), `REF-CleanArchitecture.md` §1 (topology).
- `bootstrap-hexagonal-backend`: the same shape in Python and FastAPI.
- `bootstrap-react-mvvm`: the separate client project a client-server core is consumed by.
- `bootstrap-atomic-shadcn`, `bootstrap-electron`: a standalone application's view layer
  and desktop shell.
