---
name: audit-intent
description: Audit any CSD intent project - validate intent.yaml against CSD-INTENT-01, check that every @intent / intent() test marker references a real claim, and report unattested claims. Cross-runtime, scanning Python (.py) and JS/TS (.ts, .tsx, .js, .jsx) test files in the same pass. Thin wrapper over the standalone csd-intent CLI.
galaxy: craft
refs:
  - REF-CSD
  - REF-Tests
---

# Audit intent

Invoked when the user wants to verify the health of a CSD intent project - confirm `intent.yaml` matches the canonical schema, catch typos where a test references a non-existent claim, and surface claims that have no test marker anywhere.

This skill is the *auditor* sibling of the `bootstrap-*-intent` skills. The bootstrap skills install the language-specific test marker (`@intent` for pytest, `intent()` for vitest/playwright). The auditor reads all of them, regardless of which marker package put them there.

## Pre-flight

1. **Read** `REF-CSD.md` and `../csd-library/csd-intent/README.md` for the model.
2. **Confirm target** - directory containing `intent.yaml` at the root, or any subdirectory of a project the user wants to audit.
3. **Confirm `csd-intent` is installed**:
   ```bash
   csd-intent --version
   ```
   If not, install it:
   ```bash
   pip install "csd-intent>=0.6.0,<0.7"
   ```
   (Any Python venv works - the tool only depends on PyYAML.)

## What it does

Runs three checks and reports violations:

| Check | Catches |
|---|---|
| **schema** | `intent.yaml` claims missing required fields, wrong types, invalid enum values |
| **orphan** | A test marker references an `INT-NNN` that doesn't exist in `intent.yaml` |
| **unattested** | A claim in `intent.yaml` has no test marker anywhere in the project |

The walker scans `.py` (via AST), `.ts/.tsx/.js/.jsx/.mts/.cts` (via regex). Standard excludes: `node_modules`, `.venv`, `dist`, `__pycache__`, etc.

## Steps

1. **Run the audit** against the project root (default: cwd):
   ```bash
   csd-intent <project-dir>
   ```
   Or with explicit options:
   ```bash
   csd-intent /path/to/project \
     --tests-dir backend/tests \
     --tests-dir frontend/src \
     --tests-dir e2e
   ```
2. **Read the output**. A clean audit prints:
   ```
   intent.yaml (.../intent.yaml): 36 claims, 36 attested. CLEAN.
   ```
   Violations are grouped by kind (SCHEMA / ORPHAN / UNATTESTED), each with the claim ID and a short reason.
3. **Surface to user** - exit code 0 means clean. Non-zero exit means at least one violation. Default `--fail-on any` (every kind fails); use `--fail-on schema` to tolerate unattested claims (the "intent before test" workflow).

## Options worth knowing

| Flag | Purpose |
|---|---|
| `--intent PATH` | Override the intent.yaml location (default: `<project>/intent.yaml`). |
| `--tests-dir DIR` | Restrict the walker to specific dirs (repeatable). Default scans everything. |
| `--fail-on schema\|orphan\|unattested\|any\|none` | Which violation kinds cause non-zero exit. |
| `--quiet` | One-line summary only (suppresses per-violation list). |

## Failure modes

- **`intent.yaml` not found** - surface the resolved path so the user can either move the file or pass `--intent`.
- **`csd-intent` not on PATH** - the venv it was installed into isn't active. Either activate the venv or invoke via `<venv>/bin/python -m csd_intent.cli`.
- **All claims report as unattested** - check the `--tests-dir` filter; the walker may be looking in the wrong place. Default (no filter) scans the whole project.
- **In a monorepo with multiple modules** - each module has its own `intent.yaml`. Audit each module separately (`csd-intent module-a`, `csd-intent module-b`) rather than the monorepo root, otherwise the walker finds markers for the *other* module's claims and reports them as orphans.

## See also

- `../csd-library/csd-intent/` - the package this skill invokes
- `bootstrap-pytest-intent` skill - Python `@intent` decorator
- `bootstrap-vitest-intent` skill - JS/TS `intent()` wrapper
- `bootstrap-playwright-intent` skill - e2e `intent()` wrapper
- `REF-CSD.md` - methodology
