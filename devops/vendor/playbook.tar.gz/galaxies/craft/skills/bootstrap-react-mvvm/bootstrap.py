"""Scaffolder for the bootstrap-react-mvvm skill.

Writes a REF-conformant React + TypeScript + Tailwind MVVM frontend whose Model
layer is generated from a supplied OpenAPI spec. Copies the spec to
src/models/openapi.json and writes the project. Idempotent: existing files skipped.
Templates use sentinels replaced at write time; no .format is used.

src/components/ui/ is shadcn CLI territory, never hand-written (REF-Frontend
section 2), so the scaffold writes the components.json the CLI reads and the
example slice's one primitive arrives with `npx shadcn@latest add card`.

Every component is a folder (REF-Frontend section 9): the component with its exported
props, a test, a story (REF-Frontend section 5.1; not for pages), and an index.ts
barrel. src/structure.test.ts fails the build on anything else.
"""

from __future__ import annotations

import argparse
import shutil
from pathlib import Path

FILES: dict[str, str] = {
    "package.json": r'''{
    "name": "__NAME__",
    "private": true,
    "version": "0.1.0",
    "type": "module",
    "scripts": {
        "dev": "vite",
        "build": "npm run api:generate && tsc --noEmit && vite build",
        "preview": "vite preview",
        "api:export": "node scripts/fetch-openapi.mjs",
        "api:generate": "openapi-typescript src/models/openapi.json -o src/models/schema.d.ts && node scripts/generate-barrel.mjs",
        "api:sync": "npm run api:export && npm run api:generate",
        "lint": "eslint .",
        "lint:fix": "eslint . --fix",
        "format": "prettier --write .",
        "format:check": "prettier --check .",
        "style": "npm run format && npm run lint:fix",
        "style:check": "npm run format:check && npm run lint",
        "test": "vitest run",
        "test:coverage": "vitest run --coverage",
        "test:watch": "vitest",
        "storybook": "storybook dev -p 6006",
        "build-storybook": "storybook build"
    },
    "dependencies": {
        "class-variance-authority": "^0.7.0",
        "clsx": "^2.1.1",
        "react": "^18.3.1",
        "react-dom": "^18.3.1",
        "tailwind-merge": "^2.5.2",
        "zustand": "^4.5.5"
    },
    "devDependencies": {
        "@eslint/js": "^9.11.1",
        "@storybook/addon-a11y": "^10.6.0",
        "@storybook/react-vite": "^10.6.0",
        "@testing-library/jest-dom": "^6.5.0",
        "@testing-library/react": "^16.0.1",
        "@types/node": "^22.7.4",
        "@types/react": "^18.3.10",
        "@types/react-dom": "^18.3.0",
        "@vitejs/plugin-react": "^6.1.1",
        "autoprefixer": "^10.4.20",
        "eslint": "^9.11.1",
        "eslint-plugin-react": "^7.37.2",
        "eslint-plugin-react-hooks": "^5.1.0",
        "eslint-plugin-jsx-a11y": "^6.10.0",
        "eslint-plugin-react-refresh": "^0.4.12",
        "eslint-plugin-sonarjs": "^3.0.2",
        "globals": "^15.9.0",
        "jsdom": "^25.0.1",
        "openapi-typescript": "^7.4.1",
        "postcss": "^8.4.47",
        "prettier": "^3.3.3",
        "storybook": "^10.6.0",
        "tailwindcss": "^3.4.13",
        "typescript": "^5.6.2",
        "typescript-eslint": "^8.7.0",
        "vite": "^8.3.2",
        "@vitest/coverage-v8": "^5.0.3",
        "vitest": "^5.0.3",
        "vitest-axe": "^1.0.0-pre.5"
    }
}
''',
    "index.html": r'''<!doctype html>
<html lang="en" class="dark">
    <head>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>__TITLE__</title>
    </head>
    <body>
        <div id="root"></div>
        <script type="module" src="/src/main.tsx"></script>
    </body>
</html>
''',
    "vite.config.ts": r'''import { fileURLToPath, URL } from 'node:url';

import react from '@vitejs/plugin-react';
import { defineConfig } from 'vitest/config';

export default defineConfig({
    plugins: [react()],
    resolve: {
        alias: {
            '@': fileURLToPath(new URL('./src', import.meta.url)),
        },
    },
    server: {
        port: 5173,
        proxy: {
            '/api': {
                target: '__APIBASE__',
                changeOrigin: true,
            },
        },
    },
    test: {
        environment: 'jsdom',
        globals: true,
        setupFiles: './src/test-setup.ts',
        coverage: {
            provider: 'v8',
            reporter: ['text', 'lcov'],
            reportsDirectory: './coverage',
            exclude: ['src/models/**', 'src/components/ui/**'],
        },
    },
});
''',
    "tsconfig.json": r'''{
    "compilerOptions": {
        "target": "ES2020",
        "useDefineForClassFields": true,
        "lib": ["ES2020", "DOM", "DOM.Iterable"],
        "module": "ESNext",
        "moduleResolution": "bundler",
        "jsx": "react-jsx",
        "strict": true,
        "noUnusedLocals": true,
        "noUnusedParameters": true,
        "noFallthroughCasesInSwitch": true,
        "esModuleInterop": true,
        "skipLibCheck": true,
        "resolveJsonModule": true,
        "isolatedModules": true,
        "noEmit": true,
        "allowImportingTsExtensions": false,
        "types": ["node", "vitest/globals", "@testing-library/jest-dom/vitest"],
        "baseUrl": ".",
        "paths": {
            "@/*": ["./src/*"]
        }
    },
    "include": ["src", "vite.config.ts"]
}
''',
    "tailwind.config.js": r'''/** @type {import('tailwindcss').Config} */
export default {
    darkMode: ['class'],
    content: ['./index.html', './src/**/*.{ts,tsx}'],
    theme: {
        extend: {
            colors: {
                border: 'hsl(var(--border))',
                input: 'hsl(var(--input))',
                ring: 'hsl(var(--ring))',
                background: 'hsl(var(--background))',
                foreground: 'hsl(var(--foreground))',
                primary: {
                    DEFAULT: 'hsl(var(--primary))',
                    foreground: 'hsl(var(--primary-foreground))',
                },
                secondary: {
                    DEFAULT: 'hsl(var(--secondary))',
                    foreground: 'hsl(var(--secondary-foreground))',
                },
                muted: {
                    DEFAULT: 'hsl(var(--muted))',
                    foreground: 'hsl(var(--muted-foreground))',
                },
                accent: {
                    DEFAULT: 'hsl(var(--accent))',
                    foreground: 'hsl(var(--accent-foreground))',
                },
                destructive: {
                    DEFAULT: 'hsl(var(--destructive))',
                    foreground: 'hsl(var(--destructive-foreground))',
                },
                card: {
                    DEFAULT: 'hsl(var(--card))',
                    foreground: 'hsl(var(--card-foreground))',
                },
            },
            borderRadius: {
                lg: 'var(--radius)',
                md: 'calc(var(--radius) - 2px)',
                sm: 'calc(var(--radius) - 4px)',
            },
            fontFamily: {
                mono: ['ui-monospace', 'SFMono-Regular', 'Menlo', 'Consolas', 'monospace'],
            },
        },
    },
    plugins: [],
};
''',
    "postcss.config.js": r'''export default {
    plugins: {
        tailwindcss: {},
        autoprefixer: {},
    },
};
''',
    # The shadcn CLI's config. It is what makes `npx shadcn@latest add <name>` write
    # into src/components/ui/, the one source of that folder's content (REF-Frontend
    # section 2). The `utils` alias points at src/utils.ts, where cn() already lives
    # (section 1), so the CLI reuses it instead of writing a second one under lib/.
    "components.json": r'''{
    "$schema": "https://ui.shadcn.com/schema.json",
    "style": "default",
    "rsc": false,
    "tsx": true,
    "tailwind": {
        "config": "tailwind.config.js",
        "css": "src/index.css",
        "baseColor": "slate",
        "cssVariables": true,
        "prefix": ""
    },
    "aliases": {
        "components": "@/components",
        "utils": "@/utils",
        "ui": "@/components/ui"
    }
}
''',
    ".prettierrc": r'''{
    "tabWidth": 4,
    "useTabs": false,
    "singleQuote": true,
    "semi": true,
    "trailingComma": "all",
    "printWidth": 100,
    "jsxSingleQuote": false
}
''',
    ".editorconfig": r'''root = true

[*]
indent_style = space
indent_size = 4
end_of_line = lf
charset = utf-8
trim_trailing_whitespace = true
insert_final_newline = true
''',
    "eslint.config.js": r'''import js from '@eslint/js';
import react from 'eslint-plugin-react';
import jsxA11y from 'eslint-plugin-jsx-a11y';
import reactHooks from 'eslint-plugin-react-hooks';
import reactRefresh from 'eslint-plugin-react-refresh';
import sonarjs from 'eslint-plugin-sonarjs';
import globals from 'globals';
import tseslint from 'typescript-eslint';

export default tseslint.config(
    { ignores: ['dist', 'node_modules', 'src/models', 'src/components/ui', 'storybook-static', 'coverage'] },
    {
        extends: [
            js.configs.recommended,
            ...tseslint.configs.recommended,
            sonarjs.configs.recommended,
            // The static accessibility tier (REF-Accessibility.md §10), at strict, as
            // errors: missing accessible names, invalid ARIA, contradictory roles,
            // unlabelled inputs, click handlers on non-interactive elements. It catches
            // only a minority of real conformance failures, so it never stands in for
            // the manual keyboard and screen-reader passes (§10 there).
            jsxA11y.flatConfigs.strict,
        ],
        files: ['**/*.{ts,tsx}'],
        languageOptions: {
            ecmaVersion: 2020,
            globals: globals.browser,
        },
        plugins: {
            react,
            'react-hooks': reactHooks,
            'react-refresh': reactRefresh,
        },
        settings: { react: { version: 'detect' } },
        rules: {
            ...reactHooks.configs.recommended.rules,
            'react-refresh/only-export-components': ['warn', { allowConstantExport: true }],
            '@typescript-eslint/no-explicit-any': 'error',
            '@typescript-eslint/no-unused-vars': ['error', { argsIgnorePattern: '^_' }],
            // NOSONAR is banned (REF-Frontend.md §10.5): it silences every rule on the
            // line, forever and invisibly. Fix the code, or resolve the issue on the
            // SonarQube server as a false positive with a written justification.
            'no-warning-comments': [
                'error',
                { terms: ['nosonar', 'no-sonar'], location: 'anywhere' },
            ],
        },
    },
    {
        // Component rules a linter can decide (REF-Frontend section 10.6). No default
        // export anywhere in views/ - components or barrels; React.lazy's default is
        // mapped at the route declaration instead (section 7), never carved out here.
        files: ['src/views/**/*.{ts,tsx}'],
        ignores: ['**/*.stories.tsx'],
        rules: {
            '@typescript-eslint/consistent-type-definitions': ['error', 'interface'],
            'react/function-component-definition': [
                'error',
                { namedComponents: 'arrow-function', unnamedComponents: 'arrow-function' },
            ],
            'no-restricted-exports': [
                'error',
                {
                    restrictDefaultExports: {
                        direct: true,
                        named: true,
                        defaultFrom: true,
                        namedFrom: true,
                        namespaceFrom: true,
                    },
                },
            ],
        },
    },
);
''',
    ".gitignore": r'''node_modules/
coverage/
dist/
.vite/
coverage/
.scannerwork/
*.local
storybook-static/
src/models/schema.d.ts
src/models/index.ts
''',
    ".prettierignore": r'''dist
node_modules
src/models
src/components/ui
storybook-static
''',
    # Storybook (REF-Frontend section 5.1): the stories resolve through the app's own
    # vite.config.ts, so the @ alias and Tailwind work unchanged inside them.
    ".storybook/main.ts": r'''import type { StorybookConfig } from '@storybook/react-vite';

const config: StorybookConfig = {
    stories: ['../src/views/**/*.stories.@(ts|tsx)'],
    addons: ['@storybook/addon-a11y'],
    framework: {
        name: '@storybook/react-vite',
        options: {},
    },
};

export default config;
''',
    ".storybook/preview.ts": r'''import type { Preview } from '@storybook/react-vite';

import '@/index.css';

// Mirrors index.html, which renders the app under the dark theme's tokens.
document.documentElement.classList.add('dark');

const preview: Preview = {
    parameters: {
        controls: { matchers: { color: /(background|color)$/i, date: /Date$/i } },
    },
};

export default preview;
''',
    "scripts/generate-barrel.mjs": r'''// Generates src/models/index.ts: friendly type aliases for each OpenAPI schema.
// Auto-run by the api:generate npm script. Never hand-edit src/models/.

import { readFileSync, writeFileSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const here = dirname(fileURLToPath(import.meta.url));
const root = resolve(here, '..');
const spec = JSON.parse(readFileSync(resolve(root, 'src/models/openapi.json'), 'utf8'));
const schemas = Object.keys(spec.components?.schemas ?? {}).sort();

const lines = [
    '// AUTO-GENERATED by scripts/generate-barrel.mjs. Do not edit.',
    "import type { components } from './schema';",
    '',
    "export type Schemas = components['schemas'];",
    '',
    ...schemas.map((name) => `export type ${name} = components['schemas']['${name}'];`),
    '',
];

writeFileSync(resolve(root, 'src/models/index.ts'), lines.join('\n'), 'utf8');
console.log(`Generated barrel with ${schemas.length} schema types.`);
''',
    "scripts/fetch-openapi.mjs": r'''// Refresh src/models/openapi.json from a running backend's /openapi.json.
// Override the base with API_BASE; defaults to the dev-proxy target.

import { writeFileSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const here = dirname(fileURLToPath(import.meta.url));
const root = resolve(here, '..');
const base = (process.env.API_BASE ?? '__APIBASE__').replace(/\/$/, '');
const url = `${base}/openapi.json`;

const response = await fetch(url);
if (!response.ok) {
    throw new Error(`Failed to fetch ${url}: ${response.status} ${response.statusText}`);
}
const spec = await response.json();
const out = resolve(root, 'src/models/openapi.json');
writeFileSync(out, `${JSON.stringify(spec, null, 2)}\n`, 'utf8');
console.log(`Wrote ${out} from ${url}`);
''',
    "src/vite-env.d.ts": r'''/// <reference types="vite/client" />
''',
    "sonar-project.properties": r'''# SonarQube scanner config (REF-Frontend.md §10.5).
# The quality profile is the server's default ("Sonar way"), unmodified: no rule is
# disabled here. Set sonar.host.url and the token in CI, never in this file.
sonar.projectKey=__NAME__
sonar.projectName=__NAME__
sonar.sources=src
sonar.tests=src
sonar.test.inclusions=**/*.test.ts,**/*.test.tsx
sonar.exclusions=src/models/**,src/components/ui/**,dist/**,coverage/**
sonar.coverage.exclusions=**/*.test.ts,**/*.test.tsx,src/main.tsx,src/App.tsx
sonar.javascript.lcov.reportPaths=coverage/lcov.info
sonar.sourceEncoding=UTF-8
''',
    "src/test-setup.ts": r'''import '@testing-library/jest-dom/vitest';

// The runtime accessibility tier (REF-Accessibility.md §10): every page- and
// organism-level test asserts its rendered tree has no violations, which catches
// accessible names, role and ARIA validity, label relationships, image
// alternatives, duplicate ids and orphaned ARIA refs that the static tier cannot
// see. Usage, as in ItemRow.test.tsx:
//   await expect(axe(container)).resolves.toHaveNoViolations();
//
// It does NOT cover contrast or landmark structure: this DOM has no layout engine,
// so vitest-axe turns every colour rule off, and the run is scoped to the
// container, not the document. Contrast is validated per token pair; page
// structure is reviewed and checked in a browser.
//
// This entrypoint, not 'vitest-axe/matchers' plus expect.extend: only
// extend-expect carries the `declare module 'vitest'` augmentation, and without it
// tsc --noEmit fails on toHaveNoViolations (the build script runs tsc).
import 'vitest-axe/extend-expect';
''',
    "src/main.tsx": r'''import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';

import { App } from '@/App';

import '@/index.css';

const container = document.getElementById('root');
if (container === null) {
    throw new Error('Root element #root not found');
}

createRoot(container).render(
    <StrictMode>
        <App />
    </StrictMode>,
);
''',
    "src/App.tsx": r'''import { DashboardPage } from '@/views/pages/DashboardPage';
import { MainLayout } from '@/views/templates/MainLayout';

export const App = () => (
    <MainLayout>
        <DashboardPage />
    </MainLayout>
);
''',
    "src/index.css": r'''@tailwind base;
@tailwind components;
@tailwind utilities;

@layer base {
    :root {
        --background: 0 0% 100%;
        --foreground: 222 47% 11%;
        --card: 0 0% 100%;
        --card-foreground: 222 47% 11%;
        --primary: 221 83% 53%;
        --primary-foreground: 0 0% 100%;
        --secondary: 210 40% 96%;
        --secondary-foreground: 222 47% 11%;
        --muted: 210 40% 96%;
        --muted-foreground: 215 19% 40%;
        --accent: 210 40% 94%;
        --accent-foreground: 222 47% 11%;
        --destructive: 0 72% 51%;
        --destructive-foreground: 0 0% 100%;
        --border: 214 32% 88%;
        --input: 214 20% 55%;
        --ring: 221 83% 53%;
        --radius: 0.5rem;
    }

    .dark {
        --background: 222 47% 11%;
        --foreground: 210 40% 98%;
        --card: 222 45% 13%;
        --card-foreground: 210 40% 98%;
        --primary: 217 91% 60%;
        --primary-foreground: 222 47% 11%;
        --secondary: 217 33% 18%;
        --secondary-foreground: 210 40% 98%;
        --muted: 217 33% 17%;
        --muted-foreground: 215 20% 65%;
        --accent: 217 33% 21%;
        --accent-foreground: 210 40% 98%;
        --destructive: 0 84% 65%;
        --destructive-foreground: 222 47% 11%;
        --border: 217 33% 24%;
        --input: 217 20% 49%;
        --ring: 217 91% 60%;
        --radius: 0.5rem;
    }
}

@layer base {
    * {
        border-color: hsl(var(--border));
    }

    body {
        background-color: hsl(var(--background));
        color: hsl(var(--foreground));
    }
}
''',
    "src/utils.ts": r'''import { type ClassValue, clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';

/** Merge Tailwind class names, resolving conflicts. */
export function cn(...inputs: ClassValue[]): string {
    return twMerge(clsx(inputs));
}

/** Fetch JSON from the API, throwing an Error with the server-provided detail on failure. */
export async function apiFetch<T>(path: string, init?: RequestInit): Promise<T> {
    const response = await fetch(path, {
        headers: { 'Content-Type': 'application/json' },
        ...init,
    });
    if (!response.ok) {
        let detail = `${response.status} ${response.statusText}`;
        try {
            const body = (await response.json()) as { detail?: string; error?: string };
            detail = body.detail ?? body.error ?? detail;
        } catch {
            // Non-JSON error body; keep the status text.
        }
        throw new Error(detail);
    }
    return (await response.json()) as T;
}
''',
    "src/viewmodels/items/items.state.ts": r'''import type { ItemResponse } from '@/models';

export interface ItemsState {
    items: ItemResponse[];
    loading: boolean;
    error: string | null;
}
''',
    "src/viewmodels/items/items.model.ts": r'''import type { ItemsState } from './items.state';

export const selectItemCount = (state: ItemsState): number => state.items.length;
''',
    "src/viewmodels/items/items.actions.ts": r'''import { create } from 'zustand';

import type { ItemResponse } from '@/models';
import { apiFetch } from '@/utils';

import type { ItemsState } from './items.state';

interface ItemsActions {
    load: () => Promise<void>;
}

export const useItems = create<ItemsState & ItemsActions>()((set) => ({
    items: [],
    loading: false,
    error: null,

    load: async () => {
        set({ loading: true, error: null });
        try {
            const items = await apiFetch<ItemResponse[]>('/api/items');
            set({ items });
        } catch (err) {
            set({ error: err instanceof Error ? err.message : 'Failed to load items' });
        } finally {
            set({ loading: false });
        }
    },
}));
''',
    "src/viewmodels/items/index.ts": r'''export type { ItemsState } from './items.state';
export { selectItemCount } from './items.model';
export { useItems } from './items.actions';
''',
    # Views: one folder per component (REF-Frontend section 9). Each folder holds the
    # component with its exported props, a test, a story (not for pages), and an
    # index.ts barrel; the test and the story import the component by relative path,
    # everything else imports the folder.
    "src/views/atoms/Spinner/Spinner.tsx": r'''import { cn } from '@/utils';

export interface SpinnerProps {
    className?: string;
}

// Decorative: the organism that shows it announces the loading state in its own
// live region (REF-Accessibility.md §6), so the spinner is never a second one.
export const Spinner = ({ className }: SpinnerProps) => (
    <div
        aria-hidden="true"
        className={cn(
            'size-4 animate-spin rounded-full border-2 border-muted border-t-foreground',
            className,
        )}
    />
);
''',
    "src/views/atoms/Spinner/Spinner.test.tsx": r'''import { render, screen } from '@testing-library/react';
import { describe, expect, it } from 'vitest';

import { Spinner } from './Spinner';

describe('Spinner', () => {
    it('is decorative: the organism that shows it announces the state', () => {
        const { container } = render(<Spinner />);
        expect(container.firstElementChild).toHaveAttribute('aria-hidden', 'true');
        expect(screen.queryByRole('status')).toBeNull();
    });
});
''',
    "src/views/atoms/Spinner/Spinner.stories.tsx": r'''import type { Meta, StoryObj } from '@storybook/react-vite';

import { Spinner } from './Spinner';

const meta = {
    title: 'Atoms/Spinner',
    component: Spinner,
} satisfies Meta<typeof Spinner>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {};

export const Large: Story = {
    args: { className: 'size-8' },
};
''',
    "src/views/atoms/Spinner/index.ts": r'''export { Spinner } from './Spinner';
export type { SpinnerProps } from './Spinner';
''',
    "src/views/molecules/ItemRow/ItemRow.tsx": r'''import type { ItemResponse } from '@/models';

export interface ItemRowProps {
    item: ItemResponse;
}

export const ItemRow = ({ item }: ItemRowProps) => (
    <div className="flex items-center gap-3 border-b border-border/60 px-3 py-2 text-sm">
        <span className="font-mono text-muted-foreground">{item.id}</span>
        <span>{item.name}</span>
    </div>
);
''',
    "src/views/molecules/ItemRow/ItemRow.test.tsx": r'''import { render, screen } from '@testing-library/react';
import { describe, expect, it } from 'vitest';

import { axe } from 'vitest-axe';

import { ItemRow } from './ItemRow';

describe('ItemRow', () => {
    it('renders the item name', () => {
        render(<ItemRow item={{ id: '1', name: 'Widget' }} />);
        // Query by role and accessible name where the element has them; text is the
        // fallback (REF-React.md §6). A test id is the last resort.
        expect(screen.getByText('Widget')).toBeInTheDocument();
    });

    // The runtime accessibility tier (REF-Accessibility.md §10). Keep this shape on
    // every organism and page test: it is the half of the gate a linter cannot reach.
    it('has no accessibility violations', async () => {
        const { container } = render(<ItemRow item={{ id: '1', name: 'Widget' }} />);
        await expect(axe(container)).resolves.toHaveNoViolations();
    });
});
''',
    "src/views/molecules/ItemRow/ItemRow.stories.tsx": r'''import type { Meta, StoryObj } from '@storybook/react-vite';

import { ItemRow } from './ItemRow';

const meta = {
    title: 'Molecules/ItemRow',
    component: ItemRow,
    args: { item: { id: '1', name: 'Widget' } },
} satisfies Meta<typeof ItemRow>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {};
''',
    "src/views/molecules/ItemRow/index.ts": r'''export { ItemRow } from './ItemRow';
export type { ItemRowProps } from './ItemRow';
''',
    "src/views/organisms/ItemsTable/ItemsTable.tsx": r'''import { useItems } from '@/viewmodels/items';
import { Spinner } from '@/views/atoms/Spinner';
import { ItemRow } from '@/views/molecules/ItemRow';

export const ItemsTable = () => {
    const { items, loading, error } = useItems();
    const status = loading ? 'Loading items.' : error ? '' : `${items.length} items loaded.`;

    // The organism owns the live regions for its own asynchronous state, and both
    // exist before their messages do (REF-Accessibility.md §6): polite for the
    // outcome, assertive only for the failure that stops the user.
    return (
        <div className="rounded-lg border bg-card">
            <p role="status" className="sr-only">
                {status}
            </p>
            <div role="alert">
                {error && <p className="p-6 text-sm text-destructive">{error}</p>}
            </div>
            {loading && items.length === 0 && (
                <div className="flex items-center gap-2 p-6 text-sm text-muted-foreground">
                    <Spinner /> Loading...
                </div>
            )}
            {!error && items.length > 0 && (
                <ul>
                    {items.map((item) => (
                        <li key={item.id}>
                            <ItemRow item={item} />
                        </li>
                    ))}
                </ul>
            )}
            {!loading && !error && items.length === 0 && (
                <p className="p-6 text-sm text-muted-foreground">No items.</p>
            )}
        </div>
    );
};
''',
    # A connected organism is tested and storied by setting its ViewModel's state through
    # the store's own setState() (REF-React section 6, REF-Frontend section 5.1), never
    # through a mocked module.
    "src/views/organisms/ItemsTable/ItemsTable.test.tsx": r'''import { render, screen } from '@testing-library/react';
import { beforeEach, describe, expect, it } from 'vitest';
import { axe } from 'vitest-axe';

import { useItems } from '@/viewmodels/items';

import { ItemsTable } from './ItemsTable';

describe('ItemsTable', () => {
    beforeEach(() => {
        useItems.setState({ items: [], loading: false, error: null });
    });

    it('renders a row per item', () => {
        useItems.setState({ items: [{ id: '1', name: 'Widget' }] });
        render(<ItemsTable />);
        expect(screen.getByText('Widget')).toBeInTheDocument();
    });

    it('shows the load error', () => {
        useItems.setState({ error: 'Failed to load items' });
        render(<ItemsTable />);
        expect(screen.getByText('Failed to load items')).toBeInTheDocument();
    });

    it('announces loading and the outcome politely, and a failure assertively', () => {
        useItems.setState({ loading: true });
        const first = render(<ItemsTable />);
        expect(screen.getByRole('status')).toHaveTextContent('Loading items.');
        first.unmount();
        useItems.setState({ loading: false, items: [{ id: '1', name: 'Widget' }] });
        const second = render(<ItemsTable />);
        expect(screen.getByRole('status')).toHaveTextContent('1 items loaded.');
        expect(screen.getAllByRole('listitem')).toHaveLength(1);
        second.unmount();
        useItems.setState({ items: [], error: 'Failed to load items' });
        render(<ItemsTable />);
        expect(screen.getByRole('alert')).toHaveTextContent('Failed to load items');
    });

    it('has no accessibility violations', async () => {
        useItems.setState({ items: [{ id: '1', name: 'Widget' }] });
        const { container } = render(<ItemsTable />);
        await expect(axe(container)).resolves.toHaveNoViolations();
    });
});
''',
    "src/views/organisms/ItemsTable/ItemsTable.stories.tsx": r'''import type { Meta, StoryObj } from '@storybook/react-vite';

import { useItems } from '@/viewmodels/items';

import { ItemsTable } from './ItemsTable';

const meta = {
    title: 'Organisms/ItemsTable',
    component: ItemsTable,
} satisfies Meta<typeof ItemsTable>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {
    beforeEach: () => {
        useItems.setState({
            items: [
                { id: '1', name: 'Widget' },
                { id: '2', name: 'Gadget' },
            ],
            loading: false,
            error: null,
        });
    },
};

export const Loading: Story = {
    beforeEach: () => {
        useItems.setState({ items: [], loading: true, error: null });
    },
};

export const Empty: Story = {
    beforeEach: () => {
        useItems.setState({ items: [], loading: false, error: null });
    },
};

export const Failed: Story = {
    beforeEach: () => {
        useItems.setState({ items: [], loading: false, error: 'Failed to load items' });
    },
};
''',
    "src/views/organisms/ItemsTable/index.ts": r'''export { ItemsTable } from './ItemsTable';
''',
    "src/views/templates/MainLayout/MainLayout.tsx": r'''import type { ReactNode } from 'react';

export interface MainLayoutProps {
    children: ReactNode;
}

export const MainLayout = ({ children }: MainLayoutProps) => (
    <div className="min-h-screen bg-background text-foreground">
        <header className="border-b">
            <div className="mx-auto max-w-5xl px-4 py-3">
                <p className="text-lg font-semibold">__TITLE__</p>
            </div>
        </header>
        <main className="mx-auto max-w-5xl px-4 py-4">{children}</main>
    </div>
);
''',
    "src/views/templates/MainLayout/MainLayout.test.tsx": r'''import { render, screen } from '@testing-library/react';
import { describe, expect, it } from 'vitest';

import { MainLayout } from './MainLayout';

describe('MainLayout', () => {
    it('renders the app name and its content, and leaves the h1 to the page', () => {
        render(
            <MainLayout>
                <p>Content</p>
            </MainLayout>,
        );
        expect(screen.getByText('__TITLE__')).toBeInTheDocument();
        expect(screen.queryByRole('heading', { level: 1 })).toBeNull();
        expect(screen.getByText('Content')).toBeInTheDocument();
    });
});
''',
    "src/views/templates/MainLayout/MainLayout.stories.tsx": r'''import type { Meta, StoryObj } from '@storybook/react-vite';

import { MainLayout } from './MainLayout';

const meta = {
    title: 'Templates/MainLayout',
    component: MainLayout,
    parameters: { layout: 'fullscreen' },
    args: { children: <div className="h-32 rounded-lg border border-dashed" /> },
} satisfies Meta<typeof MainLayout>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {};
''',
    "src/views/templates/MainLayout/index.ts": r'''export { MainLayout } from './MainLayout';
export type { MainLayoutProps } from './MainLayout';
''',
    "src/views/pages/DashboardPage/DashboardPage.tsx": r'''import { useEffect } from 'react';

import { Card, CardContent } from '@/components/ui/card';
import { selectItemCount, useItems } from '@/viewmodels/items';
import { ItemsTable } from '@/views/organisms/ItemsTable';

export const DashboardPage = () => {
    const load = useItems((state) => state.load);
    const count = useItems(selectItemCount);

    useEffect(() => {
        void load();
    }, [load]);

    return (
        <div className="flex flex-col gap-4">
            <h1 className="text-xl font-semibold">Dashboard</h1>
            <Card>
                <CardContent className="p-4">
                    <p className="text-xs uppercase tracking-wide text-muted-foreground">Items</p>
                    <p className="text-2xl font-bold">{count}</p>
                </CardContent>
            </Card>
            <ItemsTable />
        </div>
    );
};
''',
    "src/views/pages/DashboardPage/DashboardPage.test.tsx": r'''import { render, screen } from '@testing-library/react';
import { describe, expect, it, vi } from 'vitest';

import { useItems } from '@/viewmodels/items';

import { DashboardPage } from './DashboardPage';

describe('DashboardPage', () => {
    it('loads the items on mount and shows their count', () => {
        const load = vi.fn(async () => {});
        useItems.setState({
            items: [{ id: '7', name: 'Widget' }],
            loading: false,
            error: null,
            load,
        });
        render(<DashboardPage />);
        expect(load).toHaveBeenCalled();
        expect(screen.getByText('1')).toBeInTheDocument();
    });
});
''',
    "src/views/pages/DashboardPage/index.ts": r'''export { DashboardPage } from './DashboardPage';
''',
    # The structure gate for REF-Frontend section 9: it fails the build on a loose file,
    # a file outside a component folder's allowlist, or an `export *` barrel.
    "src/structure.test.ts": r'''import { existsSync, readdirSync, readFileSync, statSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { describe, expect, it } from 'vitest';

const SRC = dirname(fileURLToPath(import.meta.url));
const VIEWS = join(SRC, 'views');
const COMPONENTS = join(SRC, 'components');
const LEVELS = ['atoms', 'molecules', 'organisms', 'templates', 'pages'];

const isDir = (path: string) => statSync(path).isDirectory();
const levels = LEVELS.filter((level) => existsSync(join(VIEWS, level)));
const componentsIn = (level: string) =>
    readdirSync(join(VIEWS, level)).filter((entry) => isDir(join(VIEWS, level, entry)));

describe('component folders (REF-Frontend section 9)', () => {
    it('views/ holds only level folders', () => {
        const unexpected = readdirSync(VIEWS).filter(
            (entry) => !LEVELS.includes(entry) || !isDir(join(VIEWS, entry)),
        );
        expect(unexpected).toEqual([]);
    });

    it('a level folder holds only PascalCase component folders', () => {
        const loose = levels.flatMap((level) =>
            readdirSync(join(VIEWS, level))
                .filter(
                    (entry) =>
                        !isDir(join(VIEWS, level, entry)) || !/^[A-Z][A-Za-z0-9]*$/.test(entry),
                )
                .map((entry) => `${level}/${entry}`),
        );
        expect(loose).toEqual([]);
    });

    it('a component folder holds its required files and nothing else', () => {
        const problems: string[] = [];
        for (const level of levels) {
            for (const name of componentsIn(level)) {
                const dir = join(VIEWS, level, name);
                const files = readdirSync(dir);
                const required = [`${name}.tsx`, `${name}.test.tsx`, 'index.ts'];
                if (level !== 'pages') required.push(`${name}.stories.tsx`);
                // .types.ts is allowed but never required (REF-Frontend section 9.2):
                // the rare component whose own types, not its logic, make it long.
                const allowed = [...required, `${name}.types.ts`];
                for (const file of files) {
                    if (!allowed.includes(file)) {
                        problems.push(`${level}/${name}/${file} is not allowed`);
                    }
                }
                for (const file of required) {
                    if (!files.includes(file)) {
                        problems.push(`${level}/${name}/${file} is missing`);
                    }
                }
                const barrel = join(dir, 'index.ts');
                if (existsSync(barrel) && /export \*/.test(readFileSync(barrel, 'utf8'))) {
                    problems.push(`${level}/${name}/index.ts uses export *`);
                }
            }
        }
        expect(problems).toEqual([]);
    });

    it('components/ holds only the shadcn CLI output', () => {
        const entries = existsSync(COMPONENTS) ? readdirSync(COMPONENTS) : [];
        expect(entries.filter((entry) => entry !== 'ui')).toEqual([]);
    });
});
''',
    "src/utils.test.ts": r'''import { describe, expect, it } from 'vitest';

import { cn } from '@/utils';

describe('cn', () => {
    it('merges conflicting tailwind classes, keeping the last', () => {
        expect(cn('p-2', 'p-4')).toBe('p-4');
    });

    it('drops falsy values', () => {
        expect(cn('text-sm', undefined, null, 'font-bold')).toBe('text-sm font-bold');
    });
});
''',
}


def _render(text: str, name: str, title: str, api_base: str) -> str:
    return text.replace("__NAME__", name).replace("__TITLE__", title).replace("__APIBASE__", api_base)


def main() -> None:
    parser = argparse.ArgumentParser(description="Scaffold a React MVVM frontend from an OpenAPI spec.")
    parser.add_argument("--target", required=True, help="Parent directory for the project.")
    parser.add_argument("--name", required=True, help="kebab-case project folder name.")
    parser.add_argument("--openapi", required=True, help="Path to the openapi.json to type against.")
    parser.add_argument("--title", default=None, help="UI title (default: project name).")
    parser.add_argument("--api-base", default="http://127.0.0.1:8000", help="Dev proxy target.")
    args = parser.parse_args()

    spec_src = Path(args.openapi).resolve()
    if not spec_src.is_file():
        parser.error(f"--openapi '{spec_src}' does not exist")

    title = args.title or args.name
    root = Path(args.target).resolve() / args.name
    written = 0
    skipped = 0

    for rel, content in FILES.items():
        dest = root / rel
        if dest.exists():
            skipped += 1
            continue
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_text(
            _render(content, args.name, title, args.api_base), encoding="utf-8", newline="\n"
        )
        written += 1

    spec_dest = root / "src" / "models" / "openapi.json"
    if not spec_dest.exists():
        spec_dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(spec_src, spec_dest)
        written += 1
    else:
        skipped += 1

    print(f"Scaffolded {root}: {written} files written, {skipped} skipped.")
    print("Next: npm install, npx shadcn@latest add card (the example slice's primitive),")
    print("npm run api:generate, npm run style, npm run build, npm run test.")


if __name__ == "__main__":
    main()
