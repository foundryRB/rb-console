---
name: bootstrap-react-mvvm
description: Scaffold a new React + TypeScript + Tailwind frontend in MVVM (Model / ViewModel / View) form per REF-Frontend and REF-React, with its Model layer generated from a given OpenAPI spec. Produces the Vite project, the OpenAPI to TypeScript codegen pipeline (openapi-typescript + barrel), Zustand SAM viewmodels, Atomic-Design views as one folder per component (component, test, story, index.ts barrel) with a structure test that enforces it, Storybook, the shadcn CLI config its primitives come from, eslint/prettier (4-space) with the SonarQube default rules in the lint run, the scanner config and LCOV coverage its quality gate reads, the WCAG 2.2 AA static and runtime accessibility tiers (jsx-a11y strict, axe assertions in the test setup), a vite dev proxy, and vitest. Pairs with bootstrap-hexagonal-backend.
galaxy: craft
refs:
  - REF-Frontend
  - REF-React
  - REF-Tests
  - REF-Accessibility
---

# Bootstrap React MVVM

Invoked when a new frontend is needed for an existing HTTP API: a React + TypeScript
SPA whose Model layer is generated from the backend's OpenAPI spec, with ViewModels
(SAM + Zustand) and Views (Atomic Design) per REF-Frontend and REF-React. It is the
frontend counterpart to `bootstrap-hexagonal-backend`; point it at the `openapi.json`
that skill exports.

## Pre-flight

1. **Read** `REF-Frontend.md`, `REF-React.md`, `REF-Tests.md`, `REF-Accessibility.md`. The skeleton instantiates them.
2. **Obtain the OpenAPI spec** the frontend will type against: a path to an `openapi.json`
   (for the paired backend: run its `scripts/export_openapi.py` first).
3. **Confirm with user**:
   - Project name (kebab-case folder): e.g. `order-web`
   - UI title (default = project name)
   - API base URL for the dev proxy (default `http://127.0.0.1:8000`)
4. **Confirm target path** (parent directory the project folder is created in).

## Steps

Run the helper at `<this-skill>/bootstrap.py`:

```bash
python bootstrap.py \
  --target <parent-dir> \
  --name <project-name> \
  --openapi <path-to-openapi.json> \
  [--title "<UI title>"] \
  [--api-base http://127.0.0.1:8000]
```

It copies the spec to `src/models/openapi.json` and writes the tree below. Then:

```bash
cd <target>/<name>
npm install
npx shadcn@latest add card   # the example slice's one primitive; see below
npm run api:generate   # openapi-typescript + barrel -> src/models/{schema.d.ts,index.ts}
npm run style          # prettier + eslint --fix
npm run build          # tsc --noEmit + vite build
npm run test
npm run test:coverage  # writes coverage/lcov.info for the Sonar scan
npm run dev            # http://localhost:5173, /api proxied to the backend
```

Storybook ships configured (`REF-Frontend.md` §5.1): `.storybook/` resolves through the
app's own `vite.config.ts`, so the `@` alias and Tailwind work inside stories, and every
component the scaffold writes below the page level has its story in its component
folder (`REF-Frontend.md` §9). Add one for each new atom, molecule, organism, or
template. It is a developer tool the human runs by hand (`npm run storybook`,
http://localhost:6006): do not run or build it as part of scaffolding, and it is not a CI
gate.

The lint run carries the SonarQube default rules (`eslint-plugin-sonarjs`, `recommended`),
so a Sonar finding surfaces at `npm run lint` rather than at the merge gate. The scaffold
also writes `sonar-project.properties` (sources, test pattern, exclusions matching
`REF-Frontend.md` §10.4, the LCOV path). The scanner itself runs in CI against the server's
default profile; the server URL and token are CI settings, never committed. Do not disable
a rule in `eslint.config.js` or the properties file to clear a finding (`REF-Frontend.md`
§10.5 and Anti-Patterns 17-19).

`NOSONAR` is rejected mechanically: the flat config errors on the term in any `.ts`/`.tsx`
comment (`no-warning-comments`), so `npm run lint` and the CI check both fail on it. A
genuine false positive is resolved on the SonarQube server with a justification, not
silenced in the source.

Two of the three accessibility tiers of `REF-Accessibility.md` §10 ship wired: the static
tier is `eslint-plugin-jsx-a11y` at **strict** in the same lint run, and the runtime tier is
the axe matcher registered in `src/test-setup.ts` with an example assertion in
`ItemRow.test.tsx`. Keep that assertion shape on every organism and page test as the slice
is refitted. **The third tier is not automatable**: name an owner for the keyboard,
screen-reader, zoom, and forced-colours passes, and record them per release. Tell the
engagement this at scaffold time, since a green `npm run lint` plus a green `npm run test`
is the absence of specific defects, not a WCAG 2.2 AA conformance claim.

`src/components/ui/` is the primitive layer (`REF-AtomicDesign.md` §2): shadcn CLI
territory, domain-unaware and never hand-written (`REF-Frontend.md` §2). The scaffold
writes the `components.json` the CLI reads, and every primitive the project uses arrives
through `npx shadcn@latest add <name>`. The `utils` alias is `@/utils`, so the CLI reuses
the `cn()` the scaffold already put at `src/utils.ts` (§1) rather than writing a second
one under `lib/`. The example slice imports `Card`, hence the one `add card` above; add
more as the UI grows.

Customization lands in `src/views/atoms/`, the layer you own: an atom wraps one primitive
and carries the domain meaning, look lives in the design tokens (`REF-Design.md` §2), and
a change no wrapper can reach is authored as a hand-written atom rather than edited into
`components/ui/`. That is what keeps `npx shadcn@latest add` re-runnable.

`npm run api:sync` re-fetches the spec from a running backend (`<api-base>/openapi.json`)
and regenerates types. Run it after any backend DTO/route change.

Between `api:generate` and `build`, swap the placeholder `items` example slice for the
engagement's own domain (see "The example slice" below). This is an expected build step,
not optional polish: the scaffold ships against a placeholder domain and `npm run build`
fails fast until the slice is refitted.

## What it produces

```
<target>/<name>/
├── package.json                # scripts incl. api:generate / api:sync / style / test
├── vite.config.ts              # @ alias, dev proxy /api -> <api-base>, vitest
├── tsconfig.json               # strict, @/* path
├── tailwind.config.js, postcss.config.js, index.html
├── components.json             # shadcn CLI config: ui -> @/components/ui, utils -> @/utils
├── .prettierrc (4-space), .editorconfig, eslint.config.js (flat + sonarjs + jsx-a11y strict), .gitignore
├── sonar-project.properties    # scanner config: sources, tests, exclusions, lcov path
├── .storybook/                 # main.ts (stories glob, addon-a11y), preview.ts (tokens + theme)
├── scripts/generate-barrel.mjs # friendly type aliases from the schema
├── scripts/fetch-openapi.mjs   # refresh src/models/openapi.json from the backend
└── src/
    ├── models/                 # M: openapi.json (seed) + generated schema.d.ts/index.ts (gitignored)
    ├── viewmodels/items/       # VM: state / actions (Zustand) / model / index (SAM)
    ├── views/<level>/<Name>/   # V: one folder per component (REF-Frontend §9): Name.tsx,
    │                           #    Name.test.tsx, Name.stories.tsx (not pages), index.ts
    ├── components/ui/          # shadcn CLI output (npx shadcn add); not written here
    ├── utils.ts                # cn(), apiFetch()
    ├── App.tsx, main.tsx, index.css
    ├── utils.test.ts           # vitest example test
    └── structure.test.ts       # fails the build on a file REF-Frontend §9 does not allow
```

## The example slice (expect to swap it)

A minimal `items` domain (list) wired Model -> ViewModel -> View, typed with the
generated `ItemResponse` and calling `GET /api/items` (both produced by the paired
backend skill's example). It is a deliberate throwaway: the scaffold ships one working
vertical slice against a placeholder domain, and **fitting it to the engagement's real
domain is expected build work, budgeted from the start, not surprise friction.** If your
spec lacks `ItemResponse` / `/api/items`, `npm run build` flags the missing type
immediately, which is the point: the fail-fast import proves the generated types are the
contract (REF-Frontend §3). Never hand-write API types.

The swap is mechanical but spans one placeholder domain across the tree. Rename
`items`/`ItemResponse` to the engagement's entity and repoint the API path across:

- `src/viewmodels/items/` - the four SAM files (`items.state.ts`, `items.model.ts`, `items.actions.ts`, `index.ts`); rename the folder and rewrite the `ItemResponse` type and `/api/items` path references.
- `src/views/molecules/ItemRow/`, `src/views/organisms/ItemsTable/`, `src/views/pages/DashboardPage/` - the view slice that consumes the viewmodel: rename each folder with its component, and refit the `ItemResponse` import, the inline `{ id, name }` fixtures in the tests and stories, and the `useItems.setState(...)` shapes.

The generated `@/models` barrel already exposes every schema in the spec, so the swap is
retyping against a name that exists, not authoring types.

## Failure modes

- **`--openapi` path missing** -> reject before writing.
- **Spec lacks the example's schema** -> the build fails fast on the example import; replace the example domain. This is intended (it proves the generated types are the contract).
- **A target file already exists** -> skipped (idempotent); re-run safely.

## See also

- `REF-Frontend.md`, `REF-React.md`
- `bootstrap-hexagonal-backend` skill: the paired backend whose `openapi.json` feeds this.
- `bootstrap-vitest-intent` skill: to add CSD intent testing on top.
