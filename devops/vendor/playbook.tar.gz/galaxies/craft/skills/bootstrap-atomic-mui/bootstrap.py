"""Scaffolder for the bootstrap-atomic-mui skill.

Writes an Atomic-Design views/ tree backed by MUI (@mui/material) primitives into
an existing React + TypeScript project. It lays out the five level folders and one
worked example per rung that demonstrates the composition ladder and the purity
gradient of REF-AtomicDesign (atoms/molecules stay pure; the page is the connection
seam). Every component is a folder with its test, story (not for pages) and index.ts
barrel (REF-Frontend section 9). The MUI counterpart to bootstrap-react-mvvm's
Tailwind/shadcn views: same taxonomy, different primitives source.

Idempotent: existing files are skipped, never clobbered. Files are written verbatim
(no sentinels, no .format) so the embedded TSX is exactly what lands on disk.

Usage:
    python bootstrap.py --target <project-root> [--views-root src/views]
"""

from __future__ import annotations

import argparse
from pathlib import Path

__all__ = ["main"]

# Every path is relative to the chosen views root (default: src/views). Every component is
# a folder (REF-Frontend.md section 9): the component with its exported props, a test, a
# story (not for pages), and an index.ts barrel. Imports from outside a folder go through
# the folder path with the '@/' alias for src/ (REF-TypeScript.md section 2), so the target
# project must configure it (bootstrap-react-mvvm does); the test and the story import the
# component by relative path. Named exports only (REF-React.md section 1).
FILES: dict[str, str] = {
    # --- Atoms: wrap one MUI primitive each; props in, markup out (REF-AtomicDesign §5). ---
    "atoms/StatusBadge/StatusBadge.tsx": r'''import Chip from '@mui/material/Chip';

// The atom owns the statuses it can render and their presentation mapping; a higher
// level reaches them through StatusBadgeProps, never a type of its own (REF-Frontend §9.3).
export interface StatusBadgeProps {
    status: 'active' | 'pending' | 'archived';
}

const COLOR: Record<StatusBadgeProps['status'], 'success' | 'warning' | 'default'> = {
    active: 'success',
    pending: 'warning',
    archived: 'default',
};

export const StatusBadge = ({ status }: StatusBadgeProps) => (
    <Chip label={status} color={COLOR[status]} size="small" variant="outlined" />
);
''',
    "atoms/StatusBadge/StatusBadge.test.tsx": r'''import { render, screen } from '@testing-library/react';
import { describe, expect, it } from 'vitest';

import { StatusBadge } from './StatusBadge';

// A pure atom is testable in isolation: no ViewModel, no provider, no fetch.
// That isolation is the payoff of the purity gradient (REF-AtomicDesign §5).
describe('StatusBadge', () => {
    it('renders the status as its label', () => {
        render(<StatusBadge status="active" />);
        expect(screen.getByText('active')).toBeInTheDocument();
    });
});
''',
    "atoms/StatusBadge/StatusBadge.stories.tsx": r'''import type { Meta, StoryObj } from '@storybook/react-vite';

import { StatusBadge } from './StatusBadge';

const meta = {
    title: 'Atoms/StatusBadge',
    component: StatusBadge,
    args: { status: 'active' },
} satisfies Meta<typeof StatusBadge>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Active: Story = {};

export const Pending: Story = { args: { status: 'pending' } };

export const Archived: Story = { args: { status: 'archived' } };
''',
    "atoms/StatusBadge/index.ts": r'''export { StatusBadge } from './StatusBadge';
export type { StatusBadgeProps } from './StatusBadge';
''',
    "atoms/TextInput/TextInput.tsx": r'''import TextField from '@mui/material/TextField';

export interface TextInputProps {
    label: string;
    value: string;
    /** Called on every edit with the field's new value. */
    onChange: (value: string) => void;
    placeholder?: string;
}

export const TextInput = ({ label, value, onChange, placeholder }: TextInputProps) => (
    <TextField
        label={label}
        value={value}
        placeholder={placeholder}
        size="small"
        fullWidth
        onChange={(event) => onChange(event.target.value)}
    />
);
''',
    "atoms/TextInput/TextInput.test.tsx": r'''import { fireEvent, render, screen } from '@testing-library/react';
import { describe, expect, it, vi } from 'vitest';

import { TextInput } from './TextInput';

describe('TextInput', () => {
    it('hands every edit up as the new value', () => {
        const onChange = vi.fn();
        render(<TextInput label="Name" value="" onChange={onChange} />);
        fireEvent.change(screen.getByLabelText('Name'), { target: { value: 'abc' } });
        expect(onChange).toHaveBeenCalledWith('abc');
    });
});
''',
    "atoms/TextInput/TextInput.stories.tsx": r'''import type { Meta, StoryObj } from '@storybook/react-vite';
import { fn } from 'storybook/test';

import { TextInput } from './TextInput';

const meta = {
    title: 'Atoms/TextInput',
    component: TextInput,
    args: { label: 'Name', value: '', placeholder: 'Type a name', onChange: fn() },
} satisfies Meta<typeof TextInput>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Empty: Story = {};

export const Filled: Story = { args: { value: 'First item' } };
''',
    "atoms/TextInput/index.ts": r'''export { TextInput } from './TextInput';
export type { TextInputProps } from './TextInput';
''',
    "atoms/SubmitButton/SubmitButton.tsx": r'''import Button from '@mui/material/Button';
import type { ReactNode } from 'react';

export interface SubmitButtonProps {
    children: ReactNode;
    onClick?: () => void;
    disabled?: boolean;
}

export const SubmitButton = ({ children, onClick, disabled }: SubmitButtonProps) => (
    <Button variant="contained" onClick={onClick} disabled={disabled}>
        {children}
    </Button>
);
''',
    "atoms/SubmitButton/SubmitButton.test.tsx": r'''import { fireEvent, render, screen } from '@testing-library/react';
import { describe, expect, it, vi } from 'vitest';

import { SubmitButton } from './SubmitButton';

describe('SubmitButton', () => {
    it('calls onClick when pressed', () => {
        const onClick = vi.fn();
        render(<SubmitButton onClick={onClick}>Save</SubmitButton>);
        fireEvent.click(screen.getByRole('button', { name: 'Save' }));
        expect(onClick).toHaveBeenCalledOnce();
    });

    it('is not pressable when disabled', () => {
        render(<SubmitButton disabled>Save</SubmitButton>);
        expect(screen.getByRole('button', { name: 'Save' })).toBeDisabled();
    });
});
''',
    "atoms/SubmitButton/SubmitButton.stories.tsx": r'''import type { Meta, StoryObj } from '@storybook/react-vite';
import { fn } from 'storybook/test';

import { SubmitButton } from './SubmitButton';

const meta = {
    title: 'Atoms/SubmitButton',
    component: SubmitButton,
    args: { children: 'Save', onClick: fn() },
} satisfies Meta<typeof SubmitButton>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {};

export const Disabled: Story = { args: { disabled: true } };
''',
    "atoms/SubmitButton/index.ts": r'''export { SubmitButton } from './SubmitButton';
export type { SubmitButtonProps } from './SubmitButton';
''',
    # --- Molecule: composes atoms only; one job; may hold self-contained UI state. ---
    "molecules/SearchBar/SearchBar.tsx": r'''import Stack from '@mui/material/Stack';
import { useState } from 'react';

import { SubmitButton } from '@/views/atoms/SubmitButton';
import { TextInput } from '@/views/atoms/TextInput';

export interface SearchBarProps {
    /** Called with the current query when the Search button is pressed. */
    onSearch: (query: string) => void;
    placeholder?: string;
}

// One responsibility (capture a query and hand it up), composed from two atoms.
// The transient query string is the only state a molecule may keep (REF-AtomicDesign
// §5); the actual searching is a ViewModel Action, never done here.
export const SearchBar = ({ onSearch, placeholder }: SearchBarProps) => {
    const [query, setQuery] = useState('');
    return (
        <Stack direction="row" spacing={1} sx={{ alignItems: 'center' }}>
            <TextInput label="Search" value={query} placeholder={placeholder} onChange={setQuery} />
            <SubmitButton onClick={() => onSearch(query)}>Search</SubmitButton>
        </Stack>
    );
};
''',
    "molecules/SearchBar/SearchBar.test.tsx": r'''import { fireEvent, render, screen } from '@testing-library/react';
import { describe, expect, it, vi } from 'vitest';

import { SearchBar } from './SearchBar';

describe('SearchBar', () => {
    it('hands the typed query up when Search is pressed', () => {
        const onSearch = vi.fn();
        render(<SearchBar onSearch={onSearch} />);
        fireEvent.change(screen.getByLabelText('Search'), { target: { value: 'first' } });
        fireEvent.click(screen.getByRole('button', { name: 'Search' }));
        expect(onSearch).toHaveBeenCalledWith('first');
    });
});
''',
    "molecules/SearchBar/SearchBar.stories.tsx": r'''import type { Meta, StoryObj } from '@storybook/react-vite';
import { fn } from 'storybook/test';

import { SearchBar } from './SearchBar';

const meta = {
    title: 'Molecules/SearchBar',
    component: SearchBar,
    args: { onSearch: fn(), placeholder: 'Search items' },
} satisfies Meta<typeof SearchBar>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {};
''',
    "molecules/SearchBar/index.ts": r'''export { SearchBar } from './SearchBar';
export type { SearchBarProps } from './SearchBar';
''',
    # --- Organism: a named section, composed from atoms + primitives. Props in (pure). ---
    "organisms/ItemsTable/ItemsTable.tsx": r'''import Paper from '@mui/material/Paper';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';

import type { StatusBadgeProps } from '@/views/atoms/StatusBadge';
import { StatusBadge } from '@/views/atoms/StatusBadge';

export interface ItemsTableProps {
    items: { id: string; name: string; status: StatusBadgeProps['status'] }[];
}

// This organism is presentational (props in). An organism MAY instead call its own
// SAM ViewModel hook (REF-Frontend §5); promote it to that only when a real second
// caller earns the connection (REF-AtomicDesign §3, §4). No business logic here:
// filtering/sorting is ViewModel work; the view presents (REF-AtomicDesign §5).
export const ItemsTable = ({ items }: ItemsTableProps) => (
    <TableContainer component={Paper} variant="outlined">
        <Table size="small" aria-label="items">
            <TableHead>
                <TableRow>
                    <TableCell>ID</TableCell>
                    <TableCell>Name</TableCell>
                    <TableCell>Status</TableCell>
                </TableRow>
            </TableHead>
            <TableBody>
                {items.map((item) => (
                    <TableRow key={item.id}>
                        <TableCell>{item.id}</TableCell>
                        <TableCell>{item.name}</TableCell>
                        <TableCell>
                            <StatusBadge status={item.status} />
                        </TableCell>
                    </TableRow>
                ))}
                {items.length === 0 && (
                    <TableRow>
                        <TableCell colSpan={3}>No items.</TableCell>
                    </TableRow>
                )}
            </TableBody>
        </Table>
    </TableContainer>
);
''',
    "organisms/ItemsTable/ItemsTable.test.tsx": r'''import { render, screen } from '@testing-library/react';
import { describe, expect, it } from 'vitest';

import { ItemsTable } from './ItemsTable';

describe('ItemsTable', () => {
    it('renders a row per item with its status', () => {
        render(<ItemsTable items={[{ id: '1', name: 'First item', status: 'pending' }]} />);
        expect(screen.getByText('First item')).toBeInTheDocument();
        expect(screen.getByText('pending')).toBeInTheDocument();
    });

    it('says so when there are no items', () => {
        render(<ItemsTable items={[]} />);
        expect(screen.getByText('No items.')).toBeInTheDocument();
    });
});
''',
    "organisms/ItemsTable/ItemsTable.stories.tsx": r'''import type { Meta, StoryObj } from '@storybook/react-vite';

import { ItemsTable } from './ItemsTable';

const meta = {
    title: 'Organisms/ItemsTable',
    component: ItemsTable,
    args: {
        items: [
            { id: '1', name: 'First item', status: 'active' },
            { id: '2', name: 'Second item', status: 'pending' },
            { id: '3', name: 'Third item', status: 'archived' },
        ],
    },
} satisfies Meta<typeof ItemsTable>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {};

export const Empty: Story = { args: { items: [] } };
''',
    "organisms/ItemsTable/index.ts": r'''export { ItemsTable } from './ItemsTable';
export type { ItemsTableProps } from './ItemsTable';
''',
    # --- Template: layout of organisms into a shell with slots; no real data. ---
    "templates/DashboardTemplate/DashboardTemplate.tsx": r'''import AppBar from '@mui/material/AppBar';
import Box from '@mui/material/Box';
import Container from '@mui/material/Container';
import Toolbar from '@mui/material/Toolbar';
import Typography from '@mui/material/Typography';
import type { ReactNode } from 'react';

export interface DashboardTemplateProps {
    title: string;
    /** Rendered in the header bar, after the title. */
    actions?: ReactNode;
    children: ReactNode;
}

// Structure and slots only: it positions a header bar and a content area but commits
// to no real content (REF-AtomicDesign §6). The page fills the slots. A template that
// imported a domain type to render it would have become a page.
export const DashboardTemplate = ({ title, actions, children }: DashboardTemplateProps) => (
    <Box sx={{ minHeight: '100vh' }}>
        <AppBar position="static" color="default" elevation={1}>
            <Toolbar sx={{ gap: 2 }}>
                <Typography variant="h6" component="h1" sx={{ flexGrow: 1 }}>
                    {title}
                </Typography>
                {actions}
            </Toolbar>
        </AppBar>
        <Container maxWidth="lg" sx={{ py: 3 }}>
            {children}
        </Container>
    </Box>
);
''',
    "templates/DashboardTemplate/DashboardTemplate.test.tsx": r'''import { render, screen } from '@testing-library/react';
import { describe, expect, it } from 'vitest';

import { DashboardTemplate } from './DashboardTemplate';

describe('DashboardTemplate', () => {
    it('fills its slots with what the page hands it', () => {
        render(
            <DashboardTemplate title="Items" actions={<span>action</span>}>
                <p>content</p>
            </DashboardTemplate>,
        );
        expect(screen.getByRole('heading', { name: 'Items' })).toBeInTheDocument();
        expect(screen.getByText('action')).toBeInTheDocument();
        expect(screen.getByText('content')).toBeInTheDocument();
    });
});
''',
    "templates/DashboardTemplate/DashboardTemplate.stories.tsx": r'''import Box from '@mui/material/Box';
import type { Meta, StoryObj } from '@storybook/react-vite';

import { DashboardTemplate } from './DashboardTemplate';

const meta = {
    title: 'Templates/DashboardTemplate',
    component: DashboardTemplate,
    parameters: { layout: 'fullscreen' },
    args: {
        title: 'Items',
        children: <Box sx={{ height: 128, border: '1px dashed' }} />,
    },
} satisfies Meta<typeof DashboardTemplate>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {};
''',
    "templates/DashboardTemplate/index.ts": r'''export { DashboardTemplate } from './DashboardTemplate';
export type { DashboardTemplateProps } from './DashboardTemplate';
''',
    # --- Page: one per route; binds the template to data; the connection seam. ---
    "pages/DashboardPage/DashboardPage.tsx": r'''import Typography from '@mui/material/Typography';
import { useState } from 'react';

import { SearchBar } from '@/views/molecules/SearchBar';
import type { ItemsTableProps } from '@/views/organisms/ItemsTable';
import { ItemsTable } from '@/views/organisms/ItemsTable';
import { DashboardTemplate } from '@/views/templates/DashboardTemplate';

// Placeholder data so the slice renders standalone. REPLACE with the route's SAM
// ViewModel hook, the real connection point (REF-Frontend §4):
//   const { items, loading } = useItems();  // from '@/viewmodels/items'
const SEED: ItemsTableProps['items'] = [
    { id: '1', name: 'First item', status: 'active' },
    { id: '2', name: 'Second item', status: 'pending' },
    { id: '3', name: 'Third item', status: 'archived' },
];

// The page is the only connected component in the slice: it acquires the data and
// hands it down as props (REF-AtomicDesign §5). Everything below stays pure. A router
// lazy-loads it by mapping this named export (REF-Frontend §7), never a default export.
export const DashboardPage = () => {
    const [items] = useState(SEED);
    const [query, setQuery] = useState('');

    // In the real app this dispatches a ViewModel Action; searching/filtering is
    // ViewModel work, never done in the View (REF-AtomicDesign §5, REF-Frontend §4).
    const handleSearch = (next: string) => setQuery(next);

    return (
        <DashboardTemplate title="Items" actions={<SearchBar onSearch={handleSearch} />}>
            {query !== '' && (
                <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                    Showing results for &quot;{query}&quot;
                </Typography>
            )}
            <ItemsTable items={items} />
        </DashboardTemplate>
    );
};
''',
    "pages/DashboardPage/DashboardPage.test.tsx": r'''import { fireEvent, render, screen } from '@testing-library/react';
import { describe, expect, it } from 'vitest';

import { DashboardPage } from './DashboardPage';

describe('DashboardPage', () => {
    it('renders the items it acquires', () => {
        render(<DashboardPage />);
        expect(screen.getByText('First item')).toBeInTheDocument();
    });

    it('reflects a submitted search', () => {
        render(<DashboardPage />);
        fireEvent.change(screen.getByLabelText('Search'), { target: { value: 'second' } });
        fireEvent.click(screen.getByRole('button', { name: 'Search' }));
        expect(screen.getByText('Showing results for "second"')).toBeInTheDocument();
    });
});
''',
    "pages/DashboardPage/index.ts": r'''export { DashboardPage } from './DashboardPage';
''',
}


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Scaffold an Atomic-Design views/ tree backed by MUI primitives."
    )
    parser.add_argument("--target", required=True, help="Project root (the folder holding src/).")
    parser.add_argument(
        "--views-root",
        default="src/views",
        help="Views root relative to the target (default: src/views).",
    )
    args = parser.parse_args()

    root = Path(args.target).resolve() / args.views_root
    written = 0
    skipped = 0

    for rel, content in FILES.items():
        dest = root / rel
        if dest.exists():
            skipped += 1
            continue
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_text(content, encoding="utf-8", newline="\n")
        written += 1

    print(f"Scaffolded {root}: {written} files written, {skipped} skipped.")
    print("Next: npm install @mui/material @emotion/react @emotion/styled, then npm run build")
    print("and npm run test.")
    print("Then wire DashboardPage to the route's SAM ViewModel hook (REF-Frontend section 4).")


if __name__ == "__main__":
    main()
