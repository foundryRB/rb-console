---
name: bootstrap-atomic-mui
description: "Scaffold an Atomic-Design views/ tree (atoms, molecules, organisms, templates, pages) backed by MUI (@mui/material) primitives, per REF-AtomicDesign's levels, composition ladder, and purity gradient. The MUI counterpart to bootstrap-react-mvvm's Tailwind/shadcn views; drops into an existing React + TypeScript frontend."
galaxy: craft
refs:
  - REF-AtomicDesign
  - REF-Frontend
  - REF-React
---

# Bootstrap atomic mui

Invoked when a React + TypeScript frontend needs its View layer laid out as an
Atomic-Design `views/` tree whose primitives come from MUI (`@mui/material`)
rather than a Tailwind/shadcn `components/ui/` folder. It writes the five level
folders (`atoms/`, `molecules/`, `organisms/`, `templates/`, `pages/`) with one
worked example per rung that demonstrates the composition ladder and the purity
gradient end to end, every component a folder with its test, story, and barrel
(`REF-Frontend.md` §9). It is the MUI sibling of `bootstrap-react-mvvm` (which ships
the Tailwind/shadcn stack): same taxonomy, different primitives source.

Use it on an existing project (the one `bootstrap-react-mvvm` scaffolded, or any
Vite/CRA React + TypeScript app). It touches only `src/views/`; it does not create
a project, a ViewModel, or a Model layer.

## Pre-flight

1. **Read** `REF-AtomicDesign.md` (the taxonomy this instantiates: §2 the five
   levels, §3 the classification test, §4 the composition ladder, §5 the purity
   gradient, §7 level-is-folder / one-component-per-unit), `REF-Frontend.md` §5
   (the React delta: the connection point is a ViewModel hook, called only at pages
   and connected organisms), `REF-Frontend.md` §9 (one folder per component),
   `REF-React.md` §1 (component patterns) and `REF-TypeScript.md` §2 (the `@/`
   import alias), and `REF-Frontend.md` §10 (the 4-space code style).
2. **Confirm the target is a React + TypeScript project** with a `src/` (or a chosen
   views root). This skill lays out the View layer; it does not scaffold the app.
3. **Confirm with user**:
   - Target project root (the folder holding `src/`).
   - Views root, if not the default `src/views`.
4. **The MUI delta over the core**: the primitive layer (`REF-AtomicDesign.md` §2) is the
   `@mui/material` package itself, with no CLI-installed local folder (the shadcn
   `components/ui/` of `REF-Frontend.md` §1). Atoms import MUI primitives directly from
   `@mui/material`, and styling is MUI's `sx`/theme rather than Tailwind
   (`REF-Frontend.md` §8). The atomic taxonomy is unchanged; only the primitives source
   and the styling mechanism differ. Nothing below an organism reads connected state.
5. **Customization lands in the atom or the theme**: a package primitive cannot be edited
   at all, which makes the rule the core already states (`REF-AtomicDesign.md` §2)
   mechanical here. Domain meaning and variants go in the wrapping atom (`StatusBadge`
   over `Chip`), look goes in the MUI theme, which is where MUI holds design tokens
   (`REF-Design.md` §2). A component MUI's props cannot express is authored as a
   hand-written atom on raw elements rather than forced through an ill-fitting primitive.

## Steps

Run the helper at `<this-skill>/bootstrap.py`:

```bash
python bootstrap.py --target <project-root> [--views-root src/views]
```

It writes the tree below (idempotent: existing files are skipped, so it is safe to
re-run and it never clobbers your work). Then, in the target project:

```bash
npm install @mui/material @emotion/react @emotion/styled
npm run build   # or: tsc --noEmit
npm run test    # every component's test
```

MUI's peer dependencies are `@emotion/react` and `@emotion/styled`; the scaffold
imports only `@mui/material`, so those three packages are all it needs to render.

The tests assert with `toBeInTheDocument()`, so they need the project's vitest
harness to carry `@testing-library/react` and `@testing-library/jest-dom`, with
jest-dom imported from the vitest `setupFiles` entry and listed in the tsconfig
`types` (the shape `bootstrap-react-mvvm` scaffolds, in its `src/test-setup.ts`).
The stories need the project's Storybook (`REF-Frontend.md` §5.1, which
`bootstrap-react-mvvm` ships). Add the harness and Storybook first on a project
that lacks them: a component folder without its test or story breaks §9.

## What it produces

```
<target>/<views-root>/
├── atoms/
│   ├── StatusBadge/         # wraps MUI Chip; maps a status to a color. Props only.
│   ├── TextInput/           # wraps MUI TextField. Props only.
│   └── SubmitButton/        # wraps MUI Button. Props only.
├── molecules/
│   └── SearchBar/           # composes TextInput + SubmitButton; one job; local query state
├── organisms/
│   └── ItemsTable/          # composes MUI Table primitives + StatusBadge; a named section (props in)
├── templates/
│   └── DashboardTemplate/   # MUI AppBar + Container layout with named slots; no data
└── pages/
    └── DashboardPage/       # binds the template to data; the connection seam (§5)
```

Each folder holds `<Name>.tsx`, `<Name>.test.tsx`, `<Name>.stories.tsx` (not in
`pages/`), and an `index.ts` barrel (`REF-Frontend.md` §9.2). Every export is named,
the page included: a router lazy-loads it by mapping the named export
(`REF-Frontend.md` §7).

The example is a deliberate throwaway slice, exactly like `bootstrap-react-mvvm`'s:
one vertical of a placeholder `items` domain wired atom -> molecule -> organism ->
template -> page. Refit it to the engagement's real domain, or delete it once your
own components exist. It exists to make the ladder and the purity gradient concrete,
not to ship.

## The connection seam (expect to wire it)

`DashboardPage` is the only connected component in the slice: it acquires the data and
passes it down (`REF-AtomicDesign.md` §5, `REF-Frontend.md` §5). The scaffold seeds
that data with local `useState` and marks the spot; **replace it with the route's SAM
ViewModel hook** (`useItems()` from `@/viewmodels/items`, per `REF-Frontend.md` §4).
Everything below the page stays pure: atoms and molecules take props, the organism
takes props. Promote the organism to call its own ViewModel hook only when a real
second caller earns it (`REF-AtomicDesign.md` §3, §4).

## Failure modes

- **Target has no `src/` (or the given views root's parent is missing)**: the helper
  creates the views root regardless, so a wrong `--target` writes the tree in the wrong
  place; confirm the target is a React project first (pre-flight 2).
- **A target file already exists**: skipped (idempotent); re-run safely. To regenerate
  an example, delete it first.
- **`npm run build` flags a missing `@/viewmodels/items` import** once you wire the
  page to a real hook: create the ViewModel with `bootstrap-react-mvvm`'s SAM pattern
  (`REF-Frontend.md` §4), or keep the seeded `useState` placeholder until it exists.
- **MUI types unresolved**: install the three packages in Steps; MUI ships its own
  types, so no `@types/*` package is needed.

## See also

- `REF-AtomicDesign.md`, `REF-Frontend.md` §5, `REF-React.md`.
- `bootstrap-react-mvvm` skill: the full React MVVM project (Tailwind/shadcn views) this drops into.
