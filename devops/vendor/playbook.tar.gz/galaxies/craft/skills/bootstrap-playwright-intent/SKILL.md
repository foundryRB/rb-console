---
name: bootstrap-playwright-intent
description: Scaffold Playwright + playwright-intent into a frontend project - install both packages, drop a CSD-INTENT-01 canonical intent.yaml stub (if missing), a playwright.config.ts, and an e2e/ directory with an example intent() test. Does NOT generate meta-test files; cross-runtime auditing lives in the standalone csd-intent CLI. Mirror of bootstrap-pytest-intent / bootstrap-vitest-intent for browser-driven e2e.
galaxy: craft
refs:
  - REF-CSD
  - REF-Tests
  - REF-PhoneLayout
---

# Bootstrap playwright-intent

Invoked when a frontend project wants CSD-style e2e testing - `intent("INT-NNN", name, fn)` calls in Playwright tests, with spec validation + coverage handled by the standalone `csd-intent` CLI.

This skill is the *e2e-marker* sibling of `bootstrap-pytest-intent` and `bootstrap-vitest-intent`. All three drop the same `intent.yaml` stub shape, then add their language-specific marker package. Auditing is shared via `csd-intent`.

## Pre-flight

1. **Read** `REF-CSD.md` and `../csd-library/playwright-intent/README.md` for the model.
2. **Confirm target** - directory of an existing JS/TS frontend project (or where one will live). Must have a `package.json`.
3. **Confirm Node + npm available** - the runtime + scaffolder rely on both.
4. **Confirm the backend is reachable** - Playwright tests drive the real UI, so the backend must already be runnable (e.g. `python -m foo.run`) and the frontend must already be runnable (`npm run dev`). The scaffold wires Playwright's `webServer` to start them.

## What it produces

```
<target>/
├── intent.yaml                  # CSD-INTENT-01 canonical stub (only if missing)
├── playwright.config.ts         # baseURL, webServer wiring, retries, browsers
└── e2e/
    ├── example.spec.ts          # one example intent('INT-XXX-E01', ...) test
    └── phone.spec.ts            # the phone project: no overflow at 320 and 375px, axe with wcag22aa
```

If `intent.yaml` already exists at the target (typical when the project already uses pytest-intent or vitest-intent), the stub is NOT overwritten - the user appends new claims into the existing file.

Notice what's NOT produced: no `tests/meta.test.ts`, no schema-check helpers. Auditing belongs to `csd-intent`.

## Steps

1. **Install Playwright + playwright-intent** (published to the public npm registry per csd-library ADR-0003; installed + imported under its published scoped name, with no `.npmrc` and no credential):
   ```bash
   cd <target>
   npm install --save-dev @playwright/test @axe-core/playwright@^4 @psa-department-of-engineering/playwright-intent@^2.0.1
   ```

   Local dev against an unreleased `csd-library` checkout:
   ```bash
   npm install --save-dev --install-links ../../csd-library/playwright-intent
   ```
   `--install-links` is **required** for the local-path install: it packs the package per its `files` allowlist instead of symlinking the checkout, whose dev copy of `@playwright/test` would otherwise make Playwright throw *"Requiring @playwright/test second time"*.
2. **Install the auditor** (optional but strongly recommended):
   ```bash
   pip install "csd-intent>=0.6.0,<0.7"
   ```
3. **Run scaffolder** (Python helper at `<this-skill>/bootstrap.py`):
   ```bash
   python bootstrap.py --target <project-path> [--prefix INT-XXX]
   ```
   The helper writes the files listed above. Idempotent - skips files that already exist. The optional `--prefix` (e.g. `--prefix INT-SB`) seeds the example test with the right project prefix; default is `INT-DEMO`.
4. **One-time browser install** (~300MB):
   ```bash
   cd <target> && npx playwright install
   ```
5. **Verify the example runs**:
   ```bash
   cd <target> && npx playwright test
   ```
   The example expects backend + frontend to be wired in `playwright.config.ts`'s `webServer`. If they fail to start, fix the commands in that file (they're commented placeholders by default).
6. **Surface to user**:
   - "playwright-intent installed; e2e/example.spec.ts shows the pattern. Wire your backend + frontend commands into playwright.config.ts's webServer. Add e2e claims to intent.yaml with INT-XXX-E01 (or similar) IDs. Run `npx playwright test` for tests, `csd-intent <project>` to audit."

## CSD-INTENT-01 claim shape for e2e (what the example demonstrates)

```yaml
INT-SB-E01:
  version: 1.0.0
  status: active
  statement: "Clicking 'Pull all' MUST stream events and refresh the status list."
  rationale: "The headline operator action - must work end-to-end with a real browser."
  test:
    scope: e2e
    component: Dashboard
    type: behavior
  criticality: high
```

The `E` prefix in the ID (e.g. `INT-SB-E01`) is a convention to separate e2e claims from unit/integration claims in the same `intent.yaml`. The schema doesn't enforce it; it's just human-readable.

## Failure modes

- **No package.json** - surface to user, don't `npm install` outside a Node project.
- **Existing `playwright.config.ts`** - the scaffold skips and leaves it alone. Merge manually if needed.
- **`npx playwright install` not run** - `npx playwright test` will print "browser not found"; the message tells you what to do.
- **Backend not running** - Playwright's `webServer` block in `playwright.config.ts` should start it; if you've commented those out for an existing dev setup, ensure the backend is up before running tests.

## See also

- `../csd-library/playwright-intent/` - the package this skill installs (just the wrapper)
- `../csd-library/csd-intent/` - the standalone auditor (CLI: `csd-intent <project>`)
- `bootstrap-pytest-intent` skill - Python sibling
- `bootstrap-vitest-intent` skill - JS/TS unit/integration sibling
- `audit-intent` skill - wraps the auditor CLI
- `REF-CSD.md` - methodology
