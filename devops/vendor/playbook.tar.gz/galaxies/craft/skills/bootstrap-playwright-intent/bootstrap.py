#!/usr/bin/env python3
"""Scaffold Playwright + playwright-intent into a frontend project.

Idempotent - skips files that already exist. Mirror of
``bootstrap-vitest-intent/bootstrap.py`` for browser-driven e2e.

Drops four files into the target:
  - intent.yaml (CSD-INTENT-01 canonical stub) - only if missing
  - playwright.config.ts (baseURL, webServer wiring placeholders, a desktop and a phone project)
  - e2e/example.spec.ts (one intent('INT-XXX-E01', ...) test)
  - e2e/phone.spec.ts (the phone project: no element wider than 320 and 375px, axe with the
    wcag22aa tag, per REF-PhoneLayout section 9)

Does NOT generate any meta-test file. Schema + orphan + coverage checks live in
the standalone `csd-intent` CLI.

Usage:
  python bootstrap.py --target <project-path> [--prefix INT-XXX]
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

INTENT_YAML_STUB = '''\
# Intent claims for this project (CSD-INTENT-01 canonical schema).
#
# Required fields per claim:
#   version     - semver of the claim itself (bump on statement/scope change)
#   status      - draft | active | deprecated
#   statement   - single-sentence declarative behavior, RFC 2119 language
#   test:
#     scope     - unit | integration | e2e
#     component - where this is exercised in the system
#     type      - invariant | behavior | contract
#   criticality - critical | high | medium | low
#
# Optional: rationale, domain, examples, derived_from, parent, related.
#
# Convention: e2e claims use an `E` suffix in the ID (e.g. INT-FOO-E01) so they
# are easy to skim alongside unit/integration claims in the same file.
#
# To audit this file + verify every claim has a test marker, use the standalone
# csd-intent CLI:
#   csd-intent .
'''

PLAYWRIGHT_CONFIG_TMPL = '''\
import { defineConfig, devices } from '@playwright/test';

/**
 * Playwright config. Defaults are conservative:
 *   - One browser (chromium) for local fast iteration. Add firefox / webkit as needed.
 *   - Headless. Set `headed: true` for debugging.
 *   - Tests live in ./e2e.
 *   - Wire the backend + frontend in `webServer` below so `npx playwright test`
 *     can be run cold. If you already have them running in another terminal,
 *     either delete the webServer block or set `reuseExistingServer: true`.
 */
export default defineConfig({
    testDir: './e2e',
    timeout: 30_000,
    fullyParallel: false,
    forbidOnly: !!process.env.CI,
    retries: process.env.CI ? 2 : 0,
    workers: 1,
    reporter: [['list']],
    use: {
        baseURL: 'http://localhost:5173',
        trace: 'on-first-retry',
        screenshot: 'only-on-failure',
    },
    projects: [
        { name: 'chromium', use: { ...devices['Desktop Chrome'] } },
        { name: 'phone', use: { ...devices['iPhone 13'] } },
    ],
    // Uncomment + adapt to start your servers automatically. Each command runs
    // in this project's directory; tweak the paths if your backend lives elsewhere.
    // webServer: [
    //     {
    //         command: 'cd ../backend && .venv/Scripts/python.exe -m yourapp.run',
    //         url: 'http://localhost:8000/api/health',
    //         reuseExistingServer: !process.env.CI,
    //         timeout: 60_000,
    //     },
    //     {
    //         command: 'npm run dev',
    //         url: 'http://localhost:5173',
    //         reuseExistingServer: !process.env.CI,
    //         timeout: 30_000,
    //     },
    // ],
});
'''

EXAMPLE_SPEC_TMPL = '''\
import {{ expect }} from '@playwright/test';
import {{ intent }} from '@psa-department-of-engineering/playwright-intent';

/**
 * Example e2e test. Replace {prefix}-E01 with your actual claim ID and
 * adjust the assertions to match your app.
 *
 * Each intent() call binds the test to a claim in intent.yaml - csd-intent
 * uses these markers to verify cross-runtime coverage.
 */

intent('{prefix}-E01', 'the app loads and shows its title', async ({{ page }}) => {{
    await page.goto('/');
    await expect(page).toHaveTitle(/./);
}});
'''


PHONE_SPEC_TMPL = '''\
import {{ expect }} from '@playwright/test';
import {{ intent }} from '@psa-department-of-engineering/playwright-intent';
import AxeBuilder from '@axe-core/playwright';

/**
 * Phone checks (REF-PhoneLayout section 9): the page reflows at phone widths
 * and the WCAG 2.2 AA rules hold, target size included. Runs under the 'phone'
 * project only. Replace {prefix}-E02 with your actual claim ID.
 */

const PHONE_WIDTHS = [320, 375];

intent(
    '{prefix}-E02',
    'the page reflows at phone widths and meets WCAG 2.2 AA',
    async ({{ page }}, testInfo) => {{
        testInfo.skip(testInfo.project.name !== 'phone', 'phone project only');
        for (const width of PHONE_WIDTHS) {{
            await page.setViewportSize({{ width, height: 812 }});
            await page.goto('/');
            // An element wider than its box with overflow left visible pushes the
            // page sideways; a scroll region (overflow auto or scroll) is allowed.
            const overflowing = await page.evaluate(() =>
                Array.from(document.querySelectorAll('body *'))
                    .filter(
                        (el) =>
                            el.scrollWidth > el.clientWidth + 1 &&
                            getComputedStyle(el).overflowX === 'visible',
                    )
                    .map((el) => el.tagName.toLowerCase() + (el.id ? '#' + el.id : '')),
            );
            expect(overflowing, 'elements wider than ' + width + 'px').toEqual([]);
            const pageWidth = await page.evaluate(() => document.documentElement.scrollWidth);
            expect(pageWidth).toBeLessThanOrEqual(width);
        }}
        // axe ships target-size (2.5.8) disabled; the wcag22aa tag turns it on.
        const results = await new AxeBuilder({{ page }})
            .withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa', 'wcag22a', 'wcag22aa'])
            .analyze();
        expect(results.violations).toEqual([]);
    }},
);
'''


def write_if_missing(path: Path, content: str) -> bool:
    """Write content to path only if it doesn't exist. Returns True if written."""
    if path.exists():
        print(f"  SKIP (exists): {path}")
        return False
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")
    print(f"  WRITE: {path}")
    return True


def find_intent_yaml_upwards(start: Path, max_depth: int = 5) -> Path | None:
    """Walk parent directories looking for an existing intent.yaml.

    Useful when bootstrapping a sub-package (e.g. frontend/) whose canonical
    intent.yaml lives at the module root (one level up). Returns the path to
    the closest existing intent.yaml, or None if not found within max_depth.
    """
    current = start.resolve()
    for _ in range(max_depth + 1):
        candidate = current / "intent.yaml"
        if candidate.exists():
            return candidate
        if current.parent == current:
            return None
        current = current.parent
    return None


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--target", type=Path, required=True, help="JS/TS frontend project root")
    ap.add_argument(
        "--prefix",
        default="INT-DEMO",
        help="Claim ID prefix for the example test (e.g. INT-SB, INT-WB). Default: INT-DEMO",
    )
    args = ap.parse_args()

    target: Path = args.target
    if not target.exists():
        print(f"target does not exist: {target}", file=sys.stderr)
        return 2
    if not target.is_dir():
        print(f"target is not a directory: {target}", file=sys.stderr)
        return 2
    if not (target / "package.json").exists():
        print(f"target has no package.json (not a Node project): {target}", file=sys.stderr)
        return 2

    prefix = args.prefix.upper().rstrip("-")
    if not prefix.startswith("INT-"):
        prefix = f"INT-{prefix}"

    print(f"Scaffolding Playwright + playwright-intent into {target}")

    # If a parent already has an intent.yaml (common in monorepos where the
    # frontend is a sub-package of a module with its own canonical spec), don't
    # drop a duplicate stub.
    existing_intent = find_intent_yaml_upwards(target)
    if existing_intent is None:
        write_if_missing(target / "intent.yaml", INTENT_YAML_STUB)
    else:
        print(f"  SKIP (existing intent.yaml at module root): {existing_intent}")

    write_if_missing(target / "playwright.config.ts", PLAYWRIGHT_CONFIG_TMPL)
    write_if_missing(target / "e2e" / "example.spec.ts", EXAMPLE_SPEC_TMPL.format(prefix=prefix))
    write_if_missing(target / "e2e" / "phone.spec.ts", PHONE_SPEC_TMPL.format(prefix=prefix))

    print()
    print("Next steps:")
    print("  1. Install Playwright + playwright-intent (public npm; no .npmrc, no token -")
    print("     see csd-library ADR-0003; installed + imported under the scoped name):")
    print("       npm install --save-dev @playwright/test @axe-core/playwright@^4 @psa-department-of-engineering/playwright-intent@^2.0.1")
    print("       # local dev against a checkout: npm i -D --install-links ../../csd-library/playwright-intent")
    print("  2. Install the auditor (optional but recommended):")
    print('       pip install "csd-intent>=0.6.0,<0.7"')
    print("  3. One-time browser install (~300MB):")
    print(f"       cd {target} && npx playwright install")
    print("  4. Wire your backend + frontend into playwright.config.ts's webServer block.")
    print("  5. Add e2e claims to intent.yaml with the convention {prefix}-E01, -E02, ...")
    print(f"  6. Run e2e: cd {target} && npx playwright test")
    print(f"  7. Audit spec + coverage: csd-intent {target}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
