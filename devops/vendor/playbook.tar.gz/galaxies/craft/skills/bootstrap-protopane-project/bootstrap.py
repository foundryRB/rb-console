#!/usr/bin/env python3
"""Create a new prototype project in a running protopane instance.

Deterministic scaffold step for the bootstrap-protopane-project skill: POST a new
project to the instance API, optionally from a template, optionally seeding the
brand primary colour into the project's design tokens. Prints the project slug and
the editor URL. AI then authors the screens (see SKILL.md and REF-Design.md).

Creating a project is not idempotent: each run creates a new project (the instance
assigns a unique slug on a name collision). Use --dry-run to validate inputs and
check reachability without creating anything.

Usage:
  python bootstrap.py --name "<client name>" [--base-url <url>] \
      [--template <slug>] [--primary "#RRGGBB"] [--dry-run]

The base URL defaults to the PROTOPANE_BASE_URL environment variable, then to a
local instance. It is never hardcoded into shared content.
"""

from __future__ import annotations

import argparse
import base64
import json
import os
import re
import sys
import urllib.error
import urllib.request

DEFAULT_BASE_URL = os.environ.get("PROTOPANE_BASE_URL", "http://localhost:8800")
HEX_RE = re.compile(r"^#?[0-9a-fA-F]{6}$")


def hex_to_hsl(value: str) -> str:
    """Convert a #rrggbb colour to the `H S% L%` triple protopane tokens use."""
    h = value.lstrip("#")
    r, g, b = (int(h[i : i + 2], 16) / 255 for i in (0, 2, 4))
    high, low = max(r, g, b), min(r, g, b)
    light = (high + low) / 2
    delta = high - low
    if delta == 0:
        hue = sat = 0.0
    else:
        sat = delta / (2 - high - low) if light > 0.5 else delta / (high + low)
        if high == r:
            hue = ((g - b) / delta) % 6
        elif high == g:
            hue = (b - r) / delta + 2
        else:
            hue = (r - g) / delta + 4
        hue *= 60
        if hue < 0:
            hue += 360
    return f"{round(hue)} {round(sat * 100)}% {round(light * 100)}%"


def request_json(method: str, url: str, body: dict | None = None) -> dict:
    """Send a JSON request and parse the JSON response (empty body tolerated).

    Sends HTTP Basic auth when PROTOPANE_AUTH_USER and PROTOPANE_AUTH_PASSWORD are
    set, so the scaffolder works against a secured instance.
    """
    data = json.dumps(body).encode("utf-8") if body is not None else None
    headers = {"Content-Type": "application/json"} if body is not None else {}
    # Edge WAFs (e.g. Cloudflare bot rules) reject Python's default
    # urllib User-Agent with 403, so every request names itself.
    headers["User-Agent"] = "protopane-bootstrap/1.0"
    user = os.environ.get("PROTOPANE_AUTH_USER")
    password = os.environ.get("PROTOPANE_AUTH_PASSWORD")
    if user and password:
        token = base64.b64encode(f"{user}:{password}".encode()).decode()
        headers["Authorization"] = f"Basic {token}"
    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    with urllib.request.urlopen(req, timeout=15) as resp:
        raw = resp.read().decode("utf-8")
    return json.loads(raw) if raw else {}


def main() -> int:
    ap = argparse.ArgumentParser(description="Create a protopane prototype project.")
    ap.add_argument("--name", required=True, help="Project / client engagement name")
    ap.add_argument(
        "--base-url",
        default=DEFAULT_BASE_URL,
        help="Protopane instance base URL (or set PROTOPANE_BASE_URL)",
    )
    ap.add_argument("--template", default=None, help="Starting template slug (omit for blank)")
    ap.add_argument("--primary", default=None, help="Brand primary colour as #RRGGBB")
    ap.add_argument(
        "--dry-run",
        action="store_true",
        help="Validate inputs and instance reachability; create nothing",
    )
    args = ap.parse_args()

    base = args.base_url.rstrip("/")
    name = args.name.strip()
    if not name:
        print("name must not be empty", file=sys.stderr)
        return 2
    if args.primary is not None and not HEX_RE.match(args.primary):
        print(f"primary must be #RRGGBB hex, got: {args.primary}", file=sys.stderr)
        return 2

    # Reachability check. This is also the whole of --dry-run.
    try:
        request_json("GET", f"{base}/api/projects")
    except urllib.error.HTTPError as exc:
        if exc.code == 401:
            print(
                f"{base} requires auth. Set PROTOPANE_AUTH_USER and PROTOPANE_AUTH_PASSWORD.",
                file=sys.stderr,
            )
        else:
            print(f"cannot reach protopane at {base}: HTTP {exc.code} {exc.reason}", file=sys.stderr)
        return 2
    except urllib.error.URLError as exc:
        print(f"cannot reach protopane at {base} ({exc}). Is the instance running?", file=sys.stderr)
        return 2

    if args.dry_run:
        template = args.template or "(blank)"
        print(f"OK: {base} reachable. Would create '{name}' from template {template}.")
        return 0

    # Create the project.
    try:
        project = request_json("POST", f"{base}/api/projects", {"name": name, "template": args.template})
    except urllib.error.HTTPError as exc:
        if args.template and exc.code == 404:
            print(
                f"template '{args.template}' not found. List them: GET {base}/api/templates",
                file=sys.stderr,
            )
        else:
            print(f"create failed: HTTP {exc.code} {exc.reason}", file=sys.stderr)
        return 2

    slug = project["slug"]

    # Seed the brand primary into the project's tokens, if one was given.
    if args.primary is not None:
        tokens = dict(project["theme"]["tokens"])
        hsl = hex_to_hsl(args.primary)
        tokens["--primary"] = hsl
        tokens["--ring"] = hsl
        request_json("PUT", f"{base}/api/projects/{slug}/theme", {"tokens": tokens})

    print(f"Created project '{project['name']}' (slug: {slug}).")
    print(f"Editor: {base}/p/{slug}")
    print()
    print("Next steps (AI authors the screens, per the instance's guide and REF-Design.md):")
    print("  1. Refine the remaining theme tokens to the brand, then:")
    print(f"       PUT {base}/api/projects/{slug}/theme   with {{ tokens }}")
    print("  2. Author each view as an HTML body in the block vocabulary (token-backed")
    print("     utilities, never inline hex), then save it:")
    print(f"       PUT {base}/api/projects/{slug}/screens/<screen>   with {{ name, html, css }}")
    print(f"  3. Open {base}/p/{slug} to iterate live with the customer.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
