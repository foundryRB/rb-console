---
name: bootstrap-protopane-project
description: Create a new client prototype in a running protopane instance, then build its first screens from a brief. The deterministic step posts a new project (optional starting template, optional brand primary colour) to the instance API. Then AI authors screen markup from the prompt and optional design references (a colour, a style description, reference images or URLs), honoring the project's design tokens, and saves it back. For the design phase, before a customer frontend repo exists.
galaxy: craft
refs:
  - REF-Design
---

# Bootstrap protopane project

Invoked when starting a customer design engagement: stand up a themed, populated prototype in protopane from a brief, ready to iterate live with the customer. The deterministic script creates the project; AI builds the screens against the model and conventions the instance's own guide states and the design practice of `REF-Design.md`.

This is a design-phase skill. Its output is a throwaway prototype (a theme plus screen markup), a reference for the eventual `REF-Frontend.md` build, not a maintained artifact.

## Pre-flight

1. **Read** the instance's own guide (the protopane door serves it) for the model, the token set, the screen-markup rules, the block vocabulary, and the operations, and `REF-Design.md` for the design practice.
2. **Confirm a reachable instance** - the base URL of a running protopane (configured per environment; defaults to a local instance). Verify with `python bootstrap.py --dry-run --name "<name>" [--base-url <url>]`, which checks reachability and creates nothing. If the instance has auth enabled, set `PROTOPANE_AUTH_USER` and `PROTOPANE_AUTH_PASSWORD` in the environment first; the scaffolder sends them as HTTP Basic auth.
3. **Collect the brief from the user**:
   - Project name (the client or engagement name).
   - What to build: the screens and their purpose.
   - Optional design references: a brand primary colour (`#RRGGBB`), a style description, reference image paths, or a reference URL.
   - Optional starting template (one of the instance's templates; omit for blank). The instance lists them.
4. **Confirm Python is available** - the scaffolder uses only the standard library.

## What it produces

The deterministic script creates one project in the instance (persisted server-side):

```
<protopane instance>
└── project "<name>"  (slug: <slug>)
    ├── theme tokens   (brand primary seeded if --primary was given)
    └── screen "home"  (from the template, or the default starter)
```

It prints the slug and the editor URL. AI then authors and saves the screens; that is not the script's job.

## Steps

1. **Verify reachability** (and dry-run the inputs):
   ```bash
   python bootstrap.py --dry-run --name "<client name>" [--base-url <url>]
   ```
2. **Scaffold the project** (Python helper at `<this-skill>/bootstrap.py`):
   ```bash
   python bootstrap.py --name "<client name>" [--base-url <url>] [--template <slug>] [--primary "#RRGGBB"]
   ```
   It creates the project and prints the slug plus editor URL. `--primary` maps the brand colour to the `--primary` and `--ring` tokens; the rest of the palette stays default for AI to refine. Creating a project is not idempotent: each run makes a new project.

   **For palette or style variants to compare with the customer, do NOT run this once per variant** (that makes N sibling projects, the wrong shape: variants are schemes inside one project, the protopane door's doctrine). Create one project, then save each variant as a named scheme, or run the `design-session` skill's prepare step, which does exactly that. The customer flips between schemes in one click.
3. **Load the conventions** - ensure the instance's guide and `REF-Design.md` are in context.
4. **Interpret the design references**:
   - The brand primary is already applied; refine the remaining tokens (background, accent, secondary, and so on) to match the references, then save the theme with the full token set.
   - Read any reference images (Read tool) and fetch any reference URLs for palette, layout, and tone. Produce an original interpretation; never reproduce a copyrighted asset.
5. **Seed the identity before the screens** - when the look draws on a vendored design system, list the instance's design-system library, pick the one that fits the brief, read that system whole for its tokens and guidance, and save the theme naming that system as its source, so the project records the provenance and its guidance travels to the gate export. Apply the system, do not just cite it: its typography becomes the theme's `--font-sans` and its corner language `--radius` - the two non-color tokens the canonical set carries exactly so projects do not all render in the scaffold's default font - and its tokens re-hue to the customer's brand primary.
6. **Author the screens under the guidance** - list the instance's block vocabulary and compose each view as an HTML body from it, token-backed utilities only, never inline hex (the protopane door's doctrine), letting the chosen system's elevation and voice guidance shape the composition (shadow depth, density, copy tone). Save each screen. The instance enforces token discipline: a save carrying a literal color (hex, `rgb()`, numeric `hsl()`) is rejected with a violation report; fix the markup and retry.
7. **Surface to the user** - the editor URL to open the prototype and iterate live with the customer. Note it is a throwaway design reference for the eventual frontend build.

## Design references (accepted forms)

| Form | How it is used |
|---|---|
| Brand primary colour (`#RRGGBB`) | Mapped deterministically to `--primary` / `--ring` by the script |
| Style description (prose) | Interpreted into token choices and layout density |
| Reference image (a path) | Read for palette, layout, and tone; reinterpreted, not copied |
| Reference URL | Fetched for structure and style cues; reinterpreted, not copied |

## Failure modes

- **Instance not reachable** - the script reports it and exits non-zero. Start protopane or correct the base URL; do not proceed.
- **Unknown template slug** - the script reports it; list the instance's templates, then pick one or omit for blank.
- **Invalid primary colour** - it must be `#RRGGBB` hex; the script rejects anything else.
- **A screen or theme save answers 422** - the instance's token-discipline gate found literal colors in the markup or a non-canonical token set; the response body carries the violation list. Rewrite with token-backed utilities (or the full canonical token set) and retry.
- **A reference is copyrighted** - produce an original interpretation; never reproduce the asset.

## See also

- `REF-Design.md` - the design practice this skill applies; the protopane door's guide states the model and conventions it builds against.
- `REF-Frontend.md` - the downstream MVVM build the prototype informs.
- the protopane project's `README.md` - how to run an instance.
- An agent connected to the protopane door can run this same flow through the door
  itself, starting from its guide; this skill is the HTTP-API form for agents that are
  not connected.
