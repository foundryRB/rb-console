---
name: bootstrap-vitest-intent
description: Scaffold vitest-intent into any JS/TS project - install the package, write an intent.yaml stub and an example intent() test. Schema + coverage auditing live in the standalone csd-intent CLI (no in-suite meta-test). Reusable across Starlight sites and any other Node + vitest project that wants CSD-aligned intent testing. Mirror of bootstrap-pytest-intent for the JS/TS ecosystem.
galaxy: craft
refs:
  - REF-CSD
  - REF-Tests
---

# Bootstrap vitest-intent

Invoked when a JS/TS project wants CSD-style intent testing - `intent("INT-NNN", name, fn)` calls in tests, with schema validation + intent ↔ test coverage handled by the standalone `csd-intent` CLI.

This skill is the *test-infrastructure* sibling of `bootstrap-pytest-intent`. Same model, different ecosystem (Node + vitest instead of Python + pytest). Bootstrap skills that scaffold JS/TS projects (e.g. `bootstrap-starlight`) delegate their tests/ scaffolding to this skill or duplicate the same pattern internally.

> **Division of labour.** `vitest-intent` (>=0.2) is *only* the `intent()` marker: it binds claim IDs to vitest tests, and vitest behaviour is unchanged. Schema validation (CSD-INTENT-01), orphan detection, and coverage all live in the standalone `csd-intent` CLI, run separately (ad-hoc, pre-commit, or CI). There is no in-suite meta-test, and no `vitest-intent/meta-tests` module to import.

## Pre-flight

1. **Read** `REF-CSD.md` and `../csd-library/vitest-intent/README.md` for the model.
2. **Confirm target** - directory of an existing JS/TS project (or where one will live). Must have a `package.json`.
3. **Confirm Node + npm available** - the runtime + scaffolder rely on both.
4. **No credential to resolve.** `vitest-intent` is published to the **public npm registry** (csd-library ADR-0003), so `npm install` resolves it anonymously - no `.npmrc`, no scope mapping, no PAT, in any environment. A local machine, a delivery pod, and CI are all the same install. If a target repo still carries an `.npmrc` pointing the scope at `npm.pkg.github.com`, that is stale wiring from the GitHub Packages era: delete it, and regenerate the lockfile (`npm i --package-lock-only`), because every `resolved:` entry still names the old registry and `npm ci` keeps hitting it until the lock is rewritten.

## What it produces

```
<target>/
├── intent.yaml              # stub with one commented CSD-INTENT-01 example
└── tests/
    └── example.test.ts      # one example intent("INT-001", ...) test
```

No in-suite meta-test file is written; auditing is `csd-intent`'s job (below).

## Steps

1. **Install vitest-intent** into the project. It is published to the public npm registry (csd-library ADR-0003); install + import it under its published scoped name:
   ```bash
   npm install --save-dev vitest @psa-department-of-engineering/vitest-intent@^2.0.1
   ```
   (Local dev against an unreleased checkout: `npm install --save-dev --install-links path/to/csd-library/vitest-intent` - `--install-links` packs per the `files` allowlist instead of symlinking the checkout's `node_modules`.)
2. **Run scaffolder** (Python helper at `<this-skill>/bootstrap.py`):
   ```bash
   python bootstrap.py --target <project-path>
   ```
   The helper writes the two files above. Idempotent - skips files that already exist.
3. **Author claims and tests**: add CSD-INTENT-01 claims to `intent.yaml` and attest each with `intent("INT-NNN", name, fn)` in a `*.test.ts` file under `tests/`.
4. **Run vitest** to confirm tests pass:
   ```bash
   cd <project-path> && npx vitest run
   ```
5. **Audit spec + coverage** with the standalone CLI (schema valid, no orphan markers, every claim attested):
   ```bash
   cd <project-path> && csd-intent .
   ```
6. **Surface to user**: "vitest-intent installed; intent.yaml + an example test scaffolded. Add `intent('INT-NNN', name, fn)` calls + claims to intent.yaml, then `csd-intent .` to audit."

## Multiple intent domains (multi-file / multi-dir)

`csd-intent` audits one `intent.yaml` per invocation root and scans test markers across runtimes. For a project with more than one intent domain (for example an app standard plus a docs site with its own `intent.yaml`), audit each at its own root and constrain the scan with `--tests-dir`, so markers from one domain are not reported as orphans of another:

```bash
csd-intent . --tests-dir src        # the project standard
csd-intent docs                     # a nested docs intent unit
```

## Failure modes

- **No package.json** - surface to user, don't `npm install` outside a Node project.
- **`vitest` or `vitest-intent` not findable after install** - the install failed; surface the npm error. A 401 or 404 against `npm.pkg.github.com` means the repo still carries a stale `.npmrc` or an unregenerated lockfile from the GitHub Packages era (pre-flight step 4), not a missing credential - there is no credential.
- **The install fails and the run continues anyway** - this is the expensive one, and it costs claims rather than an install. With no `intent()` runtime present, no marker resolves, so every frontend claim the suite would attest stays **draft** (unattested) even though the app builds and passes plain vitest smoke tests. A build that discovers this at attestation time has already produced draft claims it cannot lift without re-running, so treat a successful install as a **precondition** checked before the run, never a step whose failure is absorbed.
- **`csd-intent` not on PATH** - it's a separate Python CLI; install per the `audit-intent` skill / the csd-library README.

## See also

- `../csd-library/vitest-intent/` - the package this skill installs
- `REF-CSD.md` - methodology
- `bootstrap-pytest-intent` skill - Python+pytest sibling
- `bootstrap-playwright-intent` skill - e2e sibling
- `audit-intent` skill - wraps the `csd-intent` CLI
- `bootstrap-starlight` skill - uses this internally for the test infrastructure
