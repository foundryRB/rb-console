#!/usr/bin/env python3
"""Scaffold vitest-intent test infrastructure into a JS/TS project.

Idempotent - skips files that already exist. Mirror of
``bootstrap-pytest-intent/bootstrap.py`` for the Node + vitest ecosystem.

vitest-intent (>=0.2) provides only the intent() marker; schema and coverage
auditing are done out of band by the standalone csd-intent CLI, so no in-suite
meta-test file is written.

Usage:
  python bootstrap.py --target <project-path>
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

INTENT_YAML_STUB = '''\
# Intent claims for this project (CSD-INTENT-01 schema).
# Attest each claim with an intent("INT-NNN", ...) test, then audit out of band
# with the standalone csd-intent CLI:
#   csd-intent .

# Example (uncomment + adapt):
# INT-001:
#   version: 1.0.0
#   status: active
#   statement: "Session data MUST never cross user boundaries."
#   rationale: "Data leakage between sessions is the top security risk for this app."
#   test:
#     scope: unit
#     component: SessionService
#     type: invariant
#   criticality: critical
'''

EXAMPLE_TEST_TMPL = '''\
import { intent } from "@psa-department-of-engineering/vitest-intent";

/**
 * Example intent-bound test. Replace INT-001 with a real claim from intent.yaml.
 * intent(id, name, fn) wraps vitest's test(); the standalone csd-intent CLI reads
 * these markers to verify every claim is attested. Auditing is NOT in this suite.
 */
intent("INT-001", "example claim is attested", () => {
  // assert real behavior here
});
'''


def write_if_missing(path: Path, content: str) -> bool:
    """Write content to path only if it doesn't exist. Returns True if written."""
    if path.exists():
        print(f"  SKIP (exists): {path}")
        return False
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")
    print(f"  WRITE: {path}")
    return True


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--target", type=Path, required=True, help="JS/TS project root")
    args = ap.parse_args()

    target: Path = args.target
    if not target.exists():
        print(f"target does not exist: {target}", file=sys.stderr)
        return 2
    if not target.is_dir():
        print(f"target is not a directory: {target}", file=sys.stderr)
        return 2
    if not (target / "package.json").exists():
        print(f"target has no package.json (not a Node project): {target}", file=sys.stderr)
        return 2

    print(f"Scaffolding vitest-intent infrastructure at {target}")
    write_if_missing(target / "intent.yaml", INTENT_YAML_STUB)
    write_if_missing(target / "tests" / "example.test.ts", EXAMPLE_TEST_TMPL)

    print()
    print("Next steps:")
    print("  1. Install vitest + vitest-intent (public npm; no .npmrc, no token - see csd-library ADR-0003):")
    print("       npm install --save-dev vitest @psa-department-of-engineering/vitest-intent@^2.0.1")
    print("       # local dev against an unreleased checkout: npm i -D --install-links path/to/csd-library/vitest-intent")
    print("  2. Add intent('INT-NNN', name, fn) calls to your test files; add claims to intent.yaml")
    print(f"  3. Run tests:   cd {target} && npx vitest run")
    print(f"  4. Audit spec + coverage with the standalone CLI:   csd-intent {target}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
