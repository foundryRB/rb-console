#!/usr/bin/env python3
"""Scaffold a new Starlight (Astro) documentation site.

See SKILL.md. Idempotent - skips existing files.

Usage:
  python bootstrap.py --target <path> --name "<Site Name>" --description "<one-line>"
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

# The STARLIGHT bundle ships with the apply-intent-bundle skill; its templates are the one
# source of every page shape, the scaffold's own index included (REF-Documentation.md 7.11).
BUNDLE_TEMPLATES = (
    Path(__file__).resolve().parent.parent
    / "apply-intent-bundle" / "bundles" / "starlight" / "templates"
)


def _write(path: Path, content: str) -> bool:
    """Write content if file doesn't exist. Returns True if written."""
    if path.exists():
        print(f"  SKIP (exists): {path.relative_to(path.anchor)}")
        return False
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")
    print(f"  WRITE: {path.relative_to(path.anchor)}")
    return True


PACKAGE_JSON_TMPL = """{{
  "name": "{slug}",
  "version": "0.1.0",
  "private": true,
  "description": "{description}",
  "type": "module",
  "scripts": {{
    "dev": "astro dev",
    "build": "astro check && astro build",
    "preview": "astro preview",
    "test": "vitest run",
    "test:watch": "vitest",
    "lint:md": "markdownlint-cli2 \\"src/content/docs/**/*.{{md,mdx}}\\""
  }},
  "devDependencies": {{
    "@astrojs/check": "^0.9.9",
    "@astrojs/mdx": "^7.0.2",
    "@astrojs/starlight": "^0.41.3",
    "@types/node": "^22.0.0",
    "astro": "^7.0.6",
    "markdownlint-cli2": "^0.23.0",
    "typescript": "^5.8.0",
    "vitest": "^5.0.3",
{vitest_intent_dep}    "zod": "^3.25.0"
  }},
  "dependencies": {{
    "@psa-department-of-engineering/starlight-theme": "{starlight_theme_spec}",
    "astro-mermaid": "^2.0.2",
    "mermaid": "^11.15.0"
  }}
}}
"""


ASTRO_CONFIG_TMPL = """import {{ defineConfig }} from 'astro/config';
import mermaid from 'astro-mermaid';
import mdx from '@astrojs/mdx';
import starlight from '@astrojs/starlight';
import {{ mermaidConfig }} from '@psa-department-of-engineering/starlight-theme';

export default defineConfig({{
  site: process.env.SITE_URL ?? 'http://localhost:4321',
  integrations: [
    // Must precede starlight so it transforms ```mermaid blocks before
    // expressive-code renders them as code. autoTheme follows dark/light.
    // mermaidConfig + the stylesheet come from the shared starlight-theme package
    // (one source of truth; REF-StarlightDocs 8.1).
    mermaid({{ autoTheme: true, mermaidConfig }}),
    starlight({{
      title: '{title}',
      description: '{description}',
      // Shared theme first, then this site's own overrides (kept minimal).
      customCss: [
        '@psa-department-of-engineering/starlight-theme/styles.css',
        './src/styles/custom.css',
      ],
      lastUpdated: true,
      tableOfContents: {{
        minHeadingLevel: 2,
        maxHeadingLevel: 3,
      }},
      // The application documentation set (REF-Documentation.md section 7.11), in the reader's
      // journey (section 7.1): a page joins its group by the folder it is written in. Add the brand page and the glossary as
      // items once they exist ('brand', 'glossary'); a slug naming no page fails the build.
      sidebar: [
        {{ label: 'Overview', items: ['index'] }},
        {{ label: 'Modules', items: [{{ autogenerate: {{ directory: 'modules' }} }}] }},
        {{ label: 'Flows', items: [{{ autogenerate: {{ directory: 'flows' }} }}] }},
        {{ label: 'Operations', items: [{{ autogenerate: {{ directory: 'operations' }} }}] }},
        {{ label: 'Reference', items: [{{ autogenerate: {{ directory: 'reference' }} }}] }},
        {{ label: 'Decisions', items: [{{ autogenerate: {{ directory: 'decisions' }} }}] }},
      ],
    }}),
    // mdx() must be placed after starlight() (astro-expressive-code ordering,
    // REF-StarlightDocs section 5).
    mdx(),
  ],
}});
"""


CONTENT_CONFIG_TMPL = """import { defineCollection, z } from 'astro:content';
import { docsLoader } from '@astrojs/starlight/loaders';
import { docsSchema } from '@astrojs/starlight/schema';

// Required frontmatter per REF-StarlightDocs §4.
// Extends Starlight's docsSchema with project-specific fields.
const docs = defineCollection({
  loader: docsLoader(),
  schema: docsSchema({
    extend: z.object({
      id: z.string().regex(/^DOC-[A-Z0-9-]+$/, "id must look like DOC-FOO-001"),
      type: z.enum(['Overview', 'Guide', 'Standard', 'Reference', 'Template', 'Intent', 'Flow', 'Module']),
      status: z.enum(['Draft', 'Active', 'Deprecated']).default('Draft'),
      updated: z.string().regex(/^\\d{4}-\\d{2}-\\d{2}$/, "updated must be YYYY-MM-DD"),
      version: z.string().optional(),
      owner: z.string().optional(),
      tags: z.array(z.string()).optional(),
      summary: z.string().optional(),
    }),
  }),
});

export const collections = { docs };
"""


TSCONFIG_TMPL = """{
  "extends": "astro/tsconfigs/strict",
  "include": [".astro/types.d.ts", "**/*"],
  "exclude": ["dist"]
}
"""


VITEST_CONFIG_TMPL = """import { defineConfig } from 'vitest/config';

export default defineConfig({
  test: {
    include: ['tests/**/*.test.ts'],
    environment: 'node',
    // A fresh scaffold may have no test files yet (scaffolded with --no-intent,
    // or before the STARLIGHT bundle's claim tests land), so an empty run passes.
    passWithNoTests: true,
  },
});
"""


GITIGNORE_TMPL = """# Build output
dist/
.astro/

# Dependencies
node_modules/

# Logs
npm-debug.log*

# Environment
.env
.env.local
.env.*.local

# Editor
.DS_Store
.vscode/
.idea/

# OS
Thumbs.db
"""


CUSTOM_CSS_TMPL = """/* Site-specific overrides only. The shared theme (warm dark palette + Mermaid
   contrast layer) comes from @psa-department-of-engineering/starlight-theme, wired
   ahead of this file in astro.config.mjs customCss. Keep this file minimal; add a
   rule here only for something genuinely specific to this site.
   See REF-StarlightDocs section 8.1 ("consume the shared theme package"). */
"""


README_TMPL = """# {title}

{description}

## Quickstart

```bash
npm install
npm run dev          # http://localhost:4321
```

## Scripts

| Command            | Action                                                   |
|--------------------|----------------------------------------------------------|
| `npm run dev`      | Start local dev server                                   |
| `npm run build`    | Run `astro check` + production build                     |
| `npm run preview`  | Preview the production build locally                     |
| `npm run test`     | Run vitest (STARLIGHT bundle frontmatter claims)         |
| `npm run lint:md`  | Lint Markdown content                                    |

## Structure

```
.
├── astro.config.mjs       # Starlight configuration
├── src/
│   ├── content.config.ts  # Content collection schema (frontmatter validation)
│   ├── content/
│   │   └── docs/          # All site content: the application documentation set
│   └── styles/
│       └── custom.css     # Site-specific overrides (the shared theme comes from the package)
├── tests/
│   └── starlight.test.ts     # STARLIGHT bundle frontmatter claims (--no-intent skips)
├── templates/                # Per-type page templates (from STARLIGHT bundle)
├── intent.yaml               # CSD intent claims (from STARLIGHT bundle)
└── public/                # Static assets
```

## Authoring rules

- Use Markdown by default; MDX only when components are needed (per `REF-StarlightDocs.md` §3 in the playbook).
- Every doc page requires frontmatter with: `title`, `id`, `type`, `status`, `updated`. Schema enforces this at build time.
- The sidebar follows the application documentation set (`REF-Documentation.md` §7.11 in the playbook): a page written under `modules/`, `flows/`, `operations/`, `reference/` or `decisions/` joins its group. With the STARLIGHT bundle applied, each page starts from its type's template in `templates/`.

## Scaffolded by

`bootstrap-starlight` skill - see `skills/bootstrap-starlight/SKILL.md` in the playbook.
"""


# A placeholder in a template's prose: `<what goes here>`. Fenced blocks and HTML comments are
# left as the template wrote them.
_KEPT_RE = re.compile(r"(^[ \t]*(`{3,}|~{3,})[^\n]*\n[\s\S]*?\n[ \t]*\2[ \t]*$|<!--[\s\S]*?-->)", re.M)
_PLACEHOLDER_RE = re.compile(r"<(?![!/])([^<>\n]+)>")
_LINK_TARGET_RE = re.compile(r"\]\(<[^<>\n]+>\)")
# Holds the intro's place while the placeholders are filled, so the description is never read
# as one.
_INTRO = "\x00INTRO\x00"


def render_index(title: str, description: str, today: str, template: Path) -> str:
    """The site's index, rendered from the bundle's Overview template.

    The scaffold owns the frontmatter values; the template owns the shape. The intro
    placeholder, the first paragraph that is a placeholder alone, carries the site's
    description verbatim. Every other placeholder becomes the render-safe form the module
    template uses (UPPERCASE text, a link target of `#`), so the page builds and the build
    that fills it sees what is left. The template's authoring comments are its own and stay
    out of the page. A template missing a field the scaffold fills is refused.
    """
    text = template.read_text(encoding="utf-8").replace("\r\n", "\n")
    if not text.startswith("---\n"):
        raise ValueError(f"{template}: no frontmatter")
    close = text.index("\n---\n", 4)
    front, body = text[4:close], text[close + 5:]
    values = {
        "title": json.dumps(title, ensure_ascii=False),
        "id": "DOC-OVERVIEW-001",
        "status": "Draft",
        "updated": f'"{today}"',
        "summary": json.dumps(description, ensure_ascii=False),
    }
    for key, value in values.items():
        line = f"{key}: {value}"
        front, n = re.subn(rf"^{key}:.*$", lambda m, line=line: line, front, count=1, flags=re.M)
        if n != 1:
            raise ValueError(f"{template}: the frontmatter has no `{key}:` field to fill")

    def fill(prose: str) -> str:
        prose = _LINK_TARGET_RE.sub("](#)", prose)
        return _PLACEHOLDER_RE.sub(lambda m: m.group(1).upper(), prose)

    body = re.sub(r"\n*<!--[\s\S]*?-->\n*", "\n\n", body).lstrip("\n")
    intro = re.compile(r"^<(?![!/])[^<>\n]+>[ \t]*$", re.M)
    heading = body.find("\n## ")
    lead = body if heading < 0 else body[:heading]
    lead = intro.sub(_INTRO, lead, count=1)
    body = lead + ("" if heading < 0 else body[heading:])
    parts = _KEPT_RE.split(body)
    out, i = [], 0
    while i < len(parts):
        out.append(fill(parts[i]))
        if i + 1 < len(parts):
            out.append(parts[i + 1])
        i += 3
    return f"---\n{front}\n---\n\n" + "".join(out).replace(_INTRO, description)


def slugify(name: str) -> str:
    return "".join(c if c.isalnum() or c == "-" else "-" for c in name.lower()).strip("-")


def _find_csd_library(target: Path) -> Path | None:
    """Locate the csd-library clone in the target's workspace.

    Sibling-clone convention: csd-library is checked out next to the project
    clones in the workspace (<workspace>/csd-library). Walks up from the target
    through its ancestors looking for a csd-library/ directory.
    """
    target = target.resolve()
    for ancestor in [target, *target.parents]:
        cand = ancestor / "csd-library"
        if cand.is_dir():
            return cand
    return None


def _starlight_theme_spec(target: Path) -> str:
    """Resolve a working npm spec for @psa-department-of-engineering/starlight-theme.

    Mirrors ``_vitest_intent_spec``: a sibling ``csd-library/starlight-theme``
    checkout yields a relative ``file:`` spec for local dev (install with
    ``--install-links`` so npm packs per the package's ``files`` allowlist);
    otherwise the committed default is the registry range ``^1.1.0``, resolved
    from the public npm registry with no .npmrc and no credential (csd-library
    ADR-0003). The theme is wired by default, independent of intent, so this is
    resolved on every scaffold.
    """
    import os
    lib = _find_csd_library(target)
    if lib is not None and (lib / "starlight-theme").is_dir():
        return "file:" + os.path.relpath(lib / "starlight-theme", target).replace(os.sep, "/")
    return "^1.1.0"


def _vitest_intent_spec(target: Path) -> str:
    """Resolve a working npm spec for @psa-department-of-engineering/vitest-intent.

    Published to the public npm registry (see csd-library ADR-0003), so the
    committed default is the registry range ``^2.0.0`` and needs no .npmrc and
    no credential. For local dev, if a sibling
    ``csd-library/vitest-intent`` checkout is found, return a relative ``file:``
    spec instead - install that with ``npm install --install-links`` so npm packs
    per the package's ``files`` allowlist rather than symlinking the checkout's
    node_modules.
    """
    import os
    lib = _find_csd_library(target)
    if lib is not None and (lib / "vitest-intent").is_dir():
        return "file:" + os.path.relpath(lib / "vitest-intent", target).replace(os.sep, "/")
    return "^2.0.1"


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--target", type=Path, required=True, help="target directory (created if missing)")
    ap.add_argument("--name", required=True, help="site title (e.g., 'My Project Docs')")
    ap.add_argument("--description", required=True, help="one-line description")
    ap.add_argument("--no-intent", action="store_true",
                    help="skip applying the STARLIGHT intent bundle (no intent.yaml + no claim tests)")
    args = ap.parse_args()

    target: Path = args.target
    overview = BUNDLE_TEMPLATES / "overview.md"
    if not overview.is_file():
        print(
            f"the STARLIGHT bundle's Overview template is not at {overview}: install the "
            "apply-intent-bundle skill beside this one (the index is rendered from it)",
            file=sys.stderr,
        )
        return 2
    if target.exists() and any(target.iterdir()):
        print(f"target exists and is non-empty: {target}", file=sys.stderr)
        return 2

    target.mkdir(parents=True, exist_ok=True)

    from datetime import date
    today = date.today().isoformat()
    slug = slugify(args.name)

    print(f"Scaffolding Starlight site at {target}")

    # The shared starlight-theme is wired by default (the look is independent of
    # intent). Both scoped packages resolve from the public npm registry, so no
    # .npmrc and no credential is scaffolded. vitest-intent is the only
    # intent-conditional dep: with --no-intent the site gets a plain vitest
    # harness and no vitest-intent dep, but still gets the theme.
    vitest_intent_dep = (
        ""
        if args.no_intent
        else f'    "@psa-department-of-engineering/vitest-intent": "{_vitest_intent_spec(target)}",\n'
    )
    _write(target / "package.json", PACKAGE_JSON_TMPL.format(
        slug=slug,
        description=args.description.replace('"', '\\"'),
        vitest_intent_dep=vitest_intent_dep,
        starlight_theme_spec=_starlight_theme_spec(target),
    ))
    _write(target / "astro.config.mjs", ASTRO_CONFIG_TMPL.format(
        title=args.name.replace("'", "\\'"),
        description=args.description.replace("'", "\\'"),
    ))
    _write(target / "tsconfig.json", TSCONFIG_TMPL)
    _write(target / "vitest.config.ts", VITEST_CONFIG_TMPL)
    _write(target / ".gitignore", GITIGNORE_TMPL)
    _write(target / "README.md", README_TMPL.format(
        title=args.name,
        description=args.description,
    ))
    _write(target / "src" / "content.config.ts", CONTENT_CONFIG_TMPL)
    _write(target / "src" / "content" / "docs" / "index.md", render_index(
        args.name, args.description, today, overview,
    ))
    _write(target / "src" / "styles" / "custom.css", CUSTOM_CSS_TMPL)
    # No in-suite meta-test is written. Frontmatter is validated two ways:
    #   - the Zod content schema (src/content.config.ts) at build time (astro check), and
    #   - the STARLIGHT bundle's tests/starlight.test.ts (applied by default below,
    #     unless --no-intent), as claim-backed intent() vitest tests.
    # Schema + coverage auditing of intent.yaml is the standalone csd-intent CLI's job.
    # public/ is needed by Starlight; create empty
    (target / "public").mkdir(exist_ok=True)
    _write(target / "public" / ".gitkeep", "")

    # Apply STARLIGHT intent bundle by default (--no-intent to skip)
    if not args.no_intent:
        print()
        print("Applying STARLIGHT intent bundle...")
        _apply_starlight_bundle(target)

    print()
    print("Next steps:")
    print(f"  cd {target}")
    print("  npm install --install-links   # --install-links packs the local file: vitest-intent (omit if pinned to the registry range)")
    print("  npm run dev      # http://localhost:4321")
    print("  npm run test     # vitest: STARLIGHT frontmatter claims (skipped with --no-intent)")
    print("  npm run build    # astro check + production build")
    return 0


def _apply_starlight_bundle(target: Path) -> None:
    """Invoke the apply-intent-bundle skill for the STARLIGHT bundle.

    Uses subprocess since apply.py is a peer Skill; importing across Skill
    boundaries would couple bootstrap-starlight to apply-intent-bundle's
    internal module layout. The bundle ships with that skill (its bundles/
    folder), so nothing else needs to be checked out for it to apply.
    """
    import subprocess
    apply_script = Path(__file__).resolve().parent.parent / "apply-intent-bundle" / "apply.py"
    if not apply_script.is_file():
        print(f"  warn: apply-intent-bundle script not found at {apply_script} - skipping bundle apply")
        return
    cmd = [
        sys.executable, str(apply_script),
        "--bundle", "starlight",
        "--target", str(target),
        "--runner", "vitest",
    ]
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.stdout:
        for line in result.stdout.rstrip().splitlines():
            print(f"  {line}")
    if result.returncode != 0:
        if result.stderr:
            for line in result.stderr.rstrip().splitlines():
                print(f"  err: {line}", file=sys.stderr)
        print("  bundle apply failed - site is scaffolded but intent claims are not in place")


if __name__ == "__main__":
    sys.exit(main())
