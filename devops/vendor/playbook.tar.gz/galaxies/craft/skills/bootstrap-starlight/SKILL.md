---
name: bootstrap-starlight
description: Scaffold a new Starlight (Astro) documentation site with REF-StarlightDocs-aligned defaults. Wires the shared @psa-department-of-engineering/starlight-theme (customCss + the exported mermaidConfig) by default. Generates package.json (incl. vitest-intent by default), astro.config.mjs, content collection schema, a vitest harness, and placeholder content. Auto-applies the STARLIGHT intent bundle by default (use --no-intent to skip).
galaxy: craft
refs:
  - REF-Documentation
  - REF-StarlightDocs
  - REF-CSD
  - REF-Intent-Bundle
---

# Bootstrap Starlight

Invoked when the user wants to start a new Starlight documentation site, or scaffold one inside an existing project. This skill produces a *working* skeleton - `npm install && npm run dev` should yield a live local site. Sane defaults; user customizes from there.

Reference implementation: the canonical CSD docs site (separate project) is structurally complete. This skill scaffolds a thinner version of the same shape.

## Pre-flight

1. **Read** `REF-Documentation.md` and `REF-StarlightDocs.md` for content conventions.
2. **Confirm target path** - empty directory or new directory to be created.
3. **Confirm site name + description** - needed for `astro.config.mjs` and `package.json`.
4. **Verify Node.js available** - Astro 7 requires Node >= 22.12 (use `node:22-slim` in any Dockerfile). Surface to user if missing.

## What it produces

```
<target>/
├── package.json           # Astro 7.x + Starlight 0.41+ + @astrojs/mdx 7, vitest (+ vitest-intent unless --no-intent), astro-mermaid + the shared starlight-theme
├── astro.config.mjs       # Starlight + astro-mermaid wired to the shared theme (customCss + the exported mermaidConfig); mdx() after starlight(); the sidebar groups the documentation set's folders
├── tsconfig.json
├── vitest.config.ts       # Test harness for frontmatter / content validation
├── .gitignore             # node_modules, dist, .astro
├── README.md              # Quickstart instructions
├── public/                # Static assets (favicon placeholder)
├── src/
│   ├── content.config.ts  # Content collection schema (docsLoader) enforcing required frontmatter
│   ├── content/
│   │   └── docs/
│   │       └── index.md   # The Overview, rendered from the bundle's overview template
│   └── styles/
│       └── custom.css     # Site-specific overrides only; the shared theme comes from the package
├── tests/
│   └── starlight.test.ts    # STARLIGHT bundle frontmatter + page-structure claims (intent() tests; --no-intent skips)
├── templates/               # Per-type page templates copied by the bundle (--no-intent skips)
└── intent.yaml              # CSD intent claims (from the STARLIGHT bundle; --no-intent skips)
```

`templates/` and the page-structure claim tests only appear when the STARLIGHT bundle is applied (the default). With `--no-intent` the scaffold is a plain Starlight site with a frontmatter-only schema and no bundle claims, templates, or claim tests. The shared theme is wired regardless of `--no-intent`: the look is a runtime-styling concern, independent of the intent contract (see "Shared theme" below).

## Required frontmatter (per REF-StarlightDocs §4)

Every doc page gets:
- `title` - page title (string)
- `id` - stable identifier like `DOC-OVERVIEW-001`
- `type` - page kind (`Overview`, `Guide`, `Standard`, `Reference`, `Template`, `Intent`, `Flow`, `Module`)
- `status` - `Draft`, `Active`, `Deprecated`
- `updated` - ISO date

The content collection schema (`src/content.config.ts`, at the root of `src/`, using Starlight's `docsLoader()`) enforces these via Zod. Pages missing any field fail `astro check`.

## Page-structure contract (per REF-Documentation §7)

Beyond frontmatter, the STARLIGHT bundle enforces a generic, lenient page-structure contract on every doc page (applied by default; `--no-intent` skips it):

- Every page opens with non-empty introductory prose before its first level-2 heading (an optional leading nav or bold-only line is allowed, but some prose must precede the first `##`).
- Every page has at least one level-2 heading.
- A `Flow` page contains a Mermaid `sequenceDiagram` plus a steps section (a `## Steps` heading or an ordered list).
- A `Guide` page contains a numbered procedure (an ordered list, or at least two headings that begin with a number).
- A `Module` page, the low-level design of its bounded context, carries the three viewpoints Business, Functional and Technical (as tabs or level-2 headings), a Mermaid `classDiagram` or `erDiagram` of its domain model, and a `Failure modes` heading and a `Claims realised` heading; every claim id cited under Claims realised is an active claim in the application's `intent.yaml` (INT-STARLIGHT-015, whose rule for locating that file is in the bundle's README, `../apply-intent-bundle/bundles/starlight/README.md`, "What INT-STARLIGHT-015 reads") (`REF-Documentation.md` §7.11).
- Outside `decisions/`, no page's prose names an ADR identifier or links an individual decision page; the collection itself is linked from the index (`REF-Documentation.md` §7.9).

The `type` enum the bundle accepts is `{Overview, Guide, Standard, Reference, Template, Intent, Flow, Module}`, and the scaffolded content schema accepts the same set. The claims are intentionally lenient so well-formed docs across different sites pass. Site-editorial rules beyond these stay site-local and are not part of the bundle.

Per-type page templates ship with the bundle. When the bundle is applied, `apply-intent-bundle` copies them into `templates/` in the target; a new page starts from the template matching its `type`.

The site starts inside the application documentation set (`REF-Documentation.md` §7.11). The index is rendered from the bundle's `overview.md`, with or without `--no-intent`: the frontmatter carries the site's name and description, the intro is the description, and every other placeholder stays visible in upper case for the build to fill. The sidebar groups the set's folders (`modules/`, `flows/`, `operations/`, `reference/`, `decisions/`, in the journey order of `REF-Documentation.md` §7.1), so a page joins its group by where it is written; an absent folder is an empty group. The scaffold writes no other page: a page describing nothing yet is not on the site.

## Shared theme (the look)

Every scaffolded site consumes the shared `@psa-department-of-engineering/starlight-theme` package instead of carrying its own copy of the theme. The package is the single source of truth for the docs-site look (warm dark palette + a token-based Mermaid contrast layer) and ships in two parts the scaffold wires automatically:

- **`customCss`** points at `@psa-department-of-engineering/starlight-theme/styles.css` (the shared stylesheet), followed by the site's own `src/styles/custom.css` for genuinely site-specific overrides.
- **`mermaidConfig`** is imported from the package and spread into the `astro-mermaid` integration: `mermaid({ autoTheme: true, mermaidConfig })`. `astro-mermaid` is placed before `starlight()` so it transforms ` ```mermaid ` blocks before expressive-code renders them as code.

This is wired by default and is independent of `--no-intent`. Do not paste the palette or Mermaid CSS into a site; change the shared package instead so every site moves together (`REF-StarlightDocs` §8.1).

**Not the STARLIGHT intent bundle.** The theme is the *look* (CSS + Mermaid config, an npm dependency). The STARLIGHT intent bundle is the *contract* (frontmatter + page-structure claims and their `intent()` tests, copied in by `apply-intent-bundle`). They are orthogonal: `--no-intent` drops the bundle but keeps the theme; a site can adopt either, both, or neither.

## Steps

1. **Run the scaffolder** (Python helper at `<this-skill>/bootstrap.py`):
   ```bash
   python bootstrap.py --target <path> --name "<Site Name>" --description "<one-line description>"
   ```
2. **Install dependencies** (`--install-links` packs the local `file:` siblings - `starlight-theme`, and `vitest-intent` unless `--no-intent` - instead of symlinking their `node_modules`; if the scaffold pinned the registry ranges instead, they resolve from the public npm registry with no `.npmrc` and no credential, per csd-library ADR-0003):
   ```bash
   cd <target> && npm install --install-links
   ```
3. **Verify**:
   ```bash
   npm run dev    # local site at http://localhost:4321
   npm run test   # vitest frontmatter check
   npm run build  # production build (also runs astro check)
   ```
4. **Surface to user**:
   - "Starlight scaffolded. Run `npm install --install-links` then `npm run dev`. Add docs under `src/content/docs/` in the set's folders, starting from a per-type template in `templates/`. Frontmatter is enforced by the content collection schema; the STARLIGHT bundle's claim tests (`npm run test`) enforce both frontmatter and page structure (intro prose before the first heading, at least one level-2 heading, plus per-type rules for Flow and Guide pages)."

## Optional flags (future, not v1)

- `--with-plantuml` - wire CSD's remark-plantuml plugin
- `--with-mermaid` - add mermaid integration
- `--with-search algolia` - switch from default Pagefind to Algolia

For v1, scaffold minimal. Users add these after when needed.

## Failure modes

- **Target exists and is non-empty** - surface; don't overwrite.
- **Node.js not available** - surface; can't validate the scaffold without it.
- **`npm install` fails** - surface with the npm error verbatim; don't suppress.
- **The bundle's Overview template is absent** - the index is rendered from it, so the scaffold refuses before writing anything. Install the `apply-intent-bundle` skill beside this one.
- **The bundle does not apply** - the STARLIGHT bundle ships with the `apply-intent-bundle` skill, so both skills must be installed; the scaffold completes and reports what failed. Reinstall the skills (or rerun with `--no-intent`).

## Anti-patterns

- ❌ Running `npm create astro@latest` (interactive, fragile) - we write files directly with vetted defaults.
- ❌ Adding plugins/integrations the user didn't ask for. Scaffold minimal; user adds.
- ❌ Re-adding the dark palette or the Mermaid contrast layer per site. Both live once in `@psa-department-of-engineering/starlight-theme` (wired by default); `src/styles/custom.css` is for genuinely site-specific overrides only. Theme-default first, per `REF-StarlightDocs` §8.1.
- ❌ Pre-creating MDX pages - Markdown is the default per `REF-StarlightDocs §3`. MDX added when needed.
- ❌ A page skeleton carried in this skill. Every page shape, the index's included, is the STARLIGHT bundle's template, so the two never drift.

## See also

- `REF-Documentation.md` §7 - generic doc patterns
- `REF-StarlightDocs.md` - Starlight-specific patterns this skill instantiates (the shared theme is §8.1)
- `@psa-department-of-engineering/starlight-theme` (master at `../csd-library/starlight-theme`): the shared theme this skill wires by default (stylesheet + mermaidConfig)
- `bootstrap-pytest-intent` - sister skill for Python+pytest projects (doesn't apply here; Starlight uses vitest)
