---
name: contentful-content-management
description: "Work a Contentful space: hunt for the type that already exists and show it before ever proposing a new one, rule on the standing question every content request really asks - reuse, extend, or create - and never touch an existing type without putting its entry counts, inbound links and outside consumers in front of the user first. Treat every environment move as a schema act, because an env-copy deletes destination fields the source does not carry. Reads run freely; every write is proposed and confirmed, every destructive act is dry-run first and staged outside master, because a deleted field takes its data with it."
galaxy: craft
refs:
  - REF-Domain
  - REF-Autonomy
---

# Contentful content model

Invoked when a task needs to read or change a Contentful space: answering a question about what content exists, adding a field, modelling a new kind of page, auditing a model before a migration, or moving content between environments. The skill carries four things a request never carries on its own: the **orientation rule** (never act on a model you have not read), the **duplicate hunt** (find the type that already does this, and show it before proposing another), the **impact rule** (never change a type already in use without putting what depends on it in front of the user), and the **environment-move rule**, that copying content is a schema act and not a data act.

A request arrives describing a thing, and the quickest path is always to build that thing. The two most expensive mistakes in a content model are taken on that path: a second type that duplicates one already there, and an edit to a type that something else was quietly relying on. Both are cheap to prevent by looking first, and permanent once made.

## Pre-flight

1. **Read** `REF-Domain.md`. A content type is a domain entity by another name, and the "Where Does This Code Belong?" judgment (identity and lifecycle versus descriptive data) is the same judgment this skill applies to types and fields.
2. **The door is the `contentful-migrate` app, onboarded on the Foundry.** It is not an MCP server and there is no separate REST service to find: the app holds the credential the space is reached with, and that credential is what every operation in this skill travels on. Two surfaces come off it - the app's own commands for environment lifecycle (copy, create, purge, revert, prepare), and the Contentful **Management API** for reading and editing the model one type or field at a time. Resolve the credential from where the Foundry keeps it (the app's secret in its namespace), never from this document and never from a copy pasted into a shell history; a token written into the playbook is both stale and leaked the moment it lands there. If the task needs something neither surface offers, say so and stop; do not improvise a third door.
3. **Confirm the target space AND environment before the first call.** A space has many environments and they are not interchangeable. `master` is the served environment: work staged there is live the moment it is published. Name both in the proposal; "the space" is not a target.
4. **Establish write authority.** Reads need no permission. Every write is proposed and confirmed (see "Propose and confirm"). If the run has no human able to answer (`REF-Autonomy.md`), it performs reads and returns its proposal; it does not write.
5. **Read the door's live operation list from the door itself**, not from memory. The endpoint and command inventory is the door's to state; this skill names only the operations that carry the procedure.

## Steps

### 1. Orient before acting

Read the whole model of the target environment first, every time, with its relationships resolved. It is the only way to answer "does something like this already exist?" - the question the rest of this skill depends on.

Acting before orienting is how a duplicate type gets created: the request says "we need a promo banner", the model already has `promoModule` doing exactly that, and nobody looked.

For content questions rather than schema questions, a full-text or filtered entry query answers without touching the model at all. Many requests that sound like schema changes are satisfied here; check before proposing a change.

### 2. Hunt for what already exists, and show it

Orientation is passive; this step is the search, and it is not optional. Before proposing any new type, look for a type that already does the job, by **all** of these, because each catches what the others miss:

- **By id and name**, including the obvious synonyms. `promoBanner`, `promoModule`, `bannerPromo` and `marketingBanner` are four names for one idea, and nothing but a deliberate search connects them.
- **By field overlap.** A type whose fields substantially match the ask is a candidate even when its name shares nothing with the request.
- **By purpose.** Read the descriptions. Two types that render the same thing in different places are still one idea.

Then **show the user what you found**, before any ruling: the candidate's id and name, its fields, how many entries it has, and what else links to it. Name the nearest candidate even when you intend to rule "create" - a ruling that never named its neighbours is not a ruling, it is a preference.

If a match exists, the default is to **use it**, and that is the user's call to make, not yours. Propose the existing type, say plainly what the ask would need from it, and wait. Creating a near-duplicate because the existing one was *almost* right is how a model rots; the user decides whether "almost" is good enough, and they can only decide that if you showed them the candidate.

**Compute the gap, and test whether it is additive.** Having found a candidate, list exactly what the ask needs that the type does not already carry. Then ask one question of that list: *can every missing piece be an optional field?*

When the answer is yes, the gap is **additive** - adding optional fields changes nothing for anyone already using the type. Existing entries stay valid, because an optional field has no value to be missing. Existing consumers keep working, because they read fields they already know and ignore ones they do not. Nothing is renamed, retyped, or removed.

That case has a strong recommendation and you must make it explicitly, before offering to create anything:

> `heroBanner` already does this. The ask needs two fields it lacks, `subtitle` and `badgeText`. Both can be optional, so adding them changes nothing for the 412 existing entries or for anything rendering them today. Shall I extend `heroBanner` instead of creating a new type?

State the non-breaking property as the *reason*, not as a footnote - it is what makes extending the cheap option, and the user cannot weigh it if it is not said.

The recommendation flips when the gap is **not** additive: a field that must be required, an existing field that must change type or meaning, or behaviour the type would have to stop doing. Those are changes to something already in use, they go through the impact review of step 4, and a separate type may genuinely be the safer answer. Say which of the two you are looking at; do not blur them.

One guard against over-applying this: a gap that is additive on paper can still be the wrong call. If the fields would only ever be filled for one subset of entries, and never for the rest, the type is being asked to be two things. That is the lifecycle test of step 3, and it outranks the convenience of an additive diff.

Only when the user has seen the candidates and the gap, and rejected them, does "create" become available.

### 3. Classify what is actually being asked

Sort the request into one of three, using what the model showed:

| The ask | Ruling |
| --- | --- |
| A thing the model already expresses, differing only in presentation, placement, or a variant value | **Reuse.** Vary it with an existing field or a new optional one; do not add a type. |
| The same thing, carrying more facts than the type currently holds | **Extend.** Add fields to the existing type. When every missing field can be optional, this is the recommended ruling and the reason must be stated: it is non-breaking for existing entries and existing consumers. |
| A genuinely different thing: its own lifecycle, its own authoring audience, its own publishing cadence, or its own ownership | **Create.** A new content type is warranted. |

The discriminator for the third row is **lifecycle, not shape**. Two types with near-identical fields are correct when they are created, edited, published, and retired by different people on different schedules. Two types with different fields are a mistake when one of them is the other plus a flag.

A fourth ruling is always available and often right: **no model change at all**. The request is answered by content, by an existing optional field, or by a query.

### 4. Never change an existing type without an impact review

An existing type is load-bearing. Entries hold its data, other types link to it, and code somewhere renders it - and none of that is visible from the type definition alone. Changing it without looking is how a field rename takes a production page down.

So before **any** edit to a type that already exists - adding a field included - establish and state, read from the space rather than assumed:

- **How many entries** exist of this type, and how many are published. Published means live.
- **What links to it**: which other content types reference it, and which entries hold those references. A type nothing links to is a different risk from one at the centre of the model.
- **Which environments carry it**, and whether they have drifted. A change that is safe in `dev` is not automatically safe in `master`.
- **Who consumes it outside Contentful**: the frontends, the integrations, the exports. This is the part the API cannot answer, and the part most likely to break. If it cannot be established, say so - an unknown consumer is a risk to state, not to silently discount.

Then show the user that picture **before** the change, in plain terms: what is being altered, what currently depends on it, and what breaks if the assumption is wrong. A one-line "adding an optional field to `heroBanner`" is not that review; "`heroBanner` has 412 entries, 380 published, is linked from `homePage` and `campaignPage`, and exists in 6 environments" is.

The bar scales with reversibility, and it is **highest for anything that changes or removes what is already there**:

| The change | The bar |
| --- | --- |
| A new optional field | Review, then confirm. Additive and reversible. |
| A new required field, or tightening an optional one | Full review plus the backfill plan. It invalidates entries. |
| Renaming or retyping a field | Treated as destructive: it is add, migrate, verify, remove. |
| Removing a field, or deleting the type | Destructive and unrecoverable. Staged, dry-run, confirmed explicitly. |

Nothing in the right-hand column happens because it was implied by a larger request. Each is named, and each waits.

### 5. Extend safely

Adding a field is the common case and has one trap that matters:

- **Add the field optional.** A field added as required immediately invalidates every existing entry, because none of them carry a value for it.
- **Backfill** the existing entries.
- **Only then** tighten it to required, if it must be.

Skipping to a required field is the single most common way this work breaks a live space.

### 6. Treat an environment move as a schema act

An environment copy is not a data transfer with the model along for the ride. It **reconciles the destination model to the source**, and reconciliation deletes: a field present in the destination type and absent from the source type is omitted and deleted, and the type is republished. The field's data goes with it.

This is the most under-estimated destructive act in the toolkit, because nobody reading "copy content from `dev` to `test`" expects a field to disappear in `test`.

So, before any copy:

1. **Diff the two models first**, source against destination, type by type. The fields that exist only in the destination are the fields the copy will delete. Name them in the proposal, by type and field id, with their entry counts.
2. **Run the preparation pass** (preflight, reuse-map) and read its report rather than its exit code. A preflight that reports conflicts has told you the copy is not a copy.
3. **Confirm a snapshot is captured before the destination is mutated.** The revert path depends on it, and it must be taken ahead of reconciliation, not after.
4. **Keep the reuse-map honest.** Remapping links to reuse destination entries is a content decision: it silently re-points references. State which entries are being reused and why.

A copy into `master` is a production schema change. It gets the staging treatment of step 7, never a direct run.

### 7. Stage every destructive change

These are irreversible or entry-invalidating and are **never done in place on `master`**:

- **Removing a field**, whether by hand or as a side effect of an environment copy. The data is deleted with it.
- **Changing a field's type.** Not an edit; it is a new field plus a migration plus a backfill.
- **Making an existing optional field required.** Invalidates every entry lacking a value.
- **Deleting a content type.** It takes every entry of that type with it.
- **Purging an environment.** It deletes entries, assets, and content types.

Each becomes the same four-move sequence, staged in a non-master environment:

1. **Add** the new field beside the old one.
2. **Migrate** the data across.
3. **Verify** by diffing the staged environment against `master`, so the change is read before it lands rather than after.
4. **Remove** the old field, once the data is proven to be somewhere else.

Two mechanical habits make this real rather than aspirational:

- **Dry-run first, always, and read the artifact.** The destructive commands default to a dry run and write a report; the report is the blast radius, measured rather than guessed. A dry run whose report nobody opened is not a dry run.
- **The confirmation token is an environment id, not a safety net.** Typing the environment's name is all that stands between a dry run and a purge, and it is no harder to type `master` than `sandbox`. The judgment is yours; the prompt will not supply it.

### 8. Propose and confirm

Every write is proposed before it is performed. The proposal states, in plain terms:

- The ruling from step 3 and why (which existing types were considered and shown, and why each was or was not enough).
- When an existing type was a candidate: the gap between it and the ask, and whether that gap is additive. If it is, the recommendation to extend must appear here, with its non-breaking reason, even when the user has already asked for a new type.
- For a change to an existing type: the impact review from step 4 - entry counts, what links to it, which environments carry it, and the consumers that cannot be established from the API.
- The exact change: space, environment, types and fields touched, and for each, whether it is additive, entry-invalidating, or destructive.
- The blast radius: how many existing entries are affected, read from the space rather than guessed; and for an environment move, the destination fields the reconciliation will delete.
- For anything in steps 6 and 7: the staging environment, the dry-run report, and the diff that will be checked before `master` is touched.
- Whether a revert exists for this act, and what it restores. Some acts have one; a purge does not.

Then stop and wait. Reads may continue; writes wait for the word. A rejected proposal is a normal outcome, not a failure.

## Failure modes

- **A duplicate type gets proposed.** The search of step 2 was skipped or skimmed - most often because the request named a thing that sounded new. Search by id, by field overlap, and by purpose, then show the candidates. A model with `promoBanner` and `bannerPromo` in it is the permanent, visible cost of one skipped search.
- **A near-duplicate gets created because the existing type was "almost" right.** "Almost" is a decision for the user, not a reason to branch. Show the candidate, say what it lacks, and let them rule; adding an optional field to the existing type is nearly always cheaper than a second type nobody can tell apart later.
- **A new type was created when optional fields would have done.** The gap was additive and nobody said so, so the user chose between "new type" and nothing. Compute the gap, test whether every missing piece can be optional, and if it can, recommend extending and state why it is safe. An unstated option is not an option the user rejected.
- **Something broke that nobody connected to the change.** A type was edited without the step 4 review, so a consumer outside Contentful - a frontend, an export, an integration - was never in the picture. The API cannot enumerate those; the only defence is asking before the edit, not diagnosing after it.
- **Entries go invalid after a field is added.** The field was added required. Make it optional, backfill, then tighten. There is no way to un-invalidate entries other than supplying the values.
- **A field vanished in the destination after a copy.** Reconciliation deleted it because the source type did not carry it. This is the documented behaviour, not a bug. Recovery is the import's snapshot, if one was taken and kept; otherwise the data is gone.
- **A field was removed by hand and the data is gone.** It does not come back. This is why step 7 exists and why writes are confirmed. Recovery is from whatever backup, export, or snapshot the space keeps, which is a fact to establish *before* a destructive change, not after.
- **A content type refuses to delete.** Entries still reference it. Deciding what happens to those entries is a content decision for the owner, not a mechanical one to route around.
- **A revert does not restore what was expected.** A snapshot restores what it captured, in the state it captured - what existed, what was published, what was archived. Anything created after the snapshot, and anything the snapshot did not cover, is outside it. Read what the snapshot holds before relying on it.
- **Requests start failing in bulk.** The Management API rate-limits. A bulk operation must pace itself rather than retry into the limit; treat the limit as the design constraint for any sweep over many entries.
- **Every call returns 401.** The token is absent, wrong, or carries a stray character from a copy-paste. Check the token's own identity endpoint before concluding the permissions are wrong - an invalid token and an unauthorized one fail differently and are fixed differently.
- **A 401 that names an organization grant.** The token is valid but the organization has not granted it access. No code change gets past it; an org admin must approve.

## Anti-patterns

- **Acting before reading the model.** Every ruling in step 3 depends on knowing what already exists; without the model, "create a new type" is a guess wearing a decision's clothes.
- **Ruling "create" without showing the neighbours.** The user cannot overrule a candidate they were never shown. Naming the nearest existing type is what makes the ruling reviewable.
- **Editing an existing type on the quiet.** A type already in use carries entries, inbound links, and consumers the API cannot list. Changing it without that picture in front of the user is the single most expensive habit in this skill.
- **Treating an environment copy as a data operation.** It rewrites the destination's schema and deletes fields. Anyone who calls it "just a copy" has not diffed the two models.
- **Restating the door's operation list.** Each door serves its own inventory and ships its own documentation; a copy here drifts the first time a route or command is added. Name only the operations that carry the procedure.
- **Writing an instance URL, token, or CLI path into the playbook.** Instance facts live with the instance. The playbook says how to decide, never where this particular server happens to answer today.
- **Modelling by shape.** Two types are not the same because their fields match, and not different because they do not. Lifecycle and ownership decide.
- **A new type for a variant.** "Hero banner" and "hero banner, but green" is one type with a field. The pull toward a second type is strong and almost always wrong.
- **Schema changes straight onto `master`.** The staged environment plus the diff is the whole safety mechanism; skipping it converts a reversible mistake into a permanent one.
- **Performing a destructive write because it was implied.** "Clean up the model" and "sync the environments" do not authorize deleting fields. The proposal names each destructive act, and each waits.
- **Confirming your way through a prompt.** Typing the environment id is a mechanism, not a judgment. The dry-run report is where the judgment happens.

## See also

- `REF-Domain.md` - entity versus value object, identity and lifecycle: the same judgment this skill applies to content types and fields.
- `REF-Autonomy.md` - what a run does when no human is available to confirm a gated act.
- `REF-AppContract.md` - how an onboarded app holds its credential, which is where this skill's door gets its access to the space.
- The `contentful-migrate` app's own documentation and command list - the authoritative, current inventory this skill deliberately does not copy.
