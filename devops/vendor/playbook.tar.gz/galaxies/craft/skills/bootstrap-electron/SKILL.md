---
name: bootstrap-electron
description: "Scaffold an Electron desktop shell around an existing Vite/React MVVM renderer per REF-Electron: a locked-down main process (contextIsolation on, nodeIntegration off, sandbox on), a typed contextBridge preload surface, an electron-builder config, a per-OS packaging job wired into the release run (not on: release: published), and a Playwright-drives-Electron smoke e2e. Composes with bootstrap-react-mvvm rather than scaffolding a frontend; caller runs npm install, then the build and e2e gates."
galaxy: craft
refs:
  - REF-Electron
---

# Bootstrap Electron shell

Invoked when an existing Vite/React MVVM renderer should ship as an installable desktop app, and the Electron shell around it should conform to `REF-Electron.md` from the first commit. Deterministic scaffold; it adds the shell, it does not author the renderer.

## Pre-flight

1. **Read** `REF-Electron.md` (especially §2 shell/renderer boundary, §3 process security defaults, §4 the typed IPC surface, §6 the release-trigger trap).
2. **Confirm the ask is actually Electron**: the app needs the local machine (filesystem, native menus, tray, notifications, background work, offline-first). If a PWA or a browser tab would do, stop and route there instead (`REF-Electron.md` §1; `bootstrap-pwa` for the PWA).
3. **Confirm the renderer exists.** The shell composes around `bootstrap-react-mvvm`'s output; run that skill first if there is no Vite/React renderer to host. The scaffolder points the window at the renderer's build output, it does not create a frontend (`REF-Electron.md` §2).
4. **Confirm with user**: app name (kebab-case), the target directory, and the renderer's location relative to it (default `renderer/`).

## Steps

1. **Run the scaffolder**:
   ```bash
   python bootstrap.py --name <app-name> [--dir <target>] [--renderer <path>]
   ```
   This writes the `electron/` process code (`main.ts` with the locked-down `webPreferences`, `preload.ts` declaring the typed `contextBridge` surface), `electron-builder.yml`, the `package.json` scripts, the Playwright-drives-Electron smoke e2e, the release+package GitHub Actions workflow (packaging wired via `needs:` into the release run, per `REF-Electron.md` §6), and the README. It refuses to overwrite an existing target.
2. **Install and prove the shell**: `npm install`, then `npm run build` (renderer + main/preload), then `npm run e2e`. The e2e launches the packaged shell headlessly and asserts the window opens, the renderer signals ready, one IPC round-trip returns, and no console errors fired (`REF-Electron.md` §8).
3. **Wire the renderer to the bridge**: consume `window.desktop` through the typed `DesktopApi` façade as an outbound port in the MVVM layer, with a web fallback when the API is absent, so one codebase serves both the browser and the shell (`REF-Electron.md` §2, §4).
4. **Replace the placeholder IPC handlers** (`config:read`, `file:save`) with the app's real operations, keeping each a specific typed method and validating arguments on the main side.
5. **Iterate** with `npm run dev` (Vite dev server for the renderer, Electron pointed at it).

## Failure modes

- **Target directory already exists**: the scaffolder refuses; pick another name or remove the leftover.
- **The window is blank / renderer 404s**: the shell is pointed at the wrong renderer build path; fix `--renderer` (or the `loadFile` path in `main.ts`) to the renderer's actual `dist/` output.
- **An import fails in the renderer with "require is not defined"**: renderer code reached for Node or `electron`; move that work to the main process and expose it over the bridge (`REF-Electron.md` §3), never re-enable `nodeIntegration`.
- **The release ships with no installers attached**: the packaging job was keyed on `on: release: published`, which a `GITHUB_TOKEN` release never triggers; restore the `needs:`-on-release wiring (`REF-Electron.md` §6).
- **macOS or Windows installer missing from the matrix**: the packaging job inherited a Linux-only runner default; pin `runs-on` per OS (`REF-Electron.md` §5).
