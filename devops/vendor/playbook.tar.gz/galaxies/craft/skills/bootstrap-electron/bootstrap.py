#!/usr/bin/env python3
"""Scaffold an Electron desktop shell around an existing renderer, per REF-Electron.

Writes <parent>/<app-name>/ with the Electron process code (a locked-down main
process, a typed contextBridge preload surface), an electron-builder config, a
Playwright-drives-Electron smoke e2e, and a release+package GitHub Actions
workflow whose packaging job is wired into the release run (NOT keyed on
`on: release: published`, which a GITHUB_TOKEN release never triggers). The
shell composes around a Vite/React MVVM renderer (bootstrap-react-mvvm output);
this scaffolder writes the shell, not the frontend. Refuses to overwrite.

Usage:
    python bootstrap.py --name <app-name> [--dir <parent>] [--renderer <path>]
"""

from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

__all__ = ["main"]

NAME_RE = re.compile(r"^[a-z][a-z0-9]*(-[a-z0-9]+)*$")

PACKAGE_JSON = """{
    "name": "__APP_NAME__",
    "private": true,
    "version": "0.0.0",
    "description": "Electron desktop shell (REF-Electron) around the __RENDERER__/ renderer",
    "main": "dist-electron/main.js",
    "scripts": {
        "dev": "npm run build:shell && electron .",
        "build:shell": "tsc -p electron/tsconfig.json",
        "build": "npm run build:shell",
        "e2e": "npm run build && playwright test"
    },
    "devDependencies": {
        "@playwright/test": "^1.49.0",
        "electron": "^33.2.0",
        "electron-builder": "^25.1.8",
        "typescript": "^5.6.3"
    }
}
"""

# The shell's TS compiles to CommonJS under dist-electron/; Electron's main and
# preload load fastest as plain CJS and need no bundler.
ELECTRON_TSCONFIG = """{
    "compilerOptions": {
        "target": "ES2022",
        "module": "CommonJS",
        "moduleResolution": "node",
        "lib": ["ES2022", "DOM"],
        "outDir": "../dist-electron",
        "rootDir": ".",
        "strict": true,
        "noUnusedLocals": true,
        "noUnusedParameters": true,
        "esModuleInterop": true,
        "skipLibCheck": true
    },
    "include": ["main.ts", "preload.ts", "ipc.ts"]
}
"""

# The IPC contract, typed once. The renderer imports DesktopApi (the type),
# never this module; the implementation lives behind the contextBridge.
IPC_TS = """// The single source of truth for the renderer <-> main contract.
// Channel names are namespaced `domain:action` and never leak to the renderer,
// which sees only the methods preload publishes (REF-Electron section 4).

export interface AppConfig {
    version: string;
    locale: string;
}

export const CHANNELS = {
    configRead: 'config:read',
    fileSave: 'file:save',
    updateProgress: 'update:progress',
} as const;
"""

MAIN_TS = """import { app, BrowserWindow, ipcMain, shell } from 'electron';
import { writeFile } from 'node:fs/promises';
import * as path from 'node:path';
import { CHANNELS, type AppConfig } from './ipc';

// The renderer's built assets. Point this at the renderer's Vite `dist/` output
// (REF-Electron section 2); in development, ELECTRON_RENDERER_URL is the dev server.
const RENDERER_DIST = path.join(__dirname, '..', '__RENDERER__', 'dist');
const DEV_URL = process.env.ELECTRON_RENDERER_URL;

function createWindow(): BrowserWindow {
    const win = new BrowserWindow({
        width: 1100,
        height: 720,
        show: false,
        webPreferences: {
            // The three security defaults are load-bearing, not tunable per feature
            // (REF-Electron section 3): a compromised renderer stays contained.
            contextIsolation: true,
            nodeIntegration: false,
            sandbox: true,
            preload: path.join(__dirname, 'preload.js'),
        },
    });

    // Own assets only in the privileged window; real links go to the OS browser.
    win.webContents.setWindowOpenHandler(({ url }) => {
        void shell.openExternal(url);
        return { action: 'deny' };
    });
    win.webContents.on('will-navigate', (event, url) => {
        const current = win.webContents.getURL();
        if (url !== current) {
            event.preventDefault();
            void shell.openExternal(url);
        }
    });

    win.once('ready-to-show', () => win.show());
    if (DEV_URL) {
        void win.loadURL(DEV_URL);
    } else {
        void win.loadFile(path.join(RENDERER_DIST, 'index.html'));
    }
    return win;
}

function registerIpc(): void {
    // Request/response via handle; each handler is a specific, validated operation.
    ipcMain.handle(CHANNELS.configRead, (): AppConfig => {
        return { version: app.getVersion(), locale: app.getLocale() };
    });

    ipcMain.handle(CHANNELS.fileSave, async (_event, contents: unknown): Promise<string> => {
        // IPC input is untrusted input (REF-Electron section 4): validate before use.
        if (typeof contents !== 'string') {
            throw new TypeError('file:save expects a string payload');
        }
        const target = path.join(app.getPath('userData'), 'document.txt');
        await writeFile(target, contents, 'utf-8');
        return target;
    });
}

app.whenReady().then(() => {
    registerIpc();
    createWindow();
    app.on('activate', () => {
        if (BrowserWindow.getAllWindows().length === 0) createWindow();
    });
});

app.on('window-all-closed', () => {
    if (process.platform !== 'darwin') app.quit();
});
"""

PRELOAD_TS = """import { contextBridge, ipcRenderer } from 'electron';
import { CHANNELS, type AppConfig } from './ipc';

// The whole contract, exposed once as a narrow, typed surface. No generic
// `invoke(channel, ...)` passthrough: that would hand back the Node access the
// sandbox just removed (REF-Electron section 4).
const api = {
    readConfig: (): Promise<AppConfig> => ipcRenderer.invoke(CHANNELS.configRead),
    saveFile: (contents: string): Promise<string> => ipcRenderer.invoke(CHANNELS.fileSave, contents),
    onUpdateProgress: (cb: (pct: number) => void): (() => void) => {
        const handler = (_e: unknown, pct: number) => cb(pct);
        ipcRenderer.on(CHANNELS.updateProgress, handler);
        return () => ipcRenderer.removeListener(CHANNELS.updateProgress, handler);
    },
};

contextBridge.exposeInMainWorld('desktop', api);

// The renderer imports this type to wire `window.desktop` into its MVVM layer as
// a typed outbound port, with a web fallback when it is absent (REF-Electron section 2).
export type DesktopApi = typeof api;
"""

ELECTRON_BUILDER_YML = """# electron-builder is the single source of truth for what ships (REF-Electron section 5).
# The per-OS packaging matrix (see .github/workflows/release.yml) builds each
# target on a matching runner: a macOS .dmg needs macos-latest, a clean Windows
# installer needs windows-latest.
appId: com.example.__APP_NAME__
productName: __APP_NAME__
directories:
    output: release
files:
    - dist-electron/**/*
    - __RENDERER__/dist/**/*
win:
    target: nsis
mac:
    target: dmg
linux:
    target:
        - AppImage
        - deb
"""

PLAYWRIGHT_CONFIG = """import { defineConfig } from '@playwright/test';

// The smoke spec launches the built Electron shell directly; no web server.
export default defineConfig({
    testDir: './e2e',
    timeout: 60_000,
    expect: { timeout: 30_000 },
    workers: 1,
    reporter: 'line',
});
"""

SMOKE_SPEC = """import { _electron as electron, expect, test } from '@playwright/test';
import type { ElectronApplication, Page } from '@playwright/test';

// Launches the packaged shell headlessly and proves the boundary is wired:
// the window opens, the renderer reaches main, and nothing errored
// (REF-Electron section 8).
test('the shell opens a window, an IPC round-trip returns, and nothing errors', async () => {
    const errors: string[] = [];
    const app: ElectronApplication = await electron.launch({ args: ['.'] });

    const page: Page = await app.firstWindow();
    page.on('pageerror', (err) => errors.push(String(err)));
    page.on('console', (msg) => {
        if (msg.type() === 'error') errors.push(msg.text());
    });

    // One representative IPC round-trip through the preload surface.
    const config = await page.evaluate(() => (window as unknown as {
        desktop: { readConfig: () => Promise<{ version: string }> };
    }).desktop.readConfig());
    expect(config.version).toBeTruthy();

    expect(errors).toEqual([]);
    await app.close();
});
"""

RENDERER_PLACEHOLDER = """<!doctype html>
<html lang="en">
    <head>
        <meta charset="UTF-8" />
        <title>__APP_NAME__</title>
    </head>
    <body>
        <main id="app">Replace this with the bootstrap-react-mvvm renderer (REF-Electron section 2).</main>
        <script type="module">
            // The renderer talks to the shell only through the typed bridge, and
            // degrades to a web fallback when it is absent (REF-Electron section 4).
            const desktop = window.desktop;
            if (desktop) {
                const config = await desktop.readConfig();
                document.getElementById('app').textContent = `__APP_NAME__ v${config.version}`;
            }
        </script>
    </body>
</html>
"""

RELEASE_WORKFLOW = """name: Release

# Packaging is wired INTO the release run, never keyed on `on: release: published`:
# a Release created by a GITHUB_TOKEN workflow triggers no new workflow runs, so a
# job on that event silently never fires and the release ships with no installers
# (REF-Electron section 6). Adjust the release job to your own release tool; the
# package job below only needs it to have pushed the tag it reads.
on:
    push:
        branches: [main]

permissions:
    contents: write

jobs:
    release:
        runs-on: ubuntu-latest
        steps:
            - uses: actions/checkout@v4
              with:
                  fetch-depth: 0
            # ... your release step: cut the version and push its tag on HEAD ...

    package:
        needs: release
        permissions:
            contents: write
        strategy:
            matrix:
                # Each installer builds on a matching runner; pin per OS, never
                # inherit a Linux-only org default (REF-Electron section 5). On a
                # private repo the macOS runner bills at 10x: a cost decision.
                os: [windows-latest, macos-latest, ubuntu-latest]
        runs-on: ${{ matrix.os }}
        steps:
            - uses: actions/checkout@v4
              with:
                  fetch-depth: 0
            - id: tag
              shell: bash
              run: echo "tag=$(git tag --points-at HEAD)" >> "$GITHUB_OUTPUT"
            - if: steps.tag.outputs.tag == ''
              shell: bash
              run: echo "No tag on HEAD; not a release commit. Nothing to package."
            - if: steps.tag.outputs.tag != ''
              uses: actions/setup-node@v4
              with:
                  node-version: "20"
            - if: steps.tag.outputs.tag != ''
              run: npm ci
            - if: steps.tag.outputs.tag != ''
              run: npm run build
            - if: steps.tag.outputs.tag != ''
              # electron-builder builds the installer; do not let it publish, the
              # upload step below attaches assets to the release the tag points at.
              run: npx electron-builder --publish never
            - if: steps.tag.outputs.tag != ''
              shell: bash
              run: gh release upload "${{ steps.tag.outputs.tag }}" release/*.* --clobber
              env:
                  GH_TOKEN: ${{ github.token }}
"""

GITIGNORE = """node_modules/
dist-electron/
release/
test-results/
playwright-report/
"""

README_MD = """# __APP_NAME__

An Electron desktop shell scaffolded per the team playbook's `REF-Electron.md`;
read that REF before extending the shell. The shell hosts a Vite/React MVVM
renderer (bootstrap-react-mvvm output) in `__RENDERER__/`; this project owns the
process code, packaging, and release wiring, not the UI.

## Layout

| Path | What it is |
|---|---|
| `electron/main.ts` | Main process: window lifecycle, OS access, IPC handlers |
| `electron/preload.ts` | The typed `contextBridge` surface (the whole renderer contract) |
| `electron/ipc.ts` | Channel names and shared IPC types |
| `__RENDERER__/` | The renderer (replace the placeholder with bootstrap-react-mvvm output) |
| `electron-builder.yml` | What ships, per OS |
| `.github/workflows/release.yml` | Release + per-OS packaging (wired into the release run) |

## Commands

| Command | What it does |
|---|---|
| `npm run dev` | Build the shell and launch Electron (set `ELECTRON_RENDERER_URL` for the renderer dev server) |
| `npm run build` | Compile main + preload to `dist-electron/` |
| `npm run e2e` | Build, then run the Playwright-drives-Electron smoke test |

## Conventions baked in

- `contextIsolation` on, `nodeIntegration` off, `sandbox` on: the security floor,
  not per-feature knobs.
- Every renderer <-> main path crosses the one typed `contextBridge` surface in
  `preload.ts`; the renderer never sees a channel string.
- Installers are release artifacts, built by the per-OS matrix job and attached
  to the release the tag points at (never on `on: release: published`).
- v1 floor: artifacts are unsigned (expect SmartScreen/Gatekeeper warnings) and
  there is no auto-updater; record either upgrade in `docs/` ADRs.
"""


def _write(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8", newline="\n")
    print(f"  {path}")


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--name", required=True, help="app name, kebab-case")
    ap.add_argument("--dir", type=Path, default=Path.cwd(), help="parent directory (default: cwd)")
    ap.add_argument(
        "--renderer",
        default="renderer",
        help="renderer directory, relative to the app root (default: renderer)",
    )
    args = ap.parse_args()

    if not NAME_RE.match(args.name):
        print(f"error: name must be kebab-case: {args.name!r}", file=sys.stderr)
        return 2
    renderer = args.renderer.strip("/")
    if not renderer or renderer.startswith(".."):
        print(f"error: --renderer must be a path inside the app: {args.renderer!r}", file=sys.stderr)
        return 2
    root = args.dir / args.name
    if root.exists():
        print(f"error: {root} already exists", file=sys.stderr)
        return 2

    def fill(text: str) -> str:
        return text.replace("__APP_NAME__", args.name).replace("__RENDERER__", renderer)

    print(f"Creating {root}")
    _write(root / "package.json", fill(PACKAGE_JSON))
    _write(root / "electron" / "tsconfig.json", ELECTRON_TSCONFIG)
    _write(root / "electron" / "ipc.ts", IPC_TS)
    _write(root / "electron" / "main.ts", fill(MAIN_TS))
    _write(root / "electron" / "preload.ts", PRELOAD_TS)
    _write(root / "electron-builder.yml", fill(ELECTRON_BUILDER_YML))
    _write(root / "playwright.config.ts", PLAYWRIGHT_CONFIG)
    _write(root / "e2e" / "smoke.spec.ts", SMOKE_SPEC)
    _write(root / ".github" / "workflows" / "release.yml", RELEASE_WORKFLOW)
    _write(root / ".gitignore", GITIGNORE)
    _write(root / "README.md", fill(README_MD))

    # Only seed a placeholder renderer when none is there yet; the shell composes
    # around an existing bootstrap-react-mvvm renderer and must not clobber it.
    renderer_index = root / renderer / "dist" / "index.html"
    if not (root / renderer).exists():
        _write(renderer_index, fill(RENDERER_PLACEHOLDER))

    print("\nNext steps:")
    print(f"  cd {root}")
    print(f"  # put the bootstrap-react-mvvm renderer in {renderer}/ (or point --renderer at it)")
    print("  npm install")
    print("  npm run build          # compiles the shell")
    print("  npm run e2e            # launches the shell headlessly and proves the IPC round-trip")
    return 0


if __name__ == "__main__":
    sys.exit(main())
