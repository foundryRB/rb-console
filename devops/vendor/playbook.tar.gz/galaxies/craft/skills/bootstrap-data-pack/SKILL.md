---
name: bootstrap-data-pack
description: Scaffold a new Data Pack at a given path. Supports three modes - empty, intent-first, and excel-import. Produces folder structure with intent.yaml + intent.md + TSVs + pytest test scaffolding aligned with REF-DataPack.
galaxy: craft
refs:
  - REF-DataPack
  - REF-CSD
  - REF-Tests
  - REF-Python
---

# Bootstrap Data Pack

Invoked when the user wants to create a new Data Pack - a folder containing TSVs, CSD-aligned intent, pytest validators, and optional views. See `REF-DataPack.md` for the pattern.

## Pre-flight

1. **Read** `REF-DataPack.md`, `REF-CSD.md` (intent format), `REF-Tests.md` (pytest philosophy).
2. **Confirm target path** with the user - Data Packs live wherever they're needed in the user's PARA structure; default to current working directory if user doesn't specify.
3. **Confirm mode** - empty, from-intent, or from-excel.

## Mode 1 - Empty

User input: pack name + target path.

Generates:
- `<path>/<name>/README.md` (placeholder)
- `<path>/<name>/intent.md` (narrative placeholder)
- `<path>/<name>/intent.yaml` (one example INT-001 commented out)
- `<path>/<name>/data/.gitkeep`
- `<path>/<name>/tests/conftest.py` (project_root, data_dir fixtures)
- `<path>/<name>/tests/helpers.py` (TSV loader, common assertions)
- `<path>/<name>/tests/test_smoke.py` (placeholder)
- `<path>/<name>/views/.gitkeep`

User then writes intent claims, populates TSVs, and runs `pytest <path>/<name>/tests/`.

## Mode 2 - From intent

User input: pack name + target path + multi-line intent text.

Process:
1. Parse the intent text into candidate claims (each line/paragraph that asserts something testable).
2. **Ratification gate (REF-DataPack §6):** propose the parsed claims to the user as an intent.yaml draft. User approves or corrects each `INT-NNN` before commit.
3. Generate intent.yaml with ratified claims.
4. Scaffold one test stub per claim, named after the `INT-NNN`.
5. Generate empty TSVs implied by the claims (e.g., if a claim references "Resources.RecurringMonthlyCost", create a `data/resources.tsv` with header).
6. Run pytest - tests should fail (no data yet); confirms the harness is wired.

## Mode 3 - From Excel

User input: pack name + target path + Excel file path.

Process:
1. Read the Excel file via `openpyxl`. Enumerate sheets.
2. Convert each sheet to TSV in `data/<sheet-name-slug>.tsv`. Skip pivot tables and computed views (they're outputs, not source data).
3. **Infer intent claims** from detected schema (no synchronous ratification - see REF-DataPack §6):
   - Unique-ID columns → uniqueness claims (scope: unit)
   - Foreign-key-shaped columns → referential integrity claims (scope: integration)
   - Numeric columns → non-negative / range claims (scope: unit)
   - Status/enum columns → valid-values claims (scope: unit)
   - Non-null required columns → not-empty claims (scope: unit)
4. Generate intent.yaml directly from inferred claims (with `scope:` field per CSD).
5. Scaffold test stubs per claim.
6. Run pytest. Failures surface as either real data issues OR wrong inferences - user reviews intent.yaml post-hoc and edits/removes wrong claims (e.g., Family Resources INT-041 was removed after first run revealed ComponentID was a separate namespace).
7. Surface to user: "Imported N tables, M claims inferred (X passing, Y failing). Review intent.yaml when convenient."

## Steps

Python helper at `<this-skill>/bootstrap_data_pack.py` does the mechanical scaffolding. AI orchestrates ratification gates, surfaces proposed intent for human approval, then invokes the helper with confirmed inputs.

```bash
python bootstrap_data_pack.py --target <path> --name <name> --mode {empty,from-intent,from-excel} [--source <input>]
```

## Post-bootstrap

1. Run `pytest <path>/<name>/tests/`. Expect:
   - Empty mode: smoke test passes; no real validation yet
   - From-intent: validation tests fail (no data yet); confirms harness
   - From-excel: real failures may surface (data issues the auditor caught)
2. Surface result + next steps to user.
3. **Offer an interactive dashboard** if the pack has populated TSVs and the user might want sortable tables / KPIs / charts beyond `views/generate.py`'s static Markdown output. Suggest: "Want me to scaffold an Observable Framework dashboard alongside this? It reads the TSVs read-only and gives you live filters, charts, and polished cards." If yes, invoke `bootstrap-observable-dashboard` (separate skill); see `REF-ObservableFramework.md` for the pattern. Don't auto-invoke - the dashboard is a *tooling* layer with its own dependencies; making it opt-in keeps `bootstrap-data-pack` focused and the data pack itself dependency-light.

## Failure modes

- **Excel has no exportable data** (only pivots / dashboards) → tell user, suggest providing source data sheets.
- **Intent text too vague to parse** → ask user to refine specific claims, OR fall back to empty mode.
- **Path conflict** (target exists) → confirm overwrite vs cancel.
- **openpyxl missing** → install via pip; surface to user if not available.

## Anti-patterns

- Generating tests without a ratified intent claim - never. (REF-DataPack §10 #1)
- Auto-applying inferred intent without ratification - never. (REF-DataPack §10 #2)
- Inventing pytest fixture patterns instead of reusing the conventional layout this skill scaffolds - never. (REF-DataPack §10 #4)

## See also

- `REF-DataPack.md` - the pattern this Skill instantiates
- `REF-CSD.md` - methodology, especially Intent Specification format
- `REF-Tests.md` - general test philosophy
- `bootstrap-observable-dashboard` - sister skill that scaffolds an Observable Framework dashboard against the Data Pack this skill produces (see post-bootstrap step 3 and `REF-ObservableFramework.md`)
