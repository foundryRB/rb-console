#!/usr/bin/env python3
"""Bootstrap a new Data Pack.

See SKILL.md for invocation patterns. This script handles the mechanical
scaffolding; the orchestrating AI handles ratification gates with the user.

Modes:
  --mode empty           Just folder structure with placeholders.
  --mode from-intent     Build around a multi-line intent text (--source <text-or-file>).
  --mode from-excel      Import sheets as TSVs from an .xlsx file (--source <path>).

Usage:
  python bootstrap_data_pack.py --target <dir> --name <pack-name> --mode <mode> [--source <input>]
"""

from __future__ import annotations

import argparse
import csv
import re
import sys
from dataclasses import dataclass
from pathlib import Path

__all__ = ["main"]


# ----- templates -----

README_TMPL = """\
# {name}

Data Pack - see `REF-DataPack.md` in the playbook for the pattern.

## Files
- `intent.md` - narrative: what this data is for, who reads it
- `intent.yaml` - machine-checkable claims (CSD format)
- `data/*.tsv` - the data tables
- `tests/` - pytest validators (one test per intent claim)
- `views/` - derived projections (Dataview md, React, etc.)

## Run tests
```bash
pytest tests/
```
"""

INTENT_MD_TMPL = """\
# Intent - {name}

## What this data represents

<one-paragraph description: domain, entities, relationships>

## Who reads it

<who consumes this; what queries they run>

## Source of truth

<where canonical edits happen; this folder, or another system>

## Review cadence

<monthly / quarterly / event-driven>

## See also

- `intent.yaml` - machine-checkable claims
- `tests/` - test files map 1:1 to claims by `INT-NNN`
"""

INTENT_YAML_EMPTY_TMPL = """\
# Intent claims for {name}.
# Format: each top-level key is `INT-NNN`. Required fields:
#   statement, test, rationale, criticality
# Optional: owner, revisit_when

# Example (uncomment + adapt):
# INT-001:
#   statement: "Every Resources.id is unique"
#   test: tests/test_referential_integrity.py::test_resource_ids_unique
#   rationale: "Duplicate IDs break joins downstream"
#   criticality: critical
"""

CONFTEST_TMPL = '''\
"""Pytest fixtures for the {name} Data Pack.

Conventional Data Pack layout. See REF-DataPack §5.
"""

from __future__ import annotations

from pathlib import Path

import pytest


@pytest.fixture(scope="session")
def pack_root() -> Path:
    """Absolute path to the Data Pack root (where this conftest lives, parent)."""
    return Path(__file__).resolve().parent.parent


@pytest.fixture(scope="session")
def data_dir(pack_root: Path) -> Path:
    return pack_root / "data"
'''

HELPERS_TMPL = '''\
"""Shared helpers for {name} tests."""

from __future__ import annotations

import csv
from pathlib import Path
from typing import Iterator

__all__ = ["load_tsv", "tsv_columns"]


def load_tsv(path: Path) -> list[dict[str, str]]:
    """Load a TSV file into a list of dicts (header-keyed)."""
    if not path.exists():
        raise FileNotFoundError(f"TSV not found: {{path}}")
    with path.open(encoding="utf-8", newline="") as f:
        reader = csv.DictReader(f, delimiter="\\t")
        return list(reader)


def tsv_columns(rows: list[dict[str, str]], col: str) -> Iterator[str]:
    """Yield values from a single column."""
    for row in rows:
        yield row.get(col, "")
'''

SMOKE_TEST_TMPL = '''\
"""Smoke test - confirms the test harness runs."""

from __future__ import annotations


def test_smoke() -> None:
    """Trivial test to confirm pytest is wired up."""
    assert True
'''

INTENT_COVERAGE_TMPL = '''\
"""Meta-test: every intent claim has a test, every test traces to a claim.

Implements CSD's invariant that intent and tests are 1:1.
"""

from __future__ import annotations

import ast
import re
from pathlib import Path


TEST_REF_RE = re.compile(r"^\\s*test:\\s*(\\S+)\\s*$", re.MULTILINE)


def _parse_intent_yaml(text: str) -> list[tuple[str, str]]:
    out: list[tuple[str, str]] = []
    blocks = re.split(r"^(INT-\\d+):\\s*$", text, flags=re.MULTILINE)
    for i in range(1, len(blocks), 2):
        cid = blocks[i]
        body = blocks[i + 1] if i + 1 < len(blocks) else ""
        m = TEST_REF_RE.search(body)
        if m:
            out.append((cid, m.group(1).strip()))
    return out


def _collect_test_functions(tests_dir: Path) -> set[str]:
    funcs: set[str] = set()
    for path in tests_dir.glob("test_*.py"):
        if path.name.startswith("test_intent_"):
            continue  # meta-tests are framework, not claim tests
        tree = ast.parse(path.read_text(encoding="utf-8"))
        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef) and node.name.startswith("test_"):
                funcs.add(f"tests/{path.name}::{node.name}")
    return funcs


def test_every_claim_has_a_test_function(pack_root: Path) -> None:
    intent_path = pack_root / "intent.yaml"
    claims = _parse_intent_yaml(intent_path.read_text(encoding="utf-8"))
    if not claims:
        return  # empty pack - intent not ratified yet
    funcs = _collect_test_functions(pack_root / "tests")
    missing = [(cid, ref) for cid, ref in claims if ref not in funcs]
    assert not missing, f"intent claims pointing at non-existent test functions: {missing}"


def test_every_test_function_has_a_claim(pack_root: Path) -> None:
    intent_path = pack_root / "intent.yaml"
    claims = _parse_intent_yaml(intent_path.read_text(encoding="utf-8"))
    if not claims:
        return  # empty pack - intent not ratified yet; meta-tests pass vacuously
    referenced = {ref for _cid, ref in claims}
    funcs = _collect_test_functions(pack_root / "tests")
    orphan = sorted(funcs - referenced)
    assert not orphan, f"test functions not traced to any intent claim (CSD violation): {orphan}"
'''

INTENT_SCHEMA_TMPL = '''\
"""Meta-test: every intent.yaml claim conforms to the CSD schema.

Required fields per claim:
- statement, test, rationale, criticality, scope

Allowed values:
- criticality: critical | high | medium | low
- scope: unit | integration | e2e | system
"""

from __future__ import annotations

import re
from pathlib import Path


REQUIRED = {"statement", "test", "rationale", "criticality", "scope"}
VALID_CRITICALITY = {"critical", "high", "medium", "low"}
VALID_SCOPE = {"unit", "integration", "e2e", "system"}


def _parse_intent_blocks(text: str) -> dict[str, dict[str, str]]:
    out: dict[str, dict[str, str]] = {}
    parts = re.split(r"^(INT-\\d+):\\s*$", text, flags=re.MULTILINE)
    for i in range(1, len(parts), 2):
        cid = parts[i]
        body = parts[i + 1] if i + 1 < len(parts) else ""
        fields: dict[str, str] = {}
        for line in body.splitlines():
            m = re.match(r"^\\s+(\\w+):\\s*(.+?)\\s*$", line)
            if m:
                key, val = m.group(1), m.group(2)
                val = val.strip().strip(\'"\').strip("\'")
                fields[key] = val
        out[cid] = fields
    return out


def test_intent_schema_required_fields(pack_root: Path) -> None:
    text = (pack_root / "intent.yaml").read_text(encoding="utf-8")
    claims = _parse_intent_blocks(text)
    if not claims:
        return
    violations = []
    for cid, fields in claims.items():
        missing = REQUIRED - set(fields.keys())
        if missing:
            violations.append((cid, sorted(missing)))
    assert not violations, f"intent.yaml schema violations (missing fields): {violations}"


def test_intent_schema_criticality_values(pack_root: Path) -> None:
    text = (pack_root / "intent.yaml").read_text(encoding="utf-8")
    claims = _parse_intent_blocks(text)
    if not claims:
        return
    bad = [(cid, f.get("criticality")) for cid, f in claims.items()
           if f.get("criticality") and f["criticality"] not in VALID_CRITICALITY]
    assert not bad, f"invalid criticality values (allowed {sorted(VALID_CRITICALITY)}): {bad}"


def test_intent_schema_scope_values(pack_root: Path) -> None:
    text = (pack_root / "intent.yaml").read_text(encoding="utf-8")
    claims = _parse_intent_blocks(text)
    if not claims:
        return
    bad = [(cid, f.get("scope")) for cid, f in claims.items()
           if f.get("scope") and f["scope"] not in VALID_SCOPE]
    assert not bad, f"invalid scope values (allowed {sorted(VALID_SCOPE)}): {bad}"
'''


# ----- core scaffolding -----


@dataclass
class IntentClaim:
    id: str
    statement: str
    test: str
    rationale: str
    criticality: str = "medium"

    def yaml_block(self) -> str:
        return (
            f"{self.id}:\n"
            f"  statement: \"{self.statement}\"\n"
            f"  test: {self.test}\n"
            f"  rationale: \"{self.rationale}\"\n"
            f"  criticality: {self.criticality}\n"
        )


def slugify(s: str) -> str:
    s = s.strip().lower()
    s = re.sub(r"[^\w\s-]", "", s)
    s = re.sub(r"[\s_-]+", "-", s)
    return s.strip("-")


def write_file(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")


VIEWS_GENERATE_TMPL = '''\
#!/usr/bin/env python3
"""Generate Markdown summary views from this Data Pack's TSV data.

Run from the Data Pack root:
    python views/generate.py

Re-run after TSV changes. Output is idempotent.

Stub: customize per-pack - read your tables, compute what matters, write .md files.
"""

from __future__ import annotations

import csv
from pathlib import Path

PACK_ROOT = Path(__file__).resolve().parent.parent
DATA = PACK_ROOT / "data"
VIEWS = PACK_ROOT / "views"


def load(name: str) -> list[dict[str, str]]:
    with (DATA / name).open(encoding="utf-8") as f:
        return list(csv.DictReader(f, delimiter="\\t"))


def write_view(name: str, content: str) -> None:
    (VIEWS / name).write_text(content, encoding="utf-8")
    print(f"  wrote views/" + name)


def view_summary() -> None:
    # TODO: customize. Example below counts rows per table.
    lines = ["# __PACK_NAME__ - Summary", "", "Auto-generated by `views/generate.py`.", "", "## Counts", ""]
    for tsv in sorted(DATA.glob("*.tsv")):
        rows = load(tsv.name)
        lines.append("- " + tsv.stem + ": " + str(len(rows)) + " rows")
    write_view("summary.md", "\\n".join(lines) + "\\n")


def main() -> None:
    print("Generating views...")
    view_summary()
    print("Done.")


if __name__ == "__main__":
    main()
'''


def scaffold_skeleton(target: Path, name: str) -> None:
    """Common scaffold: README, intent.md, conftest, helpers, meta-test, view stub, .gitkeep markers."""
    write_file(target / "README.md", README_TMPL.format(name=name))
    write_file(target / "intent.md", INTENT_MD_TMPL.format(name=name))
    write_file(target / "data" / ".gitkeep", "")
    write_file(target / "views" / "generate.py", VIEWS_GENERATE_TMPL.replace("__PACK_NAME__", name))
    write_file(target / "tests" / "__init__.py", "")
    write_file(target / "tests" / "conftest.py", CONFTEST_TMPL.format(name=name))
    write_file(target / "tests" / "helpers.py", HELPERS_TMPL.format(name=name))
    # Self-contained CSD meta-tests (schema + coverage). The marker packages (>=0.2)
    # ship only the @intent/intent() markers; the standalone csd-intent CLI is the
    # cross-runtime auditor, and these in-pack tests give the Data Pack local enforcement.
    write_file(target / "tests" / "test_intent_schema.py", INTENT_SCHEMA_TMPL)
    write_file(target / "tests" / "test_intent_coverage.py", INTENT_COVERAGE_TMPL)


def scaffold_empty(target: Path, name: str) -> None:
    scaffold_skeleton(target, name)
    write_file(target / "intent.yaml", INTENT_YAML_EMPTY_TMPL.format(name=name))
    write_file(target / "tests" / "test_smoke.py", SMOKE_TEST_TMPL)


def scaffold_from_intent(target: Path, name: str, claims: list[IntentClaim]) -> None:
    scaffold_skeleton(target, name)
    yaml_body = f"# Intent claims for {name}.\n\n" + "\n".join(c.yaml_block() for c in claims)
    write_file(target / "intent.yaml", yaml_body)
    # One test stub per claim
    for claim in claims:
        # claim.test format: tests/<file>.py::<func>
        test_path_str, func_name = claim.test.split("::", 1)
        test_path = target / test_path_str
        existing = test_path.read_text(encoding="utf-8") if test_path.exists() else _test_file_header(claim)
        new_func = (
            f'\n\n@intent("{claim.id}")\n'
            f"def {func_name}() -> None:\n"
            f'    """{claim.statement}\n\n'
            f'    Rationale: {claim.rationale}\n'
            f'    """\n'
            f"    pytest.skip('TODO: implement validator for {claim.id}')\n"
        )
        write_file(test_path, existing + new_func)


def _test_file_header(claim: IntentClaim) -> str:
    return (
        f'"""Tests for {claim.id} and related claims."""\n\n'
        "from __future__ import annotations\n\n"
        "import pytest\n\n"
        "from pytest_intent import intent\n\n"
        "from .helpers import load_tsv\n"
    )


def scaffold_from_excel(target: Path, name: str, excel_path: Path, claims: list[IntentClaim]) -> dict[str, list[str]]:
    """Convert excel sheets to TSV; scaffold against ratified claims.

    Returns mapping of sheet name -> column headers (for AI to use in claim refinement).
    """
    try:
        import openpyxl
    except ImportError:
        sys.exit("openpyxl not installed. pip install openpyxl")

    scaffold_skeleton(target, name)

    wb = openpyxl.load_workbook(excel_path, data_only=True, read_only=True)
    sheet_columns: dict[str, list[str]] = {}
    for sheet_name in wb.sheetnames:
        if sheet_name.startswith("PivotTable"):
            continue
        if sheet_name.lower().startswith("dashboard"):
            continue
        ws = wb[sheet_name]
        rows = list(ws.iter_rows(values_only=True))
        if not rows:
            continue
        # First row = headers
        headers = [str(c) if c is not None else "" for c in rows[0]]
        sheet_columns[sheet_name] = headers
        slug = slugify(sheet_name)
        tsv_path = target / "data" / f"{slug}.tsv"
        with tsv_path.open("w", encoding="utf-8", newline="") as f:
            writer = csv.writer(f, delimiter="\t", lineterminator="\n")
            writer.writerow(headers)
            for row in rows[1:]:
                vals = []
                for v in row:
                    if v is None:
                        vals.append("")
                    elif isinstance(v, str) and v.startswith("="):
                        # Skip formulas; user can refine downstream
                        vals.append("")
                    else:
                        vals.append(str(v))
                # Skip fully-empty rows
                if any(v.strip() for v in vals):
                    writer.writerow(vals)
        print(f"  TSV: {tsv_path.relative_to(target)} ({len(rows) - 1} data rows)")

    # Write intent.yaml from ratified claims
    if claims:
        yaml_body = f"# Intent claims for {name} (imported from {excel_path.name}).\n\n" + "\n".join(c.yaml_block() for c in claims)
        write_file(target / "intent.yaml", yaml_body)
        for claim in claims:
            test_path_str, func_name = claim.test.split("::", 1)
            test_path = target / test_path_str
            existing = test_path.read_text(encoding="utf-8") if test_path.exists() else _test_file_header(claim)
            new_func = (
                f"\n\ndef {func_name}() -> None:\n"
                f'    """{claim.id}: {claim.statement}\n\n'
                f'    Rationale: {claim.rationale}\n'
                f'    """\n'
                f"    pytest.skip('TODO: implement validator for {claim.id}')\n"
            )
            write_file(test_path, existing + new_func)
    else:
        write_file(target / "intent.yaml", INTENT_YAML_EMPTY_TMPL.format(name=name))
        write_file(target / "tests" / "test_smoke.py", SMOKE_TEST_TMPL)

    return sheet_columns


# ----- CLI -----


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--target", type=Path, required=True, help="parent directory under which the pack folder is created")
    ap.add_argument("--name", required=True, help="pack name (folder will be created with this name)")
    ap.add_argument("--mode", choices=["empty", "from-intent", "from-excel", "inspect-excel"], required=True)
    ap.add_argument("--source", type=str, default=None, help="path to source (xlsx for excel mode); not used for empty/intent")
    ap.add_argument("--claims-yaml", type=Path, default=None, help="path to ratified claims yaml (for from-intent / from-excel)")
    args = ap.parse_args()

    target = args.target / args.name
    if target.exists() and any(target.iterdir()):
        print(f"target exists and is non-empty: {target}", file=sys.stderr)
        return 2

    # Inspect-only mode: read excel, dump sheet structure for AI to use in proposing claims
    if args.mode == "inspect-excel":
        if not args.source:
            sys.exit("--source <path-to-xlsx> required for inspect-excel")
        try:
            import openpyxl
        except ImportError:
            sys.exit("openpyxl not installed. pip install openpyxl")
        wb = openpyxl.load_workbook(args.source, data_only=True, read_only=True)
        print(f"Excel: {args.source}")
        print(f"Sheets: {wb.sheetnames}")
        for sheet_name in wb.sheetnames:
            ws = wb[sheet_name]
            rows = list(ws.iter_rows(values_only=True))
            if not rows:
                print(f"\n{sheet_name}: (empty)")
                continue
            headers = [str(c) if c is not None else "" for c in rows[0]]
            data_rows = sum(1 for r in rows[1:] if any(c is not None for c in r))
            print(f"\n{sheet_name}: {data_rows} rows, columns: {headers}")
        return 0

    # Load claims if provided
    claims: list[IntentClaim] = []
    if args.claims_yaml:
        try:
            import yaml
        except ImportError:
            sys.exit("PyYAML not installed. pip install pyyaml")
        with args.claims_yaml.open(encoding="utf-8") as f:
            data = yaml.safe_load(f) or {}
        for cid, fields_dict in data.items():
            if not cid.startswith("INT-"):
                continue
            claims.append(IntentClaim(
                id=cid,
                statement=fields_dict.get("statement", ""),
                test=fields_dict.get("test", f"tests/test_{slugify(cid)}.py::test_{slugify(cid).replace('-', '_')}"),
                rationale=fields_dict.get("rationale", ""),
                criticality=fields_dict.get("criticality", "medium"),
            ))

    if args.mode == "empty":
        scaffold_empty(target, args.name)
        print(f"Empty Data Pack scaffolded at {target}")
    elif args.mode == "from-intent":
        if not claims:
            sys.exit("--claims-yaml <path> required for from-intent mode")
        scaffold_from_intent(target, args.name, claims)
        print(f"Data Pack scaffolded at {target} with {len(claims)} intent claims")
    elif args.mode == "from-excel":
        if not args.source:
            sys.exit("--source <path-to-xlsx> required for from-excel mode")
        sheet_columns = scaffold_from_excel(target, args.name, Path(args.source), claims)
        print(f"\nData Pack scaffolded at {target}")
        print(f"  Sheets imported: {len(sheet_columns)}")
        if not claims:
            print("  No intent claims provided. Run again with --claims-yaml after ratification.")

    return 0


if __name__ == "__main__":
    sys.exit(main())
