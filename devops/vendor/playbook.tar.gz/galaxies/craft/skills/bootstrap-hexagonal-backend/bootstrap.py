"""Scaffolder for the bootstrap-hexagonal-backend skill.

Writes a REF-conformant hexagonal FastAPI skeleton (domain / application / adapters,
Container, logging WIRED, app factory, exception handler, OpenAPI export, tests).
Idempotent: existing files are skipped. Templates use sentinels replaced at write
time; no .format is used, so braces in the templates are preserved verbatim.
"""

from __future__ import annotations

import argparse
from pathlib import Path

# Package directories that need an __init__.py. Barrels (model, exceptions) and the
# root __init__ are written from FILES below; the rest get a generated stub.
PKG_DIRS = [
    "",
    "domain",
    "domain/model",
    "domain/exceptions",
    "application",
    "application/ports",
    "application/ports/inbound",
    "application/ports/outbound",
    "application/use_cases",
    "adapters",
    "adapters/inbound",
    "adapters/inbound/http",
    "adapters/inbound/http/dtos",
    "adapters/inbound/http/mappers",
    "adapters/inbound/http/routers",
    "adapters/outbound",
    "adapters/outbound/memory",
]

FILES: dict[str, str] = {
    "pyproject.toml": r'''[build-system]
requires = ["setuptools>=68"]
build-backend = "setuptools.build_meta"

[project]
name = "__PROJECT__"
version = "0.1.0"
description = "__DESC__"
requires-python = ">=__PYFLOOR__"
dependencies = [
    "fastapi>=0.110",
    "uvicorn[standard]>=0.29",
    "pydantic>=2.6",
]

[project.optional-dependencies]
dev = [
    "pytest>=7.0",
    "ruff>=0.4",
    "httpx2>=2.13",
    "starlette>=1.2",
]

[project.scripts]
__PROJECT__-api = "__MODULE__.adapters.inbound.http.run:main"

[tool.setuptools.packages.find]
include = ["__MODULE__*"]

[tool.ruff]
target-version = "py310"
line-length = 120

[tool.ruff.lint]
select = ["E", "F", "I", "UP", "B", "SIM"]

[tool.pytest.ini_options]
testpaths = ["tests"]
pythonpath = ["."]
''',
    ".gitignore": r'''__pycache__/
*.py[cod]
*.egg-info/
.venv/
.pytest_cache/
.ruff_cache/
''',
    "README.md": r'''# __PROJECT__

__DESC__

A Python FastAPI service in hexagonal (ports and adapters) architecture, scaffolded
by the bootstrap-hexagonal-backend skill.

## Develop

Create a venv, install, lint, test (POSIX paths shown; on Windows use
`.venv\Scripts\python.exe`):

```bash
python -m venv .venv
.venv/bin/python -m pip install -e ".[dev]"
.venv/bin/python -m ruff check .
.venv/bin/python scripts/export_openapi.py
.venv/bin/python -m pytest -q
.venv/bin/python -m __MODULE__.adapters.inbound.http.run
```

## The OpenAPI contract

`openapi.json` is committed and gated: `scripts/export_openapi.py` writes it from
the app factory (no running server), the test suite fails while it is stale, and
`--check` gives CI the same gate without writing. Re-export and commit the diff
on every route or DTO change.

## Layout

- `__MODULE__/domain` - entities, value objects, exceptions (no outward imports)
- `__MODULE__/application` - inbound/outbound ports and use cases
- `__MODULE__/adapters` - HTTP inbound adapter and outbound adapters
- `__MODULE__/container.py` - composition root
''',
    "scripts/export_openapi.py": r'''"""Export the OpenAPI spec to openapi.json at the project root."""

from __future__ import annotations

import json
import sys
from pathlib import Path

__all__ = ["main"]


def main() -> None:
    """Write the OpenAPI spec to openapi.json; `--check` verifies it instead.

    Adds the project root to sys.path so this runs whether or not the package is
    installed (for example, straight after scaffolding, before `pip install -e .`).
    With `--check`, exits 1 when the committed spec disagrees with the app - wire
    that into CI so a stale spec is a red build.
    """
    root = Path(__file__).resolve().parents[1]
    sys.path.insert(0, str(root))

    from __MODULE__.adapters.inbound.http.app import create_app

    spec = json.dumps(create_app().openapi(), indent=2) + "\n"
    out = root / "openapi.json"
    if "--check" in sys.argv[1:]:
        if not out.exists() or out.read_text(encoding="utf-8") != spec:
            print(f"{out} is stale - run scripts/export_openapi.py and commit the diff")
            raise SystemExit(1)
        print(f"{out} is current")
        return
    out.write_text(spec, encoding="utf-8")
    print(f"Wrote {out}")


if __name__ == "__main__":
    main()
''',
    "__MODULE__/__init__.py": r'''"""__DESC__"""

from __future__ import annotations

__all__ = ["__version__"]

__version__ = "0.1.0"
''',
    "__MODULE__/logging.py": r'''"""Centralized logging configuration and logger factory."""

from __future__ import annotations

import logging
import sys

__all__ = ["configure_logging", "get_logger"]

_ROOT = "__MODULE__"
_FORMAT = "%(asctime)s  %(levelname)-5s  %(name)s  %(message)s"
_configured = False


def configure_logging(level: int = logging.INFO) -> None:
    """Configure the root logger once. Idempotent."""
    global _configured
    if _configured:
        return
    handler = logging.StreamHandler(sys.stderr)
    handler.setFormatter(logging.Formatter(_FORMAT))
    root = logging.getLogger(_ROOT)
    root.setLevel(level)
    root.addHandler(handler)
    root.propagate = False
    _configured = True


def get_logger(name: str) -> logging.Logger:
    """Return a logger under the project root namespace.

    A name already inside the namespace (a module's `__name__`) is used as is; any other name is prefixed.
    """
    inside = name == _ROOT or name.startswith(f"{_ROOT}.")
    return logging.getLogger(name if inside else f"{_ROOT}.{name}")
''',
    "__MODULE__/container.py": r'''"""Composition root: wires adapters and use cases."""

from __future__ import annotations

from typing import TypeVar

from __MODULE__.adapters.outbound.memory.in_memory_item_repository import InMemoryItemRepository
from __MODULE__.application.ports.inbound.get_item_port import GetItemPort
from __MODULE__.application.ports.inbound.list_items_port import ListItemsPort
from __MODULE__.application.use_cases.get_item import GetItem
from __MODULE__.application.use_cases.list_items import ListItems

__all__ = ["Container"]

_T = TypeVar("_T")


def _check(instance: object, port: type[_T]) -> _T:
    if not isinstance(instance, port):
        raise TypeError(f"{type(instance).__name__} does not satisfy {port.__name__}")
    return instance


class Container:
    """Instantiates outbound adapters once and builds use cases on demand."""

    def __init__(self) -> None:
        self._item_repository = InMemoryItemRepository()

    def list_items(self) -> ListItemsPort:
        return _check(ListItems(self._item_repository), ListItemsPort)

    def get_item(self) -> GetItemPort:
        return _check(GetItem(self._item_repository), GetItemPort)
''',
    "__MODULE__/domain/model/item.py": r'''"""An item in the catalogue."""

from __future__ import annotations

from dataclasses import dataclass

__all__ = ["Item"]


@dataclass(frozen=True)
class Item:
    """A catalogue item identified by id."""

    id: str
    name: str
''',
    "__MODULE__/domain/model/__init__.py": r'''"""Domain model barrel: re-exports all entities and value objects."""

from __future__ import annotations

from __MODULE__.domain.model.item import Item

__all__ = ["Item"]
''',
    "__MODULE__/domain/exceptions/app_error.py": r'''"""Root application error type."""

from __future__ import annotations

__all__ = ["AppError"]


class AppError(Exception):
    """Base class for all application errors."""
''',
    "__MODULE__/domain/exceptions/entity_not_found_error.py": r'''"""A required entity or record could not be found."""

from __future__ import annotations

from __MODULE__.domain.exceptions.app_error import AppError

__all__ = ["EntityNotFoundError"]


class EntityNotFoundError(AppError):
    """A required entity or record could not be found."""

    def __init__(self, entity_type: str, identifier: str) -> None:
        self.entity_type = entity_type
        self.identifier = identifier
        super().__init__(f"{entity_type} not found: {identifier}")
''',
    "__MODULE__/domain/exceptions/__init__.py": r'''"""Exception hierarchy barrel."""

from __future__ import annotations

from __MODULE__.domain.exceptions.app_error import AppError
from __MODULE__.domain.exceptions.entity_not_found_error import EntityNotFoundError

__all__ = ["AppError", "EntityNotFoundError"]
''',
    "__MODULE__/application/ports/inbound/list_items_port.py": r'''"""Inbound port: list all items."""

from __future__ import annotations

from typing import Protocol, runtime_checkable

from __MODULE__.domain.model.item import Item

__all__ = ["ListItemsPort"]


@runtime_checkable
class ListItemsPort(Protocol):
    """Returns all items."""

    def execute(self) -> list[Item]: ...
''',
    "__MODULE__/application/ports/inbound/get_item_port.py": r'''"""Inbound port: get one item by id."""

from __future__ import annotations

from typing import Protocol, runtime_checkable

from __MODULE__.domain.model.item import Item

__all__ = ["GetItemPort"]


@runtime_checkable
class GetItemPort(Protocol):
    """Returns one item by id."""

    def execute(self, item_id: str) -> Item: ...
''',
    "__MODULE__/application/ports/outbound/item_repository.py": r'''"""Outbound port: item storage."""

from __future__ import annotations

from typing import Protocol, runtime_checkable

from __MODULE__.domain.model.item import Item

__all__ = ["ItemRepository"]


@runtime_checkable
class ItemRepository(Protocol):
    """Stores and retrieves items."""

    def list_all(self) -> list[Item]: ...

    def get(self, item_id: str) -> Item: ...
''',
    "__MODULE__/application/use_cases/list_items.py": r'''"""Use case: list all items."""

from __future__ import annotations

from __MODULE__.application.ports.outbound.item_repository import ItemRepository
from __MODULE__.domain.model.item import Item
from __MODULE__.logging import get_logger

__all__ = ["ListItems"]

logger = get_logger(__name__)


class ListItems:
    """Lists all items. Implements ListItemsPort."""

    def __init__(self, repository: ItemRepository) -> None:
        self._repository = repository

    def execute(self) -> list[Item]:
        """Return all items."""
        items = self._repository.list_all()
        logger.info("Listed %d items", len(items))
        return items
''',
    "__MODULE__/application/use_cases/get_item.py": r'''"""Use case: get one item by id."""

from __future__ import annotations

from __MODULE__.application.ports.outbound.item_repository import ItemRepository
from __MODULE__.domain.model.item import Item
from __MODULE__.logging import get_logger

__all__ = ["GetItem"]

logger = get_logger(__name__)


class GetItem:
    """Gets one item by id. Implements GetItemPort."""

    def __init__(self, repository: ItemRepository) -> None:
        self._repository = repository

    def execute(self, item_id: str) -> Item:
        """Return the item with the given id, or raise EntityNotFoundError."""
        logger.info("Fetching item %s", item_id)
        return self._repository.get(item_id)
''',
    "__MODULE__/adapters/outbound/memory/in_memory_item_repository.py": r'''"""Outbound adapter: in-memory item storage. Implements ItemRepository."""

from __future__ import annotations

from __MODULE__.domain.exceptions.entity_not_found_error import EntityNotFoundError
from __MODULE__.domain.model.item import Item
from __MODULE__.logging import get_logger

__all__ = ["InMemoryItemRepository"]

logger = get_logger(__name__)

_SEED = (
    Item(id="1", name="First item"),
    Item(id="2", name="Second item"),
)


class InMemoryItemRepository:
    """Holds items in memory. Implements the ItemRepository port."""

    def __init__(self) -> None:
        self._items: dict[str, Item] = {item.id: item for item in _SEED}
        logger.info("Loaded %d seed items", len(self._items))

    def list_all(self) -> list[Item]:
        return list(self._items.values())

    def get(self, item_id: str) -> Item:
        item = self._items.get(item_id)
        if item is None:
            raise EntityNotFoundError("Item", item_id)
        return item
''',
    "__MODULE__/adapters/inbound/http/app.py": r'''"""FastAPI application factory."""

from __future__ import annotations

from fastapi import FastAPI

from __MODULE__ import __version__
from __MODULE__.adapters.inbound.http.exception_handlers import register_exception_handler
from __MODULE__.adapters.inbound.http.routers import items, system
from __MODULE__.logging import configure_logging

__all__ = ["create_app"]


def create_app() -> FastAPI:
    """Create and configure the FastAPI application."""
    configure_logging()
    app = FastAPI(title="__PROJECT__ API", version=__version__)
    register_exception_handler(app)
    app.include_router(system.router, prefix="/api", tags=["system"])
    app.include_router(items.router, prefix="/api", tags=["items"])
    return app
''',
    "__MODULE__/adapters/inbound/http/run.py": r'''"""Console entry point: run the API with uvicorn."""

from __future__ import annotations

import os

import uvicorn

__all__ = ["main"]


def main() -> None:
    """Start the uvicorn server using the app factory."""
    host = os.environ.get("HOST", "127.0.0.1")
    port = int(os.environ.get("PORT", "8000"))
    uvicorn.run(
        "__MODULE__.adapters.inbound.http.app:create_app",
        factory=True,
        host=host,
        port=port,
    )


if __name__ == "__main__":
    main()
''',
    "__MODULE__/adapters/inbound/http/dependencies.py": r'''"""Container dependency for FastAPI routes."""

from __future__ import annotations

from typing import Annotated

from fastapi import Depends

from __MODULE__.container import Container

__all__ = ["get_container", "ContainerDep"]

_container: Container | None = None


def get_container() -> Container:
    """Return the shared Container singleton, creating it on first use."""
    global _container
    if _container is None:
        _container = Container()
    return _container


ContainerDep = Annotated[Container, Depends(get_container)]
''',
    "__MODULE__/adapters/inbound/http/exception_handlers.py": r'''"""Register global exception handlers on the FastAPI app."""

from __future__ import annotations

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse

from __MODULE__.adapters.inbound.http.mappers.exception_mapper import DEFAULT_STATUS, STATUS_MAP
from __MODULE__.domain.exceptions.app_error import AppError

__all__ = ["register_exception_handler"]


def register_exception_handler(app: FastAPI) -> None:
    """Install a single handler mapping domain errors to HTTP responses."""

    @app.exception_handler(AppError)
    async def _handle_app_error(request: Request, exc: AppError) -> JSONResponse:
        status = STATUS_MAP.get(type(exc), DEFAULT_STATUS)
        return JSONResponse(
            status_code=status,
            content={"error": type(exc).__name__, "detail": str(exc)},
        )
''',
    "__MODULE__/adapters/inbound/http/dtos/health_response.py": r'''"""Response DTO for the health check."""

from __future__ import annotations

from pydantic import BaseModel

__all__ = ["HealthResponse"]


class HealthResponse(BaseModel):
    """Service liveness and version."""

    status: str
    version: str
''',
    "__MODULE__/adapters/inbound/http/dtos/item_response.py": r'''"""Response DTO for an item."""

from __future__ import annotations

from pydantic import BaseModel

__all__ = ["ItemResponse"]


class ItemResponse(BaseModel):
    """An item returned over HTTP."""

    id: str
    name: str
''',
    "__MODULE__/adapters/inbound/http/mappers/exception_mapper.py": r'''"""Mapping from domain exceptions to HTTP status codes."""

from __future__ import annotations

from __MODULE__.domain.exceptions.entity_not_found_error import EntityNotFoundError

__all__ = ["STATUS_MAP", "DEFAULT_STATUS"]

STATUS_MAP: dict[type[Exception], int] = {
    EntityNotFoundError: 404,
}
DEFAULT_STATUS = 500
''',
    "__MODULE__/adapters/inbound/http/mappers/item_mapper.py": r'''"""Mapper: domain Item to ItemResponse DTO."""

from __future__ import annotations

from typing import TYPE_CHECKING

from __MODULE__.adapters.inbound.http.dtos.item_response import ItemResponse

if TYPE_CHECKING:
    from __MODULE__.domain.model.item import Item

__all__ = ["map_item"]


def map_item(item: Item) -> ItemResponse:
    """Convert a domain item to its response DTO."""
    return ItemResponse(id=item.id, name=item.name)
''',
    "__MODULE__/adapters/inbound/http/routers/system.py": r'''"""System routes: health and version."""

from __future__ import annotations

from fastapi import APIRouter

from __MODULE__ import __version__
from __MODULE__.adapters.inbound.http.dtos.health_response import HealthResponse

__all__ = ["router"]

router = APIRouter()


@router.get("/health")
async def health() -> HealthResponse:
    """Report service liveness and version."""
    return HealthResponse(status="ok", version=__version__)
''',
    "__MODULE__/adapters/inbound/http/routers/items.py": r'''"""Item routes: list and detail."""

from __future__ import annotations

from fastapi import APIRouter

from __MODULE__.adapters.inbound.http.dependencies import ContainerDep
from __MODULE__.adapters.inbound.http.dtos.item_response import ItemResponse
from __MODULE__.adapters.inbound.http.mappers.item_mapper import map_item

__all__ = ["router"]

router = APIRouter()


@router.get("/items")
async def list_items(container: ContainerDep) -> list[ItemResponse]:
    """Return all items."""
    items = container.list_items().execute()
    return [map_item(item) for item in items]


@router.get("/items/{item_id}")
async def get_item(item_id: str, container: ContainerDep) -> ItemResponse:
    """Return one item by id."""
    return map_item(container.get_item().execute(item_id))
''',
    "tests/conftest.py": r'''"""Shared test fixtures."""

from __future__ import annotations

import pytest
from fastapi.testclient import TestClient

from __MODULE__.adapters.inbound.http.app import create_app


@pytest.fixture
def client() -> TestClient:
    return TestClient(create_app())
''',
    "tests/integration/test_http_api.py": r'''"""Integration tests for the HTTP API via FastAPI TestClient."""

from __future__ import annotations

from fastapi.testclient import TestClient


class TestHttpApi:
    def test_health(self, client: TestClient) -> None:
        response = client.get("/api/health")
        assert response.status_code == 200
        assert response.json()["status"] == "ok"

    def test_list_items(self, client: TestClient) -> None:
        response = client.get("/api/items")
        assert response.status_code == 200
        assert len(response.json()) >= 1

    def test_get_item(self, client: TestClient) -> None:
        response = client.get("/api/items/1")
        assert response.status_code == 200
        assert response.json()["id"] == "1"

    def test_get_unknown_item_returns_404(self, client: TestClient) -> None:
        response = client.get("/api/items/does-not-exist")
        assert response.status_code == 404
''',
    "tests/integration/test_openapi_contract.py": r'''"""The committed OpenAPI contract matches the routes the app serves."""

from __future__ import annotations

import json
from pathlib import Path

from __MODULE__.adapters.inbound.http.app import create_app

SPEC = Path(__file__).resolve().parents[2] / "openapi.json"


class TestOpenApiContract:
    def test_committed_spec_is_current(self) -> None:
        assert SPEC.exists(), "openapi.json is missing - run scripts/export_openapi.py and commit it"
        committed = json.loads(SPEC.read_text(encoding="utf-8"))
        assert committed == create_app().openapi(), (
            "openapi.json is stale - run scripts/export_openapi.py and commit the diff"
        )
''',
}


def _render(text: str, module: str, project: str, description: str, py_floor: str) -> str:
    return (
        text.replace("__MODULE__", module)
        .replace("__PROJECT__", project)
        .replace("__DESC__", description)
        .replace("__PYFLOOR__", py_floor)
    )


def main() -> None:
    parser = argparse.ArgumentParser(description="Scaffold a hexagonal FastAPI service.")
    parser.add_argument("--target", required=True, help="Parent directory for the project.")
    parser.add_argument("--project-name", required=True, help="kebab-case project/dist name.")
    parser.add_argument("--module-name", required=True, help="snake_case import package.")
    parser.add_argument("--description", default="A hexagonal FastAPI service.")
    parser.add_argument("--python-floor", default="3.10")
    args = parser.parse_args()

    if not args.module_name.isidentifier():
        parser.error(f"--module-name '{args.module_name}' is not a valid Python identifier")

    root = Path(args.target).resolve() / args.project_name
    written = 0
    skipped = 0

    for rel, content in FILES.items():
        dest = root / rel.replace("__MODULE__", args.module_name)
        if dest.exists():
            skipped += 1
            continue
        dest.parent.mkdir(parents=True, exist_ok=True)
        rendered = _render(
            content, args.module_name, args.project_name, args.description, args.python_floor
        )
        dest.write_text(rendered, encoding="utf-8", newline="\n")
        written += 1

    for pkg in PKG_DIRS:
        init = root / args.module_name / pkg / "__init__.py"
        if init.exists():
            continue
        init.parent.mkdir(parents=True, exist_ok=True)
        dotted = args.module_name + (("." + pkg.replace("/", ".")) if pkg else "")
        init.write_text(
            f'"""{dotted} package."""\n\nfrom __future__ import annotations\n',
            encoding="utf-8",
            newline="\n",
        )
        written += 1

    print(f"Scaffolded {root}: {written} files written, {skipped} skipped.")
    print(
        "Next: create a venv, `pip install -e \".[dev]\"`, then `ruff check .`, "
        "`python scripts/export_openapi.py` (the suite gates the committed spec), and `pytest -q`."
    )


if __name__ == "__main__":
    main()
