---
name: bootstrap-hexagonal-backend
description: Scaffold a new Python FastAPI service in hexagonal (ports and adapters) architecture, conforming to REF-CleanArchitecture / REF-FastAPI / REF-Python. Produces domain / application / adapters layers, a composition-root Container, logging WIRED through the layers (not just configured), a FastAPI app factory plus exception handler, an OpenAPI export script, and TestClient integration tests. Pairs with bootstrap-react-mvvm for the frontend.
galaxy: craft
refs:
  - REF-CleanArchitecture
  - REF-FastAPI
  - REF-Python
  - REF-Tests
  - REF-ExceptionHandling
---

# Bootstrap Hexagonal Backend

Invoked when a new Python backend service is needed at REF-conformant quality from
day one: clean hexagonal layering, a Container composition root, a FastAPI HTTP
adapter, and (critically) logging wired into adapters and use cases, not merely
configured. It is the application-service counterpart to `bootstrap-python-package`
(which scaffolds a publishable library, a different shape).

## Pre-flight

1. **Read** `REF-CleanArchitecture.md`, `REF-FastAPI.md`, `REF-Python.md`,
   `REF-ExceptionHandling.md`, `REF-Tests.md`. The skeleton instantiates them.
2. **Confirm with user**:
   - Project name (kebab-case folder and distribution name): e.g. `order-service`
   - Module name (snake_case import package): default = project name, `-` to `_`
   - One-sentence description
   - Python floor (default 3.10)
3. **Confirm target path** (the parent directory the project folder is created in).

## Steps

Run the helper at `<this-skill>/bootstrap.py`:

```bash
python bootstrap.py \
  --target <parent-dir> \
  --project-name <name> \
  --module-name <module> \
  --description "<one sentence>" \
  [--python-floor 3.10]
```

It writes the tree below. Idempotent: any file that already exists is skipped.

Then verify (Windows shown; on POSIX use `.venv/bin/python`):

```bash
cd <target>/<project-name>
python -m venv .venv
.venv\Scripts\python.exe -m pip install -e ".[dev]"
.venv\Scripts\python.exe -m ruff check .
.venv\Scripts\python.exe scripts\export_openapi.py   # writes openapi.json
.venv\Scripts\python.exe -m pytest -q
```

The export runs before pytest because the suite gates the committed spec: the
drift test fails while `openapi.json` is missing or stale (`--check` gives CI
the same gate). `openapi.json` is committed, and it is the contract you feed to
`bootstrap-react-mvvm`.

## What it produces

```
<target>/<project-name>/
├── pyproject.toml                 # deps, ruff (select E,F,I,UP,B,SIM), pytest, console script
├── .gitignore
├── README.md
├── scripts/export_openapi.py      # imports the app factory; writes or --checks openapi.json
├── <module>/
│   ├── __init__.py                # __version__
│   ├── logging.py                 # get_logger + configure_logging (single root namespace)
│   ├── container.py               # composition root; factories return inbound ports
│   ├── domain/
│   │   ├── model/                 # Item entity + barrel __init__
│   │   └── exceptions/            # AppError, EntityNotFoundError + barrel __init__
│   ├── application/
│   │   ├── ports/inbound/         # ListItemsPort, GetItemPort (Protocols)
│   │   ├── ports/outbound/        # ItemRepository (Protocol)
│   │   └── use_cases/             # ListItems, GetItem  (BOTH emit logs)
│   └── adapters/
│       ├── inbound/http/          # app factory, dependencies, exception handler,
│       │                          # dtos/, mappers/, routers/ (system + items)
│       └── outbound/memory/       # InMemoryItemRepository  (emits logs)
└── tests/
    ├── conftest.py                # TestClient fixture
    ├── integration/test_http_api.py  # health, list, detail, 404 (exercises the error path)
    └── integration/test_openapi_contract.py  # committed openapi.json matches the app (drift gate)
```

## The example slice

A minimal `Item` domain (list and get-by-id) wired end to end. It exists to
demonstrate every layer and the logging wiring; replace it with the real domain
and delete the example files once your own use cases exist.

## Logging is wired, not just configured (REF-Python §7)

The generated use cases and the in-memory adapter call `get_logger(__name__)` and
emit logs (adapters and use-case outcomes at INFO; the not-found path raises a
domain exception mapped to HTTP 404). This is deliberate: a configured-but-silent
logger is the exact gap this skill exists to prevent. Extend these calls; do not
strip them as boilerplate.

## Failure modes

- **A target file already exists** -> it is skipped (idempotent); other files are
  still written. Re-run safely.
- **Module name is not a valid Python identifier** -> reject before running.
- **No venv when verifying** -> create one first; never `pip install` outside it.

## See also

- `REF-CleanArchitecture.md`, `REF-FastAPI.md`, `REF-ExceptionHandling.md`, `REF-Python.md`
- `bootstrap-react-mvvm` skill: scaffolds a React MVVM frontend from the `openapi.json`
  this service exports.
- `bootstrap-python-package` skill: for a publishable *library* (src layout, LICENSE,
  `py.typed`), not an application service.
