#!/usr/bin/env python3
"""Scaffold a new Three.js 3D app conforming to REF-ThreeJS.

Writes <parent>/<app-name>/ with a Vite + TypeScript project: a
framework-agnostic SceneApp module (setAnimationLoop, delta-time motion,
ResizeObserver resize, full dispose), OrbitControls demo content, and a
Playwright smoke e2e preconfigured with the CI SwiftShader flags. With
--xr the scene is WebXR-ready (renderer.xr enabled, VRButton, camera rig).
Refuses to overwrite. Deterministic skeleton only; the caller replaces the
demo content with the real scene (see SKILL.md).

Usage:
    python bootstrap.py --name <app-name> [--dir <parent>] [--xr]
"""

from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

__all__ = ["main"]

NAME_RE = re.compile(r"^[a-z][a-z0-9]*(-[a-z0-9]+)*$")

PACKAGE_JSON = """{
    "name": "__APP_NAME__",
    "private": true,
    "version": "0.0.0",
    "type": "module",
    "scripts": {
        "dev": "vite",
        "build": "tsc --noEmit && vite build",
        "preview": "vite preview",
        "e2e": "npm run build && playwright test"
    },
    "dependencies": {
        "three": "^0.185.0"
    },
    "devDependencies": {
        "@playwright/test": "^1.49.0",
        "@types/three": "^0.185.0",
        "typescript": "^5.6.3",
        "vite": "^6.0.1"
    }
}
"""

TSCONFIG_JSON = """{
    "compilerOptions": {
        "target": "ES2022",
        "module": "ESNext",
        "moduleResolution": "bundler",
        "lib": ["ES2022", "DOM", "DOM.Iterable"],
        "strict": true,
        "noUnusedLocals": true,
        "noUnusedParameters": true,
        "noFallthroughCasesInSwitch": true,
        "skipLibCheck": true,
        "noEmit": true,
        "types": ["vite/client"]
    },
    "include": ["src"]
}
"""

VITE_CONFIG = """import { defineConfig } from 'vite';

// base './' keeps the built app servable from any sub-path.
export default defineConfig({
    base: './',
});
"""

INDEX_HTML = """<!doctype html>
<html lang="en">
    <head>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>__APP_NAME__</title>
        <style>
            html,
            body {
                margin: 0;
                height: 100%;
                background: #0b0e14;
            }
            #app {
                width: 100%;
                height: 100%;
            }
            /* CSS owns the canvas layout; the renderer only sizes the buffer
               (renderer.setSize(w, h, false) - REF-ThreeJS section 3). */
            #app canvas {
                display: block;
                width: 100%;
                height: 100%;
            }
        </style>
    </head>
    <body>
        <div id="app"></div>
        <script type="module" src="/src/main.ts"></script>
    </body>
</html>
"""

MAIN_TS = """import { createSceneApp } from './scene/SceneApp';

const container = document.getElementById('app');
if (!container) throw new Error('missing #app container');

const app = createSceneApp();
app.mount(container);
app.start();
"""

SCENE_APP_TS = """import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
__XR_IMPORT__
export interface SceneApp {
    mount(container: HTMLElement): void;
    start(): void;
    stop(): void;
    dispose(): void;
}

export function createSceneApp(): SceneApp {
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0b0e14);

    // The camera rides a rig; locomotion (and XR presentation) moves the rig,
    // never the camera itself (REF-ThreeJS section 9). Units are meters, Y up.
    const camera = new THREE.PerspectiveCamera(60, 1, 0.1, 100);
    camera.position.set(0, 1.6, 3);
    const rig = new THREE.Group();
    rig.name = 'camera-rig';
    rig.add(camera);
    scene.add(rig);

    scene.add(new THREE.HemisphereLight(0xffffff, 0x3a3f4a, 1.0));
    const sun = new THREE.DirectionalLight(0xffffff, 2.0);
    sun.position.set(3, 5, 2);
    scene.add(sun);

    // Demo content: replace with the real scene, keep the group + naming shape.
    const content = new THREE.Group();
    content.name = 'demo-content';
    const knot = new THREE.Mesh(
        new THREE.TorusKnotGeometry(0.4, 0.14, 128, 32),
        new THREE.MeshStandardMaterial({ color: 0x4f8cff, roughness: 0.3, metalness: 0.1 }),
    );
    knot.name = 'demo-knot';
    knot.position.set(0, 1.2, 0);
    content.add(knot);
    const floor = new THREE.Mesh(
        new THREE.CylinderGeometry(3, 3, 0.05, 48),
        new THREE.MeshStandardMaterial({ color: 0x232833, roughness: 0.9 }),
    );
    floor.name = 'demo-floor';
    floor.position.y = -0.025;
    content.add(floor);
    scene.add(content);

    let renderer: THREE.WebGLRenderer | null = null;
    let controls: OrbitControls | null = null;
    let observer: ResizeObserver | null = null;
    let host: HTMLElement | null = null;
    const clock = new THREE.Clock();

    function frame(): void {
        const dt = clock.getDelta();
        knot.rotation.x += dt * 0.6;
        knot.rotation.y += dt * 0.9;
        controls?.update();
        if (renderer) renderer.render(scene, camera);
        // Readiness signal: flips once the first frame has actually rendered.
        // The smoke e2e (and any loading UI) keys off it.
        if (host && host.dataset.sceneReady !== 'true') host.dataset.sceneReady = 'true';
    }

    return {
        mount(container: HTMLElement): void {
            host = container;
            renderer = new THREE.WebGLRenderer({ antialias: true });
            renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
            renderer.outputColorSpace = THREE.SRGBColorSpace;
            renderer.toneMapping = THREE.ACESFilmicToneMapping;
            container.appendChild(renderer.domElement);
__XR_MOUNT__
            controls = new OrbitControls(camera, renderer.domElement);
            controls.enableDamping = true;
            controls.target.set(0, 1.2, 0);

            observer = new ResizeObserver(() => {
                if (!renderer || !host) return;
                const width = host.clientWidth;
                const height = Math.max(host.clientHeight, 1);
                camera.aspect = width / height;
                camera.updateProjectionMatrix();
                renderer.setSize(width, height, false);
            });
            observer.observe(container);
        },
        start(): void {
            renderer?.setAnimationLoop(frame);
        },
        stop(): void {
            renderer?.setAnimationLoop(null);
        },
        dispose(): void {
            this.stop();
            observer?.disconnect();
            observer = null;
            controls?.dispose();
            controls = null;
            scene.traverse((node) => {
                const mesh = node as THREE.Mesh;
                if (mesh.geometry) mesh.geometry.dispose();
                const material = mesh.material as THREE.Material | THREE.Material[] | undefined;
                const materials = Array.isArray(material) ? material : material ? [material] : [];
                for (const m of materials) m.dispose();
            });
            renderer?.dispose();
            renderer?.domElement.remove();
            renderer = null;
            host = null;
        },
    };
}
"""

XR_IMPORT = "import { VRButton } from 'three/addons/webxr/VRButton.js';\n"

XR_MOUNT = """            renderer.xr.enabled = true;
            // The button mounts only when an immersive session is
            // supported; flat browsers get no VR chrome at all.
            navigator.xr?.isSessionSupported('immersive-vr').then((ok) => {
                if (ok) container.appendChild(VRButton.createButton(renderer));
            });
"""

PLAYWRIGHT_CONFIG = """import { defineConfig, devices } from '@playwright/test';

// Local runs serve the built app via `vite preview`; point BASE_URL at a
// deployed URL to run the same specs post-deploy and skip the local server.
const PORT = 4173;
const BASE_URL = process.env.BASE_URL ?? `http://localhost:${PORT}`;

export default defineConfig({
    testDir: './e2e',
    timeout: 60_000,
    expect: { timeout: 30_000 },
    workers: 1,
    reporter: 'line',
    use: {
        baseURL: BASE_URL,
        // WebGL under headless Chromium runs on SwiftShader; these flags
        // enable it, in CI included (REF-ThreeJS section 10).
        launchOptions: {
            args: [
                '--use-gl=angle',
                '--use-angle=swiftshader',
                '--enable-unsafe-swiftshader',
                '--ignore-gpu-blocklist',
            ],
        },
    },
    projects: [{ name: 'chromium', use: { ...devices['Desktop Chrome'] } }],
    webServer: process.env.BASE_URL
        ? undefined
        : {
              command: 'npm run preview',
              url: `http://localhost:${PORT}`,
              reuseExistingServer: !process.env.CI,
              timeout: 120_000,
          },
});
"""

SMOKE_SPEC = """import { expect, test } from '@playwright/test';

test('the scene mounts, renders a first frame, and logs no errors', async ({ page }) => {
    const errors: string[] = [];
    page.on('pageerror', (err) => errors.push(String(err)));
    page.on('console', (msg) => {
        if (msg.type() === 'error') errors.push(msg.text());
    });

    await page.goto('/');

    // data-scene-ready flips on the first rendered frame (src/scene/SceneApp.ts);
    // reaching it proves the WebGL context and the animation loop are alive.
    await expect(page.locator('#app[data-scene-ready="true"]')).toBeAttached();

    const canvas = page.locator('#app canvas').first();
    await expect(canvas).toBeVisible();
    const size = await canvas.evaluate((el) => ({
        w: (el as HTMLCanvasElement).width,
        h: (el as HTMLCanvasElement).height,
    }));
    expect(size.w).toBeGreaterThan(0);
    expect(size.h).toBeGreaterThan(0);

    expect(errors).toEqual([]);
});
"""

GITIGNORE = """node_modules/
dist/
test-results/
playwright-report/
"""

README_MD = """# __APP_NAME__

A Three.js 3D app scaffolded per the team playbook's `REF-ThreeJS.md`; read that
REF before extending the scene. The 3D core is the framework-agnostic `SceneApp`
module in `src/scene/`; the demo content inside it is placeholder.

## Commands

| Command | What it does |
|---|---|
| `npm run dev` | Dev server with HMR |
| `npm run build` | Type-check + production build to `dist/` |
| `npm run e2e` | Build, then run the headless WebGL smoke e2e against `vite preview` |

First machine only: `npx playwright install chromium` before `npm run e2e`.

## Conventions baked in

- `renderer.setAnimationLoop` drives the frame loop (XR-compatible); all motion
  is delta-time scaled.
- The camera rides the `camera-rig` group; locomotion moves the rig.
- Units are meters, Y up.
- `#app` gets `data-scene-ready="true"` after the first rendered frame; loading
  UI and the smoke e2e key off it.
- `dispose()` frees every GPU resource; call it whenever the app unmounts.
__README_XR__"""

README_XR_ON = """
## WebXR

The renderer is XR-enabled and a `VRButton` is mounted. Immersive sessions need
a secure context: the deployed HTTPS URL works in a headset browser as-is; for
local development use an HTTPS tunnel/proxy or a desktop WebXR emulator
extension. See `REF-ThreeJS.md` section 9 for rig locomotion, controllers, and
comfort rules.
"""

README_XR_OFF = """
## Going immersive later

The scaffold is already WebXR-shaped (`setAnimationLoop`, meters, camera rig).
To enable VR, flip `renderer.xr.enabled = true` and mount `VRButton` in
`SceneApp.mount()`; see `REF-ThreeJS.md` section 9.
"""


def _write(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8", newline="\n")
    print(f"  {path}")


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--name", required=True, help="app name, kebab-case")
    ap.add_argument("--dir", type=Path, default=Path.cwd(), help="parent directory (default: cwd)")
    ap.add_argument("--xr", action="store_true", help="scaffold WebXR-ready (VRButton, renderer.xr enabled)")
    args = ap.parse_args()

    if not NAME_RE.match(args.name):
        print(f"error: name must be kebab-case: {args.name!r}", file=sys.stderr)
        return 2
    root = args.dir / args.name
    if root.exists():
        print(f"error: {root} already exists", file=sys.stderr)
        return 2

    scene_app = SCENE_APP_TS.replace("__XR_IMPORT__", XR_IMPORT if args.xr else "")
    scene_app = scene_app.replace("__XR_MOUNT__\n", XR_MOUNT + "\n" if args.xr else "")
    readme = README_MD.replace("__APP_NAME__", args.name).replace(
        "__README_XR__", README_XR_ON if args.xr else README_XR_OFF
    )

    print(f"Creating {root}")
    _write(root / "package.json", PACKAGE_JSON.replace("__APP_NAME__", args.name))
    _write(root / "tsconfig.json", TSCONFIG_JSON)
    _write(root / "vite.config.ts", VITE_CONFIG)
    _write(root / "index.html", INDEX_HTML.replace("__APP_NAME__", args.name))
    _write(root / "playwright.config.ts", PLAYWRIGHT_CONFIG)
    _write(root / ".gitignore", GITIGNORE)
    _write(root / "README.md", readme)
    _write(root / "src" / "main.ts", MAIN_TS)
    _write(root / "src" / "scene" / "SceneApp.ts", scene_app)
    _write(root / "e2e" / "smoke.spec.ts", SMOKE_SPEC)

    print("\nNext steps:")
    print(f"  cd {root}")
    print("  npm install")
    print("  npx playwright install chromium   # first machine only")
    print("  npm run e2e                       # proves the scene renders headlessly")
    print("  npm run dev")
    return 0


if __name__ == "__main__":
    sys.exit(main())
