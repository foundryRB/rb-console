---
name: bootstrap-threejs-app
description: "Scaffold a new Three.js 3D app per REF-ThreeJS: Vite + TypeScript, a framework-agnostic SceneApp module (setAnimationLoop, delta-time motion, ResizeObserver resize, full dispose), OrbitControls demo content, an optional --xr variant (VRButton + camera rig, WebXR-ready), and a Playwright smoke e2e preconfigured with the CI SwiftShader flags. Caller runs npm install, then the build and e2e gates."
galaxy: craft
refs:
  - REF-ThreeJS
---

# Bootstrap Three.js app

Invoked when a new 3D app (visualization, game, or WebXR experience) is starting and the skeleton should conform to `REF-ThreeJS.md` from the first commit. Deterministic scaffold; the demo content is a placeholder the author replaces with the real scene.

## Pre-flight

1. **Read** `REF-ThreeJS.md` (especially §2 module boundary, §3 renderer and loop, §9 WebXR, §10 testing).
2. **Confirm with user**: app name (kebab-case), target parent directory, and whether the app should be WebXR-ready from day one (`--xr`).
3. **Check the ask is actually 3D**: charts and dashboards route to `REF-ObservableFramework.md` instead (`REF-ThreeJS.md` §1).

## Steps

1. **Run the scaffolder**:
   ```bash
   python bootstrap.py --name <app-name> [--dir <parent>] [--xr]
   ```
   This writes the Vite + TypeScript project: the `SceneApp` module (REF-ThreeJS §2 to §4, §6), demo content, the Playwright smoke e2e with the SwiftShader launch flags (§10), and the README.
2. **Install and prove the render**: `npm install`, then `npx playwright install chromium` (first machine only), then `npm run e2e`. The e2e script builds first (the preview server serves the last build, so a rebuild is part of the gate) and asserts the first frame rendered headlessly with no console errors.
3. **Replace the demo content** with the real scene, keeping the `SceneApp` contract and the `data-scene-ready` readiness signal intact.
4. **Iterate** with `npm run dev`.

## Failure modes

- **Target directory already exists**: the scaffolder refuses; pick another name or remove the leftover.
- **e2e fails creating a WebGL context**: the SwiftShader launch flags were removed or the browser install is stale; restore `launchOptions.args` in `playwright.config.ts` and re-run `npx playwright install chromium`.
- **e2e passes but exercises old behavior**: something ran `playwright test` directly against a stale `dist/`; always go through `npm run e2e`, which rebuilds first.
- **VR button says not supported on a headset**: immersive sessions need a secure context; serve the app over HTTPS (`REF-ThreeJS.md` §9).
