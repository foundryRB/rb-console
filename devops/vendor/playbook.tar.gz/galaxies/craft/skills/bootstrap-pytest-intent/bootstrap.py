#!/usr/bin/env python3
"""Scaffold pytest-intent test infrastructure into a Python project.

Idempotent. Skips files that already exist.

pytest-intent provides only the @intent decorator; schema and coverage auditing
are done out of band by the standalone csd-intent CLI, so no in-suite meta-test
file is written.

Usage:
  python bootstrap.py --target <project-path>
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

CONFTEST_TMPL = '''\
"""pytest fixtures for this project."""

from __future__ import annotations

from pathlib import Path

import pytest


@pytest.fixture(scope="session")
def pack_root() -> Path:
    """Project root, where intent.yaml lives (tests/ is a child by default)."""
    return Path(__file__).resolve().parent.parent
'''

INTENT_YAML_STUB = '''\
# Intent claims for this project (CSD-INTENT-01 schema).
# Attest each claim with an @intent("INT-NNN") test under tests/, then audit out of
# band with the standalone csd-intent CLI:
#   csd-intent .

# Example (uncomment and adapt):
# INT-001:
#   version: 1.0.0
#   status: active
#   statement: "Session data MUST never cross user boundaries."
#   rationale: "Data leakage between sessions is the top security risk for this app."
#   test:
#     scope: unit
#     component: SessionService
#     type: invariant
#   criticality: critical
'''


def write_if_missing(path: Path, content: str) -> bool:
    """Write content to path only if it doesn't exist. Returns True if written."""
    if path.exists():
        print(f"  SKIP (exists): {path}")
        return False
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")
    print(f"  WRITE: {path}")
    return True


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--target", type=Path, required=True, help="Python project root")
    args = ap.parse_args()

    target: Path = args.target
    if not target.exists():
        print(f"target does not exist: {target}", file=sys.stderr)
        return 2
    if not target.is_dir():
        print(f"target is not a directory: {target}", file=sys.stderr)
        return 2

    print(f"Scaffolding pytest-intent infrastructure at {target}")
    write_if_missing(target / "intent.yaml", INTENT_YAML_STUB)
    write_if_missing(target / "tests" / "__init__.py", "")
    write_if_missing(target / "tests" / "conftest.py", CONFTEST_TMPL)

    print()
    print("Next steps:")
    print("  1. Install the runtime + auditor in your venv, e.g.:")
    print('       pip install "csd-pytest-intent~=0.3.0" "csd-intent>=0.6.0,<0.7"')
    print("       # local dev against a checkout:  pip install -e path/to/csd-library/pytest-intent -e path/to/csd-library/csd-intent")
    print("  2. Add claims to intent.yaml (CSD-INTENT-01 schema; see the commented example)")
    print("  3. Attest each with @intent('INT-NNN') on a test function under tests/")
    print("  4. Run the tests:   pytest tests/")
    print("  5. Audit coverage:  csd-intent .   (schema valid, no orphans, every claim attested)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
