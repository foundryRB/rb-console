---
name: bootstrap-pytest-intent
description: Scaffold pytest-intent into any Python project. Installs the @intent decorator runtime, writes the intent.yaml stub and the pack_root fixture, and points schema/coverage auditing at the standalone csd-intent CLI. Reusable across Data Packs and any other Python+pytest project that wants CSD-aligned intent testing.
galaxy: craft
refs:
  - REF-CSD
  - REF-Tests
  - REF-Python
---

# Bootstrap pytest-intent

Invoked when a Python project wants CSD-style intent testing: `@intent("INT-NNN")` decorators that bind a test to one or more intent claims, with schema and coverage auditing handled out of band by `csd-intent`.

This skill is the test-infrastructure sibling of `bootstrap-data-pack`. Data Packs delegate their tests/ scaffolding to this skill (or duplicate the same pattern internally).

> **Division of labour.** `pytest-intent` is *only* the `@intent` decorator: it attaches claim IDs to test functions, and pytest behaviour is unchanged. Schema validation (CSD-INTENT-01), orphan detection, and coverage all live in the standalone `csd-intent` CLI, run separately (ad-hoc, pre-commit, or CI). There is no in-suite meta-test, and no `pytest_intent.meta_tests` module to import.

## Pre-flight

1. **Read** `REF-CSD.md`, `../csd-library/pytest-intent/README.md`, and `../csd-library/csd-intent/README.md` for the model.
2. **Confirm target**: the directory of an existing Python project (or where one will live).
3. **Confirm a Python venv exists**: the runtimes are `pip install`-ed into it. If there is no venv yet, instruct the user to create one before proceeding.

## What it produces

```
<target>/
├── intent.yaml              # stub with one commented CSD-INTENT-01 example
└── tests/
    ├── __init__.py
    └── conftest.py          # pack_root fixture (project root)
```

No in-suite meta-test file is written; auditing is `csd-intent`'s job (below).

## Steps

1. **Install the runtime and auditor** into the project venv:
   ```bash
   pip install "csd-pytest-intent~=0.3.0" "csd-intent>=0.6.0,<0.7"
   ```
2. **Run the scaffolder** (Python helper at `<this-skill>/bootstrap.py`):
   ```bash
   python bootstrap.py --target <project-path>
   ```
   The helper writes the three files above. Idempotent: it skips files that already exist.
3. **Author claims and tests**: add CSD-INTENT-01 claims to `intent.yaml` and attest each with `@intent("INT-NNN")` on a test function under `tests/`.
4. **Run the tests** to confirm they pass:
   ```bash
   cd <project-path> && pytest tests/
   ```
5. **Audit coverage** with the standalone CLI (schema valid, no orphan markers, every claim attested):
   ```bash
   cd <project-path> && csd-intent .
   ```
6. **Surface to user**: "pytest-intent + csd-intent installed; intent.yaml + tests/ scaffolded. Add claims to intent.yaml, `@intent('INT-NNN')` to the matching tests, then `csd-intent .` to audit."

## Multiple intent domains (multi-file / multi-dir)

`csd-intent` audits one `intent.yaml` per invocation root and scans test markers across runtimes. For a project with more than one intent domain (for example a backend standard plus a docs site with its own `intent.yaml`), audit each at its own root and constrain the scan with `--tests-dir`, so markers from one domain are not reported as orphans of another:

```bash
csd-intent . --tests-dir tests     # the project standard
csd-intent docs                    # a nested docs intent unit
```

## Failure modes

- **No venv**: surface to the user; do not `pip install` outside one.
- **Target already has tests/conftest.py with different `pack_root` semantics**: diff the existing fixture against ours; if it conflicts, surface and let the user merge manually.
- **`pytest_intent` or `csd_intent` not importable after install**: the venv is likely not active when running pytest / csd-intent. Surface.

## See also

- `../csd-library/pytest-intent/` : the @intent decorator runtime this skill installs
- `../csd-library/csd-intent/` : the standalone schema + coverage auditor
- `REF-CSD.md` : methodology
- `bootstrap-data-pack` skill : superset for full Data Pack scaffolding (uses this internally for the test infrastructure)
