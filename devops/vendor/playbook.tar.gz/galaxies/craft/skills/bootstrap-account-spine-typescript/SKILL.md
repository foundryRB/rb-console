---
name: bootstrap-account-spine-typescript
description: "Add the account spine to an existing TypeScript backend (domain/ plus adapters/{http,pg}) per REF-Identity: an opaque non-derived user id, an accounts table carrying the federation link, digest-only sessions, one session-resolution choke point, a guess budget, and the credential rung named explicitly with --rung (no default, because a scaffold that picks the rung is advocacy with a code generator attached). Ships the guest + recovery-code rung; other rungs route to REF-Identity section 2."
galaxy: craft
refs:
  - REF-Identity
  - REF-CleanArchitecture
  - REF-React
  - REF-Tests
---

# Bootstrap account spine (TypeScript)

Additive to an existing backend in the `domain/` plus `adapters/{http,pg}`
shape. It writes the parts of an identity that are the same whichever
credential you chose, and the credential module for the one you name. The
Python counterpart is `bootstrap-account-spine-python`; both instantiate the
same REF, and neither shares code with the other, because what is common here
is the contract, not the implementation.

## Pre-flight

1. **Choose the rung first, with `REF-Identity.md` section 2.** Recovery decides
   it, not stakes: for accounts that were never identity-proofed the conforming
   recovery set is closed to three, and "is there an email to recover against"
   and "does an operator exist" eliminate rungs outright. This script will not
   choose for you and has no default.
2. **Check the rung this generator emits covers your answer.** It emits
   `guest-recovery-code`. If section 2 routed you elsewhere, stop: that rung
   needs its own credential module, because the hashing differs by the
   credential's entropy and the routes differ by what the caller presents. For
   OIDC, use the chosen identity provider's integration guide.
3. **Confirm the host shape**: a source root containing `domain/` and
   `adapters/`. That much the generator checks, and it refuses rather than
   inventing a layout. It checks nothing else, so two things are yours to
   confirm before you run it:
   - **`pg` and `express` are the emitted adapters' dependencies.** The
     Postgres repository imports `pg`, and `accounts-routes.ts` is an
     `express.Router`. A host that serves HTTP another way (a raw
     `node:http` router, Fastify, Hono) gets a file that will not compile;
     port the route bodies into that host's own router, keeping
     `sessionTokenOf` and the `resolveSession` call exactly as they are.
   - **The store is Postgres.** Another database needs its own repository
     against the same port.
4. **Read** `REF-Identity.md` sections 4 and 5 before reviewing the output: the
   generated code makes two choices that look wrong to anyone who has not read
   them (a fast digest rather than a KDF, and two columns nothing reads yet).

## Steps

1. **Generate**, from this skill's folder:

   ```sh
   python bootstrap.py --src <backend>/src --rung guest-recovery-code
   ```

   It writes `domain/credential.ts`, `domain/accounts.ts`,
   `domain/guess-budget.ts`, `adapters/memory/accounts-repo.ts` and
   `adapters/pg/accounts-repo.ts`, plus `adapters/http/accounts-routes.ts`. It
   refuses to overwrite; pass `--force` only when you mean to.

2. **Apply the schema.** `ACCOUNTS_SCHEMA` is exported from the Postgres
   adapter; run it where the project applies its other DDL, so the tables and
   both unique indexes land with everything else.

3. **Wire it.** Construct the repository the way the project selects its other
   backends (a database URL present means Postgres, absent means the in-memory
   one), build one `AccountService` and one `GuessBudget`, and mount
   `buildAccountRoutes(accounts, budget)` under the API prefix. Pass the
   application's own session lifetime to `AccountService`; the default is a
   floor, not a recommendation, and the stakes axis is what sets it
   (`REF-Identity.md` section 2).

4. **`AccountService.sweep()` is on offer, not owed.** It deletes guests whose
   sessions have all expired, which are unreachable by construction because a
   guest holds no credential but its session token. That makes it safe to run,
   and it bounds a table anyone can add rows to without a credential.

   It is still a background job, with a schedule and a grace window to own, so
   it is earned by a table that is actually growing rather than by one that
   might (craft violation #4, Gall's Law). Ship without it, watch the row
   count, and wire it on an interval when the count says so. Nothing else in
   the spine depends on it. Deleting the method is a fine answer too.

5. **Route every private surface through `resolveSession`.** That function is
   the choke point the whole model rests on. A handler that reads an identity
   from a body, a path, or a proxy header is the defect this spine exists to
   prevent, and it will pass every test that does not look for it.

6. **Attribute what the account owns.** Anywhere the app records something under
   a name a caller supplied, take the name from the resolved account instead and
   ignore the body's. Leaving the body trusted turns an anonymous write surface
   into an attribution-forgery one the moment accounts exist.

7. **Record the decision in an ADR**, in the same change: the rung, the recovery
   rung beside it, and what is lost when an account is taken.

8. **Run the gates**: the project's typecheck, its test suite, and its intent
   audit if it carries claims.

## What it deliberately does not do

- **Pick your rung.** See Pre-flight 1.
- **Emit a profile or any app data.** A profile hangs off an account; it is not
  part of an identity.
- **Build federation.** The two link columns and the lookup by the pair are
  present and empty. No shared user table, no cross-app protocol, no hub: a
  standalone app must never depend on a federation that does not exist. The
  columns are there because adding them later is a live migration with an
  account-takeover window open across it.
- **Add sign-in UI.** The HTTP surface is the contract; the screens are the
  app's.

## Failure modes

- **`unknown rung`**: the generator emits one rung and you named another. This
  is the intended refusal, not a gap to work around.
- **`has no domain/ and adapters/`**: the host is not in the shape this
  scaffold writes into. Place the files by hand, or use the layout the corpus
  routes to.
- **`refusing to overwrite`**: reconcile by hand rather than forcing; a half-
  overwritten identity is worse than either version.
- **Typecheck fails on `.js` import specifiers**: the templates use
  NodeNext-style extensions. A project on a different module resolution should
  drop the extensions rather than change resolution to suit the scaffold.
- **Tests pass but nothing is authenticated**: the routes are mounted and the
  choke point is not used. Assert it directly: a request carrying a made-up
  token, a claimed user id, and a proxy header must each be unauthenticated.
