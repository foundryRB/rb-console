"""Scaffold the account spine into an existing TypeScript backend.

Targets the `domain/` plus `adapters/{http,pg}` shape: the domain holds the
account service, the credential module and the guess budget; the adapters hold
the Postgres repository and the Express routes.

Writes the rung-independent spine (opaque user id, accounts table carrying the
federation link, digest-only sessions, one session-resolution choke point, a
guess budget) plus the credential module for the rung named on the command line.

`--rung` has no default, deliberately. A scaffold that picks the credential rung
makes that rung the house answer for every app that runs it, including the ones
whose stakes say otherwise, and it does so with working code that nobody argues
with. The rung is a decision `REF-Identity.md` section 2 routes; this script
refuses to make it for you.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

TEMPLATES = Path(__file__).parent / "templates"

RUNGS = {
    "guest-recovery-code": (
        "A guest is an account; registration upgrades it in place and mints a "
        "high-entropy recovery code, stored as a fast digest because it sits "
        "far above the 112-bit line (REF-Identity section 4)."
    ),
}

OTHER_RUNGS = (
    "password+session, OIDC against a hosted IdP, magic link, passkeys/WebAuthn, "
    "JWT bearer, device-bound anonymous"
)


def render(src_root: Path, force: bool) -> list[Path]:
    written: list[Path] = []
    for template in sorted(TEMPLATES.rglob("*.tmpl")):
        relative = template.relative_to(TEMPLATES).with_suffix("")
        destination = src_root / relative
        if destination.exists() and not force:
            raise SystemExit(
                f"refusing to overwrite {destination}\n"
                "The spine is additive; move or delete the existing file, or pass --force."
            )
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_text(template.read_text(encoding="utf-8"), encoding="utf-8")
        written.append(destination)
    return written


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Add the account spine to an existing TypeScript backend."
    )
    parser.add_argument(
        "--src",
        required=True,
        help="The backend's source root, the directory holding domain/ and adapters/",
    )
    parser.add_argument(
        "--rung",
        required=True,
        help=(
            "The credential rung. No default: choose it with REF-Identity section 2. "
            f"This generator emits: {', '.join(sorted(RUNGS))}."
        ),
    )
    parser.add_argument("--force", action="store_true", help="Overwrite existing files")
    args = parser.parse_args()

    if args.rung not in RUNGS:
        print(
            f"unknown rung {args.rung!r}.\n\n"
            f"This generator emits: {', '.join(sorted(RUNGS))}.\n"
            f"REF-Identity section 3 covers the rest ({OTHER_RUNGS}); each needs its own\n"
            "credential module, because the hashing differs by the credential's entropy\n"
            "and the routes differ by what the caller presents. Pick the rung with\n"
            "REF-Identity section 2 first: recovery decides it, not stakes.",
            file=sys.stderr,
        )
        return 2

    src_root = Path(args.src).resolve()
    if not src_root.is_dir():
        print(f"no source root at {src_root}", file=sys.stderr)
        return 2
    if not (src_root / "domain").is_dir() or not (src_root / "adapters").is_dir():
        print(
            f"{src_root} has no domain/ and adapters/.\n"
            "This scaffold is additive to an existing backend in that shape, not a new project.",
            file=sys.stderr,
        )
        return 2

    written = render(src_root, args.force)
    print(f"Account spine written into {src_root} ({args.rung}):")
    for path in written:
        print(f"  {path.relative_to(src_root).as_posix()}")
    print(
        "\nStill yours (SKILL.md lists them):\n"
        "  1. Apply ACCOUNTS_SCHEMA where the project applies its other DDL.\n"
        "  2. Construct AccountService and one GuessBudget, and mount buildAccountRoutes.\n"
        "  3. Route every private surface through AccountService.resolveSession.\n"
        "  4. Record the rung and its recovery rung in an ADR, with the reasoning.\n"
        "  5. Run the gates."
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
