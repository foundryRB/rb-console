"""Scaffolder for the bootstrap-atomic-shadcn skill.

Lays an Atomic-Design View layer onto an existing React + TypeScript + Tailwind
project, backed by shadcn/ui primitives. Writes the five level folders
(atoms / molecules / organisms / templates / pages) with one exemplar each, every
exemplar a component folder with its test, story (not for pages) and index.ts barrel
(REF-Frontend section 9), a placeholder ViewModel hook that marks the connection point,
and the `components.json` the shadcn CLI reads.

The `components/ui/` primitives the atoms wrap, and the `cn()` helper at the `utils`
alias, are the CLI's output: `npx shadcn@latest add card badge` installs the two this
slice imports (REF-Frontend section 2, components/ui is toolchain output, never
hand-written). Run it after this scaffolder, before the build.

Additive and idempotent: config files land at the project root, source files under
the source directory (default `src/`); an existing file is skipped, never
overwritten, so a re-run is safe. Distinct from `bootstrap-react-mvvm`, which
scaffolds a whole Vite project with a generated Model layer; this skill adds only
the View taxonomy to a project that already exists.

The exemplars follow REF-AtomicDesign: the level ladder (section 2), the composition
ladder (section 4, compose own level or below only), and the purity gradient
(section 5, data enters at the page and flows down as props; atoms and molecules
stay pure). Imports use the `@/*` alias (shadcn's default), so they do not depend on
the literal source-directory name; the project's tsconfig / vite must map `@` to the
source directory (as `bootstrap-react-mvvm` does).

Usage:
    python bootstrap.py --root <project-dir> [--src-dir src] [--title "Dashboard"]
"""

from __future__ import annotations

import argparse
from pathlib import Path

# Files that live at the project root (shadcn config), keyed by path relative to --root.
ROOT_FILES: dict[str, str] = {
    "components.json": r'''{
    "$schema": "https://ui.shadcn.com/schema.json",
    "style": "default",
    "rsc": false,
    "tsx": true,
    "tailwind": {
        "config": "tailwind.config.js",
        "css": "__SRC_DIR__/index.css",
        "baseColor": "slate",
        "cssVariables": true,
        "prefix": ""
    },
    "aliases": {
        "components": "@/components",
        "utils": "@/utils",
        "ui": "@/components/ui"
    }
}
''',
}

# Source files, keyed by path relative to <root>/<src-dir>. Imports use the `@/*`
# alias so they are independent of the literal source-directory name.
SRC_FILES: dict[str, str] = {
    # --- ViewModel connection point (placeholder; a real project supplies a SAM VM) ---
    "viewmodels/widgets/useWidgets.ts": r'''// The View's connection point to data. In a full MVVM project this is a SAM
// ViewModel hook (REF-Frontend section 4); here it is a self-contained placeholder
// returning static example data so the scaffold runs with no backend. Replace it
// with the engagement's real ViewModel (see the bootstrap-react-mvvm skill), keeping
// the same shape: only the page and connected organisms call it (REF-AtomicDesign
// section 5, the purity gradient).
import { useEffect, useState } from 'react';

export type WidgetStatus = 'healthy' | 'degraded' | 'down';

export interface Widget {
    id: string;
    name: string;
    status: WidgetStatus;
}

export interface WidgetsViewModel {
    widgets: Widget[];
    loading: boolean;
    error: string | null;
}

const EXAMPLE_WIDGETS: Widget[] = [
    { id: 'ingest', name: 'Ingest', status: 'healthy' },
    { id: 'index', name: 'Index', status: 'degraded' },
    { id: 'search', name: 'Search', status: 'down' },
];

export function useWidgets(): WidgetsViewModel {
    const [state, setState] = useState<WidgetsViewModel>({
        widgets: [],
        loading: true,
        error: null,
    });

    useEffect(() => {
        // Stand-in for a ViewModel action (an HTTP call in a real project).
        setState({ widgets: EXAMPLE_WIDGETS, loading: false, error: null });
    }, []);

    return state;
}
''',
    # --- Views: one folder per component (REF-Frontend section 9): the component with
    # its exported props, a test, a story (not for pages), and an index.ts barrel. The
    # test and the story import the component by relative path; everything else
    # imports the folder. ---------------------------------------------------------
    # --- Atoms: smallest units, wrap a single primitive, pure (props in, markup out) ---
    "views/atoms/StatusBadge/StatusBadge.tsx": r'''// Atom (REF-AtomicDesign section 2): wraps the single shadcn Badge primitive and
// maps a status to a variant. Props only, no hooks, no data (section 5, atoms are pure).
import { Badge } from '@/components/ui/badge';
import type { WidgetStatus } from '@/viewmodels/widgets/useWidgets';

const VARIANT: Record<WidgetStatus, 'default' | 'secondary' | 'destructive'> = {
    healthy: 'default',
    degraded: 'secondary',
    down: 'destructive',
};

export interface StatusBadgeProps {
    status: WidgetStatus;
}

export const StatusBadge = ({ status }: StatusBadgeProps) => (
    <Badge variant={VARIANT[status]}>{status}</Badge>
);
''',
    "views/atoms/StatusBadge/StatusBadge.test.tsx": r'''import { render, screen } from '@testing-library/react';
import { describe, expect, it } from 'vitest';

import { StatusBadge } from './StatusBadge';

// Atoms are pure (REF-AtomicDesign section 5), so they render with no provider,
// store, or data source: props in, markup out.
describe('StatusBadge', () => {
    it('renders the status label', () => {
        render(<StatusBadge status="degraded" />);
        expect(screen.getByText('degraded')).toBeInTheDocument();
    });
});
''',
    "views/atoms/StatusBadge/StatusBadge.stories.tsx": r'''import type { Meta, StoryObj } from '@storybook/react-vite';

import { StatusBadge } from './StatusBadge';

const meta = {
    title: 'Atoms/StatusBadge',
    component: StatusBadge,
    args: { status: 'healthy' },
} satisfies Meta<typeof StatusBadge>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Healthy: Story = {};

export const Degraded: Story = { args: { status: 'degraded' } };

export const Down: Story = { args: { status: 'down' } };
''',
    "views/atoms/StatusBadge/index.ts": r'''export { StatusBadge } from './StatusBadge';
export type { StatusBadgeProps } from './StatusBadge';
''',
    "views/atoms/Spinner/Spinner.tsx": r'''// Atom (REF-AtomicDesign section 2): a pure loading indicator, no data or state.
import { cn } from '@/utils';

export interface SpinnerProps {
    className?: string;
}

export const Spinner = ({ className }: SpinnerProps) => (
    <div
        role="status"
        aria-label="loading"
        className={cn(
            'size-4 animate-spin rounded-full border-2 border-muted border-t-foreground',
            className,
        )}
    />
);
''',
    "views/atoms/Spinner/Spinner.test.tsx": r'''import { render, screen } from '@testing-library/react';
import { describe, expect, it } from 'vitest';

import { Spinner } from './Spinner';

describe('Spinner', () => {
    it('announces itself as a loading status', () => {
        render(<Spinner />);
        expect(screen.getByRole('status', { name: 'loading' })).toBeInTheDocument();
    });
});
''',
    "views/atoms/Spinner/Spinner.stories.tsx": r'''import type { Meta, StoryObj } from '@storybook/react-vite';

import { Spinner } from './Spinner';

const meta = {
    title: 'Atoms/Spinner',
    component: Spinner,
} satisfies Meta<typeof Spinner>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {};

export const Large: Story = { args: { className: 'size-8' } };
''',
    "views/atoms/Spinner/index.ts": r'''export { Spinner } from './Spinner';
export type { SpinnerProps } from './Spinner';
''',
    # --- Molecule: a small cluster of atoms with one job, pure ------------------
    "views/molecules/WidgetSummary/WidgetSummary.tsx": r'''// Molecule (REF-AtomicDesign section 2): one job
// (summarize one widget), composed of atoms only (section 4, a molecule composes
// atoms). Pure: props in, markup out (section 5); it neither fetches nor reads
// connected state.
import type { Widget } from '@/viewmodels/widgets/useWidgets';
import { StatusBadge } from '@/views/atoms/StatusBadge';

export interface WidgetSummaryProps {
    widget: Widget;
}

export const WidgetSummary = ({ widget }: WidgetSummaryProps) => (
    <div className="flex items-center justify-between border-b border-border/60 px-3 py-2 text-sm">
        <span>{widget.name}</span>
        <StatusBadge status={widget.status} />
    </div>
);
''',
    "views/molecules/WidgetSummary/WidgetSummary.test.tsx": r'''import { render, screen } from '@testing-library/react';
import { describe, expect, it } from 'vitest';

import { WidgetSummary } from './WidgetSummary';

describe('WidgetSummary', () => {
    it('shows the widget name and its status', () => {
        render(<WidgetSummary widget={{ id: 'ingest', name: 'Ingest', status: 'down' }} />);
        expect(screen.getByText('Ingest')).toBeInTheDocument();
        expect(screen.getByText('down')).toBeInTheDocument();
    });
});
''',
    "views/molecules/WidgetSummary/WidgetSummary.stories.tsx": r'''import type { Meta, StoryObj } from '@storybook/react-vite';

import { WidgetSummary } from './WidgetSummary';

const meta = {
    title: 'Molecules/WidgetSummary',
    component: WidgetSummary,
    args: { widget: { id: 'ingest', name: 'Ingest', status: 'healthy' } },
} satisfies Meta<typeof WidgetSummary>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {};
''',
    "views/molecules/WidgetSummary/index.ts": r'''export { WidgetSummary } from './WidgetSummary';
export type { WidgetSummaryProps } from './WidgetSummary';
''',
    # --- Organism: a self-contained section, composes molecules and atoms -------
    "views/organisms/WidgetPanel/WidgetPanel.tsx": r'''// Organism (REF-AtomicDesign section 2): a
// self-contained section, composed of molecules and atoms and a ui primitive
// (section 4, an organism composes its own level or below). Presentational here:
// it receives its data as props and the page owns acquisition (section 5). A
// connected organism MAY instead call its own ViewModel hook (REF-Frontend
// section 5); keep exactly one owner per data slice.
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import type { Widget } from '@/viewmodels/widgets/useWidgets';
import { Spinner } from '@/views/atoms/Spinner';
import { WidgetSummary } from '@/views/molecules/WidgetSummary';

export interface WidgetPanelProps {
    widgets: Widget[];
    loading: boolean;
    /** The last load's failure message; null when it succeeded. */
    error: string | null;
}

export const WidgetPanel = ({ widgets, loading, error }: WidgetPanelProps) => (
    <Card>
        <CardHeader>
            <CardTitle>Widgets</CardTitle>
        </CardHeader>
        <CardContent>
            {loading ? (
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Spinner /> Loading...
                </div>
            ) : error ? (
                <div className="text-sm text-destructive">{error}</div>
            ) : widgets.length === 0 ? (
                <div className="text-sm text-muted-foreground">No widgets.</div>
            ) : (
                widgets.map((widget) => <WidgetSummary key={widget.id} widget={widget} />)
            )}
        </CardContent>
    </Card>
);
''',
    "views/organisms/WidgetPanel/WidgetPanel.test.tsx": r'''import { render, screen } from '@testing-library/react';
import { describe, expect, it } from 'vitest';

import { WidgetPanel } from './WidgetPanel';

const WIDGETS = [{ id: 'ingest', name: 'Ingest', status: 'healthy' as const }];

describe('WidgetPanel', () => {
    it('lists the widgets it is handed', () => {
        render(<WidgetPanel widgets={WIDGETS} loading={false} error={null} />);
        expect(screen.getByText('Ingest')).toBeInTheDocument();
    });

    it('shows the spinner while loading', () => {
        render(<WidgetPanel widgets={[]} loading error={null} />);
        expect(screen.getByRole('status', { name: 'loading' })).toBeInTheDocument();
    });

    it('shows the error instead of the list', () => {
        render(<WidgetPanel widgets={WIDGETS} loading={false} error="Failed to load" />);
        expect(screen.getByText('Failed to load')).toBeInTheDocument();
        expect(screen.queryByText('Ingest')).not.toBeInTheDocument();
    });

    it('says so when there are no widgets', () => {
        render(<WidgetPanel widgets={[]} loading={false} error={null} />);
        expect(screen.getByText('No widgets.')).toBeInTheDocument();
    });
});
''',
    "views/organisms/WidgetPanel/WidgetPanel.stories.tsx": r'''import type { Meta, StoryObj } from '@storybook/react-vite';

import { WidgetPanel } from './WidgetPanel';

const meta = {
    title: 'Organisms/WidgetPanel',
    component: WidgetPanel,
    args: {
        widgets: [
            { id: 'ingest', name: 'Ingest', status: 'healthy' },
            { id: 'index', name: 'Index', status: 'degraded' },
            { id: 'search', name: 'Search', status: 'down' },
        ],
        loading: false,
        error: null,
    },
} satisfies Meta<typeof WidgetPanel>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Loaded: Story = {};

export const Loading: Story = { args: { widgets: [], loading: true } };

export const Failed: Story = { args: { widgets: [], error: 'Failed to load widgets' } };

export const Empty: Story = { args: { widgets: [] } };
''',
    "views/organisms/WidgetPanel/index.ts": r'''export { WidgetPanel } from './WidgetPanel';
export type { WidgetPanelProps } from './WidgetPanel';
''',
    # --- Template: page-level layout, slots only, no real data -----------------
    "views/templates/DashboardTemplate/DashboardTemplate.tsx": r'''// Template (REF-AtomicDesign section 2,
// section 6): the layout arrangement only, with slots and no real data (section 5,
// templates hold no data). A page fills the slots; the same template can back many
// pages.
import type { ReactNode } from 'react';

export interface DashboardTemplateProps {
    title: string;
    children: ReactNode;
}

export const DashboardTemplate = ({ title, children }: DashboardTemplateProps) => (
    <div className="min-h-screen bg-background text-foreground">
        <header className="border-b">
            <div className="mx-auto max-w-5xl px-4 py-3">
                <h1 className="text-lg font-semibold">{title}</h1>
            </div>
        </header>
        <main className="mx-auto max-w-5xl px-4 py-4">{children}</main>
    </div>
);
''',
    "views/templates/DashboardTemplate/DashboardTemplate.test.tsx": r'''import { render, screen } from '@testing-library/react';
import { describe, expect, it } from 'vitest';

import { DashboardTemplate } from './DashboardTemplate';

describe('DashboardTemplate', () => {
    it('fills its slots with what the page hands it', () => {
        render(
            <DashboardTemplate title="Status">
                <p>content</p>
            </DashboardTemplate>,
        );
        expect(screen.getByRole('heading', { name: 'Status' })).toBeInTheDocument();
        expect(screen.getByText('content')).toBeInTheDocument();
    });
});
''',
    "views/templates/DashboardTemplate/DashboardTemplate.stories.tsx": r'''import type { Meta, StoryObj } from '@storybook/react-vite';

import { DashboardTemplate } from './DashboardTemplate';

const meta = {
    title: 'Templates/DashboardTemplate',
    component: DashboardTemplate,
    parameters: { layout: 'fullscreen' },
    args: {
        title: '__TITLE__',
        children: <div className="h-32 rounded-lg border border-dashed" />,
    },
} satisfies Meta<typeof DashboardTemplate>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {};
''',
    "views/templates/DashboardTemplate/index.ts": r'''export { DashboardTemplate } from './DashboardTemplate';
export type { DashboardTemplateProps } from './DashboardTemplate';
''',
    # --- Page: one per route, owns data, fills a template ----------------------
    "views/pages/DashboardPage/DashboardPage.tsx": r'''// Page (REF-AtomicDesign section 2, section 6):
// a concrete route instance. It owns data acquisition (section 5) by calling the
// ViewModel hook, then fills the template and passes the data down to organisms as
// props. This is the connection point; every level below it stays pure. A router
// lazy-loads it by mapping this named export (REF-Frontend section 7).
import { useWidgets } from '@/viewmodels/widgets/useWidgets';
import { WidgetPanel } from '@/views/organisms/WidgetPanel';
import { DashboardTemplate } from '@/views/templates/DashboardTemplate';

export const DashboardPage = () => {
    const { widgets, loading, error } = useWidgets();

    return (
        <DashboardTemplate title="__TITLE__">
            <WidgetPanel widgets={widgets} loading={loading} error={error} />
        </DashboardTemplate>
    );
};
''',
    "views/pages/DashboardPage/DashboardPage.test.tsx": r'''import { render, screen } from '@testing-library/react';
import { describe, expect, it } from 'vitest';

import { DashboardPage } from './DashboardPage';

describe('DashboardPage', () => {
    it('fills the template with what the ViewModel hook returns', async () => {
        render(<DashboardPage />);
        expect(screen.getByRole('heading', { name: '__TITLE__' })).toBeInTheDocument();
        expect(await screen.findByText('Ingest')).toBeInTheDocument();
    });
});
''',
    "views/pages/DashboardPage/index.ts": r'''export { DashboardPage } from './DashboardPage';
''',
}


def _render(text: str, title: str, src_dir: str) -> str:
    return text.replace("__TITLE__", title).replace("__SRC_DIR__", src_dir)


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Lay an Atomic-Design views/ tree backed by shadcn/ui onto a React project."
    )
    parser.add_argument("--root", required=True, help="Project root directory (holds components.json).")
    parser.add_argument("--src-dir", default="src", help="Source directory under the root (default: src).")
    parser.add_argument("--title", default="Dashboard", help="Page/template title (default: Dashboard).")
    args = parser.parse_args()

    root = Path(args.root).resolve()
    if not root.is_dir():
        parser.error(f"--root '{root}' is not an existing directory")
    src = root / args.src_dir

    written = 0
    skipped = 0
    for rel, content in ROOT_FILES.items():
        dest = root / rel
        if dest.exists():
            skipped += 1
            continue
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_text(_render(content, args.title, args.src_dir), encoding="utf-8", newline="\n")
        written += 1
    for rel, content in SRC_FILES.items():
        dest = src / rel
        if dest.exists():
            skipped += 1
            continue
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_text(_render(content, args.title, args.src_dir), encoding="utf-8", newline="\n")
        written += 1

    print(f"Scaffolded Atomic-Design views into {src}: {written} files written, {skipped} skipped.")
    print("Prerequisites: React + TypeScript + Tailwind, the shadcn tokens in index.css,")
    print("and the `@` -> source-dir path alias.")
    print("Next: npx shadcn@latest add card badge (it writes components/ui/ and the")
    print("cn() helper at the utils alias), then run the project's build and test.")


if __name__ == "__main__":
    main()
