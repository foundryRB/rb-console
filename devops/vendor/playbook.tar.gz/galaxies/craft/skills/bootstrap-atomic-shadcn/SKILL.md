---
name: bootstrap-atomic-shadcn
description: "Scaffold an Atomic-Design views/ tree (atoms, molecules, organisms, templates, pages) backed by shadcn/ui primitives onto a React + Tailwind project, one exemplar per level demonstrating the composition ladder and purity gradient of REF-AtomicDesign; additive to an existing project, distinct from the whole-project bootstrap-react-mvvm."
galaxy: craft
refs:
  - REF-AtomicDesign
  - REF-Frontend
  - REF-React
---

# Bootstrap atomic shadcn

Invoked when an existing React + TypeScript + Tailwind project needs an Atomic-Design
View layer backed by shadcn/ui: the five level folders (`atoms/`, `molecules/`,
`organisms/`, `templates/`, `pages/`) with one exemplar each, every exemplar a component
folder with its test, story, and barrel (`REF-Frontend.md` section 9), a placeholder
ViewModel hook marking the connection point, and the `components.json` the shadcn CLI reads. The
`components/ui/` primitives those atoms wrap, and the `cn()` helper at the `utils`
alias, are the CLI's own output (`REF-Frontend.md` section 2: `components/ui` is
toolchain output, never hand-written), so a Step below runs `npx shadcn@latest add
card badge` for the two this slice imports.

It is **additive**: it drops the taxonomy onto a project that already exists, distinct
from `bootstrap-react-mvvm`, which scaffolds a whole Vite project with a generated Model
layer. Reach for this skill when the project (and its ViewModels) are already there and
only the View structure is missing, or to re-anchor a drifting `views/` tree on the
ladder.

The exemplars are a teaching slice, not the final UI: they show the levels, the
composition ladder, and the purity gradient, and are meant to be renamed and refitted
to the engagement's real domain (the placeholder ViewModel hook especially).

## Pre-flight

1. **Read** `REF-AtomicDesign.md` (the level ladder in section 2, the classification test in
   section 3, the composition ladder in section 4, the purity gradient in section 5, and
   the level-is-folder rule in section 7), `REF-Frontend.md` section 9 (one folder per
   component), `REF-Frontend.md` section 5 (the React/SAM
   delta: the connection point is a ViewModel hook, called only by pages and connected
   organisms), and `REF-Frontend.md` section 2 (the layer table: `components/ui` is
   shadcn toolchain output, domain-unaware, never hand-written). The scaffold
   instantiates them; do not restate their rules in the code.
2. **Confirm the target is a React + TypeScript + Tailwind project** that already has the
   shadcn design tokens in its CSS (the `--background`, `--primary`, `--card`, ... HSL
   variables) and maps the `@` path alias to its source directory. `bootstrap-react-mvvm`
   produces exactly this shape; a bare Vite React project needs Tailwind and the tokens
   added first. This skill adds the View taxonomy, not the toolchain.
3. **Confirm with user** (or, headless, take the defaults and record the call):
   - Project root (holds `components.json`) and the source directory (default `src`).
   - Page/template title (default `Dashboard`).
4. **Do not force a whole-project scaffold**: if there is no project yet, run
   `bootstrap-react-mvvm` first (it already lays an Atomic-Design tree); this skill is for
   adding or realigning the View layer on an existing one.

## Steps

Run the helper at `<this-skill>/bootstrap.py`:

```bash
python bootstrap.py --root <project-dir> [--src-dir src] [--title "Dashboard"]
```

It writes `components.json` at the root and, under the source directory, a
placeholder `viewmodels/widgets/useWidgets.ts` (the connection point) and one exemplar
per level:

| Component folder | Level | Composes | Data / state (`REF-AtomicDesign.md` section 5) |
| ---------------- | ----- | -------- | ---------------------------------------------- |
| `views/atoms/StatusBadge/` | Atom | a shadcn `Badge` primitive | Props only, pure |
| `views/atoms/Spinner/` | Atom | primitives | Props only, pure |
| `views/molecules/WidgetSummary/` | Molecule | atoms | Props only, pure |
| `views/organisms/WidgetPanel/` | Organism | molecules, atoms, a `Card` primitive | Presentational; fed by the page |
| `views/templates/DashboardTemplate/` | Template | organisms (as slots) | Layout only, no data |
| `views/pages/DashboardPage/` | Page | a template + data | Owns data (calls the ViewModel hook) |

Each folder holds `<Name>.tsx`, `<Name>.test.tsx`, `<Name>.stories.tsx` (not in
`pages/`), and an `index.ts` barrel (`REF-Frontend.md` section 9.2). Existing files are
skipped, so a re-run is safe. Then:

1. **Install the primitives the slice imports with the shadcn CLI**, from the project
   root:

   ```bash
   npx shadcn@latest add card badge
   ```

   It reads the `components.json` the scaffolder wrote, writes `components/ui/` and the
   `cn()` helper at the `utils` alias (`@/utils`, so `src/utils.ts` per
   `REF-Frontend.md` section 1 - no `lib/`; a project that already has one keeps it),
   and pulls `clsx`, `tailwind-merge`, and `class-variance-authority`. This is the only
   source of `components/ui/` content: it is the primitive layer, toolchain output,
   never hand-written (`REF-AtomicDesign.md` section 2, `REF-Frontend.md` section 2).
   Add further primitives the same way as the UI grows.
2. **Render the exemplar** through the route (mount `DashboardPage`, or wire it to the
   router) to confirm the tokens, the `@` alias, and Tailwind resolve.
3. **Customize in the atoms, not in `components/ui/`**: the exemplar `StatusBadge` shows
   the seam, wrapping the `Badge` primitive and mapping a domain status onto its
   variants. Variants and domain meaning belong to the atom, look belongs to the design
   tokens (`REF-Design.md` section 2), and a change no wrapper can reach is authored as
   a hand-written atom in `views/atoms/` rather than edited into `components/ui/`
   (`REF-AtomicDesign.md` section 2). That keeps `npx shadcn@latest add` re-runnable.
4. **Refit the slice to the domain**: rename the `widgets` example (the `Widget` type, the
   `useWidgets` hook, and the `StatusBadge` / `WidgetSummary` / `WidgetPanel` /
   `DashboardPage` slice) to the engagement's entities, and replace the placeholder hook
   with the project's real ViewModel (`REF-Frontend.md` section 4). Keep the connection
   point at the page and connected organisms only; everything below stays pure.
5. **Run the project's build and tests** (the repo's conformance) and confirm green. The
   tests assert with `toBeInTheDocument()`, so they need the project's vitest harness to
   carry `@testing-library/react` and `@testing-library/jest-dom`, with jest-dom
   imported from the vitest `setupFiles` entry and listed in the tsconfig `types` (the
   shape `bootstrap-react-mvvm` scaffolds, in its `src/test-setup.ts`). The stories need
   the project's Storybook (`REF-Frontend.md` section 5.1, which `bootstrap-react-mvvm`
   ships). Add the harness and Storybook first on a project that lacks them: a component
   folder without its test or story breaks section 9.

## Failure modes

- **No project yet**: this skill is additive; scaffold the project with
  `bootstrap-react-mvvm` first, then run this to add or realign the View layer.
- **Missing tokens or `@` alias**: components render unstyled or imports fail to resolve;
  add the shadcn HSL token block to the project CSS and map `@` to the source directory
  (pre-flight step 2) before running the build.
- **A target file already exists**: it is skipped (idempotent); a re-run never
  overwrites hand-authored views. Delete a stale file first if you want it regenerated.
- **A component lands in the wrong folder**: level is a function of composition, not size
  (`REF-AtomicDesign.md` section 3); reclassify by moving the component folder, not
  renaming it.
- **`@/components/ui/...` or `@/utils` fails to resolve**: the shadcn CLI step has not
  run (or ran before `components.json` existed). Run `npx shadcn@latest add card badge`
  from the project root, where `components.json` sits.
