#!/usr/bin/env python3
"""Apply a reusable Intent Bundle to a target Python project.

Reads a bundle from <bundles-root>/<topic>/, applies its declared
dependencies recursively, merges intent.yaml claims into the target, copies
test files, and (when the bundle ships a templates/ folder) copies those page
templates into the target's templates/. Idempotent. Refuses to overwrite
mismatched content.

The bundles live beside this script, in bundles/: they are part of the skill,
so wherever the skill is installed (a workstation, a delivery pod) the bundles
are there with it, and no other checkout is needed. --bundles-root reads a
different set from disk, for developing a bundle before it lands here.

Target project must have the matching intent runtime installed: pytest targets
are verified by tests/test_meta.py importing from pytest_intent; vitest targets
by @psa-department-of-engineering/vitest-intent declared in package.json
devDependencies.

Usage:
    python apply.py --bundle <topic> --target <project-path> [--dry-run] [--no-deps]
"""

from __future__ import annotations

import argparse
import json
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path

try:
    import yaml  # type: ignore[import-untyped]
except ImportError:
    sys.exit("PyYAML required. pip install pyyaml")

VITEST_INTENT_PACKAGE = "@psa-department-of-engineering/vitest-intent"


__all__ = ["main", "apply_bundle"]


class BundleError(Exception):
    """Any failure during bundle application."""


def _find_bundles_root() -> Path:
    """The bundles that ship with this skill: bundles/ beside this script.

    Resolved from __file__ on purpose: the skill and its bundles travel together
    (the master checkout, the runtime copy under a user's skills directory, a
    delivery pod's install), so the bundles are wherever this script is.
    """
    root = Path(__file__).resolve().parent / "bundles"
    if not root.is_dir():
        raise BundleError(
            f"this skill's bundles are missing at {root} - the install is incomplete "
            f"(reinstall the skill, or pass --bundles-root to read a set from disk)"
        )
    return root


def _load_bundle_meta(bundles_root: Path, name: str) -> dict[str, object]:
    bundle_dir = bundles_root / name
    if not bundle_dir.is_dir():
        raise BundleError(f"bundle not found: {bundle_dir}")
    meta_path = bundle_dir / "bundle.yaml"
    if not meta_path.is_file():
        raise BundleError(f"bundle missing bundle.yaml: {meta_path}")
    return yaml.safe_load(meta_path.read_text(encoding="utf-8")) or {}


def _verify_target_has_pytest_intent(target: Path) -> None:
    test_meta = target / "tests" / "test_meta.py"
    if not test_meta.is_file():
        raise BundleError(
            f"target has no tests/test_meta.py - run bootstrap-pytest-intent first.\n"
            f"  expected: {test_meta}"
        )
    body = test_meta.read_text(encoding="utf-8")
    if "pytest_intent" not in body:
        raise BundleError(
            "target's tests/test_meta.py exists but doesn't import pytest_intent - "
            "this isn't a pytest-intent project."
        )


def _detect_target_runner(target: Path) -> str:
    """Best-effort detection of the test runner used by the target project.

    Returns one of: "pytest", "vitest", "jest", "unknown".
    Caller may override with --runner.
    """
    if (target / "pyproject.toml").is_file() or (target / "setup.py").is_file():
        return "pytest"
    pkg = target / "package.json"
    if pkg.is_file():
        try:
            text = pkg.read_text(encoding="utf-8").lower()
        except OSError:
            text = ""
        if "vitest" in text:
            return "vitest"
        if "jest" in text:
            return "jest"
    return "unknown"


def _verify_target_runtime(target: Path, runner: str) -> None:
    """Each runner has its own runtime requirement. Verify before applying."""
    if runner == "pytest":
        _verify_target_has_pytest_intent(target)
    elif runner == "vitest":
        _verify_target_has_vitest_intent(target)
    elif runner == "jest":
        raise BundleError(
            "jest runner not yet supported. No jest-intent analog exists yet; "
            "extend _verify_target_runtime when shipping the first jest bundle."
        )
    else:
        raise BundleError(f"unsupported runner: {runner}")


def _verify_target_has_vitest_intent(target: Path) -> None:
    """Verify the target has vitest-intent wired up.

    Check: package.json declares @psa-department-of-engineering/vitest-intent in
    devDependencies - the vitest mirror of the pytest-intent verification.
    vitest-intent ships only the intent() marker; schema + coverage auditing live
    in the standalone csd-intent CLI, so the dependency declaration is the whole
    runtime contract.
    """
    pkg = target / "package.json"
    if not pkg.is_file():
        raise BundleError(
            f"target has no package.json - this isn't a Node/JS project.\n"
            f"  expected: {pkg}"
        )
    try:
        pkg_data = json.loads(pkg.read_text(encoding="utf-8"))
    except json.JSONDecodeError as e:
        raise BundleError(f"target's package.json is not valid JSON: {e}")
    dev_deps = pkg_data.get("devDependencies") if isinstance(pkg_data, dict) else None
    if not isinstance(dev_deps, dict) or VITEST_INTENT_PACKAGE not in dev_deps:
        raise BundleError(
            f"target's package.json devDependencies don't declare {VITEST_INTENT_PACKAGE}.\n"
            f"  add it: npm install --save-dev {VITEST_INTENT_PACKAGE}"
        )


def _impl_dir_for(bundle_dir: Path, runner: str) -> Path:
    return bundle_dir / "impls" / runner


def _target_tests_dir_for(target: Path, runner: str) -> Path:
    """Where to copy impls into, per runner convention."""
    # All currently-supported runners use the `tests/` convention. JS projects sometimes
    # use `__tests__/` instead; if a project standardises on that, override via runner-specific
    # logic here (or detect from project config).
    return target / "tests"


def _resolve_dependency_order(
    bundles_root: Path,
    name: str,
    visiting: set[str] | None = None,
    resolved: list[str] | None = None,
) -> list[str]:
    """Topological sort of bundle dependencies. Detects cycles."""
    if visiting is None:
        visiting = set()
    if resolved is None:
        resolved = []
    if name in resolved:
        return resolved
    if name in visiting:
        raise BundleError(f"cycle detected in bundle dependencies at: {name}")
    visiting.add(name)
    meta = _load_bundle_meta(bundles_root, name)
    requires = meta.get("requires") or []
    if not isinstance(requires, list):
        raise BundleError(f"bundle {name}: bundle.yaml `requires` must be a list")
    for dep in requires:
        _resolve_dependency_order(bundles_root, str(dep), visiting, resolved)
    visiting.discard(name)
    if name not in resolved:
        resolved.append(name)
    return resolved


def _parse_yaml_claims(text: str) -> dict[str, dict[str, object]]:
    """Parse intent.yaml-style content. Returns {INT-XXX: {field: value}}."""
    if not text.strip():
        return {}
    raw = yaml.safe_load(text) or {}
    if not isinstance(raw, dict):
        return {}
    return {k: v for k, v in raw.items() if isinstance(k, str) and k.startswith("INT-") and isinstance(v, dict)}


def _merge_intent_yaml(bundle_dir: Path, target_intent: Path, bundle_meta: dict[str, object], dry_run: bool) -> tuple[int, list[str]]:
    """Merge bundle's intent.yaml claims into target's intent.yaml.

    Returns (added_count, collisions). Collisions = bundle IDs that already exist
    in target with DIFFERENT content; raises BundleError if any.
    """
    bundle_intent = bundle_dir / "intent.yaml"
    if not bundle_intent.is_file():
        return 0, []
    bundle_text = bundle_intent.read_text(encoding="utf-8")
    bundle_claims = _parse_yaml_claims(bundle_text)
    if not bundle_claims:
        return 0, []

    if target_intent.exists():
        existing_text = target_intent.read_text(encoding="utf-8")
        existing_claims = _parse_yaml_claims(existing_text)
    else:
        existing_text = ""
        existing_claims = {}

    collisions: list[str] = []
    new_ids: list[str] = []
    for cid, claim in bundle_claims.items():
        if cid in existing_claims:
            if existing_claims[cid] != claim:
                collisions.append(cid)
        else:
            new_ids.append(cid)

    if collisions:
        raise BundleError(
            "claim ID collisions (already in target with different content): "
            + ", ".join(collisions)
        )

    if not new_ids:
        return 0, []

    if dry_run:
        return len(new_ids), []

    name = str(bundle_meta.get("name", "?"))
    version = str(bundle_meta.get("version", "?"))
    timestamp = datetime.now(timezone.utc).isoformat(timespec="seconds")
    header = (
        f"\n\n# --- bundle: {name} v{version} (applied {timestamp}) ---\n"
    )
    appended = header + "\n".join(_serialize_claim(cid, bundle_claims[cid]) for cid in new_ids) + "\n"

    if not target_intent.exists():
        target_intent.write_text(appended.lstrip("\n"), encoding="utf-8")
    else:
        with target_intent.open("a", encoding="utf-8") as f:
            f.write(appended)
    return len(new_ids), []


def _serialize_claim(cid: str, claim: dict[str, object]) -> str:
    """Render a claim as YAML block. Order: statement, rationale, criticality, scope, then the rest."""
    preferred = ["statement", "rationale", "criticality", "scope"]
    lines = [f"{cid}:"]
    for k in preferred:
        if k in claim:
            v = claim[k]
            lines.append(f"  {k}: {_yaml_scalar(v)}")
    for k, v in claim.items():
        if k in preferred:
            continue
        lines.append(f"  {k}: {_yaml_scalar(v)}")
    return "\n".join(lines)


def _yaml_scalar(v: object) -> str:
    if isinstance(v, str):
        if any(c in v for c in ":#\n"):
            escaped = v.replace('"', '\\"')
            return f'"{escaped}"'
        return v
    return str(v)


def _copy_impl(bundle_dir: Path, target: Path, runner: str, dry_run: bool) -> tuple[int, list[str]]:
    """Copy bundle's impls/<runner>/* into target's tests dir.

    Refuses to overwrite mismatched files. Idempotent on identical content.
    """
    bundle_impl = _impl_dir_for(bundle_dir, runner)
    if not bundle_impl.is_dir():
        return 0, []
    target_tests = _target_tests_dir_for(target, runner)
    target_tests.mkdir(parents=True, exist_ok=True)

    copied: list[str] = []
    conflicts: list[str] = []
    for src in bundle_impl.rglob("*"):
        if not src.is_file():
            continue
        rel = src.relative_to(bundle_impl)
        dst = target_tests / rel
        if dst.exists():
            if dst.read_bytes() != src.read_bytes():
                conflicts.append(str(rel))
                continue
        else:
            if not dry_run:
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(src, dst)
            copied.append(str(rel))

    if conflicts:
        raise BundleError(
            "impl file conflicts (target has different content): " + ", ".join(conflicts)
        )

    return len(copied), copied


def _copy_templates(bundle_dir: Path, target: Path, dry_run: bool) -> tuple[int, list[str]]:
    """Copy bundle's templates/* into target's templates/ directory.

    Templates are runner-agnostic page scaffolds (e.g. Starlight doc templates) shipped
    alongside a bundle. When the bundle has a templates/ folder, applying it also drops
    those files into the target at templates/ (created if missing).

    The path is relative to --target, the project root, exactly as intent.yaml and the
    tests dir are. For a Starlight site --target is the docs project itself (the folder
    holding its intent.yaml and package.json), so its templates land beside them.

    Refuses to overwrite mismatched files. Idempotent on identical content. Mirrors the
    refuse-to-overwrite-with-different-content safety of _copy_impl.
    """
    bundle_templates = bundle_dir / "templates"
    if not bundle_templates.is_dir():
        return 0, []
    target_templates = target / "templates"
    target_templates.mkdir(parents=True, exist_ok=True)

    copied: list[str] = []
    conflicts: list[str] = []
    for src in bundle_templates.rglob("*"):
        if not src.is_file():
            continue
        rel = src.relative_to(bundle_templates)
        dst = target_templates / rel
        if dst.exists():
            if dst.read_bytes() != src.read_bytes():
                conflicts.append(str(rel))
                continue
        else:
            if not dry_run:
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(src, dst)
            copied.append(str(rel))

    if conflicts:
        raise BundleError(
            "template file conflicts (target has different content): " + ", ".join(conflicts)
        )

    return len(copied), copied


def apply_bundle(
    name: str,
    target: Path,
    bundles_root: Path | None = None,
    *,
    apply_deps: bool = True,
    dry_run: bool = False,
    runner: str | None = None,
) -> dict[str, object]:
    """Apply a single bundle (and its deps) to a target. Returns a report dict.

    bundles_root: explicit bundles root. If None, the bundles that ship with
    this skill (see _find_bundles_root).
    runner: explicit override for which `impls/<runner>/` to copy. If None, detect
    from target. Bundle must declare the chosen runner in `supported_runners`.
    """
    if not target.is_dir():
        raise BundleError(f"target is not a directory: {target}")

    if bundles_root is None:
        bundles_root = _find_bundles_root()

    if apply_deps:
        order = _resolve_dependency_order(bundles_root, name)
    else:
        order = [name]

    target_intent = target / "intent.yaml"
    report: dict[str, object] = {"applied": [], "dry_run": dry_run}

    detected_runner = runner or _detect_target_runner(target)

    for bundle_name in order:
        bundle_dir = bundles_root / bundle_name
        meta = _load_bundle_meta(bundles_root, bundle_name)

        supported = meta.get("supported_runners") or []
        if not isinstance(supported, list) or not supported:
            raise BundleError(
                f"bundle {bundle_name}: bundle.yaml must declare a non-empty `supported_runners` list"
            )
        if detected_runner == "unknown":
            raise BundleError(
                f"could not detect target runner; pass --runner explicitly. "
                f"bundle {bundle_name} supports: {supported}"
            )
        if detected_runner not in supported:
            raise BundleError(
                f"bundle {bundle_name} does not support runner '{detected_runner}' "
                f"(supports: {supported}). Pass a different --runner or extend the bundle."
            )

        _verify_target_runtime(target, detected_runner)

        added, _ = _merge_intent_yaml(bundle_dir, target_intent, meta, dry_run)
        copied_count, copied_names = _copy_impl(bundle_dir, target, detected_runner, dry_run)
        templates_count, template_names = _copy_templates(bundle_dir, target, dry_run)
        report["applied"].append(
            {
                "name": bundle_name,
                "version": meta.get("version", "?"),
                "runner": detected_runner,
                "claims_added": added,
                "impl_files_copied": copied_count,
                "files_copied": copied_names,
                "template_files_copied": templates_count,
                "templates_copied": template_names,
            }
        )

    return report


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--bundle", required=True, help="bundle name (a folder under this skill's bundles/)")
    ap.add_argument("--target", type=Path, required=True, help="target project root")
    ap.add_argument("--bundles-root", type=Path, default=None,
                    help="read bundles from this directory instead of the ones that ship "
                         "with the skill (for developing a bundle)")
    ap.add_argument("--dry-run", action="store_true", help="print what would happen; modify nothing")
    ap.add_argument("--no-deps", action="store_true", help="skip applying `requires:` bundles")
    ap.add_argument("--runner", default=None,
                    help="override target runner detection (pytest|vitest|jest)")
    args = ap.parse_args()

    try:
        report = apply_bundle(
            name=args.bundle,
            target=args.target,
            bundles_root=args.bundles_root,
            apply_deps=not args.no_deps,
            dry_run=args.dry_run,
            runner=args.runner,
        )
    except BundleError as e:
        print(f"error: {e}", file=sys.stderr)
        return 1

    prefix = "[DRY RUN] " if args.dry_run else ""
    print(f"{prefix}Applied {len(report['applied'])} bundle(s) to {args.target}:")
    for entry in report["applied"]:
        print(
            f"  {entry['name']} v{entry['version']} ({entry['runner']}): "
            f"+{entry['claims_added']} claim(s), +{entry['impl_files_copied']} impl file(s), "
            f"+{entry['template_files_copied']} template file(s)"
        )
        for f in entry["files_copied"]:
            print(f"    + tests/{f}")
        for f in entry["templates_copied"]:
            print(f"    + templates/{f}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
