# STARLIGHT bundle

Reusable Intent Bundle for [Starlight](https://starlight.astro.build/) (Astro) documentation sites. Enforces content-collection conventions and generic page structure on every doc page, and keeps the Module page, the low-level design of one bounded context, whole and fresh.

## What it covers

### Frontmatter and content collection

| ID | Claim | Criticality |
|---|---|---|
| INT-STARLIGHT-001 | Every doc has a non-empty `title` | critical |
| INT-STARLIGHT-002 | Every doc has a non-empty `id` | critical |
| INT-STARLIGHT-003 | Doc `id` values are unique across the collection | critical |
| INT-STARLIGHT-004 | Every doc has `type` ∈ {Overview, Guide, Standard, Reference, Template, Intent, Flow, Module} | high |
| INT-STARLIGHT-005 | Every doc has `status` ∈ {Draft, Active, Deprecated} | high |
| INT-STARLIGHT-006 | Every doc has `updated` formatted as YYYY-MM-DD | high |

### Page structure

These claims read each page's body (the markdown after the frontmatter) and are deliberately lenient so well-formed docs across different sites pass.

| ID | Claim | Criticality |
|---|---|---|
| INT-STARLIGHT-007 | Every page has connective intro prose, not pure scaffolding; a leading navigation or onward-links block (heading plus link list) and a leading bold-only line are tolerated | high |
| INT-STARLIGHT-008 | Every page contains at least one level-2 heading | medium |
| INT-STARLIGHT-009 | A `type: Flow` page contains a Mermaid `sequenceDiagram` and a steps section (a `## Steps` heading OR an ordered list) | high |
| INT-STARLIGHT-010 | A `type: Guide` page contains a numbered procedure (an ordered list OR at least two headings beginning with a number) | medium |
| INT-STARLIGHT-011 | Internal markdown link targets are relative to the current page: no root-absolute (`/...`) link or image targets in prose; code blocks exempt | high |
| INT-STARLIGHT-012 | A `type: Module` page carries the three viewpoints Business, Functional and Technical (level-2 headings or tab labels) and a Mermaid `classDiagram` or `erDiagram` of its domain model | high |
| INT-STARLIGHT-013 | Outside `decisions/`, no page's prose names an ADR identifier (any case, three or four digits) or links an individual decision page (markdown link, reference-style definition or `href`); a link to the collection itself is allowed; code and MDX comments exempt | high |
| INT-STARLIGHT-014 | A `type: Module` page carries a `Failure modes` part and a `Claims realised` part, each a heading (level 2 to 4) of that name; code and MDX comments exempt | high |
| INT-STARLIGHT-015 | Every claim id a `type: Module` page cites under `Claims realised` is an `active` claim in the application's `intent.yaml` (see below); an absent, `draft` or `deprecated` id fails the page | high |

The type enum (INT-STARLIGHT-004) allows {Overview, Guide, Standard, Reference, Template, Intent, Flow, Module}: Template and Intent match REF-Documentation 7.3, Flow covers sequence-diagram pages, and Module covers one bounded context's page in the application documentation set (REF-Documentation 7.11). INT-STARLIGHT-013 is that set's site-wide rule: the why stays in the decisions collection. The set's target-only rule (REF-Documentation 7.9) is a reviewer's read, not a claim: no word list tells behaviour from unfinished work.

The Module page is the module's low-level design (LLD), and it holds five things: what the module is, its contract, its structure, its failure modes and the claims it realises. INT-STARLIGHT-012 holds the first three in place (the viewpoints and the drawn model) and INT-STARLIGHT-014 the last two (a `Failure modes` heading: how the module fails and what its caller sees; a `Claims realised` heading: the intent claim ids the module realises). The page stays true by derivation where derivable (REF-Documentation 7.10) and by a freshness gate where not: INT-STARLIGHT-015 reads every id under `Claims realised` against the application's `intent.yaml`.

### What INT-STARLIGHT-015 reads

The suite runs inside the docs project, whose own `intent.yaml` holds this bundle's claims; the application's claims live in a file outside it. The claim locates that file by one rule with one override:

| The application's `intent.yaml` | How it is found |
|---|---|
| default | the nearest `intent.yaml` in a directory above the docs project (`../intent.yaml` for a site at `<app>/docs/`) |
| `APP_INTENT_YAML` set | that file; a relative value resolves from the docs project root |

A cited id is every `INT-...` token in the section the `Claims realised` heading opens. The section ends at the next heading of the same or a higher level, or at a closing `</TabItem>`, whichever comes first; sub-headings stay inside it. Inline code is read; fenced code and MDX comments are exempt. An id passes when the file holds a top-level claim of that id whose `status` is `active`; a claim with no `status` counts as active, as the CSD auditor reads it. The outcomes:

| Situation | Result |
|---|---|
| No Module page cites an id (a fresh scaffold, a site whose modules cite nothing) | passes, and no application file is read |
| An id is absent from the file, or its status is `draft` or `deprecated` | fails, naming the page, the id and the file |
| An id is cited and no application `intent.yaml` exists where the rule looks | fails, naming the page, the id and where it looked |

Base-safe linking (INT-STARLIGHT-011) exists because Astro's `base` prefixes generated navigation and asset URLs but never rewrites hand-written hrefs: a root-absolute internal link escapes the base path and 404s the moment the site serves under a portal prefix (`DOCS_BASE`).

## Runners

| Runner | Path |
|---|---|
| vitest | `impls/vitest/starlight.test.ts` |

Python+pytest impl: not yet shipped. A Starlight site is JS/TS, so pytest is the wrong runtime.

## Templates

The bundle ships generic, site-agnostic page skeletons under `templates/`. Each carries frontmatter placeholders and the required and recommended sections for its type, so a new page starts already conformant with the structure claims above.

| Template | Type | Required structure it seeds |
|---|---|---|
| `templates/overview.md` | Overview | Intro, `## At a glance` (mermaid), `## Read next` |
| `templates/guide.md` | Guide | Intro, `## Steps` ordered list, `## Verify`, `## Read next` |
| `templates/flow.md` | Flow | Intro, `## Sequence` (mermaid `sequenceDiagram`), `## Steps`, `## Read next` |
| `templates/reference.md` | Reference | Intro, a table section, `## Read next` |
| `templates/decisions-index.md` | Reference | Intro, `## Current`, `## Superseded` (prefer generated tables) |
| `templates/module.mdx` | Module | Intro, `<Tabs>` Business / Functional / Technical, the Technical tab leading with a mermaid `classDiagram` and closing with `### Failure modes` and `### Claims realised`, `## Read next` |

These are starting points, not enforced artifacts; the intent claims are what the suite checks.

## Apply

```bash
python ../../playbook/skills/apply-intent-bundle/apply.py \
  --bundle starlight \
  --target <path-to-starlight-project>
```

The target must already have:
- `package.json` with `@psa-department-of-engineering/vitest-intent` and `vitest` as devDependencies
- The Starlight content layout: `src/content/docs/`

The bundle's vitest impl (`impls/vitest/starlight.test.ts`) is a normal vitest test using `intent()` markers: vitest discovers it directly; schema + coverage auditing is the standalone `csd-intent` CLI's job (no in-suite meta-test needed). `bootstrap-starlight` Skill (default flags) creates that layout AND applies this bundle.

## Assumptions

- Docs live under `src/content/docs/` (Starlight default).
- Markdown files use YAML frontmatter delimited by `---`.
- The vitest test in `impls/vitest/starlight.test.ts` walks the docs directory at runtime, so it works whether the project has 1 or 1000 docs.
- The structure claims (007-010, 012-014) read the page body and are deliberately lenient: prose may live inside the first section, leading navigation blocks are tolerated, and Starlight splash pages (`template: splash`, which render from frontmatter `hero:`) are exempt from 007 and 008.
- INT-STARLIGHT-015 reads the application's `intent.yaml`, a file outside the docs project; "What INT-STARLIGHT-015 reads" above states how the suite locates it.

## Versioning

Manual SemVer in `bundle.yaml` for now. Once Git tracks the playbook, bumps come via Conventional Commits (`feat(starlight):` minor, `fix(starlight):` patch, `feat(starlight)!:` major).

## Changelog

### 0.5.0 - 2026-10-05
Names the Module page as the low-level design of its bounded context and completes it (REF-Documentation 7.11). New claims INT-STARLIGHT-014 (a Module page carries a `Failure modes` part and a `Claims realised` part) and INT-STARLIGHT-015 (every claim id cited under `Claims realised` is an `active` claim in the application's `intent.yaml`; a site citing nothing passes). `templates/module.mdx` seeds both parts in the Technical tab.

### 0.4.0 - 2026-09-27
Adds the application documentation set's shapes (REF-Documentation 7.11): the `Module` type in INT-STARLIGHT-004, INT-STARLIGHT-012 (a Module page carries the three viewpoints and a drawn domain model), INT-STARLIGHT-013 (no ADR identifier or individual-decision link outside `decisions/`), and the `templates/module.mdx` skeleton. Diagram detection for INT-STARLIGHT-009 and 012 reads fenced Mermaid blocks, so a diagram's name in prose is not a diagram.

### 0.3.0 - 2026-07-10
Adds base-safe linking. New claim INT-STARLIGHT-011: internal markdown link and image targets in prose must be relative (no root-absolute `/...` targets; code blocks exempt), because Astro's `base` never rewrites hand-written hrefs and a root-absolute link 404s under a portal prefix (`DOCS_BASE`).

### 0.2.0 - 2026-06-14
Adds generic page-structure enforcement. New claims INT-STARLIGHT-007 (intro prose before the first level-2 heading), INT-STARLIGHT-008 (at least one level-2 heading), INT-STARLIGHT-009 (Flow pages need a `sequenceDiagram` plus steps), and INT-STARLIGHT-010 (Guide pages need a numbered procedure). Expands the INT-STARLIGHT-004 type enum to {Overview, Guide, Standard, Reference, Template, Intent, Flow}. Ships generic page skeletons under `templates/`.

### 0.1.0 - 2026-04-26
Initial bundle. Six claims covering required frontmatter (title/id/type/status/updated), ID uniqueness, and `updated` date formatting.
