# Intent Bundles

Reusable, importable Intent Specifications + their enforcement tests, packaged together. See `REF-Intent-Bundle.md` for the contract.

They ship with the `apply-intent-bundle` skill, which applies them: wherever the skill is installed, a delivery pod included, the bundles are there with it.

## Bundles in this folder

| Bundle | Purpose | Supported runners | Applies to |
|---|---|---|---|
| `starlight` | Required frontmatter, ID format, canonical type/status, ISO-date validation for Starlight docs sites | `vitest` | `bootstrap-starlight` |

Bundles are extracted only when starter intent claims are shared across ≥2 bootstrap Skills, or when a claim set is genuinely reusable across non-bootstrapped projects. Don't speculate.
