---
name: apply-intent-bundle
description: Apply a reusable Intent Bundle to a target project. Bundles ship with this skill (its bundles/<topic>/ folder) and carry runner-specific impls (pytest, vitest, etc.). Merges intent.yaml claims, copies impls/<runner>/ files, respects bundle dependencies. Idempotent. Auto-detects target runner; --runner overrides. Target must have the matching intent runtime (pytest-intent for pytest, vitest-intent for vitest) installed.
galaxy: craft
refs:
  - REF-Intent-Bundle
  - REF-CSD
  - REF-Tests
---

# Apply Intent Bundle

Invoked when the user wants to compose a packaged Intent Bundle into a target project. Bundles ship claims + their enforcement together (see `REF-Intent-Bundle.md` for the shape).

## Pre-flight

1. **Read** `REF-Intent-Bundle.md` for the bundle contract.
2. **Identify the bundle** - `<topic>` = the bundle name (e.g. `starlight`, `pybase`). Lives in this skill's `bundles/<topic>/`.
3. **Identify the target project** - must have the matching intent runtime installed. Proxy check per runner: pytest - `tests/test_meta.py` exists and imports from `pytest_intent`; vitest - `package.json` declares `@psa-department-of-engineering/vitest-intent` in `devDependencies`.
4. **Check `bundle.yaml`** - verify `applies_to` includes the relevant Skill (when invoked from a bootstrap), or proceed if user invoked manually.

## What it does

1. **Loads `bundles/<topic>/bundle.yaml`** from this skill's own folder. Reads metadata (name, version, requires).
2. **Recursively applies any `requires:` bundles first.** Bundle dependency graph traversed in topological order. Cycle detection: fail with clear error if found.
3. **Merges `intent.yaml`** - appends bundle claims to target's `intent.yaml`. Collision check: if any `INT-<TOPIC>-NNN` already exists in target with a different definition, fail and report.
4. **Copies the impl** (`impls/<runner>/*`) to target's `tests/` directory. Refuses to overwrite an existing file with different content. Same-content overwrite (re-applying same bundle version) is a no-op.
5. **Copies `templates/*`** (when the bundle ships a `templates/` folder) into target's `templates/`, creating it if missing. The path is relative to `--target`, the project root, exactly as `intent.yaml` and the tests dir are; for a Starlight site `--target` is the docs project itself, so its templates land beside them. Same refuse-to-overwrite-with-different-content safety as the impl copy; same-content re-apply is a no-op. Templates are runner-agnostic content, so this runs regardless of the detected runner.
6. **Records the application** - appends a comment to target's `intent.yaml` like `# Applied bundle <topic> v<version> on <ISO date>`.
7. **Reports** - what was merged, what was skipped, any collisions.

The operation is idempotent. Re-running with no changes = no-op.

## Steps

```bash
python apply.py --bundle <topic> --target <project-path>
```

Optional:
- `--dry-run` - print what would be done, don't modify anything.
- `--no-deps` - skip applying `requires:` bundles (use when dependencies are already applied or you want to apply individually).

## Skill chaining

Bootstrap Skills like `bootstrap-data-pack` and (future) `bootstrap-pybase-project` invoke this Skill at the end of their own scaffolding to compose the relevant bundle:

```
bootstrap-data-pack --target <path>
  → scaffolds the pack
  → invokes: apply-intent-bundle --bundle datapack --target <path>
```

The bootstrap is responsible for ensuring pytest-intent is installed first (typically by chaining `bootstrap-pytest-intent`).

## Failure modes

- **Bundle not found** - bundles ship with this skill (`bundles/` beside `apply.py`); `--bundles-root` reads a different set from disk. No `bundles/` beside the script → the install is incomplete: reinstall the skill. No `bundles/<topic>/` inside → fail with the expected bundle path.
- **Target lacks the runner's intent runtime** - pytest: `tests/test_meta.py` missing or doesn't import `pytest_intent` → run `bootstrap-pytest-intent` first; vitest: `package.json` `devDependencies` missing `@psa-department-of-engineering/vitest-intent` → run `bootstrap-vitest-intent` first.
- **Collision in claim IDs** (same `INT-<TOPIC>-NNN` exists with different content in target) → fail and report; bundle was already applied previously and has since changed; user must reconcile manually.
- **Cycle in `requires:` graph** → fail and report cycle.
- **`applies_to` mismatch** when invoked from a bootstrap → warn, proceed only if `--force` (defer; v0.2 behavior).

## Anti-patterns

- Inlining bundle content into a Skill instead of invoking this Skill. Always go through here for bundle application - it's the single mechanism that enforces collision detection, dependency ordering, idempotency, and audit trail.
- Manually copying bundle files into a project. Bypasses checks and is non-idempotent.
- Modifying a bundle's claims in the target project after application. The bundle is the source of truth; modify the bundle and re-apply.

## See also

- `REF-Intent-Bundle.md` - bundle shape, conventions, lifecycle
- `bootstrap-pytest-intent` Skill - must run first to wire pytest-intent into the project
- `REF-CSD.md` - the methodology bundles instantiate
