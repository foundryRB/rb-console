---
name: bootstrap-mcp-adapter
description: "Add an MCP inbound adapter to an existing hexagonal FastAPI backend: the tools-mirror-inbound-ports server module, streamable HTTP mounted on the same app, capability-derived tool registration, and a protocol-level integration test."
galaxy: craft
refs:
  - REF-MCP
  - REF-InboundAdapter
  - REF-CleanArchitecture
  - REF-FastAPI
---

# Bootstrap MCP adapter

Invoked when the user wants an existing hexagonal FastAPI backend to serve MCP so agents can call its use cases. Produces a third inbound door over the same core, per `REF-MCP.md`: no separate service, no wrapped HTTP calls, no mode branches.

## Pre-flight

1. **Read** `REF-MCP.md` (the pattern this skill instantiates) and skim `REF-InboundAdapter.md`, `REF-CleanArchitecture.md`.
2. **Confirm the target is hexagonal**: a composition root (container) building use cases behind inbound ports, and an app factory that mounts routers. If not, run `bootstrap-hexagonal-backend` first or refactor toward it.
3. **Inventory the inbound ports**: list every port the container exposes and mark which are wired in every composition versus capability-gated. This inventory IS the tool list.
4. **Confirm the SDK**: the official `mcp` Python package (`pip install mcp`, add to the project's dependencies).

## Steps

1. **Create the adapter module** at `<package>/adapters/inbound/mcp/server.py` exposing one builder:

   ```python
   def build_mcp_server(container: Container) -> FastMCP:
       server = FastMCP(
           "<app-name>",
           instructions="<one paragraph an agent reads before using the tools>",
           streamable_http_path="/",
           stateless_http=True,
       )

       @server.tool()
       def get_entity(name: str) -> dict[str, object]:
           """One-line contract the agent reads."""
           return map_entity(container.get_entity().execute(name=name)).model_dump()

       # ...one tool per inbound port; capability-gated tools inside
       # `if container.<capability>_enabled:` blocks (REF-MCP section 5).
       return server
   ```

   Serialize through the same mappers/DTOs as the HTTP adapter; wrap gated-operation rejections in `ToolError` with the failure report embedded (`REF-MCP.md` §3).

2. **Mount it in the app factory** on the existing FastAPI app, and run the session manager in the lifespan:

   ```python
   mcp_server = build_mcp_server(container)
   app = FastAPI(..., lifespan=_lifespan(container, mcp_server))
   ...
   app.mount("/mcp", mcp_server.streamable_http_app())
   ```

   ```python
   @asynccontextmanager
   async def lifespan(app: FastAPI) -> AsyncIterator[None]:
       async with mcp_server.session_manager.run():
           yield
   ```

   Keep `streamable_http_path="/"` on the server so mounting at `/mcp` yields the public path `/mcp` (not `/mcp/mcp`).

3. **Auth**: if the app gates its surfaces (fail-closed HTTP Basic or similar), confirm the middleware covers the mounted `/mcp` path too; do not add an MCP-only scheme.

4. **Protocol-level integration test**: start the real app (uvicorn on an ephemeral port), connect with the SDK client, and assert the contract:

   ```python
   async with (
       streamable_http_client(f"{base_url}/mcp") as (read, write, _),
       ClientSession(read, write) as session,
   ):
       await session.initialize()
       tools = await session.list_tools()
   ```

   Cover at minimum: the tool list mirrors the wired ports (including the capability-gated subset per composition), one read tool returns real content, one gated write persists and one rejected write rolls back with the report in the tool error.

5. **Prompts, only where earned** (`REF-MCP.md` §9): wrap a recurring, multi-step, client-executed procedure as a `@server.prompt()` returning the runbook parametrized with live server facts (clients surface it as a slash command). Never wrap a single tool call. Most adapters ship zero prompts at first.

6. **Intent claims** (projects using CSD intent testing): claim that writes take the same gated path on every door, and that the tool list derives from the capability wiring; attest both from the protocol-level tests.

7. **Advertise the connection** where the instance lives (app docs site or registry), per `REF-MCP.md` §8: a `claude mcp add --scope user --transport http ...` one-liner with the instance URL, and, for an app with a UI, the in-app connect panel §8 describes, its route behind the UI's own gate. Never put instance URLs in this playbook.

## Failure modes

- **The target has no composition root** (use cases constructed ad hoc in routes): stop; the tool list cannot derive from wiring that does not exist. Refactor to a container first.
- **`/mcp/mcp` instead of `/mcp`**: the server's internal `streamable_http_path` was left at its default while also mounting under `/mcp`; set it to `/`.
- **421 Misdirected Request in production, tests green**: the SDK's DNS-rebinding protection admits localhost only by default, so the deployment's public hostname is rejected. Pass `transport_security=TransportSecuritySettings(allowed_hosts=[...])` fed from an env var the deployment config sets to its public Host value; leave it unset locally so the localhost default keeps protecting an unauthenticated dev server.
- **Still 421 after the deployment config sets the allowed host**: env vars loaded from a ConfigMap land only at container start, and a config-only chart change does not restart pods (the pod template is unchanged, so no rollout happens). Verify with `env` inside the pod, then restart the workload once (`kubectl rollout restart`), or give the chart a config-checksum pod annotation so config changes roll the deployment on their own.
- **Bare `/mcp` answers 405 in production, tests green**: a SPA `StaticFiles` mount at `/` matches `/mcp` before the router's implicit slash redirect can fire (tests have no built SPA, so the SDK client silently rode the redirect). Register an explicit method-preserving 307 route from `/mcp` to `/mcp/` before the mounts.
- **Tool calls hang or 500 at runtime but tests pass via TestClient**: the session manager is not running; it must be started in the app's lifespan (step 2), and TestClient without a context manager never runs lifespans, which is why the integration test uses a real server.
- **Agents receive bare "tool failed" on gated rejections**: the adapter is not embedding the failure report in the `ToolError`; agents need the reason to self-correct.
