---
domain: framework
---

# REF: FastAPI HTTP Adapter

> When asked to create or modify the HTTP inbound adapter (FastAPI), follow these rules strictly. This complements `REF-InboundAdapter.md` with FastAPI-specific patterns.

---

## 1. App Factory Pattern

The FastAPI application is created via a factory function in `app.py`:

```python
def create_app() -> FastAPI:
    """Create and configure the FastAPI application."""
    app = FastAPI(title="My App", version="0.1.0")
    register_exception_handler(app)
    app.include_router(system.router)
    app.include_router(orders.router, prefix="/orders", tags=["orders"])
    return app
```

Rules:
- **One `create_app()` factory** - never instantiate `FastAPI()` at module level.
- Register exception handlers before routers.
- Router prefix and tags declared here, not in the router file.

---

## 2. Dependency Injection via Container

The `Container` (composition root) is the **only** DI mechanism. FastAPI's `Depends()` delegates to it:

```python
_container: Container | None = None


def get_container(request: Request | None = None) -> Container:
    """Return the shared Container singleton."""
    global _container
    if _container is None:
        _container = Container()
    return _container
```

Rules:
- **No `Depends()` chains** for wiring use cases. The Container handles all wiring.
- Routes call `container.some_use_case()` to get a port instance, then call `execute()`.
- `Depends(get_container)` is the only injected dependency in route signatures.
- **Never** use FastAPI's `Depends()` to compose repositories, writers, or use cases.

---

## 3. Route Design

Each router file groups related endpoints. Routes are thin - they delegate to use cases immediately.

```python
router = APIRouter()


@router.get("/")
async def list_orders(
    container: Container = Depends(get_container),
) -> list[OrderResponse]:
    """List all orders."""
    use_case = container.list_orders()
    orders = use_case.execute()
    return [map_order_response(o) for o in orders]
```

Rules:
- Routes return **adapter DTOs** (Pydantic models), never domain objects.
- Routes call a **mapper function** to translate domain → DTO. Never `DTO.from_domain()`.
- One router file per resource group: `orders.py`, `payments.py`, `system.py`.
- **Return type annotation always declared** with the DTO type - FastAPI (≥0.89) builds the response model, validation, and OpenAPI schema from it, and the type checker reads the same declaration. `response_model=` is only for the rare route whose wire schema must diverge from its return annotation.
- **Async routes** by default (`async def`) when the call path is non-blocking. A synchronous use case that never blocks (in-memory work, quick CPU) still belongs in `async def` - a `def` handler costs a threadpool dispatch and caps concurrency at the pool size.
- **Sync routes** (`def`) when the use case performs blocking I/O (a synchronous DB driver, a blocking HTTP client). FastAPI runs `def` handlers in its threadpool; the same call inside `async def` stalls the event loop for every in-flight request.
- `async def` is **mandatory** when the handler needs the running loop - e.g. dispatching background work with `asyncio.create_task`, which raises from a threadpool thread.

---

## 4. DTOs (Pydantic Models)

DTOs live in `dtos/`, one class per file. They are **pure data containers** for HTTP serialization.

```python
class OrderResponse(BaseModel):
    """A summary of an order."""

    order_id: str
    status: str
    total: float
```

Rules:
- Inherit from `pydantic.BaseModel`.
- **No `from_domain()` or `to_domain()` methods.** DTOs don't know domain types exist.
- **No business logic.** Only field definitions and Pydantic validators.
- Request DTOs: `*Request` suffix. Response DTOs: `*Response` suffix.
- One class per file. File name matches class name in `snake_case`.

---

## 5. Mappers

Mappers live in `mappers/`, one file per mapping concern. They translate between domain and DTOs.

```python
def map_order_response(order: Order) -> OrderResponse:
    """Convert a domain order to an order response DTO."""
    return OrderResponse(
        order_id=order.order_id,
        status=order.status.value,
        total=order.calculate_total().amount,
    )
```

Rules:
- Mapper is a **function**, not a class - unless stateful conversion is needed.
- Import domain types under `TYPE_CHECKING` when possible.
- Import DTOs from `dtos/` - never define the DTO in the mapper file.
- One mapper file per mapping concern, not one per DTO.

---

## 6. Exception Handling

A single generic exception handler catches all `AppError` subclasses:

```python
def register_exception_handler(app: FastAPI) -> None:
    @app.exception_handler(AppError)
    async def _handle_engine_error(request: Request, exc: AppError) -> JSONResponse:
        status = STATUS_MAP.get(type(exc), DEFAULT_STATUS)
        return JSONResponse(
            status_code=status,
            content={"error": type(exc).__name__, "detail": str(exc)},
        )
```

Rules:
- The **handler is thin** - it only registers the mechanism.
- The **mapping dict** (`STATUS_MAP`) lives in `mappers/exception_mapper.py`.
- **Never** scatter individual `except` blocks per exception type.
- See `REF-ExceptionHandling.md` for the full status code mapping table.

---

## 7. Folder Structure

```
http/
├── __init__.py
├── app.py                           # create_app() factory
├── exception_handlers.py            # register_exception_handler() - thin
├── dtos/
│   ├── __init__.py
│   ├── error_response.py
│   ├── order_response.py
│   ├── create_order_request.py
│   └── ...                          # one class per file
├── mappers/
│   ├── __init__.py
│   ├── exception_mapper.py          # STATUS_MAP dict
│   └── order_mapper.py
└── routers/
    ├── __init__.py
    ├── system.py                    # health check, version
    ├── orders.py                    # list, detail, create
    └── payments.py                  # charge, refund
```

---

## 8. CORS & Middleware

Configure `CORSMiddleware` in the app factory when the frontend needs to call the API.

Rules:
- CORS origins come from environment/config, not hardcoded.
- Add middleware **before** registering routers.

---

## 9. OpenAPI Spec Export (MANDATORY)

> **The backend is the single source of truth for the API contract.** Frontend types are auto-generated from the OpenAPI spec that FastAPI produces. See `REF-Frontend.md` §6.1.

The spec is exported at build time, never fetched from a running server: `scripts/export_openapi.py` imports `create_app()` and writes `openapi.json` (no server, no port - it runs wherever CI does; `REF-Frontend.md` §6 refreshes the frontend's own copy from it). The exported spec is **committed**, and a committed copy nothing checks rots silently - so the export ships with its drift gate: the script's `--check` mode exits non-zero when the committed spec disagrees with the app, and an integration test fails the suite on the same comparison.

Rules:
- **The committed spec never drifts unnoticed** - `export_openapi.py --check` in CI and the drift test in the suite make staleness a red build, not a discipline.
- **Re-export and commit the diff on every route/DTO change** - the gate catches the forgotten export; it does not perform it.
- **Every route declares its response type** - the return annotation (or `response_model=` where the wire schema diverges from it); FastAPI builds the schema from that declaration.
- **A route with neither ships an untyped response in the spec**, and the frontend type generation degrades to `unknown` - fix the annotation.

---

## 10. Running

```bash
uvicorn <package>.adapters.inbound.http.app:create_app --factory --reload
```

---

## 11. Anti-Patterns

| #  | Anti-Pattern                                    | Correct Approach                            |
|----|-------------------------------------------------|---------------------------------------------|
| 1  | `Depends()` chains for use case wiring          | Use `Container` for all wiring              |
| 2  | `DTO.from_domain()` or `DTO.to_domain()`       | Separate mapper function in `mappers/`      |
| 3  | Domain type as the declared response type       | Return adapter DTO, mapped from domain      |
| 4  | Individual `except` blocks per exception type   | Single generic handler + mapping dict       |
| 5  | `FastAPI()` at module level                     | `create_app()` factory                      |
| 6  | Business logic in route handler                 | Delegate to use case via port               |
| 7  | Multiple DTOs in one file                       | One class per file in `dtos/`               |
| 8  | Inline status code mapping in handler           | `STATUS_MAP` in `mappers/exception_mapper.py`|
| 9  | Route with no declared response type            | Annotate the return type - the spec needs it |
| 10 | Committed OpenAPI spec with no drift gate       | `--check` in CI + the drift test (§9)        |

---

## 12. Skills that instantiate this REF

Generated by `scripts/sync_backlinks.py` from skill frontmatter; do not edit by hand.

Skills whose frontmatter `refs:` includes `REF-FastAPI`:

- `bootstrap-account-spine-python` - Add the account spine to an existing Python hexagonal FastAPI backend per REF-Identity: an opaque non-derived user id, an accounts table carrying the federation link, digest-only sessions, one session-resolution choke point, a guess budget, and the credential rung named explicitly with --rung (no default, because a scaffold that picks the rung is advocacy with a code generator attached).
- `bootstrap-hexagonal-backend` - Scaffold a new Python FastAPI service in hexagonal (ports and adapters) architecture, conforming to REF-CleanArchitecture / REF-FastAPI / REF-Python.
- `bootstrap-mcp-adapter` - Add an MCP inbound adapter to an existing hexagonal FastAPI backend: the tools-mirror-inbound-ports server module, streamable HTTP mounted on the same app, capability-derived tool registration, and a protocol-level integration test.
