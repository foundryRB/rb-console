---
domain: practice
---

# REF: Identity

> Read this when choosing how an application authenticates people: the selection is a pair (login rung plus recovery rung), and recovery is what decides it.

---

## 1. The selection is a pair

Two decisions, never one. A login rung and a recovery rung are chosen together, and **the account's real assurance is the weaker of the two**. Passkeys behind an emailed reset link is an AAL1 account wearing a passkey; the prohibition on phishable methods applies to recovery exactly as it applies to login, and offering password login beside passkeys is itself the exploitable path rather than a convenience.

"We will add reset later" is therefore not a deferral, it is an undeclared choice of the weakest available rung.

For accounts that were never identity-proofed, which is essentially every consumer application, the conforming recovery set is **closed to three**: a saved recovery code, an issued recovery code, or a recovery contact (NIST SP 800-63B-4 §4.2.3.1; reproofing is unavailable because there was no proofing). This turns two questions that look like soft inputs into the hard constraint of the whole selection:

| Question | What it decides |
| --- | --- |
| Is there an email address to recover against? | Removes the recovery-contact option when absent |
| Does an operator exist to run a recovery flow? | Removes any proofing-based option when absent |

With neither, a rung whose only recovery is one of those has **no conforming recovery at all**. Permanent account loss then is a design property to state plainly to the user and in the decision record, not a defect to patch later.

## 2. The order to decide in

Work the axes in this order. Each one can eliminate rungs, so a later axis is only ever applied to what survives the earlier ones.

| # | Axis | Question | Effect |
| - | ---- | -------- | ------ |
| 1 | Recovery | Which of the three conforming mechanisms actually exists here? | Eliminates rungs outright |
| 2 | Stakes | What is lost when an account is taken: a leaderboard rank, money, or another person's data? | Grades to an assurance tier, which caps session and inactivity lifetimes and bars syncable authenticators from the top tier |
| 3 | Terminability | Must sessions die on demand: account deletion, a factor change, an administrator's act? | Eliminates any design whose credential cannot be revoked without rebuilding server state |
| 4 | Administrative boundary | Does the account cross one? | The only condition that earns federation; inside one boundary it is cost with no buyer |
| 5 | Conversion | Are accounts the product, or an obstacle to it? | Prices the wall itself, which is a real cost and not a soft one |
| 6 | Topology and durability | One origin or several? How long must the credential survive? | Credentials bind to an origin; script-written client storage is evicted on a timescale of days |

Secondary axes that modify rather than eliminate: whether the application holds PII, and what regulatory surface it stands on (§6).

## 3. The rungs

Each row is a rung, what it buys, what it costs, and the condition that disqualifies it. No rung is the default.

Two WCAG criteria bind the sign-in flow whichever rung is chosen, and are stated once in `REF-Accessibility.md` §4: accessible authentication (3.3.8) and redundant entry (3.3.7). The first is why a puzzle is no answer to automated guessing here; the throttling of §4 below, which its own standards require anyway, carries that job.

| Rung | Buys | Costs | Disqualified when |
| ---- | ---- | ----- | ----------------- |
| Password + server-side session | Universally understood; revocation is free because the session is a row | A conformant build is 15 characters minimum as a single factor, **zero** composition rules, **no** expiry, and a live breached-password blocklist. Plus a reset desk that never closes | Accessibility or conversion make a memorised secret the wrong ask |
| OIDC against a hosted IdP | The identity problem becomes someone else's; enterprise connections arrive with it | The vendor's exit terms become yours (§6). Removing the password grant forecloses "OIDC without redirecting the user", so a browser redirect is in the UX permanently | A redirect is unacceptable, or no administrative boundary is crossed (§2 axis 4) |
| Magic link | No secret for the user to hold or lose | Two different objects under one name (below). The transport is rented: link domain, deep-link handler and mail sender are separately ownable, and any one of them retires on the vendor's schedule | Any assurance-tier claim attaches, or the audience is institutional (below) |
| Passkeys / WebAuthn | The best measured funnel of any rung, on both registration and return, and no guessable secret to throttle | The recovery process must exist and be staffed **before** launch, not after. Synced and device-bound are different rungs (below) | The top assurance tier is required and only syncable authenticators are available |
| JWT bearer / stateless sessions | A credential that crosses a trust boundary a cookie cannot | Every conforming implementation carries per-user server state consulted on each request, which is the lookup a session does, minus a session's free revocation (below) | The application is first-party browser only; a cookie session is strictly cheaper |
| Device-bound anonymous identity | Zero friction, no account at all | The identity dies with the browser storage and cannot be revoked by anyone. Regulated on storage, not on content (§6) | The user must reach a second device, or survive clearing site data |
| Ephemeral guest + recovery token | Drops the signup wall without minting permanent unreapable rows; the guest **is** the account | The recovery token is an artifact you design and mint; no hosted IdP ships one | The account holds anything a stranger profits from |

Three distinctions inside that table carry more weight than the rows themselves.

**Magic link is two objects.** As a *primary authenticator* an emailed link is permitted at the lower verification levels and disqualified the instant any assurance-tier claim, top-level target, or regulated surface attaches: the standard states email SHALL NOT be used for out-of-band authentication. As a *recovery channel* the same link is explicitly exempt and is legal underneath every other rung. The two texts diverge on where this sits, so read both: one places the rule at its highest level only, the other states it flatly. Routing from either alone routes wrongly.

**Magic link also fails on infrastructure nobody controls.** Institutional mail estates prefetch and consume one-time links before the recipient clicks, so the link arrives already spent and the user sees a generic invalid-token error. Magic-link-only is unshippable to a business or institutional audience unless the token survives a GET by a scanner. The identical defect degrades the password rung's reset path, so choosing passwords does not escape it.

**"Passkeys" is not one option.** Synced passkeys reach the middle assurance tier and never the top, because the private key must be exportable and that property is fixed by the authenticator at creation and merely observed by the application. Attestation is unavailable on consumer platforms, so "we will require attestation and reject synced passkeys" is not implementable. A device-binding requirement therefore funds hardware security keys **alongside** passkeys, with the issuance, replacement and revocation logistics that implies. That is a different cost shape from "users already have a phone".

**Stateless does not mean stateless.** The verification standard names the only three conforming ways a self-contained token honours termination: a list of terminated tokens, a per-user cutoff timestamp, or a per-user signing key that rotates. Separate requirements then force that machinery to exist for account deletion, for any factor change, and for administrator action. Note the routing trap: the standard's own self-contained-tokens chapter carries no revocation requirement, so an agent that navigates by the word "JWT" never meets the duty. It lives in the session-management chapter.

## 4. Invariants: rent four, author two

These hold whichever rung is chosen. Four are published, and this REF **cites them without restating their thresholds**, because a restated number ages the day the standard revises.

| Invariant | Rent from |
| --- | --- |
| Credentials hashed at rest, salted per the entropy rule below | NIST SP 800-63B-4 §3.1.1.2; OWASP ASVS 5.0 V6 |
| Rate limiting on credential-accepting endpoints | ASVS 5.0 V6 (Level 1); NIST §3.2.2 |
| One session-resolution choke point, no undocumented authentication pathways | ASVS 5.0 V7 and V8 |
| No internal identifiers in public projections | ASVS 5.0 V8; WebAuthn user-handle privacy; OIDC pairwise subject identifiers |

Two are **authored here, deliberately above the published bar**, because no standard states them at a level that binds:

1. **Constant-time comparison of every secret, unconditionally.** The verification standard places it at its highest level only. That gating reflects the standard's cost model, not yours: it is one library call.
2. **A created secret is returned exactly once, by the call that creates it, and by no read endpoint ever.** This appears in no published requirement. An agent that finds no rule will return a recovery token from a read, and be conformant while doing it.

Two numbers worth knowing because folklore inverts both:

- **Entropy decides the hashing scheme, not the credential's name.** Above the 112-bit line, an approved hash with no salt and no memory-hard scheme is conforming and correct. Below it, salted plus a password-hashing scheme. A system-minted token at 128 bits does not want a memory-hard KDF: the KDF exists to buy back entropy a human-chosen secret lacks, and applying it to a high-entropy secret buys latency and a denial-of-service surface and nothing else. The rule inverts the moment the token is shortened to be human-typeable.
- **The throttling obligation is a ceiling of 100 consecutive failures per authenticator per account.** Lockout at three or five is folklore that no standard requires, and it is a self-inflicted denial of service that generates most of an operator's unlock queue. Note the limit of the citation: it governs credential-**accepting** endpoints and says nothing about credential-**issuing** ones (a link send, a reset request), so throttling those is authored, not rented.

## 5. Federation readiness

Three schema decisions are free at creation and a live migration with a security window afterwards. Each is a published requirement rather than a preference, so ship all three on day one, **on every rung including the anonymous and guest ones**:

| Decision | Why it is not optional |
| --- | --- |
| An opaque, non-derived primary user id: never the username, never an email, never a sequence | A PII-bearing or sequential id cannot be reused as a WebAuthn user handle, so adopting passkeys later forces a second id and re-registering every credential, because the handle lives inside the authenticator |
| A nullable `external_issuer` + `external_subject` pair, unique together, empty for standalone users | The federated subject identifier is unique only within its issuer, so storing it without the issuer is ambiguous by specification |
| One session-resolution choke point a federated session plugs into | Keying accounts on an email address lets a second identity provider asserting that address take the account over; the published mitigation is exactly the issuer-plus-subject pair above |

Equally binding is what **not** to build: no shared user table, no cross-application identity protocol, no hub. Standalone must never depend on a federation that does not exist, and a later federated login **adopts** the existing account rather than forking a second identity.

## 6. Renting versus owning

**Name a library only when the library is the deliverable.** When the shape is small enough to own, teach the shape: a named package is a dependency this REF cannot version, and a recommendation ages into an instruction to install something abandoned. A server-side session is a table, a hashed token and one resolution function, which is why the library layer over it is the liability. An identity provider is the opposite: the vendor **is** the deliverable, so select on criteria rather than on a winner.

Criteria for an identity provider, in the order they bite:

| Criterion | Why |
| --- | --- |
| Can you leave? | Password hashes commonly cannot be exported, so the exit is a forced reset for the entire user base and the entrance is a deliberate plaintext-interception window. Check the exit before the entrance |
| Does it emit a stable issuer and subject, and support pairwise identifiers? | §5 depends on it |
| Who reaps the rows? | A hosted provider models an anonymous or guest user as a permanent account and commonly documents that automatic cleanup does not exist. The reaping job becomes yours, unowned, on a schedule nobody holds |
| How is it priced, and can that be changed under you? | Free tiers are repriced unilaterally while the exit stays expensive |

Self-hosting is bounded by password-hashing CPU rather than by registered users, so a design that authenticates rarely and refreshes often runs on a fraction of the hardware of one that re-prompts. What does not shrink is the highly-available database and the operator carrying it: self-host when you already run both, rent when you do not.

**Use an available identity provider when it answers the chosen rung.** Its integration guide owns the provisioning and callback registration; the application owns its account mapping and session behavior.

## 7. The regulated surface

Jurisdiction-scoped, and stated because it is routinely assumed away: in the EU, holding no personal data does **not** place a device identifier outside the ePrivacy rules. The provision is triggered by storage on, or access to, terminal equipment regardless of whether the stored value is personal data, and client-side code instructing a browser to return a stored identifier counts as access.

The question is therefore **strict necessity for the service the user explicitly requested**, not whether the identifier names anyone. A per-session identifier serving the requested function has a defensible exemption; a persistent cross-visit device identifier does not. That boundary, and not PII content, separates a lawful anonymous rung from one that needs a consent banner, and it is what makes a short-lived guest identity the cheaper compliance position.

## 8. Anti-Patterns

| # | Anti-Pattern | Correct approach |
| - | ------------ | ---------------- |
| 1 | Choosing a login rung and deferring recovery | The selection is a pair; assurance is the weaker of the two (§1) |
| 2 | Treating "is there an email to reset against" as a soft input | For never-proofed accounts it eliminates rungs outright (§1) |
| 3 | A claimed identifier, a username, or any caller-supplied value as the authenticator | The session credential is the only authenticator (§4) |
| 4 | Applying a memory-hard KDF to a high-entropy system-minted secret | Entropy decides the scheme, not the credential's name (§4) |
| 5 | Lockout at three or five attempts, believing a standard requires it | The obligation is a ceiling of 100; low lockout is a self-inflicted denial of service (§4) |
| 6 | Restating a standard's thresholds in this REF | Cite the four rented invariants; only the two authored ones are stated here (§4) |
| 7 | Treating "passkeys" as a single option | Synced and device-bound are different rungs with different ceilings (§3) |
| 8 | Choosing a self-contained token to avoid server state | Every conforming implementation carries the state back; a cookie session is cheaper first-party (§3) |
| 9 | Keying accounts on an email address | A second issuer asserting that address takes the account over; store issuer plus subject (§5) |
| 10 | Deferring the three federation fields until federation is real | They are free at creation and a live migration with a security window afterwards (§5) |
| 11 | Building a shared user table, a cross-application identity protocol, or a hub | Standalone must never depend on a federation that does not exist (§5) |
| 12 | Naming a winning library for a rung whose shape is small enough to own | Name a library only when the library is the deliverable; otherwise teach the shape (§6) |
| 13 | Assuming an anonymous identifier is outside data-protection law | The trigger is storage on the device, not the content of what is stored (§7) |

---

## 9. Skills that instantiate this REF

Generated by `scripts/sync_backlinks.py` from skill frontmatter; do not edit by hand.

Skills whose frontmatter `refs:` includes `REF-Identity`:

- `bootstrap-account-spine-python` - Add the account spine to an existing Python hexagonal FastAPI backend per REF-Identity: an opaque non-derived user id, an accounts table carrying the federation link, digest-only sessions, one session-resolution choke point, a guess budget, and the credential rung named explicitly with --rung (no default, because a scaffold that picks the rung is advocacy with a code generator attached).
- `bootstrap-account-spine-typescript` - Add the account spine to an existing TypeScript backend (domain/ plus adapters/{http,pg}) per REF-Identity: an opaque non-derived user id, an accounts table carrying the federation link, digest-only sessions, one session-resolution choke point, a guess budget, and the credential rung named explicitly with --rung (no default, because a scaffold that picks the rung is advocacy with a code generator attached).
