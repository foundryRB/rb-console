---
domain: practice
---

# REF: Phone Layout (The Phone Line, the Shapes a Screen Takes Below It, and the Phone Review)

> Read this when a screen has to work on a phone: the phone line, how navigation, overlays, tables, forms and the primary action change shape below it, the touch and viewport mechanics, who owns each decision, and how the phone version is reviewed. `REF-Accessibility.md` holds the conformance floor and `REF-React.md` §4 and §5 the stack idiom.

---

## 1. The phone line, and what a phone layout is

- **The phone line is 640px, Tailwind's `sm`.** Unprefixed utilities are the phone layout; `sm:` and up add the wider layouts. Below the line every multi-column grid stacks to one column, so a `grid-cols-N` with N above one carries a breakpoint prefix (`grid-cols-1 sm:grid-cols-3`), never a bare value. No two systems agree where a phone ends (Material's compact class ends at 600dp, Tailwind's first breakpoint is 640px, the rented sidebar hook and Bootstrap's `md` sit at 768px), so authored markup, templates, blocks and preview devices all use this one line.
- **The rented JavaScript switches stay at 768px.** The shadcn Sidebar renders in a Sheet below 768 and the Dialog-to-Drawer recipe branches there (`REF-React.md` §5). Between 640 and 767px a screen is therefore a wide phone layout with sheet navigation; that band is tested on purpose, so a 700px window looks like one thing.
- **Mobile first is the default.** A screen is authored for the phone and widened. Desktop first is a documented exception for a desktop-primary product, never the habit.
- **Width class, never device.** Layout follows available width, not user agent, device model or orientation. A phone in landscape is wider than the line and keeps a short height, so every phone shape is also checked in landscape (locking orientation is forbidden, `REF-Accessibility.md` §5).
- **Shrink is not a phone layout.** Scaling type, spacing, column count and image resolution is what a compressed desktop layout already does. A phone layout changes shape: the navigation form, master-detail into push navigation with Back, supporting content into a sheet or below the main content, tables into a scroll region or authored cards, forms into one column with matched keyboards, art-directed crops, a dialog into a sheet or full screen, a pinned action bar, and touch-first input. The review question is "which of these shapes did the screen take, and where is each hidden region now", never "does it fit at 375px".
- **A static prototype shows a scripted pattern in its closed state.** Markup and classes carry stacking, the scroll-region table, native disclosure (`<details>`, `<dialog>`, popover), input attributes and a pinned bar. A pattern that needs script (a draggable sheet, a priority-plus menu, a component tree swapped by width) is shown closed with its trigger visible.

---

## 2. Navigation

**Navigation is never hidden without a visible replacement, and the replacement's default state is stated** (closed on load). The primary call to action stays outside any collapsed menu.

| Top-level destinations | Phone shape |
|---|---|
| Four or fewer | Shown inline; no menu |
| Three to five, on an app-like screen with frequent movement between sections | A bottom bar: equal destinations, icon above a one or two word label, labels never dropped or truncated; sections only, never actions; covered by the keyboard or a sheet at most temporarily |
| More than five, or a browse-mostly site | A sheet menu opened from a button labelled Menu, closed on load, with the two or three most used links kept visible beside it; or a visible bar plus a More destination |
| Deep trees | Drill-down one level at a time with Back; a shallow tree links to a parent landing page instead of nesting menus |

- Hidden navigation costs discoverability (used in 57% of cases against 86% for part-visible navigation, and about 15% slower on phones, in the one measurement available, from 2016); the table is the standing answer, not a per-screen debate.
- The rented stack supplies the hamburger only: the sidebar collapses into a sheet, and the registry holds no bottom bar, no marketing navbar and no sheet menu. Those are authored (`REF-React.md` §5).

---

## 3. Overlays and sheets

- Below the line, a dialog with keyboard fields, unsaved changes or a nested step renders as a bottom sheet or full screen; a short confirmation stays a dialog. One component, two renderings; the recipe is in `REF-React.md` §5.
- A sheet has a visible close control at its top edge, dismisses on scrim tap and swipe down, opens at a capped height (about half the screen) and extends to full, never stacks on another sheet, and scrolls inside itself.
- A bottom-sheet action list is the phone form of an overflow menu. The primary action is never only inside it.
- The dialog mechanics (focus moved in, trapped, returned; Escape closes; `aria-modal` and a name) come from the primitive (`REF-Accessibility.md` §5), never from hand-rolled markup.

---

## 4. Tables

| Rows are | Phone shape |
|---|---|
| Compared across columns | The table stays a `<table>` inside a focusable, labelled scroll region (`overflow-x-auto`, `tabindex="0"`, `role="region"`, `aria-labelledby` on the caption), with a sticky header row, a sticky first column and a visible overflow cue (a cut column or arrows, never dots alone) |
| Standalone records with actions | Authored card markup, a list of term and description pairs per record, with a drill-down for the remaining columns |

- Columns are never dropped silently by priority; column visibility stays under the user's control (content parity, §7).
- CSS-only stacking of a real `<table>` (`display: block` on its parts, labels from a data attribute) is forbidden: it destroys the table semantics assistive technology reads. The stacked form is different markup.
- A horizontally scrolling data table is conformant (1.4.10 exempts data tables); a horizontally scrolling page is not.
- The rented table scrolls and nothing else; the card form is authored.

---

## 5. Forms

- One column, labels above fields; two short related fields may share a row. Fields are removed before they are rearranged: field count hurts more than step count.
- The keyboard is chosen by attributes: `type="email"`, `tel` or `url` where the type is enforced, otherwise `type="text"` with `inputmode` (`numeric`, `decimal`, `tel`, `email`, `url`, `search`); never `type="number"` for codes, cards or references. `autocomplete` on every identity, address and payment field (`REF-Accessibility.md` §4), `enterkeyhint` on the Enter key, `spellcheck="false"` on names, emails and references.
- Input and body text is at least 16px on phones. iOS Safari zooms the page when a focused control is smaller, and suppressing the zoom with `user-scalable=no` or `maximum-scale=1` fails 1.4.4 (`REF-Accessibility.md` §7). The viewport tag is `<meta name="viewport" content="width=device-width, initial-scale=1">`, with `viewport-fit=cover` added when a fixed edge bar exists (§6), and nothing that blocks zoom.
- On a long form the submit stays reachable through the pinned action bar (§6).

---

## 6. Touch targets, viewport mechanics, and the pinned action

Touch:

- Interactive hit areas are at least 44 CSS px on their shorter side with 8px between neighbours on coarse pointers, written as a coarse-pointer bump (`pointer-coarse:min-h-11`) so desktop density is untouched. 24px is the audit floor (`REF-Accessibility.md` §5); 44 is what the customer's phone has taught them (Apple's default control size, Material's 48dp).
- The rented defaults sit below it (buttons and inputs at 36px, checkboxes at 16px). The wrapping atom sets the size, never the primitive (`REF-React.md` §5).
- Hover reveals nothing on its own (`hover:` fires on hover-capable pointers only), every swipe or drag has a tap path (2.5.1, 2.5.7), and animation respects `motion-reduce:`.

Viewport:

- Full-height shells and sheets use `dvh`; a pinned bar uses `svh` or a fixed height; `100vh` (`h-screen`) is never a phone height, because browser toolbars expand and retract.
- A fixed bar at a screen edge carries `viewport-fit=cover` in the viewport tag and padding of `max(<gap>, env(safe-area-inset-bottom))`, so it clears the home indicator and rounded corners.
- The on-screen keyboard covers fixed elements and resizes only the visual viewport, on both platforms. `interactive-widget=resizes-content` opts into layout resizing on Chrome Android only; nothing equivalent exists on iOS.

The pinned action bar, one authored block with every rule inside it:

- Used when a form exceeds about one and a half screens or an action needs constant access; not when the fields and the submit fit one viewport, and not inside a sheet.
- Placed after the form in DOM order; padded by the safe-area inset; sized in `svh`; `scroll-padding-bottom` equal to its height so a focused field is never hidden behind it (2.4.11); the content padded by the bar's height; validation announced through a polite live region.
- Its acceptance test is a form filled on a real phone with the keyboard open.

---

## 7. Content

- **Content parity.** Every desktop region has a named phone home, even when that home is a sheet, an accordion or a drill-down. Hide behind disclosure, never delete: the phone version carries the same primary content, alt text and structure (1.4.10; search indexing reads the phone version only).
- **Two levels of disclosure at most.** Summary first, detail behind one tap; a third level is a navigation step with Back, not another fold. Native disclosure (`<details>`) before scripted disclosure.
- **DOM order is the phone order.** Main content before supporting content. CSS `order` and grid placement change the visual order only and leave tab and reading order behind (1.3.2, 2.4.3); a CSS reorder is a listed exception, never the default tool.
- **Images are cropped, not only scaled.** `<picture>` with a `media` source for the phone crop and a fallback `<img>` carrying `alt`; `srcset` and `sizes` handle resolution; every image and video reserves its aspect ratio (`aspect-video`, `aspect-[4/3]`) so nothing shifts under a tap.

---

## 8. Who decides, and what is rented

| Decision | Owner |
|---|---|
| Priority order, what moves behind disclosure, which table strategy a given table takes, the crop, the pinned action, the navigation shape for the destination count | The designer, in the design record (`REF-Design.md` §8) |
| Sidebar to sheet, dialog to sheet, sheet detents, the target floor baked into components | The component library, and the atoms that wrap it |
| `dvh` and `svh`, safe-area insets and `viewport-fit`, keyboard behaviour, input attributes, DOM order under reordering, focus not obscured, table semantics in a scroll region, the automated gate | The engineer |

| Rented | Authored |
|---|---|
| Sidebar-to-sheet switching, Sheet, Drawer (Base UI flavour), Dialog; Tailwind's breakpoint, container-query and pointer variants; Playwright's device registry; axe and Lighthouse | The phone line; the navigation table; the bottom bar and the sheet menu; the table policy and the card form; the target floor above the rented sizes; content parity; the pinned action bar; the phone review |

---

## 9. The phone review

**Every phone rule is written as a value, a condition and a default**: "below 640px the sidebar renders as a bottom bar when there are three to five sections, otherwise as a sheet opened by a Menu button, closed on load". A rule without the three parts ("make it responsive") is not a rule. A component or block documents its phone behaviour in the same shape: what changes, at which width, the rule for choosing between variants, and the property that sets it.

The review runs the passes of `REF-Accessibility.md` §10 and adds the phone items they do not carry:

1. Input and body text at least 16px, and no zoom blocked.
2. `dvh` or `svh` on full-height elements; safe-area padding on fixed bars.
3. Content parity against the desktop screen: every hidden region named with its phone home.
4. Navigation reachable, its replacement named and closed on load, the primary action outside it.
5. One pass in landscape and one at 200% text.
6. The automated half: a Playwright phone project with an overflow assertion (`scrollWidth` against the client width, per element, at 320 and 375px) and an axe run with `wcag22aa` among its tags, which turns on the target-size rule axe ships disabled. Lighthouse's `target-size` audit tests the 24px floor only.
7. The manual half: the preview link opened on a real iPhone and a real Android phone, with the keyboard open on a form. Device chrome (the home indicator, retracting toolbars, the keyboard, focus zoom) is invisible to a desktop preview and is where a customer's approval fails.

Devices to test are picked from the customer's analytics, never from a fixed list.

---

## 10. Anti-Patterns

| # | Anti-Pattern | Correct Approach |
|---|---|---|
| 1 | Navigation hidden below the line with nothing in its place | A named replacement with a stated default state (§2) |
| 2 | A bare `grid-cols-N` | `grid-cols-1 sm:grid-cols-N` (§1) |
| 3 | `user-scalable=no` or `maximum-scale=1` to stop input focus zoom | 16px inputs (§5) |
| 4 | `100vh` or `h-screen` for a phone shell | `dvh`, and `svh` for pinned bars (§6) |
| 5 | A fixed bottom bar without safe-area padding or `scroll-padding` | The pinned action bar block (§6) |
| 6 | CSS-only stacking of a `<table>` | A scroll region, or authored card markup (§4) |
| 7 | A media-query hook choosing the tree for server-rendered chrome | CSS-only visibility; the hook only for client-only overlays (`REF-React.md` §1) |
| 8 | Columns dropped by priority, content removed on the phone | Disclosure, never deletion (§7) |
| 9 | Swipe or drag as the only way to act | A visible tap control, the gesture as a shortcut (§6) |
| 10 | Judging the phone version in a desktop preview alone | The link on a real phone with the keyboard open (§9) |

---

## 11. Skills that instantiate this REF

Generated by `scripts/sync_backlinks.py` from skill frontmatter; do not edit by hand.

Skills whose frontmatter `refs:` includes `REF-PhoneLayout`:

- `bootstrap-playwright-intent` - Scaffold Playwright + playwright-intent into a frontend project - install both packages, drop a CSD-INTENT-01 canonical intent.yaml stub (if missing), a playwright.config.ts, and an e2e/ directory with an example intent() test.
- `design-session` - Run the design gate for an engagement over a prototyping instance and lock its one durable output, the visual identity (logo, colour scheme, typography), into .delivery/design.md.
