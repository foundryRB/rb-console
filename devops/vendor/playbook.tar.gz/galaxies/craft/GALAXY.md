# Galaxy: craft

> The software-engineering galaxy: architecture, stacks, design, testing and documentation. Enter here for engineering practice; the routing table loads only what the task needs.

## Galaxy at a glance

| | |
| --- | --- |
| **Galaxy** | craft |
| **Subject** | Software-engineering practices |
| **Owner** | The org's resident software-engineering expert |
| **Anchor REF** | `REF-CleanArchitecture.md` |
| **Routing doc** | This file (`GALAXY.md`) |

---

## Project Context

Read the project's `README.md` for stack and domain concepts.

---

## Task Routing - load only what you need

| Task | Read These REFs |
| ---- | --------------- |
| Delivery, maintenance, promotion and application onboarding | [foundry galaxy](../foundry/GALAXY.md) |
| Domain entities, VOs, enums, constants | `REF-Domain.md` |
| Use cases (application orchestration) | `REF-UseCase.md` + `REF-InboundPort.md` + `REF-OutboundPort.md` |
| CLI adapter (Python, engine-side) | `REF-InboundAdapter.md` |
| CLI frontend (PowerShell, cli/) | `REF-PowerShell.md` |
| HTTP / FastAPI adapter | `REF-InboundAdapter.md` + `REF-FastAPI.md` |
| New hexagonal FastAPI service (scaffold) | skill `bootstrap-hexagonal-backend` (+ `REF-CleanArchitecture.md`, `REF-FastAPI.md`, `REF-Python.md`) |
| Exposing an app to agents via MCP | `REF-MCP.md` + `REF-InboundAdapter.md` + `REF-CleanArchitecture.md` |
| Adding an MCP adapter to an existing service (scaffold) | skill `bootstrap-mcp-adapter` (+ `REF-MCP.md`, `REF-FastAPI.md`) |
| Outbound adapter (persistence, writers) | `REF-OutboundAdapter.md` |
| Exceptions | `REF-ExceptionHandling.md` |
| Choosing how an app authenticates people (login rung + recovery rung, sessions, tokens, federation readiness) | `REF-Identity.md` |
| Adding accounts to an existing backend once the rung is chosen (scaffold) | skill `bootstrap-account-spine-python` or `bootstrap-account-spine-typescript` (+ `REF-Identity.md`; the scaffold has no default rung, because choosing one for you is what makes a generator advocacy) |
| Tests (unit, integration, E2E, conformance guards) | `REF-Tests.md` |
| Architecture / layer decisions | `REF-CleanArchitecture.md` |
| Pipeline / ordered processing pattern (data flowing through stages) | `REF-Pipeline.md` |
| Tracking long operations, live progress or streaming output, realtime updates (polling, SSE, WebSockets, webhooks) | `REF-Realtime.md` (+ `REF-FastAPI.md` server-side, `REF-Frontend.md` client-side) |
| Publishing or consuming platform events (envelope, type naming and where each owner states its types, who may publish, the one-way rule, the read model) | `REF-Events.md` (+ `REF-Realtime.md` when a browser client watches, `REF-OutboundAdapter.md` for the publisher) |
| Frontend (React components, pages) | `REF-Frontend.md` + `REF-React.md` (+ `REF-AtomicDesign.md` for View-layer component structure, `REF-Accessibility.md` for what every view owes its users) |
| A screen on a phone: the phone line, the navigation and overlay shapes, tables and forms below the line, touch targets, viewport mechanics, the pinned action, the phone review | `REF-PhoneLayout.md` (+ `REF-React.md` §4 and §5 for the stack idiom, `REF-Accessibility.md` for the conformance floor) |
| An application interface a person operates to do work: markup, a control, a form, a dialog, a chart, a theme, or a review of one (conformance target, screen-reader rules, keyboard and focus, contrast, verification) | `REF-Accessibility.md` (core) + the app's REF (`REF-Frontend.md` + `REF-React.md`, or `REF-Electron.md` for a desktop shell) |
| Structuring a frontend's View layer (component taxonomy: atoms to pages, classification, composition and purity rules) | `REF-AtomicDesign.md` (core) + `REF-Frontend.md` (React specialization) |
| New React MVVM frontend from an OpenAPI spec (scaffold) | skill `bootstrap-react-mvvm` (+ `REF-Frontend.md`, `REF-React.md`, `REF-AtomicDesign.md`, `REF-Accessibility.md`) |
| 3D rendering: visualizations, games, WebXR/VR (Three.js) | `REF-ThreeJS.md` + `REF-React.md` |
| New Three.js 3D app (scaffold) | skill `bootstrap-threejs-app` (+ `REF-ThreeJS.md`) |
| Deciding whether an application is client-server or standalone (where its interface lives) | `REF-CleanArchitecture.md` §1 |
| A standalone application: one artifact owning its domain (desktop app, game, tool) | `REF-CleanArchitecture.md` + the language REF (+ `REF-AtomicDesign.md` for its view layer, `REF-Electron.md` when it ships as a desktop app) |
| New standalone or service TypeScript application in hexagonal form (scaffold) | skill `bootstrap-hexagonal-typescript` (+ `REF-TypeScript.md`, `REF-CleanArchitecture.md`) |
| Shipping the client of a client-server application as an installable desktop app (Electron shell, IPC, packaging) | `REF-Electron.md` + `REF-Frontend.md` + `REF-React.md` |
| Wrapping an existing Vite/React MVVM renderer in an Electron shell (scaffold) | skill `bootstrap-electron` (+ `REF-Electron.md`) |
| Making a web frontend installable on phones and desktops (manifest, service worker and updates, the auth-proxy seam, web push, reach without a store) | `REF-PWA.md` + `REF-Frontend.md` + `REF-React.md` |
| Making an existing Vite/React MVVM frontend an installable PWA (scaffold) | skill `bootstrap-pwa` (+ `REF-PWA.md`) |
| Design doctrine: look vs structure, token discipline, importing and harvesting design systems | `REF-Design.md` |
| Prototyping a customer UI before the frontend exists (live theming, screen assembly, handoff) | `REF-Design.md` (+ skill `bootstrap-protopane-project` over the protopane door) |
| Estimating a delivery from a customer's requirements (the requirement spine, effort and capacity, assumptions, the clean audit) | `REF-Estimation.md` (+ skill `bootstrap-estimatekit-project` over the estimatekit door) |
| Working a headless CMS space (content types and fields, entries, moving content between environments) | skill `contentful-content-management` (+ `REF-Domain.md` for the type-versus-field judgment) |
| Documentation (README, docstrings, markdown) | `REF-Documentation.md` |
| Documentation sites (core + Starlight patterns) | `REF-Documentation.md` + `REF-StarlightDocs.md` |
| Documenting an application: the documentation set (index, modules, flows, reference, operations, decisions, glossary) | `REF-Documentation.md` §7.11 + `REF-StarlightDocs.md` (+ the STARLIGHT bundle's templates, `REF-Intent-Bundle.md`) |
| A guide for an app's users, when a customer has put user documentation down as a requirement (what comes before a guide, what it holds, the words, where it lives) | `REF-UserGuide.md` |
| Any work involving CSD methodology | `REF-CSD.md` (cites canonical CSD source) |
| Authoring or maintaining a Data Pack (TSV + intent + tests) | `REF-DataPack.md` + `REF-CSD.md` + `REF-Tests.md` |
| Adding an interactive dashboard on top of a Data Pack (Observable Framework) | `REF-ObservableFramework.md` + `REF-DataPack.md` |
| Designing or applying a reusable Intent Bundle | `REF-Intent-Bundle.md` + `REF-CSD.md` |
| Wiring vitest-intent into a JS/TS project (intent claims for Starlight, etc.) | `REF-Intent-Bundle.md` |
| **Any Python code** | `REF-Python.md` (always) |
| Authoring or auditing a publishable Python package | `REF-Python-Package.md` + `REF-Python.md` + `REF-Tests.md` |
| **Any TypeScript code** | `REF-TypeScript.md` (always) |
| **Any Java code (Spring Boot, hexagonal)** | `REF-Java.md` + `REF-CleanArchitecture.md` |
| **Any PowerShell code** | `REF-PowerShell.md` (always) |

## Available Skills (invocable)

Master copies live in `skills/<name>/SKILL.md` in this galaxy. The Claude runtime loads them from its installed-skills directory (typically `~/.claude/skills/<name>/SKILL.md`). Install or refresh runtime copies with `python scripts/install_playbook.py` from the repo root (everything) or `--only <name>` (one skill). Each skill's description lives in its `SKILL.md` frontmatter, declared to the runtime at load; this registry indexes the master copy and the REFs that ground it. The table is generated by `scripts/sync_registry.py` from that frontmatter; do not edit it by hand.

| Skill | Master | Refs |
|---|---|---|
| `apply-intent-bundle` | `skills/apply-intent-bundle/SKILL.md` | `REF-Intent-Bundle`, `REF-CSD`, `REF-Tests` |
| `audit-intent` | `skills/audit-intent/SKILL.md` | `REF-CSD`, `REF-Tests` |
| `bootstrap-account-spine-python` | `skills/bootstrap-account-spine-python/SKILL.md` | `REF-Identity`, `REF-CleanArchitecture`, `REF-FastAPI`, `REF-Python`, `REF-Tests` |
| `bootstrap-account-spine-typescript` | `skills/bootstrap-account-spine-typescript/SKILL.md` | `REF-Identity`, `REF-CleanArchitecture`, `REF-React`, `REF-Tests` |
| `bootstrap-atomic-mui` | `skills/bootstrap-atomic-mui/SKILL.md` | `REF-AtomicDesign`, `REF-Frontend`, `REF-React` |
| `bootstrap-atomic-shadcn` | `skills/bootstrap-atomic-shadcn/SKILL.md` | `REF-AtomicDesign`, `REF-Frontend`, `REF-React` |
| `bootstrap-data-pack` | `skills/bootstrap-data-pack/SKILL.md` | `REF-DataPack`, `REF-CSD`, `REF-Tests`, `REF-Python` |
| `bootstrap-electron` | `skills/bootstrap-electron/SKILL.md` | `REF-Electron` |
| `bootstrap-estimatekit-project` | `skills/bootstrap-estimatekit-project/SKILL.md` | `REF-Estimation` |
| `bootstrap-hexagonal-backend` | `skills/bootstrap-hexagonal-backend/SKILL.md` | `REF-CleanArchitecture`, `REF-FastAPI`, `REF-Python`, `REF-Tests`, `REF-ExceptionHandling` |
| `bootstrap-hexagonal-typescript` | `skills/bootstrap-hexagonal-typescript/SKILL.md` | `REF-TypeScript`, `REF-CleanArchitecture`, `REF-Tests` |
| `bootstrap-mcp-adapter` | `skills/bootstrap-mcp-adapter/SKILL.md` | `REF-MCP`, `REF-InboundAdapter`, `REF-CleanArchitecture`, `REF-FastAPI` |
| `bootstrap-observable-dashboard` | `skills/bootstrap-observable-dashboard/SKILL.md` | `REF-ObservableFramework`, `REF-DataPack`, `REF-CSD` |
| `bootstrap-playwright-intent` | `skills/bootstrap-playwright-intent/SKILL.md` | `REF-CSD`, `REF-Tests`, `REF-PhoneLayout` |
| `bootstrap-protopane-project` | `skills/bootstrap-protopane-project/SKILL.md` | `REF-Design` |
| `bootstrap-pwa` | `skills/bootstrap-pwa/SKILL.md` | `REF-PWA`, `REF-Frontend`, `REF-React` |
| `bootstrap-pytest-intent` | `skills/bootstrap-pytest-intent/SKILL.md` | `REF-CSD`, `REF-Tests`, `REF-Python` |
| `bootstrap-python-package` | `skills/bootstrap-python-package/SKILL.md` | `REF-Python-Package`, `REF-Python`, `REF-Tests`, `REF-Documentation` |
| `bootstrap-react-mvvm` | `skills/bootstrap-react-mvvm/SKILL.md` | `REF-Frontend`, `REF-React`, `REF-Tests`, `REF-Accessibility` |
| `bootstrap-starlight` | `skills/bootstrap-starlight/SKILL.md` | `REF-Documentation`, `REF-StarlightDocs`, `REF-CSD`, `REF-Intent-Bundle` |
| `bootstrap-threejs-app` | `skills/bootstrap-threejs-app/SKILL.md` | `REF-ThreeJS` |
| `bootstrap-vitest-intent` | `skills/bootstrap-vitest-intent/SKILL.md` | `REF-CSD`, `REF-Tests` |
| `contentful-content-management` | `skills/contentful-content-management/SKILL.md` | `REF-Domain`, `REF-Autonomy` |

**If you encounter a Skill listed here but not invocable**, the runtime may not have it installed. Run `python scripts/install_playbook.py --only <name>` from the repo root, or report to user.

---

## Craft Violations - Check EVERY Change

The universal violations (duplication, em-dashes, portability, change-narration) live in `AI-PLAYBOOK.md` and apply here too. These are craft's own cross-cutting mistakes; verify **none** of them apply before completing any task:

1. **PowerShell `Set-Content -Encoding UTF8` writes a BOM** - Windows PowerShell 5.1's `UTF8` encoding produces UTF-8 *with BOM*. Java, YAML/JSON parsers, and most build tools then reject the file (`illegal character: '﻿'`, or "found character that cannot start any token"). When PowerShell writes files something else will read, use `[System.IO.File]::WriteAllText($path, $text, [System.Text.UTF8Encoding]::new($false))` - or PowerShell 7+'s `-Encoding utf8NoBOM`.
2. **Docker Compose interpolates `$` in `env_file` values** - a value containing `$word` (a bcrypt hash such as `$2b$12$Yj...`, a JWT signing key, any secret with a `$`) is silently corrupted. Compose treats `$word` as a variable reference and substitutes it (to empty when undefined), so the value inside the container no longer matches the file on disk. Classic symptom: authentication works bare-metal (`fastapi dev`; pydantic-settings reads the file literally) but every login fails only under Compose. Fix: use the `env_file` long form with `format: raw`, which passes the file through verbatim:
    ```yaml
    env_file:
      - path: ../service/.env
        format: raw
    ```
    Escaping each `$` as `$$` also satisfies Compose, but then the same `.env` is wrong for every non-Compose reader (pydantic-settings, python-dotenv), so prefer `format: raw` when one file feeds both.
3. **Prose carrying structure, or the "why", in a docs page** - lead with the diagram (visual-first): the diagram carries the structure, prose only annotates it; if the shape of a thing lives in three paragraphs the reader must assemble, the diagram is missing. State what is. The "why" is not banned, but belongs only in the decision log (ADRs), never in docs prose and never as an inline link to it. See `REF-Documentation.md` §7.1, §7.9.
4. **Building the complex system directly (Gall's Law)** - "A complex system that works is invariably found to have evolved from a simple system that worked. A complex system designed from scratch never works and cannot be patched up to make it work." Fix the defect in front of you, not the subsystem the defect implies. A REF sentence describing a property is not a licence to build the machinery that would deliver it: the machinery is a separate decision, taken with evidence that something needs it.

    The tell is a fix whose diff is mostly a thing nobody asked for. Concretely, when a defect is "this lookup walks a 400-name space", the change is the name space; a background job to delete rows, its schedule, its grace window and its tests are a *second* system, and they are earned by a table that is actually growing, not by one that might. A scaffold repeats whatever it ships to every project built from it, so an unearned subsystem there is the same mistake multiplied.

    Ask before adding: what evidence says this is needed **now**? If the answer is a hypothetical, ship the simple thing that works and let the complexity be earned. Whoever owns the running system decides when that is; the corpus does not decide it for them by default.

5. **Permanent code for a transient migration** - a migration leaves a short window where old-shaped artifacts still exist, and the reflex is to teach the code about the old shape: a compatibility branch, a "this predates X" guard, a dual-read fallback, a friendly legacy error message. The window is days; the code is forever. Every such branch is maintained, read, tested and reasoned about by every future contributor long after the last old-shaped artifact is gone, and nothing ever tells them it is safe to delete.

    First ask whether the set of affected instances is finite and enumerable. If it is, that is the whole fix: list them, repair them, and let the codebase describe only the end state. Reach for code only when the old shape can keep being *created* after the migration, or the instance set is unbounded or undiscoverable. A fail-fast guard that already exists and simply refuses is fine to leave alone; do not grow it into a compatibility layer that explains and recovers. When a migration is planned, its own step is enumerate-and-repair, never "support both". This is the executable form of universal violation #4: a branch that explains the old shape is change-narration that runs.

6. **A user interface that only works for a sighted mouse user** - the three failures that account for most of it, each cheap to avoid and invisible in a screenshot: a control with no accessible name (an icon-only button), a state or status carried by colour alone, and an asynchronous change that happens silently. Before completing any UI change, check the three: can every control be named out loud, is every meaning also carried by text or shape, and is every change announced. The rules and the layer that owns each one are in `REF-Accessibility.md` §3, §6, §7, §9; the target is WCAG 2.2 AA (§1 there) and a green linter is not a conformance claim (§10 there).

Stack-specific violations (one class per file, dependency rule, `StrEnum` over magic strings, no `Any`, mapper functions instead of `from_domain()`, domain exceptions over raw ones, ...) live in the Anti-Patterns sections of the REFs the routing table already loads for the task: `REF-Python.md`, `REF-CleanArchitecture.md`, `REF-Domain.md`, `REF-UseCase.md`, `REF-ExceptionHandling.md`, `REF-Java.md`.

---

## Pre-Commit Checklist (Python hexagonal stack)

Before you consider a task on this stack complete, verify all of these:

- [ ] One class per file; file name = class name (exceptions only in cases, i.e., snake_case vs camelCase, as according to language standards)
- [ ] All function signatures fully type-hinted (parameters + return)
- [ ] Domain layer: zero imports from application or adapters
- [ ] Use cases depend on port Protocols, not concrete classes
- [ ] DTOs and mappers are in separate files, in their respective packages
- [ ] No `Any` type hints
- [ ] Domain exceptions used everywhere (not `ValueError`, `KeyError`, `FileNotFoundError`)
- [ ] Logging is emitted, not just configured (adapters at INFO, use-case outcomes at INFO/WARNING, queries at DEBUG)
- [ ] Lint passes, i.e., `python -m ruff check .`
- [ ] Tests pass, i.e.,: `python -m pytest -q`

---

## Decision Guide - Where Does This Code Belong?

| Question | It belongs in… |
| -------- | -------------- |
| Has identity and lifecycle? | Domain Entity |
| Immutable descriptive data? | Value Object (`frozen=True` dataclass) |
| Defines what the app can do? | Inbound Port (`Protocol`) |
| Defines what the app needs from outside? | Outbound Port (`Protocol`) |
| Orchestrates domain + ports? | Use Case |
| Translates HTTP ↔ domain? | HTTP Adapter (route + DTO + mapper) |
| Translates CLI ↔ domain? | CLI Adapter (command + mapper + formatter) |
| UI, orchestration, tool discovery? | PowerShell CLI (`cli/`) |
| Reads/writes files or calls services? | Outbound Adapter |
| Pure business algorithm spanning entities? | Domain Service |
| Shared constant / identifier? | `domain/constants.py` |
| Finite set of named values? | `StrEnum` in `domain/model/` |
