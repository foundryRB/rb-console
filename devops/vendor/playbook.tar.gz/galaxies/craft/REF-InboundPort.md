---
domain: architecture
---

# REF: Inbound Port Construction (Hexagonal Architecture)

> When asked to create or modify an inbound port (the `Protocol` that an adapter depends on and a use case implements), follow these rules strictly.

---

## 1. One Port Per File

Each inbound port lives in its own file under `application/ports/inbound/`, with `__all__ = ["CreateOrderPort"]`. File names must match the use case they gate - `create_order.py` gates `CreateOrder`. Naming conventions: section 7.

---

## 2. Canonical File Template

```python
"""Inbound port: <imperative description of the use case>."""

from __future__ import annotations

from typing import Protocol, runtime_checkable

from <package>.domain.model.order_status import OrderStatus  # domain imports if needed

__all__ = ["SomeUseCasePort"]


@runtime_checkable
class SomeUseCasePort(Protocol):
    """<One-line description of the capability this port exposes.>"""

    def execute(
        self,
        order_id: str,
        *,
        optional_flag: bool = False,
    ) -> ReturnType:
        """<What execute does. Mentions what it returns.>"""
        ...
```

Key structural rules:
- `from __future__ import annotations` first; `@runtime_checkable` always (DI containers and tests do `isinstance` checks).
- Single method named `execute` - never `run`, `call`, `process`, or `__call__`.
- Body is `...` (Ellipsis), not `pass` or `raise NotImplementedError`.
- Three docstrings: module (`Inbound port: …` prefix), class, method.

---

## 3. Signatures Use Domain Types, Not Primitives

### Parameters

| Smell                                      | Fix                                              |
|--------------------------------------------|--------------------------------------------------|
| `statuses: list[str]` (magic strings)      | `statuses: list[OrderStatus]` (domain `StrEnum`) |
| `format: str` (open-ended)                 | `format: OutputFormat` (domain enum/literal)      |
| `options: dict[str, Any]` (unstructured)   | Named keyword-only args or a domain value object  |

A parameter for a **finite set of domain concepts** (statuses, output formats, categories) **must** be a domain enum in `domain/model/` - never a bare `str`.

### Return Types

| Smell                                      | Fix                                              |
|--------------------------------------------|--------------------------------------------------|
| `dict[str, bool]` with meaning in a comment| Frozen dataclass in `domain/model/`              |
| `tuple[int, list[str]]` (positional slots) | Named frozen dataclass                           |
| `Any`                                      | The actual domain type (never hide it)           |

Simple returns (`int`, `Path`, `list[Path]`) are acceptable **only** when the docstring makes the meaning clear. Anything with more than one field, or needing structural interpretation, becomes a **domain value object** (frozen dataclass) in `domain/model/`.

---

## 4. Keyword-Only Arguments

Use bare `*` to force keyword-only syntax for optional behavioral flags:

```python
def execute(
    self,
    order_id: str,
    *,
    statuses: list[OrderStatus] | None = None,
    force: bool = False,
) -> OrderSummary:
```

Positional parameters are reserved for the primary "subject" of the operation (entity ID, root directory, slug); every optional behavioral flag goes after the bare `*`.

---

## 5. Domain Type Imports Are Direct

Unlike adapter code (where imports hide behind `TYPE_CHECKING`), ports **must** import domain types directly - `@runtime_checkable` needs them resolved at runtime, and a `TYPE_CHECKING` guard breaks it:

```python
# ✅ Correct - direct import; never behind TYPE_CHECKING
from <package>.domain.model.order_status import OrderStatus
from <package>.domain.model.order_summary import OrderSummary
```

---

## 6. Ports Import Domain, Never Infrastructure

A port may import from `domain/model/`, `domain/exceptions/`, and the Python stdlib. It must **never** import from `adapters/`, `application/use_cases/`, or third-party libraries (Pydantic, FastAPI, argparse, etc.).

If a port's return type is a domain concept, it lives in `domain/model/` and both the port and the use case import it from there.

---

## 7. Naming Conventions

| Element         | Convention                                              | Example                          |
|-----------------|---------------------------------------------------------|----------------------------------|
| File            | `snake_case` verb phrase matching the use case          | `create_order.py`                |
| Port class      | `PascalCase` + `Port` suffix                           | `CreateOrderPort`                |
| Method          | Always `execute`                                        | `def execute(self, ...) -> ...`  |
| Module docstring| `Inbound port: <imperative phrase>.`                    | `Inbound port: create a new order.` |
| Class docstring | What the port exposes as a capability                   | `Orchestrate the order creation pipeline.` |
| Method docstring| What execute does + what it returns                     | `Create an order. Returns an OrderSummary.` |

---

## 8. The `__init__.py` Package Docstring

`application/ports/inbound/__init__.py` contains only a docstring - **no** re-exports (consumers import from the individual files to keep dependency graphs explicit):

```python
"""Inbound ports - stable contracts that inbound adapters depend on.

Each protocol defines the signature of a single use case.  Inbound adapters
(CLI, HTTP, gRPC, …) depend only on these protocols, never on the concrete
use case classes.  The use cases implement these protocols.
"""
```

---

## 9. Anti-Patterns Checklist

Verify **none** of these apply:

| #  | Anti-Pattern                                           | Why It's Wrong                                                |
|----|--------------------------------------------------------|---------------------------------------------------------------|
| 1  | `list[str]` for a finite set of domain concepts        | Magic strings - no validation, no autocomplete, no single source of truth |
| 2  | `dict[str, bool]` return with structure in a comment   | The contract is invisible to type checkers and consumers      |
| 3  | `Any` as parameter or return type                      | Hides coupling - forces consumers to read source code         |
| 4  | Import from `adapters/` or third-party libs            | Ports face inward (domain), never outward (infra)             |
| 5  | Multiple public methods on one Protocol                | One port = one use case = one `execute` method                |
| 6  | `pass` or `raise NotImplementedError` as body          | `...` (Ellipsis) is the Protocol convention                   |
| 7  | Missing `@runtime_checkable`                           | Breaks isinstance checks in DI containers and tests           |
| 8  | Port class without `Port` suffix                       | Naming inconsistency - impossible to grep/distinguish from use cases |
| 9  | Return type that needs a comment to explain its shape  | Create a domain value object instead                          |
| 10 | Optional parameter as positional arg                   | Use bare `*` to force keyword-only                            |

---

## 10. Reference: Example Ports

| Port                     | Signature                                                                 |
|--------------------------|---------------------------------------------------------------------------|
| `CreateOrderPort`        | `execute(customer_id: str, *, items: list[OrderItem]) -> OrderSummary`    |
| `ListOrdersPort`         | `execute(*, status: OrderStatus \| None = None) -> list[OrderSummary]`   |
| `GenerateInvoicePort`    | `execute(order_id: str) -> Path`                                          |
