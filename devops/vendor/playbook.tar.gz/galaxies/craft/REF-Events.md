---
domain: architecture
---

# REF: Events

> Read before a platform tool or an app publishes or consumes an event: the CloudEvents envelope, how types are named and where each owner states its own, who may publish what, what never rides an event, the one-way publish rule, and the read model.

---

## 1. What an event is, and what it is not

An event is a **past-tense statement of fact about the producer's own domain**, published without knowledge of who reads it. It carries identity and pointers; a reader that needs more fetches it.

| An event is | An event is not |
|---|---|
| A fact that already happened | A command, a request, or a job for someone to run |
| Addressed to no one in particular | A message to a named recipient (that is an API call) |
| The pointer to the thing | The thing itself (§5) |
| Best-effort notification | The durable record of what happened (§8) |

This REF is the **semantic contract** between producers and consumers: the envelope, the vocabulary, and the rules about publishing. How an event reaches a browser is `REF-Realtime.md`, whose ladder and reconciliation invariant (§2 there) apply unchanged to any client surface built over these events.

The contract is stated **before** a bus lands, so producers implement one agreed shape instead of the shape being reverse-engineered from whichever producer shipped first.

---

## 2. The envelope is CloudEvents

Use CloudEvents. It is the existing standard for this exact problem, and inventing an envelope means owning a spec, a versioning story, and a bespoke parser in every consumer, for nothing.

| Attribute | Rule |
|---|---|
| `id` | Unique per event from its producer. This is the consumer's dedupe key, because delivery is at-least-once |
| `source` | The producing app as one stable URI-reference, fixed for the app's lifetime |
| `type` | Exactly one type the owner states on its own page (§3). Never composed at runtime |
| `time` | When the fact became true, set by the producer |
| `subject` | The id of the thing the event is about, so a consumer filters without parsing `data` |
| `data` | The minimum that makes the fact actionable, under §5 |
| `datacontenttype` | `application/json`, unless the owner's row for that type states otherwise |

- **The envelope is the contract; the transport is not.** Which binding a producer uses (HTTP, a queue, anything else) is producer-local per §7, and no consumer's code depends on that choice.
- **`data` grows, it never changes shape.** Adding an optional field is the only compatible edit. Removing a field, retyping one, or changing what one means is a **new type**, stated as its own row on the owner's page.
- **Extension attributes are declared on the owner's row** for the type that relies on them, or they do not exist.

---

## 3. Type names and where each owner states its types

Format: `com.foundry.<domain>.<thing>.<verb>`, verb in the **past tense**.

- `<domain>` is the bounded area the fact belongs to, **not the app that emitted it**. Apps get renamed, split, and replaced; domains outlive them, and a consumer subscribing to a domain should not resubscribe when the platform reorganizes.
- **The domain is the namespace, and the grant is what makes an app its owner.** Bus access is granted per domain, one owner per domain on an install, and the bus admission checks refuse a second. Names are therefore unique across producers by construction: two producers cannot own one domain, and an owner does not collide with itself. No cross-producer table exists, and none is needed.
- **Each owner states the types it publishes in its own documentation**: one reference page in the producer's repo, one row per type (the type, its `subject`, when it is published, what `data` carries), held against the publisher's code by the owner's own tests so the page cannot say one thing while the adapter emits another. That page is the consumer's contract: a consumer reads the owner's page, never a central list, and a type absent from the owner's page is not published.
- **Adding a type is one change to the page and the publisher together.** Removing a field, retyping one, or changing what one means is a new type with its own row (§2). A type no producer emits yet has no row anywhere: the page records what is settled.
- The shapes recur, and that is deliberate: a producer that admits things states `<thing>.admitted`, one that runs things states `<run>.started` and `<run>.completed` with the outcome in `data`, one that versions artifacts states `artifact.generated` and `artifact.published` under its own domain. A consumer that has read one owner's page recognizes the next.

This REF carries no type rows. A concrete vocabulary is one organization's, one install's, and one moment's; it belongs to the producer that emits it, where its tests can hold it, and a copy here would drift from every one of them at once (universal violation 1) while making the pattern specific to whoever wrote it down first (`REF-Authoring.md` §2).

---

## 4. Who may publish

**An app publishes only about its own domain. No app narrates another's.**

- The grant is the authority: one owner per domain on an install, held by the platform at grant time (§3), and a producer emits only types under the domains it was granted. Its own page states which.
- An app that wants a fact stated about someone else's domain asks that domain's owner to publish it. It never publishes on the owner's behalf, however convenient its vantage point.
- Consuming another domain's events is unrestricted (§8). Reading is open; speaking is owned.

The rule protects two things at once. A consumer can trust provenance, because `type` implies the owner and `source` confirms it. And an owner can evolve its own vocabulary by editing its own rows, rather than searching the platform for everyone else who took its name.

---

## 5. What never enters an event

Never: secrets, credentials, tokens, personal data, and the full body of anything a reader can fetch by id.

**An event carries the fact and the pointer, never the payload.** It says the thing happened and names the thing; the reader fetches it from the owner's API, under its own authorization.

| Never in an event | Instead |
|---|---|
| A secret, credential, or token | Nothing. Not redacted, not truncated, not inside an error string |
| Personal data | The opaque id of the subject, resolved by a reader that is entitled to it |
| A document, report, log, or diff body | Its id, plus only what a consumer routes on |
| A field a consumer "will probably want" | Nothing, until a stated need earns the field |

Two reasons this is a hard rule rather than a preference. A bus fans out to every subscriber at once, with a retention the producer does not control, which makes it the widest leak surface the platform has. And a payload inside an event is a second copy of a record its owner still holds, so it drifts the moment that record changes (universal violation 1); the pointer cannot drift.

---

## 6. Publishing is one-way

**A publish never blocks, slows, or fails the act that caused it.** A publish that fails is dropped and logged, and nothing else happens.

1. No producer's control or serving path may fail because the event transport is unavailable.
2. The causing act is **durable first**: the write commits, the pull request lands, the run finishes, and only then is the publish attempted.
3. A publish that cannot be delivered is dropped and logged at warning. It is never retried inside the caller's latency budget, never queued into unbounded memory, and never surfaced to the caller as an error.
4. No readiness probe, health check, or startup path depends on the transport being up.

This is the platform's observability rule applied to its bus: the layer that exists to watch the system never becomes load-bearing inside it. A studio whose onboarding fails because a broker is down is the exact failure this section exists to prevent.

**Stated testably**, so each producer's own suite attests it:

> With the event transport unreachable, every act that would publish completes with the same outcome, the same response, and the same durable state as it does with the transport up, and each dropped publish is logged.

The test binds the publisher port to a fake that raises, exercises the act, and asserts the outcome is unchanged and the failure logged (`REF-Tests.md`). A producer without that test has not implemented this section; it has only intended to.

---

## 7. Each app owns its publisher, and there is no client library

This REF is the only shared artifact. Every producer implements it in its own outbound adapter (`REF-OutboundAdapter.md`), and no shared publisher package exists.

- **Independent implementations of one contract are not duplication.** Universal violation 1 governs artifacts that must stay in sync; these need not. Two producers satisfying this REF may differ in transport, retry posture, batching, and serialization forever, and neither becomes wrong.
- **A shared client is coupling with a version number on it.** It hands every producer one outbound adapter, the dependency ports and adapters exists to invert; upgrading it becomes a platform-wide change, and its API becomes a second contract to keep aligned with this one.
- **The shape is small enough to own** (`REF-Authoring.md` §4): an envelope, a serializer, and a fire-and-forget send. A publisher is an outbound port and adapter like any other, so the domain states the fact and the adapter shapes the envelope.

---

## 8. The read model

- **Consuming is open.** Any app may subscribe to any type; §4 restricts publishing only. A producer never waits on, retries for, or reports on its consumers, and does not know they exist.
- **A consumer is durable or it is transient, and it knows which.** A durable consumer owns its cursor and replays within the transport's retention window. A transient consumer (a live view) misses whatever it was not connected for and refetches per `REF-Realtime.md` §2. Both are legitimate; a transient consumer whose correctness assumes it saw everything is not.
- **Handlers are idempotent**, keyed on `id`. Delivery is at-least-once, and order holds across neither types nor producers.
- **An event is a hint; the owner's API is the truth.** A consumer fetches the current state of `subject` rather than acting on `data` alone, which also goes stale in a retry queue (`REF-Realtime.md` §7 states the same rule for webhook deliveries).
- **A bus is not an audit log.** Retention is a channel property, ordering is best-effort, and §6 permits drops, so a stream can never answer "what happened". History comes from the owning app's own record, the only complete one, and `REF-Realtime.md` §2 says it plainly: an unbounded event log is a database, not a channel.

---

## 9. Anti-Patterns

| # | Anti-Pattern | Correct approach |
|---|---|---|
| 1 | A hand-rolled envelope, or a bare payload on a topic | CloudEvents with the attributes §2 requires |
| 2 | A command-shaped type (`...user.create`, `...run.start`) | Facts in the past tense (§1, §3); a command is an API call to the owner |
| 3 | A type composed at the call site, absent from the owner's page | Add it to the page and the publisher in one change; a type the owner has not stated is unpublishable (§3) |
| 4 | Naming the emitting app in `<domain>` | The domain is the bounded area, not the app; `source` already names the app (§3) |
| 5 | An app publishing about a domain it does not own | The owner publishes; ask it to (§4) |
| 6 | The record's body in `data`, to save the consumer a call | The fact and the pointer; the consumer fetches under its own authorization (§5) |
| 7 | A publish failure that blocks, retries inside, or fails the causing act | Drop it, log it, leave the act identical (§6) |
| 8 | A shared publisher client library every producer depends on | Each producer owns its adapter; this REF is the only shared artifact (§7) |
| 9 | Reading the stream to answer "what happened" (history, audit, reporting) | The owning app's own record is the only complete one (§8) |
| 10 | A consumer assuming it saw every event, in order, exactly once | Idempotent handlers keyed on `id`, plus refetch or reconciliation (§8) |
| 11 | A central table of every producer's types, in the playbook or anywhere else | Each owner states its own types on its own page, held by its own tests; the domain grant is the only cross-producer fact (§3) |

---

## 10. Skills that instantiate this REF

Generated by `scripts/sync_backlinks.py` from skill frontmatter; do not edit by hand.

Skills whose frontmatter `refs:` includes `REF-Events`:

- `foundry-onboard-events` - Grant an admitted application publishing rights over its owned event domains and verify its one-way publisher and isolation.
