---
domain: language
---

# REF: Java (Spring Boot - Hexagonal Architecture)

> When asked to create or modify Java code in a Spring Boot hexagonal project, follow these rules strictly. See `REF-CleanArchitecture.md` for the general architectural principles.

---

## 1. Project Structure - Multi-Module Maven

Maven modules align to hexagonal layers; each has its own `pom.xml`, so the dependency rule is enforced at **build** level - inner layers physically cannot import outer layers.

```
<project-root>/
├── pom.xml                          # Parent POM - module list, dependencyManagement
├── <name>-domain/                   # Innermost layer - pure business logic
│   └── src/main/java/<package>/domain/
├── <name>-application/              # Use cases + port interfaces
│   └── src/main/java/<package>/application/
├── <name>-adapter-in-<tech>/        # Inbound adapter (e.g. job, http)
│   └── src/main/java/<package>/adapter/in/<tech>/
├── <name>-adapter-out-<tech>/       # Outbound adapter (e.g. mongo, s3)
│   └── src/main/java/<package>/adapter/out/<tech>/
└── <name>-boot/                     # Composition root - Spring Boot launcher
    └── src/main/java/<package>/
        ├── <Name>Application.java   # @SpringBootApplication
        └── config/ApplicationConfig.java  # @Bean factory
```

### Module Dependency Rule

| Module | May Depend On | Must NOT Depend On |
|--------|--------------|-------------------|
| domain | stdlib, lombok | application, adapters, Spring |
| application | domain, slf4j, spring-context | adapters, Spring Boot starters |
| adapter-in-* | application (→ domain transitively) | other adapters |
| adapter-out-* | application (→ domain transitively) | other adapters |
| boot | application, all adapters | - (wires everything) |

---

## 2. Domain Layer

Pure Java. No Spring annotations, no framework imports.

- **Entities**: Regular classes with constructor validation (throw domain exceptions on invalid args). Use Lombok `@Data` for boilerplate.
- **Value Objects / Enums**: Plain Java enums for finite sets.
- **Exceptions**: Domain-specific hierarchy extending a common base exception.

---

## 3. Application Layer - Ports

### Inbound Ports

Interfaces declaring what the application **can do**. Located in `application/port/in/`.

- One port per use case (e.g. `DoSomethingPort`).
- Method signatures use **domain types**, not DTOs.

### Outbound Ports

Interfaces declaring what the application **needs from infrastructure**. Located in `application/port/out/`.

- Named as nouns: `Repository`, `Reader`, `Writer`, `Gateway`.
- Multiple methods per port are fine when they form a cohesive capability.
- Parameters and return types are domain types - never MongoDB documents, S3 objects, or DTOs.

---

## 4. Application Layer - Use Cases (Services)

Located in `application/service/`. Implements an inbound port.

```java
@Slf4j
@RequiredArgsConstructor
public class MyService implements DoSomethingPort {
    private final MyEntityRepository repository;
    private final SomeWriter writer;

    @Override
    public void execute(String inputId) {
        MyEntity entity = repository.findById(inputId)
            .orElseThrow(EntityNotFoundException::new);
        writer.write(entity);
    }
}
```

**Rules:**
- Constructor-injected outbound ports (via Lombok `@RequiredArgsConstructor`).
- **No `@Component` / `@Service`** - use cases are wired via `@Bean` in the boot module's `ApplicationConfig`.
- Use cases coordinate; they don't contain business logic.

---

## 5. Adapters - Inbound

Located in `adapter/in/<tech>/`. Translates external triggers into port calls.

- **Annotated with `@Component`** - Spring-managed (unlike use cases).
- Depends only on **inbound ports**, never on use case classes directly.
- Configuration via `@Value("${...}")` on fields.

---

## 6. Adapters - Outbound

Located in `adapter/out/<tech>/`. A `@Component` class implements the outbound port and maps between domain types and infrastructure types via a static mapper.

**Pattern: Document + Mapper + Spring Data Repository**

| File | Purpose |
|------|---------|
| `document/MyDocument.java` | MongoDB `@Document` / JPA `@Entity` - infrastructure DTO |
| `mapper/MyMapper.java` | Static methods: `toDomain(Document)` / `toDocument(Domain)` |
| `repositories/SpringDataRepository.java` | Spring Data interface (extends `MongoRepository`, etc.) |
| `MyEntityRepository.java` | Adapter class implementing the outbound port |

---

## 7. Boot Module - Composition Root

The boot module wires use cases to their dependencies in `config/ApplicationConfig.java`:

```java
@Configuration
public class ApplicationConfig {
    @Bean
    public DoSomethingPort doSomethingPort(
            MyEntityRepository repository,
            SomeWriter writer) {
        return new MyService(repository, writer);
    }
}
```

- Adapters are `@Component`-scanned automatically.
- Use cases are **explicitly wired** via `@Bean` methods - they never use `@Component`.

---

## 8. Configuration

Use Spring Boot's `application.yaml` (defaults + environment variable bindings) with profile-specific overrides: `application-local.yaml` (IDE development, localhost), `application-<env>.yaml`.

- Externalize all infrastructure coordinates (URIs, paths, feature flags) as `${ENV_VAR}` bindings.
- Local profile provides hardcoded defaults for zero-config IDE startup.

---

## 9. Swappable Adapters

When the same outbound port has multiple implementations (e.g. S3 vs. local filesystem), use Spring profiles or properties to activate one:

```java
@Component
@ConditionalOnProperty(name = "app.storage", havingValue = "s3")
public class S3DataReader implements DataReader { ... }

@Component
@ConditionalOnProperty(name = "app.storage", havingValue = "local", matchIfMissing = true)
public class LocalFileDataReader implements DataReader { ... }
```

`matchIfMissing = true` makes the local adapter the default - safe for development without any configuration.

---

## 10. Lombok Usage

| Annotation | Usage |
|-----------|-------|
| `@Data` | Domain entities (generates getters, setters, equals, hashCode, toString) |
| `@RequiredArgsConstructor` | Use cases and adapters - constructor injection for `final` fields |
| `@Slf4j` | All classes that log |
| `@Builder` | DTOs / documents where builder pattern aids readability |

---

## 11. Anti-Patterns

| # | Anti-Pattern | Correct Approach |
|---|-------------|------------------|
| 1 | `@Service` / `@Component` on a use case class | Wire via `@Bean` in `ApplicationConfig` |
| 2 | Adapter importing another adapter | Both depend on ports in the application layer |
| 3 | Domain class importing Spring annotations | Domain is pure Java + Lombok only |
| 4 | Outbound port returning infrastructure types (`Document`, `S3Object`) | Return domain types; adapter maps internally |
| 5 | Use case containing business logic directly | Push to domain entity methods or domain services |
| 6 | Hardcoded environment values in Java code | Use `@Value("${...}")` or `@ConfigurationProperties` |
| 7 | Single module with all layers in one source tree | Enforce layer boundaries with separate Maven modules |
