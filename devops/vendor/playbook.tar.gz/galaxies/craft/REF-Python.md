---
domain: language
---

# REF: Python Project Conventions

> When writing or modifying Python code, follow these rules strictly. They cover tooling, language features, style, and project setup.

---

## 1. Python Version & Compatibility

- **Runtime:** Python 3.13+ (development machine).
- **Target:** `py310` for ruff linting - avoid syntax exclusive to 3.11+ unless the feature is essential (e.g., `StrEnum` is 3.11+ but acceptable since we run 3.13).
- Always start every module with `from __future__ import annotations`.

---

## 2. Tooling

### Linter: ruff

```toml
[tool.ruff]
target-version = "py310"
line-length = 120

[tool.ruff.lint]
select = ["E", "F", "I", "UP", "B", "SIM"]
```

Run: `python -m ruff check .` (add `--fix` to auto-fix).

### Test runner: pytest

```toml
[tool.pytest.ini_options]
testpaths = ["tests"]
pythonpath = ["."]
```

Run: `python -m pytest -v`

### No additional tools

- No mypy (yet) - type hints are for documentation and IDE support.
- No black/autopep8 - ruff handles formatting rules via E/I/UP.
- No pre-commit hooks for *code quality* (yet) - ruff and pytest run ad-hoc or in CI. A repo-wide Conventional-Commit `commit-msg` hook is a separate concern: it validates commit messages, not code, and its policy belongs to the repository's contribution guidelines.

---

## 3. Module Structure

Every Python module follows this order:

```python
"""Module docstring - one line describing what this module provides."""

from __future__ import annotations          # 1. Future annotations (ALWAYS)

import stdlib_module                         # 2. Stdlib imports
from pathlib import Path

from third_party import Something            # 3. Third-party imports

from <package>.domain.model.thing import Thing  # 4. Local imports

__all__ = ["MyClass"]                        # 5. __all__ declaration


class MyClass:                               # 6. Code
    ...
```

Rules:
- `from __future__ import annotations` - **always first import, every file, no exceptions.**
- `__all__` - declared for every module with public symbols. Lists exactly what the module exports.

---

## 4. Type Hints

- **All function signatures** must have full type hints - parameters and return types.
- **No `Any`** unless absolutely unavoidable. If you need `Any`, that's usually a design smell.
- `TYPE_CHECKING` guard for imports only needed by type checkers, not at runtime.

---

## 5. Dataclasses

- Use `@dataclass(frozen=True)` for value objects and DTOs - immutability by default, stated explicitly, never by convention.
- Use plain `@dataclass` only for mutable aggregates/entities (e.g., `Project`).
- `field(default_factory=list)` for mutable defaults, never `= []`.

---

## 6. Enums

- Use `StrEnum` for string enumerations that need serialization (order statuses, output formats).
- Use plain `Enum` for enumerations that never leave the domain (confidence levels, priority levels).
- Enum classes live in `domain/model/`, one per file.

---

## 7. Logging

- **Single factory:** Use a project-level `get_logger` function - never raw `logging.getLogger`.
- **Single configuration:** `configure_logging()` called once at application startup.
- **Always use `__name__`:** `logger = get_logger(__name__)` at module level.
- **Levels:** Domain/services log at `DEBUG`. Adapters log at `INFO`.
- **Output:** `stderr` only. Never `print()` for diagnostic output.
- **Format:** `%(asctime)s  %(levelname)-5s  %(name)s  %(message)s`
- **Namespace:** All loggers under a single root namespace with `propagate=False`.
- **Emit logs, do not just configure them.** Wiring `configure_logging` / `get_logger` but never calling `logger.*` is a smell: configuration without emission. Every outbound adapter logs its I/O at INFO; every use case logs key outcomes at INFO (success) or WARNING / ERROR (failure); queries and pure reads log at DEBUG. A layer with zero log calls must be justified, not accidental.

---

## 8. One Class Per File

- **Every class** gets its own file. No multi-class files.
- File name is the `snake_case` version of the class name.
- Related classes still go in separate files - the one that depends on the other imports it.

| Smell                               | Fix                                                |
|--------------------------------------|----------------------------------------------------|
| `# --- OrderResultView ---`          | Move to `order_result_view.py`                     |
| Two dataclasses in one file          | Split into two files, one imports the other         |
| "But they're both small"             | Still separate files. Size doesn't matter.          |

### Scope

This rule is **absolute** for:
- Domain entities, value objects, enums
- Ports (Protocols)
- Use cases
- Exceptions

Adapter-internal types (dataclasses, DTOs, constants private to an adapter package) may be grouped by concern in a `models/` sub-package - infrastructure, not domain; the organizing principle is semantic navigability, not file count. See REF-OutboundAdapter §10.

---

## 9. Docstrings

- **Module docstrings are required**: one line stating what the module provides.
- **Class and public-method docstrings follow `REF-Documentation.md` §5**: write one where the name and signature don't already carry it (the class's role, the method's behavior and return value), skip it where they do, and never restate the identifier. One line usually suffices; let the signature's complexity set the length.
- Google/NumPy style `Args:`/`Returns:` sections for non-trivial signatures; stay within the line-length limit.

---

## 10. Dependencies

- Core dependencies minimal. **Never add a dependency without justification.** Prefer stdlib solutions.
- Adapters (e.g. HTTP) and dev tools go in `[project.optional-dependencies]`: `pip install .[http]`, `pip install .[dev]`.

---

## 11. Entry Point

```toml
[project.scripts]
myapp = "<package>.adapters.inbound.cli.__main__:main"
```

The CLI entry point is `main()` in `__main__.py`, which calls `dispatch()`.

---

## 12. Anti-Patterns

| #  | Anti-Pattern                          | Correct                                        |
|----|---------------------------------------|------------------------------------------------|
| 1  | Missing `from __future__ import annotations` | Always present, always first               |
| 2  | Raw `logging.getLogger()`            | Use project-level `get_logger`                 |
| 3  | Multiple classes in one file          | One class per file, always                     |
| 4  | Missing `__all__`                     | Declare it for every module with public symbols|
| 5  | `= []` as default parameter          | `field(default_factory=list)`                  |
| 6  | `Any` as a type hint                 | Find the real type or redesign                 |
| 7  | Logger configured but never used      | Emit `logger.*` in adapters and use cases (§7) |

## 13. Semantic Structure

Code should be self-explanatory. Names, files, and directories carry meaning - if you need a comment or a separator to explain *what* something is, the structure is wrong.

### Section separators are a refactoring signal

If a function or module contains section separator comments (`# ── Section ──`, `# --- Block ---`), it has too many responsibilities. Split along the separator boundaries - the need to label sections is evidence they belong in separate files.

### Files and directories communicate intent

- A **file name** should tell you what the module provides without opening it; a **directory tree** should tell you what the application does - without a README to narrate it.

### Name things for the reader

- Prefer descriptive names: `resolve_project_root.py` over `utils.py`.
- Avoid generic catch-all names (`helpers`, `utils`, `misc`, `common`) - they attract unrelated code. An existing narrow-scoped catch-all is acceptable only while every function in it belongs to the *same concern*.

---

## 14. Skills that instantiate this REF

Generated by `scripts/sync_backlinks.py` from skill frontmatter; do not edit by hand.

Skills whose frontmatter `refs:` includes `REF-Python`:

- `bootstrap-account-spine-python` - Add the account spine to an existing Python hexagonal FastAPI backend per REF-Identity: an opaque non-derived user id, an accounts table carrying the federation link, digest-only sessions, one session-resolution choke point, a guess budget, and the credential rung named explicitly with --rung (no default, because a scaffold that picks the rung is advocacy with a code generator attached).
- `bootstrap-data-pack` - Scaffold a new Data Pack at a given path.
- `bootstrap-hexagonal-backend` - Scaffold a new Python FastAPI service in hexagonal (ports and adapters) architecture, conforming to REF-CleanArchitecture / REF-FastAPI / REF-Python.
- `bootstrap-pytest-intent` - Scaffold pytest-intent into any Python project.
- `bootstrap-python-package` - Scaffold a new publishable-quality Python package conforming to REF-Python-Package.
