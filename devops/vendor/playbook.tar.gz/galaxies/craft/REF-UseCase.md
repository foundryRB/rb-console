---
domain: architecture
---

# REF: Use Case Construction

> When asked to create or modify a use case, follow these rules strictly. Use cases are the application layer's orchestration units.

---

## 1. What a Use Case Is

A use case is a **thin orchestrator**: it receives a request from an inbound adapter (via an inbound port), calls domain entities and outbound ports, and returns a domain result. A use case **never contains business logic** - all domain behavior lives in entities, value objects, or domain services.

---

## 2. Canonical Structure

```python
"""Use case: <imperative description of what this use case does>."""

from __future__ import annotations

from <package>.application.ports.outbound.order_repository import OrderRepository
from <package>.application.ports.outbound.invoice_writer import InvoiceWriter

__all__ = ["GenerateInvoice"]


class GenerateInvoice:
    """Generate an invoice for a completed order."""

    def __init__(self, repository: OrderRepository, writer: InvoiceWriter) -> None:
        self._repository = repository
        self._writer = writer

    def execute(self, order_id: str) -> Path:
        """Load the order and generate an invoice.

        Returns the path to the generated invoice.
        """
        order = self._repository.load(order_id)
        return self._writer.write(order)
```

---

## 3. Constructor Injection

- The constructor receives **outbound ports** (Protocol types in the signature - never concrete adapter classes).
- Store dependencies as private attributes: `self._repository`, `self._writer`.
- No default values for dependencies - they must always be provided (by the Container).

---

## 4. Single `execute()` Method

- Every use case has exactly one public method: `execute()`.
- The signature of `execute()` must match the corresponding inbound port.
- Use cases **implement** the inbound port Protocol implicitly - the Container's `_check()` verifies this at runtime.

---

## 5. Naming

| Element          | Convention                                       |
|------------------|--------------------------------------------------|
| File             | `snake_case` matching the use case class name    |
| Class            | `PascalCase` - imperative verb phrase            |
| Port it satisfies| Same name + `Port` suffix                        |

Example: `CreateOrder` in `create_order.py` satisfies `CreateOrderPort`.

---

## 6. What Goes Where

| Concern                                  | Where It Lives                     |
|------------------------------------------|------------------------------------|
| Loading an order from the database       | Outbound port (`OrderRepository`)      |
| Calculating pricing / discounts          | Domain entity (`Order`) or service |
| Computing line item subtotals            | Domain entity (`OrderItem`)        |
| Writing output files / invoices          | Outbound port (`InvoiceWriter`, etc.)|
| Deciding which steps to run              | Use case (orchestration)           |
| Validating that an order exists          | Repository raises domain exception |
| Converting domain result to HTTP/CLI DTO | Adapter mapper (not the use case)  |

---

## 7. Return Types

Use case `execute()` returns **domain types** - the same types declared in the inbound port (`int`, `Path`, `list[Path]`, or a domain value object like `OrderSummary` / `ProcessingResult`).

**Never** return adapter-specific types (Pydantic models, dicts with string keys, HTTP responses).

---

## 8. Supporting Value Objects

When a use case needs to return a composite result, create a **frozen dataclass** in `domain/model/` - return value objects always belong in the domain layer, never in the use case file.

---

## 9. Error Handling

- Use cases **do not catch domain exceptions** - they propagate to the adapter layer, whose exception handler/mapper translates them to HTTP status codes or CLI exit codes.
- To add context, a use case may catch and re-raise with a more specific domain exception.

---

## 10. Anti-Patterns

| #  | Anti-Pattern                                    | Correct Approach                           |
|----|-------------------------------------------------|--------------------------------------------|
| 1  | Business logic in the use case                  | Move to entity method or domain service    |
| 2  | Use case calling another use case               | Extract shared logic to domain/service     |
| 3  | Catching domain exceptions in the use case      | Let them propagate to the adapter          |
| 4  | Returning adapter-specific types                | Return domain types only                   |
| 5  | Defining a return-value dataclass in the UC file| Move it to `domain/model/`                 |
| 6  | Constructor with concrete adapter types         | Use outbound port Protocols                |
| 7  | Multiple public methods                         | Single `execute()` per use case            |
| 8  | Direct file I/O in the use case                 | Delegate to outbound port                  |
