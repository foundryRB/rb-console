---
domain: architecture
---

# REF: Inbound Adapter Construction (Hexagonal Architecture)

> When asked to create or modify an inbound adapter (CLI, HTTP, GraphQL, gRPC, etc.), follow these rules strictly.

---

## 1. Folder Structure

Each inbound adapter is a package under `adapters/inbound/<adapter>/` with these sub-packages as needed:

| Sub-package   | Purpose                                                                 |
|---------------|-------------------------------------------------------------------------|
| `commands/`   | Declarative command/route/endpoint specifications (one per file)        |
| `dtos/`       | Pure data containers for request/response shapes (one class per file)   |
| `mappers/`    | Domain-to-adapter translation functions (one per mapping concern)       |
| `utils/`      | Adapter-specific utilities (formatters, parser builders, etc.)          |
| `__main__.py` | Entry point; holds the top-level dispatch/bootstrap function directly - don't create a separate file for a single orchestrator function |

---

## 2. DTOs Are Pure Data Containers

- DTOs (Pydantic models, dataclasses, etc.) hold only field definitions and validation constraints.
- **Never** place `from_domain()`, `to_domain()`, or any mapping logic on a DTO.
- DTOs must not import domain types at runtime.

---

## 3. Mappers Are Mandatory and Explicit

- Every translation between a domain object and an adapter representation lives in a dedicated mapper function inside `mappers/`.
- One mapper file per mapping concern (e.g., `discover_mapper.py`, `summary_mapper.py`, `exception_mapper.py`).
- Mappers import domain types under `TYPE_CHECKING` where possible to avoid runtime coupling.
- **Mappers import DTOs from `dtos/` - they never define the DTO themselves.**
- **Exception-to-status-code** (HTTP) and **exception-to-exit-code** (CLI) mappings live in `mappers/exception_mapper.py` as a simple dictionary (`dict[type[DomainException], int]`), never inline in handler/runner code.

---

## 4. Handlers / Runners Are Thin

- A handler or runner file registers the mechanism (e.g., FastAPI `@app.exception_handler`, argparse dispatch) and imports the mapping dict from its mapper - it never defines the mapping itself.
- Prefer a single generic handler over one-handler-per-exception.

---

## 5. No Hidden Domain Coupling

- Formatters, presenters, and utilities never receive domain objects directly - a mapper sits between the domain result and the presentation layer.
- **Never use `Any` to hide a domain type.** Either map first so the function receives an adapter-layer type, or declare the domain type explicitly via `TYPE_CHECKING`.
- If a `CommandSpec` / route spec declares both a `mapper` and a `formatter`, the runner applies `mapper(domain_result)` first, then `formatter(mapped_result)`.

---

## 6. One Class / One Concern Per File

- One class per file. No god files. The urge to add a `# --- Section ---` comment is a signal the file should be split.
- **Never combine a DTO and a mapper in the same file** (see sections 2, 3, and 8).

---

## 7. Naming Must Be Semantic

File names describe what the module *is*, not what it *does superficially*.

| Bad               | Good                                 | Reason                                       |
|-------------------|--------------------------------------|----------------------------------------------|
| `exit_codes.py`   | `mappers/exception_mapper.py`        | It maps exceptions, not just "codes"         |
| `formatters.py`   | `utils/formatters.py`                | The folder provides the missing context      |
| `handlers.py`     | `exception_handlers.py` (if thin)    | Acceptable only if it's truly just handler registration; the mapping data lives elsewhere |

---

## 8. Adapter-Layer Intermediate Types

- When the domain model is complex, create an adapter-layer intermediate type (frozen dataclass, NamedTuple, or Pydantic model) in `dtos/` (one class per file). **Never define it inside the mapper file.**
- The mapper translates **domain → intermediate**; the formatter/serializer only knows the intermediate.

---

## 9. Adapters Can Be Simple

An adapter is defined by its **responsibility** (translating between external world and domain), not its **complexity**. A one-liner adapter is still an adapter - **don't skip the pattern because the code is short.**

---

## 10. Import Hygiene

- Adapter code never imports domain types at runtime when it can be avoided.
- Use `from __future__ import annotations` + `TYPE_CHECKING` blocks.
- Re-export from `__init__.py` when a package needs a public API, so consumers import from the package, not from internal files.

---

## 11. Reference Layout: CLI

```
cli/
├── __init__.py
├── __main__.py              # dispatch() + main()
├── commands/
│   ├── __init__.py          # re-exports Arg, CommandSpec, COMMANDS
│   ├── arg.py               # Arg dataclass
│   ├── command_spec.py      # CommandSpec dataclass (has mapper + formatter fields)
│   └── registry.py          # COMMANDS list
├── dtos/
│   ├── __init__.py
│   ├── order_result_view.py     # OrderResultView frozen dataclass
│   └── order_summary_view.py    # OrderSummaryView frozen dataclass
├── mappers/
│   ├── __init__.py
│   ├── exception_mapper.py  # EXIT_CODE_MAP dict
│   ├── order_mapper.py      # map_order_result() - imports DTOs from dtos/
│   └── summary_mapper.py    # map_summary() - imports SummaryView from dtos/
└── utils/
    ├── __init__.py
    ├── formatters.py        # format_paths(), format_summary(SummaryView), etc.
    ├── parser.py            # build_parser()
    └── runner.py            # run(spec, args)
```

---

## 12. Reference Layout: HTTP

```
http/
├── __init__.py
├── app.py                           # create_app() factory + get_container()
├── exception_handlers.py            # register_exception_handler() - thin, imports from mapper
├── dtos/
│   ├── __init__.py
│   ├── error_response.py
│   ├── order_response.py            # pure Pydantic model, no from_domain()
│   ├── create_order_request.py
│   ├── create_order_response.py
│   ├── payment_request.py
│   └── order_summary_response.py
├── mappers/
│   ├── __init__.py
│   ├── exception_mapper.py          # STATUS_MAP dict
│   ├── order_mapper.py              # map_order_response()
│   └── summary_mapper.py            # map_order_summary()
└── routers/
    ├── __init__.py
    ├── system.py
    ├── orders.py                    # calls mapper functions, not DTO.from_domain()
    └── payments.py
```

---

## 13. Skills that instantiate this REF

Generated by `scripts/sync_backlinks.py` from skill frontmatter; do not edit by hand.

Skills whose frontmatter `refs:` includes `REF-InboundAdapter`:

- `bootstrap-mcp-adapter` - Add an MCP inbound adapter to an existing hexagonal FastAPI backend: the tools-mirror-inbound-ports server module, streamable HTTP mounted on the same app, capability-derived tool registration, and a protocol-level integration test.
