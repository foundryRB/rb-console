---
domain: framework
---

# REF: React Conventions

> When writing or modifying React components, hooks, or styling, follow these rules strictly. TypeScript language conventions and the `@/` alias are `REF-TypeScript.md` §1 and §2. For architecture-level decisions (MVVM, Atomic Design, API layer), see `REF-Frontend.md`.

---

## 1. Component Patterns

### Functional Components Only

```typescript
export interface KpiCardProps {
    title: string;
    value: number;
}

export const KpiCard = ({ title, value }: KpiCardProps) => (
    <div className="rounded-lg border p-4">...</div>
);
```

Rules:
- **An arrow function with the props object typed in the signature** (`({ title, value }: KpiCardProps) =>`). The return type is inferred. A no-props component takes `()`.
- **`React.FC` is not the annotation** - it fixes the return type, obstructs generic components, and its historical implicit `children` is a footgun. Type the parameter, not the binding.
- **Props interface** defined above the component, in the same file, exported, and named `<ComponentName>Props`; the component's barrel re-exports it (`REF-Frontend.md` §9.3).
- **Object shapes are `interface`; unions and utility types are `type`.**
- **Destructure props** in the function signature - never access `props.x`.
- **No class components.** Ever.
- **JSDoc a prop when its name and type do not state the whole contract**: when a callback fires, the default an optional prop falls back to, a unit or a format. A self-describing prop gets none.
- **One responsibility per component.** A component file past ~150 lines is split. When its own type declarations are what makes it long, they move to `<ComponentName>.types.ts` instead (`REF-Frontend.md` §9.2) - the component itself is still one thing.

The arrow-function, interface, named-export, and no-`any` rules are enforced by lint (`REF-Frontend.md` §10.6); JSDoc and single responsibility are checked in review.

### Named Exports Only

Every component uses a named export - no exception for pages or barrels. `React.lazy` needs a default; map it at the import call site, never inside `views/`:

```typescript
// DashboardPage.tsx
export const DashboardPage = () => { ... };

// index.ts
export { DashboardPage } from './DashboardPage';

// App.tsx
const DashboardPage = lazy(() =>
    import('./views/pages/DashboardPage').then((m) => ({ default: m.DashboardPage })),
);
```

### One Tree per Width, Chosen in CSS

Visibility and layout of server-rendered chrome (navigation, tables, cards) switch in CSS: `hidden md:block` and `md:hidden`, both trees in the markup, no script and no hydration risk. A media-query hook (`useIsMobile`, `useMediaQuery`) chooses a tree only where the branches are different components that render client-side after they open (a Dialog against a Drawer, the Sidebar's Sheet). The server has no viewport, so a hook-chosen tree renders the desktop branch first and swaps after an effect: for visible layout that is a flash on every phone load. The phone line itself is `REF-PhoneLayout.md` §1.

---

## 2. Hooks

Custom hooks encapsulate reusable logic, named `use*`.

Rules:
- **Return `as const`** from custom hooks for stable return type inference.
- **`useMemo`** for derived/computed values - never `useEffect` + `useState` for derivable state.
- **`useCallback`** only for functions passed as props.
- **Never call hooks conditionally.**
- **`useParams`** for route parameters - never prop-drill route info.

---

## 3. State Management

Three kinds of state, three homes. Where a domain's data lives and how views reach it is architecture (`REF-Frontend.md` §4); this section is the React delta.

### Local State → `useState` / `useReducer`

For state that belongs to a single component or small subtree.

### Domain State → the SAM ViewModel

The data a route or an organism renders (entities, loading and error flags, derived values) lives in the domain's SAM ViewModel: the Zustand store of `REF-Frontend.md` §4, reached through the domain hook and its selectors. A domain has exactly one container; a Context that mirrors the store, a Redux slice, or a Jotai atom holding the same entities is a second one.

### App-wide Singletons → Context + Custom Hook

For the few cross-cutting values every view may read and no domain owns (auth session, theme, feature flags).
Global state providers (Contexts) live in `viewmodels/` because they expose
hook-shaped APIs that views consume - making them ViewModels in MVVM terms (`REF-Frontend.md` §1).
Expose a `useX()` hook that throws if called outside its Provider (e.g., `useAuth` in `viewmodels/useAuthViewModel.tsx`).

Rules:
- **No prop drilling** beyond 2 levels. If data passes through intermediate components that don't use it, call the owning ViewModel hook where the data is used, or restructure.
- **No second state library.** Domain state has one container (the store, above) and app-wide singletons one mechanism (Context + hook); Redux, Jotai, or a Context mirroring a store is a second container for the same data.

---

## 4. Styling with Tailwind CSS

### Utility-First

Tailwind utility classes only - no inline `style={{...}}`, no CSS modules.

### Conditional Classes with `cn()`

```typescript
import { cn } from '@/utils';

<span className={cn(
  "rounded-full px-2 py-0.5 text-xs font-medium",
  status === 'active' && "bg-green-100 text-green-800",
)}>
```

### Component Variants with CVA

For components with multiple visual variants, use **class-variance-authority** - not inline ternaries per variant:

```typescript
const badgeVariants = cva("rounded-full px-2 py-0.5 text-xs font-medium", {
  variants: {
    variant: { success: "bg-green-100 text-green-800", error: "bg-red-100 text-red-800" },
  },
  defaultVariants: { variant: "success" },
});

interface BadgeProps extends VariantProps<typeof badgeVariants> { children: React.ReactNode; }
```

### Phone Variants

Unprefixed utilities are the phone layout and `sm:` (640px) is the house phone line (`REF-PhoneLayout.md` §1). `hover:` applies only on hover-capable pointers, so a touch device never sees a hover state; `pointer-coarse:` carries the touch-target bump (`pointer-coarse:min-h-11`) without enlarging desktop controls; `motion-reduce:` and `motion-safe:` gate animation; `h-dvh` and `h-svh` replace `h-screen` on phones.

---

## 5. shadcn/ui Components

The project uses **shadcn/ui** - a collection of accessible component primitives built on Radix UI. They are the **primitive layer** of `REF-AtomicDesign.md` §2: domain-unaware, sitting below the ladder, wrapped by the atoms in `views/atoms/`.

Rules:
- Primitives live in `src/components/ui/`, written **only** by `npx shadcn add <name>` and read as regenerable output. The folder is in the repo, but the CLI owns its contents (`REF-Frontend.md` §1, §2).
- **Customize in the atom, not in the primitive.** Variants, class names, and domain meaning belong to the `views/atoms/` component that wraps it (`StatusBadge` over `Badge`). Look belongs to the design tokens (`REF-Design.md` §2), which restyle every primitive at once.
- **Fork down when a wrapper cannot reach it.** For a structural change (a slot inside the primitive's markup, different underlying elements), author the component as an atom in `views/atoms/` on raw elements or on the Radix primitive directly, and stop importing the shadcn one there. Editing `components/ui/` in place is the anti-pattern; owning the file in `views/` is the fix.
- The `utils` alias in `components.json` is `@/utils`, so the CLI's `cn()` lands at `src/utils.ts` and no `lib/` appears (`REF-Frontend.md` §1).
- Use Radix primitives (`@radix-ui/react-*`) for complex interactive components (dialogs, dropdowns, selects, tabs).
- Don't build custom implementations of components that Radix already solves (accessibility, keyboard nav, focus management).
- **What the primitive gives you is mechanics, not conformance.** Radix supplies the role, the keyboard behaviour, and the focus management; the accessible name, the programmatic state, the contrast of the focus ring, and everything in `REF-Accessibility.md` §2 to §8 remain the wrapping atom's and the project's. A hand-written atom in place of a primitive inherits all of it, focus trap and key handling included, which is why the rule above keeps the primitive (anti-pattern 12).
- **The Sidebar renders inside a Sheet below 768px** (`useIsMobile`, `MOBILE_BREAKPOINT = 768`, repeated as `md:` classes in its markup) and the Dialog-to-Drawer recipe branches at the same width. These rented JavaScript switches stay at 768 while authored markup follows the 640px line (`REF-PhoneLayout.md` §1), so the 640 to 767px band is a wide phone layout with sheet navigation, tested on purpose.
- **NavigationMenu has no phone mode.** It is hover-driven and ships no collapse. A top navigation built on it hides it below the line and adds a button labelled Menu that opens a Sheet holding the same links, closed on load (`REF-PhoneLayout.md` §2). A bottom bar is authored; the registry holds none.
- **Dialog on desktop, Drawer on the phone** is the recipe for a form-heavy dialog, one shared child in both branches. The Drawer is taken in its Base UI flavour; a plain `Sheet` with `side="bottom"` serves when no drag gesture is needed.

---

## 6. Testing

- **Vitest** as test runner (Vite-native).
- **React Testing Library** for component tests - test behavior, not implementation. No `enzyme`.
- **`@testing-library/jest-dom`** for DOM matchers.
- Test files: a component's `<ComponentName>.test.tsx` lives in its component folder (`REF-Frontend.md` §9.2); any other test sits next to the file it tests.
- **A connected component is tested through its store**: set the ViewModel's state with the store's own `setState()` before rendering, never mock the ViewModel module. Stories follow the same rule (`REF-Frontend.md` §5.1).
- **No snapshot tests** unless explicitly justified - brittle and hard to review.
- **Query by role and accessible name** (`getByRole('button', { name: /save/i })`), falling back to label text, then text. A test id is the last resort, for an element with no role and no name of its own. This is the cheapest accessibility gate there is: an icon button that lost its label fails a test instead of reaching review (`REF-Accessibility.md` §3).
- **Assert the rendered tree is free of accessibility violations** in page-level and organism-level tests: the runtime tier of `REF-Accessibility.md` §10, which also states what that tier cannot see (contrast, landmark structure).

---

## 7. Anti-Patterns

| #  | Anti-Pattern                                    | Correct Approach                            |
|----|-------------------------------------------------|---------------------------------------------|
| 1  | Class components                                | Functional components + hooks               |
| 2  | `useEffect` for derived state                   | `useMemo`                                    |
| 3  | Inline styles                                   | Tailwind utility classes                     |
| 4  | Prop drilling through 3+ layers                 | The owning ViewModel hook, or Context + hook for an app-wide singleton (§3) |
| 5  | A default export in a component file or its barrel | Named export; map it to `React.lazy`'s default at the route declaration instead (`REF-Frontend.md` §7, §9.3) |
| 6  | Snapshot tests                                   | Behavioral assertions with Testing Library   |
| 7  | Direct DOM manipulation                          | React state + refs                           |
| 8  | `index.tsx` as component filename               | PascalCase component name; `index.ts` is only the barrel (`REF-Frontend.md` §9.3) |
| 9  | `React.FC<Props>` on the binding                | Type the props parameter: `({ x }: Props) =>` |
| 10 | Hand-written files under `components/ui/`       | `npx shadcn add <name>` (`REF-Frontend.md` §2) |
| 11 | Querying by test id where a role and accessible name exist | `getByRole(role, { name })` (§6, `REF-Accessibility.md` §3) |
| 12 | A hand-rolled dialog, menu, combobox, or tab set | The Radix primitive; a fork inherits the focus trap and key handling (§5) |

---

## 8. Skills that instantiate this REF

Generated by `scripts/sync_backlinks.py` from skill frontmatter; do not edit by hand.

Skills whose frontmatter `refs:` includes `REF-React`:

- `bootstrap-account-spine-typescript` - Add the account spine to an existing TypeScript backend (domain/ plus adapters/{http,pg}) per REF-Identity: an opaque non-derived user id, an accounts table carrying the federation link, digest-only sessions, one session-resolution choke point, a guess budget, and the credential rung named explicitly with --rung (no default, because a scaffold that picks the rung is advocacy with a code generator attached).
- `bootstrap-atomic-mui` - Scaffold an Atomic-Design views/ tree (atoms, molecules, organisms, templates, pages) backed by MUI (@mui/material) primitives, per REF-AtomicDesign's levels, composition ladder, and purity gradient.
- `bootstrap-atomic-shadcn` - Scaffold an Atomic-Design views/ tree (atoms, molecules, organisms, templates, pages) backed by shadcn/ui primitives onto a React + Tailwind project, one exemplar per level demonstrating the composition ladder and purity gradient of REF-AtomicDesign; additive to an existing project, distinct from the whole-project bootstrap-react-mvvm.
- `bootstrap-pwa` - Make an existing Vite/React MVVM frontend installable per REF-PWA, in either of its two modes: --manifest-only (the app's identity on the device, no service worker) or the full PWA (a generated worker in prompt mode, the update banner, the auth-proxy denylist, the kill switch, the shell guard).
- `bootstrap-react-mvvm` - Scaffold a new React + TypeScript + Tailwind frontend in MVVM (Model / ViewModel / View) form per REF-Frontend and REF-React, with its Model layer generated from a given OpenAPI spec.
