---
domain: language
---

# REF: TypeScript (Hexagonal Architecture)

> When asked to create or modify TypeScript outside a React component tree, follow these rules strictly. Covers language conventions and the hexagonal instantiation in TypeScript. See `REF-CleanArchitecture.md` for the general architectural principles, and `REF-React.md` for React components, hooks and styling.

---

## 1. Language Configuration

- **Strict mode** enabled: `"strict": true` in `tsconfig.json`.
- **Target:** ES2020. **Module:** ESNext with bundler resolution.
- **No `any`.** Always provide explicit types. When a library ships none, write a `.d.ts` declaration.
- **No `enum`.** Use union types (`type Status = 'active' | 'inactive';`), which carry zero runtime code.
- **`import type` for types that cross a layer boundary.** A type-only import erases at compile time, so it creates no runtime edge. This is how an adapter names a domain type without importing the domain at runtime (§7).

---

## 2. Path Aliases

`@/` is the path alias for `src/`: `import { MyEntity } from '@/domain/model/MyEntity'`, never `'../../../domain/...'`. Declared in `tsconfig.json` under `"paths": { "@/*": ["./src/*"] }`, and mirrored in the bundler's resolver when one is present.

Aliases are per-layer, not per-file: a deep relative path is a symptom that a module sits in the wrong layer.

---

## 3. Project Structure

One tree serves both topologies (`REF-CleanArchitecture.md` §1). **The topology decides which inbound adapters exist, and nothing else.**

```
src/
├── domain/
│   ├── model/                    # entities, value objects, unions
│   ├── services/                 # stateless domain services
│   └── errors/                   # domain error hierarchy
├── application/
│   ├── ports/
│   │   ├── inbound/              # one interface per use case
│   │   └── outbound/             # interfaces for infrastructure contracts
│   └── useCases/                 # implement inbound ports
├── adapters/
│   ├── inbound/
│   │   ├── http/                 # a client-server core exposes this
│   │   ├── ui/                   # a standalone application exposes this
│   │   └── cli/                  # either may expose this
│   └── outbound/
│       ├── persistence/
│       └── <service>/            # one folder per external dependency
├── container.ts                  # composition root
└── index.ts                      # entry point: builds the container, starts an adapter
```

Rules:

- **One class or one interface per file**, named for the file (`REF-CleanArchitecture.md` §7).
- **Directories are categories, not containers** (`REF-CleanArchitecture.md` §2). The top two levels read like a table of contents.
- **A barrel `index.ts` re-exports a package that forms a public API** (the domain's errors, the domain's model, a React component folder per `REF-Frontend.md` §9.3). Ports are imported from their own files, so their dependency graph stays explicit.
- `adapters/inbound/ui/` is a view layer: its components follow `REF-AtomicDesign.md`, and its state layer follows `REF-Frontend.md` §4, which is a pattern for holding view state rather than a client-server one. What does **not** apply is that REF's generated Model layer (§3): a standalone application has no published contract to generate from, and its inbound ports are the contract already (§7).

---

## 4. Ports

Ports are interfaces. TypeScript's structural typing means a class satisfies a port by shape, so **`implements` is written explicitly** on the class: it is the assertion that gets checked, and it fails at compile time when a signature drifts.

### Inbound Ports

Declare what the application **can do**. One interface per use case, in `application/ports/inbound/`.

```typescript
// application/ports/inbound/DoSomethingPort.ts
import type { MyEntity } from '@/domain/model/MyEntity';

export interface DoSomethingPort {
    execute(id: string): Promise<MyEntity>;
}
```

- **`PascalCase` verb phrase plus a `Port` suffix, and the method is `execute`** (`REF-InboundPort.md` §7). No `I` prefix.
- Signatures use **domain types**, never adapter DTOs.

### Outbound Ports

Declare what the application **needs from outside**, in `application/ports/outbound/`.

```typescript
// application/ports/outbound/MyEntityRepository.ts
import type { MyEntity } from '@/domain/model/MyEntity';

export interface MyEntityRepository {
    findById(id: string): Promise<MyEntity | null>;
    save(entity: MyEntity): Promise<void>;
}
```

- Named as nouns: `Repository`, `Reader`, `Writer`, `Gateway`, `Clock`.
- Several methods per port are correct when they form one cohesive capability.
- Parameters and returns are domain types, never rows, HTTP payloads or SDK objects.

---

## 5. Use Cases

A use case implements one inbound port and coordinates domain objects and outbound ports. It holds no business logic: that lives in entities, value objects or domain services.

```typescript
// application/useCases/DoSomethingUseCase.ts
import type { DoSomethingPort } from '@/application/ports/inbound/DoSomethingPort';
import type { MyEntityRepository } from '@/application/ports/outbound/MyEntityRepository';
import type { EventPublisher } from '@/application/ports/outbound/EventPublisher';
import { EntityNotFound } from '@/domain/errors';
import type { MyEntity } from '@/domain/model/MyEntity';

export class DoSomethingUseCase implements DoSomethingPort {
    constructor(
        private readonly repository: MyEntityRepository,
        private readonly publisher: EventPublisher,
    ) {}

    async execute(id: string): Promise<MyEntity> {
        const entity = await this.repository.findById(id);
        if (entity === null) throw new EntityNotFound(id);
        entity.advance();
        await this.repository.save(entity);
        await this.publisher.publish(entity.events());
        return entity;
    }
}
```

Rules:

- **Outbound ports arrive by constructor injection**, typed as the port interface.
- **A use case never imports another use case.** Shared logic is a domain service (`REF-CleanArchitecture.md` §10).
- Errors are domain errors (`REF-ExceptionHandling.md`); an adapter maps them to its own vocabulary.

---

## 6. The Composition Root

`container.ts` is the only file that imports every layer.

```typescript
// container.ts
import type { DoSomethingPort } from '@/application/ports/inbound/DoSomethingPort';
import { DoSomethingUseCase } from '@/application/useCases/DoSomethingUseCase';
import { PostgresMyEntityRepository } from '@/adapters/outbound/persistence/PostgresMyEntityRepository';
import { QueueEventPublisher } from '@/adapters/outbound/queue/QueueEventPublisher';

export class Container {
    private readonly repository = new PostgresMyEntityRepository(this.config.databaseUrl);
    private readonly publisher = new QueueEventPublisher(this.config.queueUrl);

    constructor(private readonly config: Config) {}

    doSomething(): DoSomethingPort {
        return new DoSomethingUseCase(this.repository, this.publisher);
    }
}
```

Rules:

- **Outbound adapters are instantiated once** and shared.
- **Factory methods return the inbound port type**, never the concrete use case class, so an adapter cannot reach past the port.
- Configuration enters here and nowhere else; no module reads an environment variable for itself.
- Every inbound adapter receives the same container.

---

## 7. Adapters

### Inbound

Translate an external trigger into a port call. They depend on inbound ports only, never on a use case class.

| Topology | Adapter | Translates |
|---|---|---|
| Client-server | `adapters/inbound/http/` | request to port call, domain result to response |
| Standalone | `adapters/inbound/ui/` | user event to port call, domain result to rendered state |
| Either | `adapters/inbound/cli/` | argument vector to port call, domain result to output |

**A process boundary inside one deployable is a transport, not a layer.** When a standalone application splits across processes (a UI process and a host process holding the outbound adapters), the inbound ports are the contract that crosses. Derive the transport from the port declarations rather than hand-writing the surface once per process: a hand-kept copy on each side drifts, and drift there is silent (`AI-PLAYBOOK.md`, first violation).

### Outbound

Implement an outbound port and map between domain types and infrastructure types.

- One folder per external dependency, named for the dependency.
- A mapper is a separate function, never a method on a DTO (`REF-CleanArchitecture.md` §10).
- Infrastructure types never escape the adapter.

---

## 8. Testing

Layer the suite the way the code layers (`REF-Tests.md`):

- **Domain and use cases run with no I/O**, outbound ports substituted by in-memory implementations of the same interface. A use case needing a running dependency to be tested is a use case reaching past its ports.
- **Outbound adapters are tested against the real dependency**, one adapter at a time.
- **Boundary tests assert the dependency rule** by walking the import graph: nothing under `domain/` imports `application/` or `adapters/`, and nothing under `application/` imports `adapters/`. This is the category `REF-CleanArchitecture.md` §11 mandates.

---

## 9. Anti-Patterns

| # | Anti-Pattern | Correct Approach |
| - | ------------ | ---------------- |
| 1 | `I`-prefixed interface names | `DoSomethingPort` for an inbound port (`REF-InboundPort.md` §7), a capability noun for an outbound one (§4) |
| 2 | A runtime import of a domain type from an adapter that only names it | `import type`, which erases at compile time (§1) |
| 3 | A use case constructing its own outbound adapter | Constructor injection from the container (§5, §6) |
| 4 | The container returning a concrete use case type | Return the inbound port type (§6) |
| 5 | An adapter calling a use case class directly | Depend on the inbound port (§7) |
| 6 | A module reading an environment variable for itself | Configuration enters at the composition root (§6) |
| 7 | `enum` | Union types, which carry no runtime code (§1) |
| 8 | `any` to silence a boundary mismatch | Type the boundary; add a `.d.ts` when a library ships none (§1) |
| 9 | Hand-writing a process transport once per side | Derive it from the inbound ports (§7) |
| 10 | Business logic in a use case | Entities, value objects, or a domain service (§5) |
| 11 | Deep relative imports across layers | The `@/` alias; a deep path means the module sits in the wrong layer (§2) |

---

## 10. Skills that instantiate this REF

Generated by `scripts/sync_backlinks.py` from skill frontmatter; do not edit by hand.

Skills whose frontmatter `refs:` includes `REF-TypeScript`:

- `bootstrap-hexagonal-typescript` - Scaffold a new TypeScript application in hexagonal (ports and adapters) architecture per REF-TypeScript: domain / application / adapters layers, ports as interfaces, a container.ts composition root, one exemplar use case wired end to end, and boundary tests asserting the dependency rule.
