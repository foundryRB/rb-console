---
domain: methodology
---

# REF: Intent Bundle

> Read this when designing or applying a reusable Intent Bundle - a packaged, importable set of intent claims with their enforcement tests, applicable to projects that have `pytest-intent` installed. Bundles separate *declarative intent* (what must hold) from *bootstrap procedure* (how to set up a project), per Single Responsibility.

---

## 1. The unit

An **Intent Bundle** is a directory with a fixed shape:

```
skills/apply-intent-bundle/bundles/<topic>/
├── bundle.yaml             # metadata: name, version, applies-to, supported_runners
├── intent.yaml             # claims with prefixed IDs: INT-<TOPIC>-NNN - language-agnostic
├── impls/
│   ├── pytest/             # Python+pytest implementation
│   │   └── test_<topic>.py
│   └── vitest/             # JS+vitest implementation (when needed)
│       └── <topic>.test.ts
├── templates/              # optional: runner-agnostic page/scaffold templates (when needed)
│   └── <name>.md
└── README.md               # human prose: what this bundle covers, how it's applied
```

Every bundle ships **claims + their enforcement together**. They cannot drift apart because they live in one directory and are imported as one unit.

The `templates/` folder is optional. When present, it carries runner-agnostic scaffolds (for example per-`type` Starlight page templates) that conform to the bundle's own claims. Apply copies them into the target's `templates/` (see §6); for a Starlight site the target is the docs project itself, so they land beside its `intent.yaml`. Unlike `impls/`, templates are not runner-specific: they are content, not tests.

A bundle declares which test runners it supports (`bundle.yaml.supported_runners`). A bundle MAY support a single runner (e.g., a Starlight bundle with `vitest` only, a Data Pack bundle with `pytest` only) or multiple (a cross-cutting bundle shipping both). Bundles add new runners as the need arises - there's no obligation to support all languages at creation. The conceptual unit is the *claim*; impls are language-bound derivatives.

A bundle is *applied* to a target project by the `apply-intent-bundle` skill. The skill detects the target's runner (or accepts an override), picks the matching `impls/<runner>/` directory, and merges intent.yaml claims + copies impl files into the target. Target must already have the corresponding intent runtime installed (e.g., `pytest-intent` for `pytest`-impl bundles).

## 2. Why bundles are separate from bootstrap skills (Single Responsibility)

| Concern | Where it lives |
|---|---|
| Procedural setup (file creation, dependency installation, scaffolding) | `bootstrap-<thing>` Skill |
| Declarative claims (what correctness means for `<thing>`) | `<topic>` bundle |

These are different concerns with different lifecycles, audiences, and ownership:

- A bootstrap runs once per project. A bundle is consulted/refreshed multiple times.
- A bootstrap is procedural (AI runs it). A bundle is declarative (humans read claims, AI enforces them).
- A bootstrap may target one tech stack. A bundle's claims may apply to *any* project using that stack - including projects that weren't bootstrapped by us.

Mixing them in one Skill mostly works *until* you want to apply the intent to a non-bootstrapped project, update intent without re-running bootstrap, or audit "what does correctness look like for X?" without reading bootstrap procedure. The split makes all three trivial.

## 3. `bundle.yaml` schema

```yaml
name: <topic>                 # short uppercase, e.g. PYBASE, DATAPACK
version: 0.1.0                 # SemVer; auto-bumped via Conventional Commits once Git is in use
description: "<one-line>"
applies_to:                    # which Skills compose this bundle
  - bootstrap-<skill-1>
  - bootstrap-<skill-2>
supported_runners:             # which test runners this bundle ships impls for
  - pytest                     # implies impls/pytest/ exists
  # - vitest                   # add when a vitest-intent impl is shipped
requires:                      # other bundles this depends on (ordered)
  - <other-topic>              # optional
maintainer: "<owner>"
```

Fields:
- `name` - short uppercase. Used as the ID prefix (`INT-<NAME>-NNN`).
- `version` - SemVer. Manual today; Conventional-Commits-driven auto-bump once Git tracks the playbook (planned).
- `applies_to` - explicit list of Skill names that may compose this bundle. Prevents misapplication (`bootstrap-fastapi` shouldn't import the `STARLIGHT` bundle).
- `supported_runners` - list of test runners with implementations in `impls/<runner>/`. At least one entry required. Bundles MAY ship a single runner (e.g., `[vitest]` for a Starlight bundle) or multiple (a cross-cutting bundle). Add new runners as need arises - no obligation to ship all from day one.
- `requires` - bundles that must be applied first. Apply skill resolves these in topological order.

## 4. ID namespacing convention

All claim IDs in a bundle are prefixed: `INT-<NAME>-NNN`. Examples:
- `INT-PYBASE-001` - Python baseline bundle, claim 001
- `INT-DATAPACK-001` - Data Pack bundle, claim 001

When a bundle is applied to a project, the IDs are preserved verbatim. This means:
- A project may end up with `INT-PYBASE-001`, `INT-DATAPACK-001`, AND its own `INT-NNN` claims (project-local, no prefix).
- Cross-project consistency: every project that imports `PYBASE` has the same `INT-PYBASE-001` referencing the same canonical claim.

Project-local claims (the user's own, not from any bundle) use plain `INT-NNN` (no topic prefix). Bundle-imported claims always carry their topic prefix.

## 5. Versioning (today, and once Git is adopted)

**Today** (no Git in vault yet): `version` field in `bundle.yaml` is bumped by hand when claims change. Use SemVer: bump major when removing or renaming a claim, minor when adding a claim, patch for documentation/test fixes.

**Once Git is adopted:** authors use Conventional Commits (`feat(pybase):` for minor bumps, `fix(pybase):` for patch, `feat(pybase)!:` or `BREAKING CHANGE:` for major). A future tool (e.g. release-please configured per-bundle) reads commits, auto-bumps versions, generates per-bundle CHANGELOGs.

For now, document changes in the bundle's `README.md` "Changelog" section. Migrate to per-bundle `CHANGELOG.md` when Git lands.

## 6. The `apply-intent-bundle` Skill

A separate Skill that takes a bundle name and a target project, and:

1. Loads `<bundles-root>/<name>/bundle.yaml` (default: the bundles that ship with the skill, in its own `bundles/` folder, so they are wherever the skill is installed, a delivery pod included; `--bundles-root` reads a different set from disk, for developing a bundle).
2. Verifies the target has the matching intent-marker package installed:
   - pytest target: `tests/test_meta.py` exists and imports from `pytest_intent`.
   - vitest target: `package.json` declares `@psa-department-of-engineering/vitest-intent` in `devDependencies`.
3. Detects the target's runner (or honors `--runner`), and verifies the bundle declares support for it via `supported_runners`.
4. Recursively applies any `requires:` bundles first (topological order, cycle detection).
5. Merges the bundle's claims into the target's own `intent.yaml`, creating it when absent. Collision detection: if a bundle ID already exists in the target with a different definition, fail and report.
6. Copies `impls/<runner>/*` into the target's `tests/` directory. Refuses to overwrite an existing file with different content.
7. Copies `templates/*` (when the bundle has a `templates/` folder) into the target's `templates/` directory, creating it if missing. Same refuse-to-overwrite-with-different-content safety as the impl copy; same-content re-apply is a no-op. Templates are runner-agnostic, so this step runs regardless of the detected runner.
8. Prepends an audit header to the merged region: `# --- bundle: <name> v<version> (applied <iso-ts>) ---`.

Bundles are idempotent at the operation level - applying twice is a no-op (the second run finds everything already there with matching content).

There is no separate "compose" Skill. Composing multiple bundles into one project = invoking `apply-intent-bundle` multiple times with different names.

## 7. Bootstrap Skills that produce bundle-shaped content

When a bootstrap Skill ships starter intent claims (e.g. `bootstrap-data-pack` writes a starter `intent.yaml` and `test_*.py`), those are **not** a bundle - they live inline in the Skill's output, in the project. They're project-local intent.

A bundle is extracted only when:
- Two or more bootstrap Skills produce overlapping starter claims, OR
- A claim set is genuinely reusable across non-bootstrapped projects (e.g. "every Python file imports `from __future__ import annotations`").

Don't extract bundles speculatively. Inline starter content is the default.

## 8. Workflow examples

### Adding intent to an existing project that uses pytest

1. User runs `bootstrap-pytest-intent` to install the `@intent` decorator + scaffold `intent.yaml` (no `tests/test_meta.py` - auditing lives in the standalone `csd-intent` CLI).
2. User invokes `apply-intent-bundle --bundle pybase --target <project>` to import baseline Python claims.
3. Tests run. Failures = real drift between claims and code.
4. `csd-intent <project>` audits the spec + coverage cross-runtime.

### Bootstrapping a Python project with bundled intent from day one

1. `bootstrap-python-package <name>` scaffolds the package (no intent layer).
2. `bootstrap-pytest-intent <project>` adds pytest-intent.
3. `apply-intent-bundle --bundle pybase --target <project>` adds baseline Python claims.

Three Skills, each doing one thing. Composition done by the user (or by a wrapper Skill in the future, if invocation chaining gets repetitive).

## 9. Anti-patterns

| # | Anti-Pattern | Correct Approach |
| - | ------------ | ---------------- |
| 1 | Bundle ships claims without their enforcement tests | A bundle is intent + tests as one unit; never half. |
| 2 | Bundle uses unprefixed `INT-NNN` IDs | Every bundle ID is `INT-<TOPIC>-NNN`. Project-local intent uses plain `INT-NNN`. |
| 3 | Skill inlines intent that's actually shared with another Skill | Once shared, extract to a bundle. Inline is fine until shared. |
| 4 | Building a "compose-intent-bundles" Skill for orchestration | Composition = repeat invocation of `apply-intent-bundle`. |
| 5 | Cross-language bundles (Python tests for a JS project) | Separate ecosystems. Wait for `vitest-intent` (or analog) before bundling JS-side intent. |
| 6 | Missing `applies_to` in `bundle.yaml` | Every bundle declares which Skills may compose it. Prevents misapplication. |
| 7 | Inlining starter intent in a Skill, then duplicating across a second Skill | Once duplication appears, extract to a bundle and have both Skills compose it. |

## 10. Future work (deferred until triggered)

- **Vitest-intent analog** for JS/TS projects. Same conceptual model; different runtime.
- **Auto-bump SemVer** from Conventional Commits, once Git is in the vault.
- **Bundle dependency resolution** beyond simple `requires:` (e.g. cycle detection, version-range constraints) - only if dependency graphs grow non-trivially.
- **Bundle registry / published index** - publish bundles for cross-org consumption. Premature.

## 11. See also

- `REF-CSD.md` - methodology this builds on (Intent Specification, Intent Tests)
- `REF-Tests.md` - general test philosophy
- `../csd-library/pytest-intent/README.md` - the Python runtime that bundles target
- `../csd-library/vitest-intent/README.md` - the JS/TS runtime that bundles target

---

## 12. Skills that instantiate this REF

Generated by `scripts/sync_backlinks.py` from skill frontmatter; do not edit by hand.

Skills whose frontmatter `refs:` includes `REF-Intent-Bundle`:

- `apply-intent-bundle` - Apply a reusable Intent Bundle to a target project.
- `bootstrap-starlight` - Scaffold a new Starlight (Astro) documentation site with REF-StarlightDocs-aligned defaults.
