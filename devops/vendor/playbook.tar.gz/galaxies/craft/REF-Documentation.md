---
domain: practice
---

# REF: Documentation

> When writing or updating documentation (README, inline comments, docstrings, markdown files), follow these principles. We optimize for **usefulness and low maintenance cost**, not comprehensiveness.

---

## 1. Philosophy

- **Every sentence must earn its place.** Document what isn't obvious, not what the reader can already see (file tree, source, tooling).
- **Redundant information is a liability.** Forgotten duplicates become lies when the code changes - worse than no docs.
- **Explain the *why* and the *how to navigate*, not the *what*.** The *what* is the code.
- **Prefer stable over detailed.** Write at an abstraction level that survives refactors.

---

## 2. What To Write

| Write this | Because |
| ---------- | ------- |
| How to install, run, and test | Not inferable from the code |
| How to navigate the codebase (conceptual) | A table of "you want X → look in Y" saves time |
| Key design decisions and their rationale | Not visible in the code; prevents re-litigation |
| Extension recipes (brief, pattern-based) | Faster than reverse-engineering the pattern |
| Pointers to related guidance (skills, ADRs, architecture notes) | Discoverability without duplication |

---

## 3. What NOT To Write

| Don't write this | Because |
| --------------- | ------- |
| File-by-file tree listings | Stop at the folder level and explain what each folder *is* |
| Code samples that mirror actual source code | They drift immediately; read the real code instead |
| Badges that require manual updating | They go stale and mislead |
| Content that restates REF documents | Point to the REF instead |
| Exhaustive API references in markdown | Docstrings are the source of truth for API detail |
| Migration plans or historical context | Archive these; they clutter living docs |

---

## 4. README Structure

A project README answers these questions, in order:

1. **What is this?** - One or two sentences.
2. **How do I use it?** - Install, run, test. Copy-pasteable commands.
3. **How do I read the codebase?** - Annotated folder tree: stop at the folder, explain what it *is*.
4. **How do I extend it?** - Brief recipes for the most common extension points.
5. **Where do I learn more?** - Pointers to shared skills, ADRs, related docs.

A section that doesn't fit one of these probably doesn't belong.

---

## 5. Inline Documentation (Docstrings & Comments)

- **Module docstrings:** one line, present in every module.
- **Class docstrings:** only when the name and constructor signature aren't self-explanatory.
- **Method docstrings:** only for non-obvious behavior, complex parameters, or invariants.
- **Quality bar, for every docstring that exists:** it must say something the identifier and signature don't. `class ListHostsUseCase: """List hosts."""` restates the name and fails the bar - delete it, or write the non-obvious fact instead.
- **File-type REFs can require more:** a REF that prescribes a docstring's *content* for a specific file type (the port template in `REF-InboundPort.md` §7, the which-port line in `REF-OutboundAdapter.md` §3, the error condition in `REF-ExceptionHandling.md` §3, the config schema in `REF-PluginArchitecture.md` §2) makes it required for that file type; prescribed content clears the bar by construction.
- **Inline comments:** explain *why*, never *what* (`# Offset by 1 because TSV headers are 0-indexed`).

---

## 6. Maintenance Rule

When modifying code, check whether existing docs still hold; fix or delete - stale docs are actively harmful.

Do not create new documentation files as a side effect of code changes unless specifically requested.

---

## 7. Documentation Site Baseline (Generic)

### 7.1 Information Architecture

One overview page per section. Major content in stable, numbered groups. Stable URLs; avoid churn from renames. Drafts in a clearly separated area.

**Narrative spine.** A docs site is a reader journey, not a pile of pages. The information architecture reads as one continuous path from "why am I here" to "how do I do the specific thing". Every page ends by pointing onward: a "Read next" block that names the next page (or small set of pages) in the journey. A page that dead-ends with no onward link is a gap in the spine. The default journey is overview to architecture (on an application site, the module pages of §7.11) to flows to guides to reference to decisions; a section may reorder this where its subject demands, but the path is explicit, not left for the reader to reconstruct.

**Visual-first.** Where structure matters (a flow, a topology, a state machine, a data model), lead with a code-rendered diagram (Mermaid or PlantUML, per the platform default), then let prose annotate it. Prose annotates the diagram; it does not carry the structure on its own. If the only way to understand the shape of a thing is to read three paragraphs and assemble the picture in your head, the page is missing its diagram. The diagram is the primary artifact and is reviewable as source; the prose explains the parts the diagram cannot.

### 7.2 Metadata Contract

Required fields on every page: `title`, `id`, `type`, `status`, `updated`, `version`.

Validation: `id` unique site-wide; `type`/`status` from allowed enums; `updated` uses `YYYY-MM-DD`; `version` follows semver.

### 7.3 Content Taxonomy

Keep a small controlled type set with consistent semantics.

Recommended `type` values: `Overview`, `Guide`, `Standard`, `Reference`, `Template`, `Intent`, `Flow`, `Module`.

Recommended `status` values: `Draft`, `Active`, `Deprecated`.

### 7.4 Multi-Viewpoint Pages

When a topic has multiple equivalent viewpoints (business, functional, technical), keep one canonical page and switch viewpoint in-page. Do not split viewpoint variants into separate pages unless each is independently navigable. The default viewpoints are Business, Functional and Technical, in that order: the page's intro carries the overview, and a domain-specific viewpoint may follow the three.

### 7.5 Quality Gates

Every docs site enforces: markdown lint, metadata validation, internal link validation, unique ID validation, successful static build in CI.

### 7.6 Migration Rules

For migrations from legacy docs: inventory first, then convert metadata, then map navigation, then migrate rendering. Preserve user-facing URLs where practical. Prefer incremental cutovers over big-bang rewrites. Adapt existing doc tests to the new metadata format instead of deleting them.

### 7.7 Specialization Rule

Platform-specific skills (e.g. Starlight, Docusaurus, MkDocs) extend this baseline and define only platform deltas. Do not duplicate generic standards across platform skills.

### 7.8 Page-Structure Contract (All Docs)

Frontmatter is not the only thing that drifts. The *body* of a page drifts too: an Overview without its diagram, a Flow with no sequence, a Guide with no numbered steps. Metadata validation (§7.2) catches none of this, so every doc page has a per-type STRUCTURE skeleton, enforced by intent tests, holding the shape of a page in place the same way §7.2 holds its frontmatter.

The contract has two parts:

- **Universal shape (every page, every type).** A page opens with non-empty introductory prose before its first section, and has at least one section. An optional leading navigation or "Read next" block may precede the intro; what matters is that a reader meets prose, not a bare heading or an empty page. A page that is pure scaffolding (headings and lists with no connective prose) fails the contract.
- **Type-conditional shape.** Each `type` adds the structure its kind of page exists to carry: a **Flow** page has a code-rendered sequence diagram and a steps section (a "Steps" heading or an ordered list); a **Guide** page has a numbered procedure (an ordered list, or a run of numbered headings); a **Module** page, the low-level design (LLD) of its bounded context, carries the three viewpoints of §7.4, its domain model drawn, its failure modes and the claims it realises (§7.11); an **Overview** page leads with a diagram (§7.1 visual-first) and ends with onward links (§7.1 narrative spine).

Reusable enforcement: the **STARLIGHT bundle** (`skills/apply-intent-bundle/bundles/starlight/`) ships these as intent claims with their tests, plus per-type page templates so a new page starts in the right shape rather than being retrofitted into it. This generalizes the discipline of §8 (fixed per-type template, tests that hold structure in place, a tiny review surface, single-source content, generated views) from a set of similar things to *all* docs: §8 is the service-roster specialization of this general contract.

### 7.9 Docs Describe the Target; State and Rationale Live Elsewhere

A documentation site describes the target architecture as the only state it has ever had. It does not narrate change (per the change-narration rule in `AI-PLAYBOOK.md` Top Violations), and it does not track its own gaps. Three concerns live in three places:

- **The target** lives in the docs, written as the present and only reality.
- **Current state and the gap to the target** live in the project's own working tracker (a backlog, an issue tracker, a project note), never in the docs. The docs never say "not yet built" or "planned"; if something is not real, it is not in the docs as though it were.
- **The why** lives only in the decision log (ADRs or equivalent). Docs prose states what is, never why, and never links the decision log inline; a reader who wants rationale goes to the decisions section, which the docs reach as a destination on the spine, not as an inline citation.

This keeps each surface single-purpose and stops the docs from rotting into a change history.

### 7.10 Drift-Proof Anything That Mirrors a Source of Truth

Any page, table, list, or diagram that restates information owned elsewhere will drift. Two cures, in order of preference:

- **Generate it** from the source at build time (an index generated from a registry, a table generated from manifests), so it cannot diverge.
- **Intent-test it** against the source (a test that fails when the page and the source disagree), when generation is too lossy.

If a section can be neither generated nor tested, do not restate the source: link to it. A hand-maintained mirror of a live source is a drift surface, not documentation. Common offenders to generate or test: a registry-driven index, a component or namespace inventory, a decisions index, a secrets table.

### 7.11 The Application Documentation Set

> The application specialization of §7.8, as §8 is the service roster's: one site describing one system, with a fixed spine, so a reader always knows where a fact lives and a build always knows where a fact lands.

An application's site is a set of page types, each carrying one concern and the diagram its structure needs (§7.1). The set is what a delivery lands as documentation: the architecture target lives in the index and the module pages, the look in the brand page, and a build grows the set by adding pages of these types, never pages of a new kind.

| Concern | Page type | Home | What the page carries |
| ------- | --------- | ---- | --------------------- |
| The system at a glance | `Overview`, the index | the site root | intro prose; an At-a-glance topology diagram; a Read-next spine that reaches every folder below, the decisions collection included |
| The look | `Standard`, the brand page | `brand` | the visual identity as `REF-Design.md` §8 lands it: the logo, the palette and type as the real theme tokens |
| One bounded context: its low-level design (LLD) | `Module` | `modules/<module>` | the three viewpoints of §7.4 in-page: Business, Functional, Technical. The Technical viewpoint leads with the domain model drawn, then a lifecycle, the module's own ports and adapters, and its persistence, each only where the module has it; the HTTP surface as a table generated from the API's export or intent-tested against it (§7.10); then its failure modes (how the module fails and what its caller sees) and the claims it realises (the intent claim IDs, intent-tested against the application's `intent.yaml` so that every cited claim is an active one, §7.10) |
| One key sequence | `Flow` | `flows/<flow>` | a sequence diagram and its steps (§7.8) |
| The API and the configuration | `Reference` | `reference/` | tables generated from their source or intent-tested against it (§7.10) |
| Running and operating it | `Guide` | `operations/` | numbered procedures: run locally, deploy, and every runbook the operators need |
| The decisions | `Reference` for the index, one page per ADR | `decisions/` | the only home of the why (§7.9), reached from the index as a destination |
| The domain's words | `Reference` | `glossary` | one line per term |

Four rules hold across the set:

- **Draw what has structure, once per concept.** A topology is a flowchart, a domain model a class or entity diagram, a lifecycle a state diagram, a sequence a sequence diagram; prose annotates each (§7.1, §8.7). Reference stays tabular.
- **The why never leaves the decisions collection.** No page outside it names an ADR or links an individual decision; the index links the collection, and a reader who wants rationale goes there (§7.9).
- **Outside the decisions collection, the site describes the target as the only state it has.** No Active page carries state narration in its prose, the "not yet built" and "planned" of §7.9 included; what is not real is not on the site as though it were.
- **A module page follows its neighbours.** A site's module pages share one shape, so a new module starts from the module template and is read beside the modules already there.

The Module page is the LLD of its bounded context, and it holds the five things an LLD holds: what the module is (the Business viewpoint), its contract (the Functional viewpoint and the HTTP surface), its structure (the domain model, the lifecycle, the ports and adapters, the persistence), its failure modes and the claims it realises. It is a maintained page in the application's `docs/`, describing what is, and it stays true by derivation where derivable (§7.10) and by a CI freshness gate where not: the claims it realises are intent-tested against the application's `intent.yaml`, so a retired or renumbered claim fails the page.

The shape is held by the STARLIGHT bundle (§7.8): the `Module` type with its viewpoints-and-diagram claim, its failure-modes-and-claims claim and the freshness claim that reads the application's `intent.yaml`, the claim that keeps decisions in their collection, and the `module.mdx` template a new module starts from. The target-only rule is the reviewer's to hold, read against §7.9: no word list tells behaviour ("an item not yet stocked") from unfinished work.

---

## 8. Templated Service Documentation

> This section is the service-roster specialization of the general page-structure contract in §7.8: the same fixed-template-plus-tests discipline, scoped to sites whose leaf pages each describe one instance of a known pattern.

Applies to documenting a **set of similar things** (microservices, adapters, connectors, plugins); extends §7. Goal: each service page is **mostly mechanical**, so the review surface is tiny and deviations jump out.

### 8.1 The Single-Source Rule

One fact, one home. A fact appearing in more than one document requires exactly one of:

1. The extra copy is a **derived view** generated by a test or build-time plugin, **or**
2. The extra copy is a **cross-reference** ("see X"), never a restated table or paragraph, **or**
3. The duplication is **valuable** (e.g. an orientation summary table) and **covered by a consistency test** that fails on drift.

If none of the above holds, delete one of the copies.

### 8.2 The Canonical-Home Decision

Before writing a fact on a service page, ask:

- Is it **true for every service of this kind**? → platform/introduction page or the relevant feature page. Service page does not repeat it.
- Is it **true for services that implement feature X**? → feature X's page. Service page lists `feature X: ✓` and nothing else.
- Is it **a deviation from the platform default**? → service page, in a dedicated "Deviations" section.
- Is it **genuinely service-specific** (e.g. a backend field mapping table for this API)? → service page.

A disciplined service page is mostly deviations plus service-specific facts.

### 8.3 Service Page Template

A service page should, in order, contain:

1. **Quick Reference** - identifiers (repo, artifact, URL, version, status).
2. **Feature Checklist** - one row per platform feature (`✓ / partial / n/a`), note only where behaviour deviates; feature name links to its canonical page.
3. **Deviations** - one table listing every departure from the feature/platform default. Columns: *Deviation*, *Current*, *Expected*, *Impact / Reason*.
4. **Service-specific sections** - e.g. API endpoints, request/response mappings, non-default SLOs. Factual; no primers, no restatements of standard patterns.

These **do not belong on a service page** if the platform defines them:

- stakeholders, default SLOs, default error taxonomy (unless the service diverges/adds)
- architecture primers, IAM prose, CI/CD scaffolding prose
- diagrams that illustrate a pattern rather than this service's topology

### 8.4 Deviation Discipline

Deviations are the most valuable content on a service page:

- Exactly one deviations table per service. If two exist, they drift. Collapse.
- Every row cites the specific file, module, or config key where the deviation lives.
- Present-tense, factual language ("module merges domain and application layers"), not value-laden prose ("has poor separation").
- A resolved deviation is deleted, not struck through. The change log captures history.

### 8.5 "Valuable Duplicates" and Their Tests

Cross-page duplication that aids discovery is allowed only with a test asserting the copies agree; without the test it is just a duplicate. Typical cases:

- **Feature → Services matrix** duplicates the per-service checklist. Test: every feature tagged on a service page appears on the matrix and vice versa.
- **Platform component list** on the root overview duplicates per-service headers. Test: every directory under services has a matching row.
- **Summary counts** inevitably drift. Generate at build time or delete.

#### 8.5.1 Enumeration Drift

A page that enumerates services by name duplicates the canonical roster and drifts silently when a service is added.

Rule: a page enumerating ≥3 services of a family lists **all** of them, or carries an explicit `Does NOT apply to:` block naming each omission with a one-line reason. No implicit omissions.

Enforce with a drift test that parses the canonical roster from the services overview (not a hardcoded list in the test), collects service references from each enumeration-prone page, and fails if a page references some but not all family members without an explicit exclusion block.

This generalises to any roster-style duplication: tenants, environments, regions, API families.

### 8.6 Typical AI Tells to Avoid

Signs of padding rather than informing. Rewrite or delete:

- Marketing adjectives: *robust*, *seamless*, *comprehensive*, *cutting-edge*, *leverage*, *empower*.
- Filler openers: "It is worth noting that…", "In essence,…", "As mentioned above,…".
- Em-dashes (-). Use commas, periods, colons, or regular dashes.
- Every table cell bolded (bold everywhere is no emphasis).
- Headings that contain only a "see also" link. Inline the link instead.
- Bullet lists where every bullet starts with the same verb. Collapse to prose or a table.
- "In this section we will…" scaffolding. Just say the thing.

Everything above is padding, deletable on sight. Prose that is *about* the subject and still says nothing new is a different class and takes a different test: §8.6.1. A paragraph restating the preceding table belongs there, not in the list above; deleting it on sight is the wrong correction, because the same slot can hold the only description a reader gets.

#### 8.6.1 Descriptors vs. Narration

Some sentences look substantive because they are about the subject, yet tell the reader nothing they did not already have. A word list cannot catch them; the same sentence position can hold either of two things, so the test is a property, not a form:

- **A descriptor** says what a thing does, for a reader who cannot read the notation or does not know the domain. It earns its place.
- **Narration** comments on the thing, restates what sits beside it, or explains something the reader already knows. It does not.

Beside `R = Σ span seconds`: "The total is its spans" is narration (the formula in words); "Add up the seconds of every span" is a descriptor (reads the notation aloud for someone who cannot). Beside a control whose value is visible, the correct prose is often nothing: the control is the description.

The sub-shapes narration takes:

| Shape | Example |
| ----- | ------- |
| Restating the adjacent artefact | A note saying what the formula, table, field, or control beside it already says. The paragraph restating the preceding table is one case; the shape generalises past tables to any adjacent artefact |
| The negated-counterpart coda | A closing clause defining a thing by what it is not: "It resets no X and replaces no Y". Appears as *never*, *no*, *nothing*, *neither*, *not a*; a sweep for one form misses the rest |
| Explaining the domain to a domain expert | Defining a term the stated audience already knows. Audience-dependent, so no word list can hold it |
| Change narration | Prose documenting a correction the author made rather than the subject itself |

On finding narration, **replace it with a descriptor** (or with nothing, when the artefact describes itself); never blanket-delete short prose. Some of these sentences are the only description a reader gets, and a cut-on-sight sweep removes genuine descriptors along with the narration.

### 8.7 Diagrams

- Code-rendered diagrams (PlantUML or equivalent) over ASCII art or hand-drawn images; diagrams are source code and must be reviewable.
- One diagram per concept. If a second diagram mostly re-shows the first, delete it.
- Service-level diagrams show this service's topology; feature-level diagrams show the pattern. Do not put the pattern diagram on every service.

### 8.8 Multi-Viewpoint Pages and the Right-Hand TOC

On a multi-tab page (see §7.4 and the Starlight specialization), **disable the in-page TOC** (e.g. `tableOfContents: false` in Starlight frontmatter) - it concatenates headings from every tab. The tabs are the primary navigation.

### 8.9 Quality Gates for Templated Service Documentation

In addition to §7.5, enforce:

- Every service page has the required frontmatter fields and `features:` declared.
- No banned-duplicate section titles (e.g. "Stakeholders", "Default SLOs", "Standard Errors") unless marked as a deviation.
- Matrix consistency: every feature tagged on a service appears on that feature's page, and vice versa.
- No broken internal links; link tests run against the built HTML, not just markdown source.
- No em-dashes in authored markdown (lint rule).

### 8.10 The Review Surface Principle

Optimise for: *what does a human reviewer actually need to read?* With a fixed template and structure tests, the reviewer reads only the short prose at the top, the deviations, and the service-specific data. If reviewers read generic prose on every service page, the template has failed.

---

## 9. Skills that instantiate this REF

Generated by `scripts/sync_backlinks.py` from skill frontmatter; do not edit by hand.

Skills whose frontmatter `refs:` includes `REF-Documentation`:

- `bootstrap-python-package` - Scaffold a new publishable-quality Python package conforming to REF-Python-Package.
- `bootstrap-starlight` - Scaffold a new Starlight (Astro) documentation site with REF-StarlightDocs-aligned defaults.
- `reconcile-docs` - Audit a repo's docs/, plus any published flyer that makes claims about it, against its code, and file every drift found as a ticket (operator-confirmed): the docs-reconciliation activity of REF-Maintenance.

---

## 10. Agents that orbit this REF

Generated by `scripts/sync_backlinks.py` from agent frontmatter; do not edit by hand.

Agents whose frontmatter `refs:` includes `REF-Documentation`:

- `programmer` - Works the maintenance loop: sweeps the inbox, takes one ticket to a pull request, audits docs against code; hand it a ticket, a repo to sweep, or docs to reconcile.
