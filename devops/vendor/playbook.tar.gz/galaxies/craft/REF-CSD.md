---
domain: methodology
---

# REF: CSD (Cognitive Software Delivery)

> Read this when working on any project that adopts CSD or any of its concepts (Intent Specification, Intent Tests, Synthesis Governance, Emergent Intent, Trust Calibration). The methodology itself lives in its canonical source and is routed to, never restated here; what this REF holds beyond that routing is the doctrine earned applying it - reviewing a claim set as a system (§5), and deriving claims from an agreed scope (§6).

---

## 1. Canonical source

The CSD methodology is documented at:

- **`../cognitive-software-delivery/src/content/docs/`** - sibling repo, local docs site (Astro/Starlight)
- Index: `00-OVERVIEW.md`
- Children: `01-INTENT/`, `02-TESTING/`, `03-TEAMS/`, `04-LIFECYCLE/`, `05-TEMPLATES/`, `06-ADOPTION/`, `07-CONTRIBUTING/`

Read those directly when you need detail. This REF only summarizes enough to route by.

## 2. The five concepts (one-liner each)

| Concept | One-liner |
|---|---|
| **Intent Specification** | Human-owned, machine-checkable truth statements (`INT-NNN`, or `INT-PREFIX-NNN` in monorepos) about what must be true for the system to be correct. AI may draft; humans must approve. |
| **Intent Tests** | Executable validations that bind claims to runnable code via `intent` markers. Every active claim has at least one attesting test; one test may attest several claims. The exception is `llm` scope (section 3). |
| **Synthesis Governance** | Constraints that *participate in execution*, not just sit in documentation. Linters, validators, schema checks, etc. |
| **Emergent Intent** | Intent discovered from synthesis failures, crystallized into permanent constraints. Not all intent is upfront. |
| **Trust Calibration** | Right-level validation per artifact type - not everything needs human review of every byte. Mechanical artifacts (frontmatter, file moves) auto-trusted; semantic claims gated by intent tests. |

## 3. Intent Specification format

Claims live in a single `intent.yaml` at the project root; the claim ID is the YAML key:

```yaml
INT-001:
  version: 1.0.0
  status: active
  statement: "Session data must never cross user boundaries"
  test:
    scope: unit
    component: SessionService
    type: invariant
  criticality: critical
```

Required per claim: `version`, `status`, `statement`, `test` (`scope`/`component`/`type`), `criticality`; `rationale` recommended. Normally paired with an executable test carrying the claim's `intent` marker. The normative schema is CSD-INTENT-01 in the canonical source (section 1).

**`llm` is the fourth scope, for a claim no runner can decide.** `unit`, `integration` and `e2e` are degrees of isolation for a test that executes; `llm` names a claim that is a proposition about *meaning* - whether a statement is falsifiable, whether an error message explains its failure, whether a document says what it claims to say. A mechanical check for one of those is an approximation standing in for a judgement, and its green means nothing, so the standard names the case rather than forcing a test.

Such a claim is attested by a **current PASS review** in its `intent.yaml` entry, per CSD-INTENT-01 §3.5. The `review` mapping contains exactly `commit` and `verdict`, holding the latest judgement and the full commit the reviewer read. A new review replaces it; Git holds its history. The reasoning lives in the reviewer's PR or delivery record. Freshness compares repository content with the reviewed commit, excluding specification `review` and lifecycle `status` fields. Other content changes make it stale. An active claim with a missing, FAIL, stale, or unreadable review is unattested. The claim carries **no test marker**; a marker on it is a violation. CI validates the record and freshness without calling a model.

Reach for it only when a runner genuinely cannot decide the claim. When one can, the ladder applies and the smallest rung wins.

## 4. When to apply CSD

Anywhere AI participates in synthesis:

- Code generation → intent tests guard correctness
- Data authoring → intent tests guard structural integrity (see `REF-DataPack.md`)
- Doc generation → intent tests guard claims and links
- Visual generation (slides, components) → templates with baked-in constraints (see `REF-Slidev.md`)

## 5. The duplication trap

Duplicating CSD content into other docs creates drift between this REF and the canonical CSD site. **Don't.** This REF is a router; CSD itself is the source of truth. Per `AI-PLAYBOOK.md` Top Violation #1 - no hand-edited copies of artifacts that must stay in sync.

If you find yourself wanting to summarize CSD content here, stop and ask whether the summary is going to drift. If yes, link to the source instead.

**The contradiction trap (claim-set review).** Claims are checked against the code and almost never against each other - and two individually true, individually attested claims can describe different products. The observed case: one claim ended a match when fewer than two players were alive, another promised respawn three seconds after death *so the match stays playable*; both fired at the same instant, the end condition won, and the respawn loop was unreachable in a two-player room while every test passed. When authoring or revving a claim set, walk the pairs that can fire at the same instant or govern the same state: where two rules meet, the **evaluation order is the real rule**, and it belongs in a claim - the set is reviewed as a system, not as a list.

## 6. Deriving claims from a scoped requirement set

Where a project's requirements arrive as an agreed scope - a proposal, a statement of work, a requirements register - the claims are **derived** from it rather than invented beside it, and the derivation is recorded. This is the bridge between what was agreed and what is attested.

- **Every claim records what it came from.** `derived_from` carries the requirement IDs the claim attests. Those IDs are the spine the whole delivery traces to; a claim with no derivation is one nobody agreed to.
- **Every requirement maps to at least one claim, or is explicitly descoped in writing.** No silent drops. Requirements already delivered carry their claims and are never re-derived or regressed; requirements quoted ahead wait for their own delivery.
- **A claim statement is attestable by the planned test surface, and names the level that attests it** - unit, integration, or e2e - with whatever is untestable named and handled some other way. A claim only a human eyeball can attest will be faked or stalled on by an unattended run.
- **An e2e claim is either self-contained or deployed.** Self-contained runs against the app's own stack and attests app behaviour; deployed runs against the live install and attests what only realm, edge, and release configuration can fail on. A deployed claim's credential stays where the deployment keeps it, attested through a contract that publishes only the verdict, and is never carried into a source-host secret store: a credential a person must type is a human gate on the evidence path.
- **An access-control capability prices a positive claim, one per shipped surface.** "An unauthenticated request is rejected" attests failing *closed*, a different proposition from a user getting *in*: every claim can be active, the capability present, and the front door still broken. Each shipped surface carries its own, because a packaged client on its own origin cannot ride another surface's session. Attest against the deployed provider rather than a mock - the failures this catches (a confidential client answering a public flow, an unregistered redirect URI) live in the provider's own configuration, where a mock passes and the shipped app still cannot sign in - and keep it headless with a provider-local test user.
- **The claims table doubles as the acceptance spec.** Statement plus requirement trace is what the work is demonstrated and accepted against, so it is written to be read by whoever signs it off, not only by the test runner.
- **An active claim names where its suite runs.** The intent audit is a static marker scan: it proves a claim is *referenced* by a test, never that the test executes, so attestation is a run somewhere real. The surface is a choice - a shared CI, the team's own, or a deliberate periodic or manual protocol with its last run evidenced - but what is never attestation is a suite **nothing runs**: tests that executed once on one workstation are invisible to the audit either way. When confirming claims, name each active claim's run surface; "no surface" is a finding, not a formality.
- **A scope change appends to the agreed scope; it never rewrites it.** New requirement IDs are minted and existing ones are never mutated, the scope is re-audited, affected claims rev per the canonical lifecycle rules, and any plan written against the old set is amended before work continues on it. Mutating an ID to absorb a change destroys the trace between what was agreed and what was built, which is the one thing this derivation exists to keep.

## 7. Cross-references

- `REF-DataPack.md` - applying CSD to plaintext-data validation
- `REF-Tests.md` - general test philosophy (engine code); CSD's Intent Tests slot under this
- `REF-Slidev.md` - applying CSD-style template-and-fill to slide generation
- Keystone - a delivery unit built on CSD (not CSD itself); maintained as a separate project

---

## 8. Skills that instantiate this REF

Generated by `scripts/sync_backlinks.py` from skill frontmatter; do not edit by hand.

Skills whose frontmatter `refs:` includes `REF-CSD`:

- `apply-intent-bundle` - Apply a reusable Intent Bundle to a target project.
- `audit-intent` - Audit any CSD intent project - validate intent.yaml against CSD-INTENT-01, check that every @intent / intent() test marker references a real claim, and report unattested claims.
- `bootstrap-data-pack` - Scaffold a new Data Pack at a given path.
- `bootstrap-observable-dashboard` - Scaffold an Observable Framework dashboard project against an existing Data Pack.
- `bootstrap-playwright-intent` - Scaffold Playwright + playwright-intent into a frontend project - install both packages, drop a CSD-INTENT-01 canonical intent.yaml stub (if missing), a playwright.config.ts, and an e2e/ directory with an example intent() test.
- `bootstrap-pytest-intent` - Scaffold pytest-intent into any Python project.
- `bootstrap-starlight` - Scaffold a new Starlight (Astro) documentation site with REF-StarlightDocs-aligned defaults.
- `bootstrap-vitest-intent` - Scaffold vitest-intent into any JS/TS project - install the package, write an intent.yaml stub and an example intent() test.
- `intent-session` - Run the intent-and-plan phase per REF-Delivery: drive CSD intent authoring to write intent.yaml and its tests against the proposal requirement IDs, then assemble the committed one-shot build handoff (.delivery/handoff.md) against that test surface, run a fresh-eyes adversarial review of both, and close the plan gate.

---

## 9. Agents that orbit this REF

Generated by `scripts/sync_backlinks.py` from agent frontmatter; do not edit by hand.

Agents whose frontmatter `refs:` includes `REF-CSD`:

- `planner` - Writes the intent claims and their tests, then the build handoff; hand it an engagement whose visual identity is locked.
