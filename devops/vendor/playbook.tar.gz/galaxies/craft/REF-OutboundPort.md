---
domain: architecture
---

# REF: Outbound Port Construction

> When asked to create or modify an outbound port (the Protocol that a use case depends on and an outbound adapter implements), follow these rules strictly.

---

## 1. What an Outbound Port Is

The Protocol contract for infrastructure operations (persistence, document generation, external service calls) that use cases need but must not implement directly. Use cases depend on the Protocol; outbound adapters implement it; the Container wires them together.

---

## 2. One Port Per File

Each outbound port lives in its own file under `application/ports/outbound/`.

| Convention          | Example                                     |
|---------------------|---------------------------------------------|
| File name           | `invoice_writer.py` (snake_case noun phrase)|
| Class name          | `InvoiceWriter` (PascalCase, descriptive)   |
| `__all__`           | `["InvoiceWriter"]`                         |

Outbound ports use **noun-based** names (Writer, Reader, Repository, Gateway, Service) describing what the port *is*; inbound ports use verb-based names describing what they *do*.

---

## 3. Canonical File Template

```python
"""Port: <noun phrase describing the infrastructure contract>."""

from __future__ import annotations

from pathlib import Path
from typing import Protocol

from <package>.domain.model.order import Order

__all__ = ["InvoiceWriter"]


class InvoiceWriter(Protocol):
    """Generate invoice documents from the order domain model."""

    def write(self, order: Order) -> Path:
        """Write an invoice for the given order.

        Returns the path to the generated invoice.
        """
        ...
```

Key differences from inbound ports:
- **No `@runtime_checkable`** - outbound ports are not checked via `isinstance()`.
- **Multiple methods allowed** - several related operations may share one port (e.g., `OrderRepository.load()/exists()/save()`).
- **Method names are domain-specific** - not `execute()` but `write()`, `load()`, `charge()`, etc.

---

## 4. Parameters and Return Types Use Domain Types

Outbound ports speak the **domain language** - never infrastructure shapes like `dict` or `dict[str, Any]`:

```python
def write(self, order: Order) -> Path: ...
def charge(self, amount: Money, method: PaymentMethod) -> PaymentResult: ...
```

Outbound ports **import domain types directly** - they are part of the application layer and need domain types resolved in the Protocol signature.

---

## 5. Granularity

Design outbound ports around **capability boundaries**, not adapter implementation details (see the examples table in section 8). Consolidate read/write into a single port when all consumers naturally need both sides (e.g., one `OrderRepository` rather than a Reader/Writer split).

---

## 6. The `__init__.py` Package

Like inbound ports, the `__init__.py` contains only a docstring - no re-exports:

```python
"""Outbound ports - infrastructure contracts that use cases depend on.

Use cases declare dependencies on these protocols. Outbound adapters
implement them. The Container wires adapters to use cases.
"""
```

Consumers import from the specific file: `from <package>.application.ports.outbound.invoice_writer import InvoiceWriter`.

---

## 7. Anti-Patterns

| #  | Anti-Pattern                                    | Correct Approach                              |
|----|-------------------------------------------------|--------------------------------------------|
| 1  | `@runtime_checkable` on outbound port           | Not needed - only inbound ports need it    |
| 2  | Infrastructure types in signature (`dict`, `str` path) | Use domain types (`Project`, `Path`) |
| 3  | Port named after implementation (`PostgresWriter`)| Name after capability (`OrderRepository`)  |
| 4  | God port with 10+ methods                       | Split by read/write or by capability       |
| 5  | Return type that leaks adapter details          | Return domain types only                   |
| 6  | Port importing from adapter layer               | Ports import only domain and stdlib        |

---

## 8. Reference: Example Outbound Ports

| Port                  | File                       | Methods                                          | Used By                |
|-----------------------|----------------------------|--------------------------------------------------|------------------------|
| `OrderRepository`     | `order_repository.py`      | `load()`, `exists()`, `list_by_status()`, `save()` | Most use cases         |
| `PaymentGateway`      | `payment_gateway.py`       | `charge()`, `refund()`                           | ProcessPayment         |
| `InvoiceWriter`       | `invoice_writer.py`        | `write()`                                        | GenerateInvoice        |
| `NotificationService` | `notification_service.py`  | `send()`                                         | CreateOrder, FulfillOrder |
