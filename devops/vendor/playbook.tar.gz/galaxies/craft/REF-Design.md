---
domain: practice
---

# REF: Design (Look and Structure, Token Discipline, Harvested Systems)

> Read this when shaping a prototype or a product's look: the two axes a design carries, why the look must be a fixed token set an engine can enforce, how design systems are imported, harvested, and exported around that token gate, why a control carries its own meaning instead of explaining itself, and how a prototype is authored and shown. The tool-agnostic core of design work.

---

## 1. The two axes

Every prototype carries its design on two independent axes. The **look** descends from a design system to a theme to a scheme; the **structure** ascends from a block to a layout to a page to a project. The two meet at the **screen**: a screen is structure (blocks arranged into a layout) painted by the active theme. This is why the vocabulary untangles: name an artifact's axis and its role is unambiguous.

| Axis | Runs | Unit to composite | What it fixes |
|---|---|---|---|
| Look | design system -> theme -> scheme | a design system distils to a theme; a scheme is one saved theme | colour, radius, typeface: how everything appears |
| Structure | block -> layout -> page -> project | blocks compose a layout; a layout is a page; pages form a project | what is on the screen and where |

The axes are orthogonal. Reskinning (swap the active theme) changes every screen's look without touching its structure; restructuring (rearrange blocks) changes a screen without touching the look. Keeping them separate is what lets a whole look swap in one click and a layout be compared under a fixed brand.

## 2. Token discipline

The look is not free-form styling; it is a **fixed, named token set**. Every colour a screen shows resolves through a token, and a literal colour (a hex triple, an `rgb()`, a numeric `hsl()`) is **rejected at every write**, on every door into the store. The token set is the machine-enforceable projection of a design system: only what is a token reskins live, so only what is a token counts as the brand.

| Rule | Why |
|---|---|
| Express the look as a closed, named token set | A fixed vocabulary is the thing an engine can validate and swap |
| Reject literal colours at write time, on every door | A hardcoded colour does not reskin and escapes the brand |
| A theme carries exactly the canonical token set | Partial or extra tokens break the one-click reskin |
| Only token-expressible properties are enforced look | Everything else is guidance (§3), not gated |
| A token ships with its validated contrast pair, per appearance | A foreground token is meaningless alone: it is legible or not against a specific ground, and in light and dark separately (`REF-Accessibility.md` §7) |

Put the gate in the write path (the use case), not a UI layer, so it holds identically however the store is written: an editor, an API, an agent tool. What survives handoff is exactly the token set; anything outside it is decoration that does not travel.

## 3. Design systems and the DESIGN.md interop

A **design system** is more than a palette. It is a multi-section specification: colour, typography, spacing, elevation, components, motion, voice, anti-patterns. Only the **token-expressible part** projects **down** into the theme, where the gate (§2) enforces it; the rest travels as **guidance**.

| Part of the system | Where it goes |
|---|---|
| Colour | the colour tokens (projected, gated) |
| Corner radius / shape | the radius token (projected, gated) |
| Primary typeface | the typeface token (projected); sizes and weights stay guidance |
| Spacing, elevation, components, motion, voice, anti-patterns | guidance, applied when screens are authored |

Because guidance is not the colour gate, literal font sizes and weights in the markup are allowed: they are not colours, and the theme does not own them. Two directions cross this boundary:

| Direction | Flow | Result |
|---|---|---|
| Import a system | corpus -> parse -> theme + guidance | a gate-clean scheme plus the non-token guidance for authoring |
| Export a locked identity | theme + guidance -> render -> a `DESIGN.md` | the brand rendered back as a portable spec |

Import makes an outside system usable as a look. Export renders a locked look back into the same interchange format a design system arrives in (a `DESIGN.md`), so the brand is legible to the wider generative ecosystem, other tools and other agents, not trapped in one editor.

## 4. Rent, author, harvest for design

Design work splits three ways by what deserves ownership:

| Stance | Applies to | Rule |
|---|---|---|
| **Author** | the token gate (§2) | The edge, the thing that must be exactly right. Own it. |
| **Harvest** | the taste corpus (§5) | Take the data (the design systems), not the tool that made it. |
| **Rent** | the renderers | Turning tokens and markup into pixels is a commodity. Never author one. |

This is the rent-and-author principle applied to design, with the third stance the design domain needs: author the differentiating edge, rent the commodity, and harvest the community's accumulated taste as data rather than depending on the tool that produced it. The gate is authored because correctness lives there; a renderer is rented because a hundred already exist; the corpus is harvested because its value is the taste, and taste travels as data.

## 5. The harvested corpus

To supply the import direction (§3) with systems, harvest a **community design-system corpus** rather than building one or leaning on the upstream tool:

1. **Pin** the corpus at a ref (a commit or a release), so the input is reproducible and cannot move under you.
2. **Vendor it 1:1**, a faithful copy checked in beside the code, so a build needs no network and the exact input is auditable.
3. **Parse it deterministically** into the canonical token set: a heuristic role-map (which source colour becomes the primary, which the background, and so on) with **fallbacks** for missing roles. No LLM in the parse; the same input yields the same tokens every time.
4. **Keep the non-token sections as per-system guidance** (§3), carried beside the tokens for the author to apply.
5. **Refresh with a hand-run script**: re-pin, re-vendor, re-parse deliberately. Never run the upstream's generation daemon or live service, because the value is the corpus as data and the gate (§2) already covers turning it into a valid look.

An open, publicly maintained catalogue of design systems (for example, a community corpus such as OpenDesign) is a fitting source: many systems, openly licensed, each a multi-section spec of the shape §3 describes.

## 6. A control carries its own meaning

A design presents itself; it does not instruct. Text that narrates what a control does is a symptom - if a control needs a sentence to explain its own affordance, the affordance is the thing to fix.

Carry meaning in the visual state - colour, weight, position, iconography, motion - and reserve in-place text for facts the visual **cannot** carry. The recurring failure has one shape: a correct control, then a caption beneath it restating what the control already shows. A legend explaining a diagram's own colours, a line telling the reader a selector switches something, a label narrating a gesture; each is cut on sight, and the tell each time is that the sentence describes what the widget *does* rather than stating a fact the widget cannot.

| Instead of | Do this |
|---|---|
| Microcopy narrating the gesture ("tap to clear") | Make the state legible - a held item reads held by its own treatment |
| A caption restating what a control demonstrates on first use | Delete it; one click teaches it faster than the sentence reads |
| A paragraph explaining a surface's own conventions | Move it where a deliberate question is being asked: a docs page, or a modal the user opened on purpose |

**What this rule cuts is visible prose, never the programmatic meaning.** Visual state replaces a caption for a sighted reader; it carries nothing to a screen reader, which reads a name, a role, and a state (`REF-Accessibility.md` §3). So a control whose caption is deleted still announces its name and its current state, a status shown by colour still carries a word or an icon (`REF-Accessibility.md` §7), and a change the visual makes obvious is still announced when it happens (§6 there). Deleting the sentence and adding nothing in its place moves the clutter problem onto the users who had the least to begin with; the tokens and the accessible name are where the meaning goes.

Instructional text also ages badly: it must be maintained against every visual change, and it truncates in the layouts it was added to serve. Before shipping any prose beside a control, ask what the reader learns from it that using the control would not teach in one second. If the answer is nothing, it is clutter. A tooltip or a source note on a data table is fine; a paragraph almost never is.

## 7. Anti-Patterns

| # | Anti-pattern | Correct approach |
|---|---|---|
| 1 | Treating a design system as only a colour scheme | It is a multi-section spec; project the tokens, carry the rest as guidance (§3) |
| 2 | Putting literal colours in the markup | Every colour resolves through a token; the gate rejects literals (§2) |
| 3 | Running a heavyweight upstream daemon for a capability the gate already covers | Vendor and parse the corpus as data; the gate turns it into a valid look (§5) |
| 4 | Authoring a renderer | Rent it; turning tokens and markup into pixels is a commodity (§4) |
| 5 | Letting the harvested corpus drift by manual re-copy | Pin a ref and refresh with a deterministic hand-run script (§5) |
| 6 | Writing microcopy that narrates a control's own affordance | Carry the meaning in the visual state; put explanation where a deliberate question is asked (§6) |
| 7 | Cutting a caption and leaving the control with no programmatic meaning | Visual state replaces visible prose only; the name, state, and announcement remain (§6, `REF-Accessibility.md` §3) |
| 8 | A new semantic token with no contrast pair validated in both appearances | The validated pair ships with the token (§2, `REF-Accessibility.md` §7) |

---

## 8. The visual identity

A design phase's one **durable** output is the visual identity: a locked logo (or a deliberate wordmark), the colour scheme, and the typography. Everything else a design phase produces is working material; this is the part the built app carries for its life.

**Its home is the app's own `docs/`**: a brand page, the committed logo asset, and the palette and type as the *real theme tokens the frontend consumes* (§2), never as a description of them. A phase that locks the identity records it in its own working record first; that record is the ephemeral carrier and `docs/` is the maintained form, so an identity still sitting only in the carrier when the phase closes has not landed.

**The logo is supplied or generated here, never deferred.** A customer-supplied asset is used as-is. Absent one, the phase authors candidate marks or wordmarks from the palette and typography and selects among them the way it selects every other dimension. The floor is a deliberate wordmark rendered mechanically from the identity's own tokens: cheap, honest, and reproducible. Every path ends in a committed asset before the phase closes, because absence handed downstream is what makes a build invent one.

Every design dimension the build will implement is either shown live in the prototype or written down, and each has one home:

| Design dimension | Where it lands |
| ---------------- | -------------- |
| Logo / brand mark | the visual identity, durable in `docs/` |
| Colour scheme and typography | the visual identity, as the theme tokens (§2), durable in `docs/` |
| Art direction statement | the design record, discarded at phase close: one falsifiable paragraph that guides the build |
| Reference imagery | the design record, discarded at phase close (§9) |
| Look-defining assets (textures, fonts, palettes) | exact source, resolution and licence in the design record, discarded at phase close; committed assets land in the repo with their credits |
| Interaction model | the design record, discarded at phase close: what is clickable, what happens, what is out of scope (a prototype cannot show state) |
| Phone shape of each screen | shown live at the phone device and on the customer's own phone; the replacement for every hidden region and the navigation and table choices in the design record, discarded at phase close (`REF-PhoneLayout.md` §9) |

**The live theme is the identity.** Where a phase locks the identity from a prototype, the prototype's live theme is what it locks, taken verbatim. Saved variants are options to show, never candidates a phase silently selects between: a phase that chooses one writes it back as the live theme before the lock, so only one source of truth exists, and the review asserts that the locked tokens equal the live theme.

**Extension tokens live in the written identity, not the theme.** The theme's token set is closed (§2), so a token the identity's own rules reference but the theme cannot hold - success and warning states, chart ramps, any semantic colour the canonical set has no token for - is locked in the written identity with explicit values for each mode, light and dark, that clear the identity's own accessibility bar. An identity that mandates a success colour while defining none, or defines one that fails its own contrast rule, is a design blocker, not a build detail: the prototype can neither hold nor show these tokens, so the written identity is the only place they are judged before the build inherits them.

**Aesthetics are never delegated to the build.** A run told to "make it look good" will invent a look, and whatever it invents becomes rework. A dimension that is neither shown live nor written down is the gap that surfaces as rework: find it before the session, not during it.

**A named reference is the acceptance bar, not inspiration.** When the ask names a concrete existing product, style or artifact as the direction, that reference is what the visual requirement is measured against, not the requirement's own text. A build that satisfies the requirement structurally while missing the referenced look has not met it: "characters at desks" answered with untextured primitives is a failed requirement, not a partial one. Compare the artifact to the named reference at the design gate and again at the build's. A look that cannot land in the phase is a scope decision to surface, never a note left in a record.

**Verify the locked look is actually applied in what was built, and typography as strictly as colour.** Colour is policed at write time: a literal colour is rejected on every door into the token store (§2), so a non-token colour cannot reach the build. **A locked typeface has no such write-time gate.** The identity pins the typeface, yet nothing stops a surface from silently rendering the fallback face, so a build can ship with the locked fonts never wired in and every surface on the system default, invisible to the tests, to review, and to any exit check that only ever confirms *a* font renders rather than the *pinned* one. Make it an exit criterion the same way colour-token usage is: for each typeface the identity locked, confirm the font is genuinely **loaded and applied at its pinned use** - the wordmark, the body, the mono, whatever the identity named - not merely present in the brand page. A pinned face that resolves to the fallback anywhere is a defect exactly as a non-token colour is, and a multi-face stack can ship with most of its faces never loaded while every check stays green.

## 9. Authoring and showing a prototype

**Render an option, never narrate it.** The customer judges a look on screen: apply every presentable option live, and write down only what the prototype cannot show (§8).

**Pin the contract, then make the screen an instance of it.** Write the scoping prose first - what the numbers describe, what the filters govern - and author the screen against it. A screen carries an implicit contract in every number on it, so a screen authored first leaves the later prose either contradicting it or bending to it, papered over by a hedged assumption. A screen is evidence for exactly one contract: where screen and prose disagree, fix the authoring order, pin the contract and re-cut the screen, rather than writing an assumption that admits both readings.

**Reinterpret a reference, never reproduce it.** A reference image or site is read for palette, layout and tone, and the screen is an original interpretation of it; a referenced asset is never copied into the prototype verbatim.

---

## 10. Skills that instantiate this REF

Generated by `scripts/sync_backlinks.py` from skill frontmatter; do not edit by hand.

Skills whose frontmatter `refs:` includes `REF-Design`:

- `bootstrap-protopane-project` - Create a new client prototype in a running protopane instance, then build its first screens from a brief.
- `design-session` - Run the design gate for an engagement over a prototyping instance and lock its one durable output, the visual identity (logo, colour scheme, typography), into .delivery/design.md.

---

## 11. Agents that orbit this REF

Generated by `scripts/sync_backlinks.py` from agent frontmatter; do not edit by hand.

Agents whose frontmatter `refs:` includes `REF-Design`:

- `designer` - Runs the design gate over the prototyping hub and locks the visual identity; hand it an engagement whose proposal gate is closed.
