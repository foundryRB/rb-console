---
domain: methodology
---

# REF: Data Pack

> Read this when authoring or maintaining a structured plaintext data set with validated integrity. A Data Pack is a folder containing TSVs (the data), an intent specification (CSD-aligned), tests that derive from intent, and optional views.

---

## 1. What a Data Pack is

A Data Pack is a folder. It contains:

- **TSVs** - the actual data (human-editable, AI-readable, version-control-friendly)
- **Intent specification** - what this data represents and what claims must hold (CSD format; see `REF-CSD.md` §3)
- **Tests** - pytest validators that derive from intent (one test per intent claim group)
- **Views** (optional) - Dataview md / React / Datacore / Streamlit - derived projections of the data
- **README** - entry point, links, how to read the pack

Data Packs apply the CSD Intent → Test → Implementation chain to plaintext data authored by humans (or AI on humans' behalf, then ratified). They replace Excel/Sheets for any dataset where AI-context-friendliness, version control, and schema integrity matter more than pivot tables.

## 2. Why TSV (not CSV, not Excel)

- **TSV** - tab-separated; aligns visually in any monospaced editor; tabs rarely appear in cell content; human-maintainable; AI-trivial to ingest.
- **CSV** - comma collisions force quoting; escapes get ugly; harder to read by hand.
- **Excel** - opaque to AI without conversion; binary diff-unfriendly; introduces lock-in to the proprietary calc engine.

When formulas / pivots are genuinely needed, use TSV + tests for the data, and a `views/` folder for computed projections.

## 3. Folder structure

```
<wherever-it's-needed>/<DataPackName>/
├── README.md           # entry: links, how to read the pack, view pointers
├── intent.md           # narrative: what this data is for, who reads it, what queries it answers
├── intent.yaml         # machine-checkable claims (CSD format - see §4)
├── data/               # TSVs (or top-level if simple)
│   ├── <table-1>.tsv
│   └── <table-2>.tsv
├── tests/              # pytest validators - one file per intent-claim group
│   ├── conftest.py     # shared fixtures (project_root, data_dir loaders)
│   ├── helpers.py      # shared helpers (TSV loaders, common assertions)
│   └── test_<group>.py
└── views/              # optional - Dataview md / React / Datacore / Streamlit / etc.
    └── <view>.md
```

A Data Pack lives **wherever the data is needed**, not in a fixed location. It can sit inside an Area, a Project, a Resource, or anywhere else in PARA that owns the concern.

## 4. intent.yaml schema

Per `REF-CSD.md` §3 + CSD-INTENT-01 canonical schema, with Data-Pack-specific guidance:

```yaml
INT-001:
  version: 1.0.0
  status: active
  statement: "Every NeedInstance.NeedID MUST reference an existing Needs.NeedID."
  rationale: "Orphan junction-table entries are silent data corruption."
  test:
    scope: integration
    component: NeedsTable
    type: invariant
  criticality: critical

INT-002:
  version: 1.0.0
  status: active
  statement: "Resources.RecurringMonthlyCost MUST be non-negative."
  rationale: "Negative recurring costs indicate data-entry errors."
  test:
    scope: unit
    component: ResourcesTable
    type: invariant
  criticality: high
```

Fields (CSD-INTENT-01 §2.1):
- `version` (required) - semver of the claim itself; bump on statement/scope change
- `status` (required) - `draft` | `active` | `deprecated`
- `statement` (required) - single-sentence declarative behavior, RFC 2119 language (`MUST`, `MUST NOT`, `SHOULD`)
- `rationale` (optional in CSD; recommended for data packs) - *why* this claim matters
- `test` (required) - nested block:
  - `scope` - `unit` (single-table claim) or `integration` (cross-table FK / aggregate). Higher scopes (`e2e`) generally don't apply to Data Packs.
  - `component` - which table/group the claim exercises (e.g. `NeedsTable`, `ResourcesTable`)
  - `type` - `invariant` (must always hold), `behavior` (input→output), or `contract` (schema guarantee)
- `criticality` (required) - `critical` | `high` | `medium` | `low`. Drives whether a failure blocks commits or just warns.

Optional CSD fields: `domain`, `examples`, `derived_from`, `parent`, `related`.

**Test linkage is bottom-up.** The claim doesn't carry a `test:` string-path pointer to its validator anymore. Instead, the validating test function carries an `@intent("INT-NNN")` decorator (see §5). The standalone [`csd-intent`](https://github.com/rafael-pires/csd-library/tree/main/csd-intent) CLI reconciles markers↔claims and reports schema violations, orphan refs, and unattested claims.

## 5. Test pattern (pytest)

Use the conventional pytest pattern below for Data Pack validation. The `bootstrap-data-pack` skill scaffolds a layout that follows it; reuse, don't reinvent.

Conventions:
- `conftest.py` exposes session-scoped fixtures: `pack_root`, `data_dir`
- Tests grouped by concern under `tests/` (one file per related-claim cluster)
- Helpers (TSV loaders, common assertions) live in `tests/helpers.py`
- Every claim-validating test function carries an `@intent("INT-NNN")` decorator from `pytest-intent` - this is the binding from test to claim

Example:

```python
# tests/test_needinstance_need_ref.py
from pytest_intent import intent
from .helpers import load_tsv


@intent("INT-001")
def test_needinstance_need_ref(data_dir):
    needs = {row["NeedID"] for row in load_tsv(data_dir / "needs.tsv")}
    orphans = [
        row for row in load_tsv(data_dir / "need_instances.tsv")
        if row["NeedID"] not in needs
    ]
    assert not orphans, f"orphan junction-table entries: {orphans}"
```

Run:
- `pytest <data-pack-folder>/tests/` - exit code 0 = all validators pass
- `csd-intent <data-pack-folder>` - audit spec (schema) + coverage (every claim attested) + orphans (no test references a non-existent claim)

See `REF-Tests.md` for general testing philosophy. This REF specializes for plaintext-data validation suites.

## 6. Authoring flow

Three valid entry points (per CSD's "Authored Intent" + "Emergent Intent"):

| Entry | Initial input | AI does |
|---|---|---|
| **Intent-first** | "I want a dataset where X, Y, Z must hold" | Generates intent.yaml + tests + table schema |
| **Data-first** | An existing Excel / TSVs | Imports tables, infers intent.yaml claims, scaffolds tests |
| **Test-first** | Sample test cases describing what shouldn't happen | Derives intent.yaml + table schema |

**Post-hoc human review.** AI generates the full pack with assumed intent. Human reviews `intent.yaml` when convenient (next conversation, next session, never if uninterested). CSD's "human owns intent" preserved without forcing a synchronous ratification pause - humans can edit, reject, or approve any claim at any time. Pre-gates are friction; post-hoc audit + git history is sufficient governance.

If an inferred claim is later found wrong (like Family Resources' INT-041), remove it with a comment explaining why (preserves the audit trail).

## 7. Views (not "dashboards")

`views/` holds derived projections. A *dashboard* is one kind of view; not all views are dashboards.

Implementations (use whichever fits):
- **`views/generate.py`** - canonical lightweight pattern. A small Python script reads the TSVs, computes summaries, writes one or more `.md` files. Re-run after TSV changes. Output committed (a snapshot) or `.gitignore`d (always-fresh) - pack's call.
- **Dataview / Datacore .md** in an Obsidian vault - fast, no build step, but Dataview can't natively query TSVs; usually paired with `generate.py` that produces queryable Markdown.
- **React frontend** - heavier, only if interactivity matters.
- **Streamlit / Jupyter** - analytical exploration.
- **Static .md** with hand-pasted summary tables - when other tools are overkill (or pre-automation).

Views **read from the TSVs**; they don't *own* data. The TSVs are the source of truth. Re-running `generate.py` should be idempotent.

## 8. The auditor as Synthesis Governance

When the Data Pack lives in a context where AI synthesis happens (e.g., AI extracts to TSV, AI authors intent), the auditor is the **Synthesis Governance** layer (CSD §3 Trust Calibration). It runs:

- After every AI write to the pack
- Before any commit
- On demand via `pytest <pack>/tests/`

Failures block the commit and surface for human review. This implements TtTO's "trust through automation" for plaintext data.

## 9. Sub-archival within a Data Pack

When part of a Data Pack becomes inactive (e.g., a legacy source format you migrated from, or an old version of a TSV) but you don't want to delete it, place it under `_Archive/` inside the Pack:

```
<DataPackName>/
├── data/...
├── tests/...
├── views/...
└── _Archive/
    ├── <legacy-source>.xlsx
    └── README.md  (optional - explains what's archived and why)
```

`_Archive/` is the vault-wide convention for "archived material that belongs to this folder, not to `04 Archive/`." It keeps related-but-inactive content co-located. Validator and tests skip `_Archive/` subtrees.

This convention applies to any vault folder, not just Data Packs (see `_System/Vault-Operations.md`).

## 10. When NOT to use a Data Pack

- **Free-form prose** that wouldn't tabularize cleanly (use plain markdown notes)
- **One-time scratchpad calculation** (use a spreadsheet ad-hoc; throw away)
- **Heavy numerical / statistical workloads** (use Python notebooks or a real tool)
- **Datasets owned by external systems** (don't copy them; reference and query)

Data Packs shine when: the data has structure, you'll edit it over time, AI may help author, and structural integrity matters.

## 11. Anti-patterns

| # | Anti-Pattern | Correct Approach |
| - | ------------ | ---------------- |
| 1 | Tests without explicit intent | Every test maps to an `INT-NNN` in intent.yaml. Meta-tests enforce 1:1. |
| 2 | Pre-ratification gates that pause AI authoring | Post-hoc review only - AI generates full pack with assumed intent; human edits/rejects when convenient |
| 3 | Mixing data and views in the same files | TSVs own data; views read from TSVs. No formulas in TSVs. |
| 4 | Reinventing pytest fixtures per pack | Reuse the conventional fixtures the bootstrap script scaffolds. |
| 5 | Calling the views folder "dashboards" | Use `views/` - a dashboard is one kind of view. |
| 6 | Co-locating Data Pack with other content in the same folder | Each Data Pack is its own folder with the structure above. |
| 7 | Intent claims without `rationale` or `scope` | Future-you (and AI) need to know *why* a claim exists and *where it tests* to maintain it. |
| 8 | Putting legacy/archived material at peer level outside the pack | Use `_Archive/` inside the pack (see §9). |

## 12. Cross-references

- `REF-CSD.md` - methodology this implements
- `REF-Tests.md` - general test philosophy (Data Pack tests are a specialization)
- `REF-Python.md` - Python conventions for the test code

---

## 13. Skills that instantiate this REF

Generated by `scripts/sync_backlinks.py` from skill frontmatter; do not edit by hand.

Skills whose frontmatter `refs:` includes `REF-DataPack`:

- `bootstrap-data-pack` - Scaffold a new Data Pack at a given path.
- `bootstrap-observable-dashboard` - Scaffold an Observable Framework dashboard project against an existing Data Pack.
