---
name: estimatekit
galaxy: craft
refs:
  - REF-Estimation
---

# MCP: estimatekit

> Knock here to drive a project-estimation engagement: structured project data in, audited and scheduled delivery artifacts out.

The estimation engine's door. The loop it serves: scaffold a project, author the requirement/activity/assumption TSVs from the engagement brief, audit until clean, then generate the roadmap, workbooks, and slide deck.

## Doctrine

- The door serves its own guide; read it first.
- A scaffold is example shape, and its sentinels are the to-do list: the audit refuses every sentinel-marked value until it is authored or deleted, so a fresh scaffold's first audit report enumerates the work and nothing scaffolded can ship.
- A failing audit means the numbers cannot be trusted; generation before a clean audit is a defect, never a shortcut.
- Keep every TSV header row byte-identical to the scaffold: the header row is the parsing contract, and the engine reads every column by its header name, so a renamed column reads as empty.
- Generated artifacts stay on the instance: hand back the deck URL and workbook downloads, never re-render them locally.
