---
name: protopane
galaxy: craft
refs:
  - REF-Design
---

# MCP: protopane

> Knock here in the design phase: customer prototypes as token-backed themes and screens, iterated live before any frontend repo exists.

The prototyping hub's door. Each engagement is a project holding shadcn design tokens (the theme) and screens (HTML bodies in token-backed utility classes); writes persist through the same use cases as the UI.

## Doctrine

- The door serves its own guide; read it first.
- Compose token-backed utilities (`bg-primary`, `text-foreground`, `border`, `rounded-md`); never inline hex colors. The tokens are the brand; only token-backed markup reskins live and survives handoff.
- Hex-shaped demo data reads as a colour: the write gate takes a `#` followed by hex digits as a colour literal wherever it appears, digits alone included, so an order number or a short hash written that way is refused like a hardcoded colour. Write such references without the `#`.
- Variants are schemes inside one project: offer palette or style variants as named schemes the customer flips between in one click, never as one project per variant.
- The prototype is throwaway by design: it informs the build, it never becomes it.
