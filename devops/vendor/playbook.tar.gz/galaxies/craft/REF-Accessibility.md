---
domain: practice
---

# REF: Accessibility

> When building or reviewing an application interface, follow these rules: the conformance target, the rules a screen reader depends on, which layer owns each one, and the checks that prove it. Prototypes and internal documents are out of scope (§1). Core REF; `REF-Frontend.md` §11, `REF-React.md` §6 and `REF-Design.md` §6 carry the framework deltas.

---

## 1. Conformance target

**The target is WCAG 2.2 Level AA for an application interface**: a surface a person operates to do work, where being unable to use it means being unable to do the work. Everything in §2 to §10 is written for that surface and is not a blanket mandate on every artifact the corpus can produce.

**Out of scope, deliberately**: throwaway prototypes (`REF-Design.md` §9), whose purpose is choosing a look and whose previews are static, and internal documentation and documents, which have no controls, no async state, and a known audience. Neither carries an obligation from this REF, and nothing here is a reason to add one to either. Revisit only when a surface's audience changes, for example a docs site that becomes externally published; until then the cost of the rules lands where nobody is paying it.

- **"Accessible" is not a claim; the target is.** A component library described as accessible supplies mechanics (§9), not conformance. Do not restate an upstream library's marketing as a project's conformance status.
- **Where a jurisdiction, a customer contract, or a procurement standard names a level** (EN 301 549 harmonises with WCAG AA), the target is the stricter of that and the above.
- **One AAA criterion is adopted anyway**, because it costs one media query: animation from interactions (2.3.3), which is why reduced motion is mandatory in §7. Separately, the name-source preference of §3 (visible text first, `aria-label` last) is **corpus policy**, not a WCAG level: label in name (2.5.3) is Level A and already inside the target, and the preference order goes beyond what any criterion requires.
- **A criterion a surface genuinely cannot meet is recorded, never dropped**: the gap, the reason, and what the user does instead, written in the project's own accessibility record where the next reader will find it. An unrecorded gap is a defect; a recorded one is a decision.
- Success criteria are cited by number throughout, as `(1.3.1)`. The criteria themselves are not reproduced here: they are a maintained external standard, and a copy in this corpus would be a copy that drifts.

---

## 2. Semantic structure first

- **A native element beats a role.** `<button>`, `<a href>`, `<input>`, `<table>`, `<ul>` arrive with role, keyboard behaviour, and focus handling. A `div` plus `role` plus handlers reimplements all three and gets one of them wrong. ARIA is for what HTML cannot express, never for what it already expresses.
- **Landmarks wrap the page**: one `main`, plus `header`, `nav`, `footer` as present. Repeated landmarks of the same kind carry distinguishing accessible names (1.3.1).
- **One `h1` per view, no skipped levels**, and headings describe the content under them rather than decorate it (1.3.1, 2.4.6). Heading level is structure; size is a token.
- **A skip link is the first focusable element** on any view with repeated navigation (2.4.1).
- **The document title changes with the view**, so history and window lists stay meaningful and a screen reader announces arrival (2.4.2).
- **The document declares its language** (3.1.1), and any passage in another language declares its own.
- **Lists, tables, and emphasis are markup, not styling.** A visual list built from `div`s announces as prose.

---

## 3. Name, role, state: what a screen reader actually says

Every interactive element must announce a **name**, a **role**, and its current **state** (4.1.2). This section is the one that decides whether a correct-looking interface is usable without sight.

**Name sources, in order of preference:**

| Preference | Source | When |
|---|---|---|
| 1 | The element's own visible text | The default. The label a sighted user reads is the label everyone gets |
| 2 | `aria-labelledby` pointing at visible text | The name exists on screen but not inside the element |
| 3 | `aria-label` | Last resort: there is no visible text at all (an icon-only control) |

- **An icon-only control carries a name.** A decorative icon or ornamental graphic is `aria-hidden` so the reader is not reading artwork (1.1.1).
- **The visible label is contained in the accessible name** (2.5.3). A button reading "Save" whose `aria-label` says "Submit form" cannot be operated by voice control, and the two labels disagree in every bug report.
- **State is programmatic**: `aria-expanded`, `aria-pressed`, `aria-current`, `aria-selected`, the `disabled` attribute. A state carried only by colour, weight, or position does not exist (1.4.1, §7).
- **Link and button text says where it goes or what it does**, from the text and its programmatic context (the sentence, list item, or table cell it sits in) at the least (2.4.4). Text that also stands alone is better: screen-reader users pull up a list of links, and "click here" and "read more" are a list of nothing.
- **Never `aria-hidden` on a focusable element**, and never a role that contradicts the element it sits on. Both produce a control that can be reached and not understood.

---

## 4. Forms and errors

- **`label` associated with its control is the default**; `aria-label` only where no visible label exists. A placeholder is not a label: it vanishes on input and fails contrast in most themes.
- **Related controls are grouped** with a named group (a fieldset and legend, or an equivalent named group role), so a radio set announces what it is choosing between (1.3.1).
- **Required and invalid are programmatic**: the `required` attribute, `aria-invalid` on failure, and `aria-describedby` pointing at the message (3.3.1, 1.3.1). A red border alone reports nothing.
- **The error message says how to fix it**, not just that something is wrong (3.3.3). "Enter a date as YYYY-MM-DD" over "Invalid input".
- **On a failed submit, focus moves once** to the first invalid control or to an error summary that links to each. Errors do not steal focus on every keystroke.
- **Identity and address fields declare `autocomplete`** (1.3.5).
- **Do not make the user re-enter what the flow already has** (3.3.7), and **do not gate authentication behind a cognitive-function test** (3.3.8): allow paste, allow a password manager, and where a test remains, offer another method or a mechanism that helps complete it. Recognising objects, or content the user supplied, are the criterion's only exceptions. See `REF-Identity.md` §3 for the credential rungs this constrains.

---

## 5. Keyboard and focus

- **Everything is operable from the keyboard** (2.1.1) and nothing traps it (2.1.2). If a pointer can do it, a keyboard can do it.
- **The focus indicator is never removed.** Restyle it to meet 3:1 against both adjacent surfaces if the default is ugly, but a suppressed outline is an accessibility defect and a code-review rejection (2.4.7, 1.4.11).
- **DOM order is reading order is tab order** (1.3.2, 2.4.3). No positive `tabindex`. Utilities that reorder visually without reordering the DOM produce a page that reads in a different sequence than it looks, which is invisible in review and obvious to a screen reader.
- **Dialogs and overlays**: focus moves in on open, stays within while open, returns to the trigger on close, and the dismiss key closes. **Inherit this from the primitive rather than re-implementing it** (`REF-React.md` §5): a hand-rolled modal is the single most common source of a keyboard trap. When the trigger is gone on close (the action removed the row whose button opened the dialog), the design names the surviving control focus moves to, never the page body.
- **A view change moves focus** to the new view's heading or its `main`, so the next keystroke acts on the new content.
- **A focused element is never entirely hidden** by sticky headers, footers, or floating chrome when it is scrolled into view (2.4.11). Keep it wholly visible where the layout allows; partly covered is the floor, not the aim.
- **No hover-only affordance.** Anything revealed on hover is revealed on focus, stays while the pointer is over it, and is dismissible without moving the pointer (1.4.13).
- **Pointer targets are at least 24 by 24** unless spaced equivalently (2.5.8).
- **Every drag has a single-pointer path without dragging** (2.5.7): a sortable list has move buttons, a slider accepts a tap on its track or a typed value, a board has a move menu; native scrolling is exempt. A path-based gesture (swipe, pinch) has a tap alternative (2.5.1); the gesture is a shortcut, never the only way.
- **No orientation lock** (1.3.4): a view works in portrait and landscape unless one orientation is essential to it, and a manifest `orientation` lock counts as a restriction.

---

## 6. Announcing change

Asynchronous interfaces fail for screen readers in one specific way: **the screen changes and nothing is said** (4.1.3). Rules:

- **Every asynchronous outcome is announced**: loading started, loading finished, saved, failed, result count changed after a filter.
- **The live region exists in the DOM before its message does.** A region inserted together with its text frequently does not announce; render the container empty and write into it.
- **Polite for status, assertive only for something that blocks the user.** An assertive region interrupts mid-sentence, so it is reserved for errors that stop progress.
- **Announce once.** A live region plus a focus move plus a toast is the same news three times; pick the one that matches the interruption the user needs.
- **A blocking error is never a toast alone.** A message that disappears on a timer is a message a screen-reader user may never hear and cannot re-read.
- **The state a view announces comes from the ViewModel as content**, not as a colour or a spinner (§9): an error message string, a status word, a count.

---

## 7. Colour, contrast, motion, and zoom

- **Contrast is a property of a token pair, validated in both appearances.** Body text 4.5:1, large text and the boundaries of controls, focus indicators, and meaning-carrying graphics 3:1 (1.4.3, 1.4.11). **A new semantic token ships with its validated light and dark pair or it does not ship** (`REF-Design.md` §2), since the token set is what the build inherits.
- **Colour is never the only carrier of meaning** (1.4.1). Pair it with text, an icon, a shape, or a position. This is the rule that keeps status badges, chart series, diff views, and validation states readable for colour-blind users and in forced-colours mode.
- **Honour the reader's environment**: reduced motion stops non-essential animation (2.3.3), and increased contrast, reduced transparency, and forced colours must not break the layout or hide content. The press galaxy already practises this (`REF-Flyer.md` §3, `REF-Plan.md` §5); application surfaces owe the same.
- **200% zoom and a 320px-wide viewport lose no content or function**, with no two-dimensional scrolling for a single column of text (1.4.4, 1.4.10), and user text-spacing overrides do not clip (1.4.12).
- **No text baked into an image**, so it scales and translates with everything else.

---

## 8. Tables, charts, images, and media

- **A data table has an accessible name and header cells with scope**; a table is never used for layout.
- **A chart carries a text alternative that states its takeaway**, and its data is reachable in a non-visual form: an adjacent table, a download, or an expandable list (1.1.1). A chart whose alternative text is "chart" conveys nothing.
- **Image alternatives describe purpose, not appearance**; a decorative image takes an empty alternative so it is skipped rather than announced by filename.
- **Inline vector graphics that carry meaning** declare an image role with a title, and decorative ones are hidden (`REF-StarlightDocs.md` §8.2 applies this to diagrams).
- **Media carries captions** (1.2.2), and nothing autoplays audio.

---

## 9. Which layer owns which rule

The rules above are not evenly distributed: each has exactly one home in the Atomic and MVVM layering (`REF-AtomicDesign.md` §2, `REF-Frontend.md` §1). A rule with no owner is a rule nobody applies.

| Layer | Owns | Reference |
|---|---|---|
| **Primitive layer** (the component library's output) | Role, keyboard behaviour, focus management. Inherited, never hand-edited; a fork here is how inherited accessibility is silently lost | `REF-Frontend.md` §2 |
| **Atoms** | The accessible name and programmatic state of one control; the focus-indicator token; the non-colour carrier of any status it shows | §3, §7 |
| **Molecules** | Label-to-control association and named grouping | §4 |
| **Organisms** | Table semantics, dialog wiring, and the live region for their own asynchronous state | §6, §8 |
| **Templates** | Landmarks, the skip link, and focus placement on view change | §2, §5 |
| **Pages** | The single `h1`, the document title, and page-level status announcements | §2, §6 |
| **ViewModels** | Exposing state that can be announced (a message, a status, a count). No DOM and no ARIA in a ViewModel | §6 |

---

## 10. Verification, and what each tier cannot prove

Three tiers. Each is necessary; none of them is sufficient alone, and the project's gates run all three.

| Tier | Mechanism | Catches | Cannot prove |
|---|---|---|---|
| **Static** | The linter's accessibility rule set, at its strict setting, failing the build | Missing names, invalid ARIA, contradictory roles, unlabelled inputs, a handler on a non-interactive element | Anything requiring a rendered tree, and **anything in CSS**: the rule set reads JSX, so a suppressed focus indicator is invisible to it and belongs to review and the manual pass |
| **Runtime** | An accessibility assertion over rendered components in the test suite | Accessible names, role and ARIA validity, label-to-control relationships, image alternatives, duplicate ids, orphaned ARIA references | **Contrast**, **document-level structure** (landmarks, heading order), the **layout rules** (target size, reflow) and **focus placement** (where focus lands as an overlay opens or closes), as well as order, announcement timing, and whether a message helps. See the notes below: these are not configuration gaps |
| **Manual** | Named passes, per release, with an owner | Everything above plus the rules that decide usability | Nothing; it is the only tier that can say the interface works |

**Two limits of the runtime tier are structural, not configurable.** A component-level assertion runs in a DOM implementation with no layout engine, so a contrast rule cannot compute a colour pair: it either is disabled by the test harness or returns "incomplete", and an incomplete result is not a failure, so **no green run there is evidence about contrast**. And the assertion is scoped to the rendered container rather than the document, so the rules about landmarks, regions, and page structure are simply inapplicable and pass silently. Neither gap is closed by enabling a rule. **Contrast is proven by the token-pair validation of §7** (a computed ratio per pair, per appearance, checked where the tokens are defined) and by the browser passes below; **document structure is proven by review against §2** and by the same passes. A project that wants contrast inside CI runs the assertion in a real browser, which is a different mechanism than this row, not a flag on it.

**Target size and reflow are layout rules the component tier cannot evaluate either**, and they are proven in the browser: a Playwright phone project runs axe with `wcag22aa` among its tags (the target-size rule ships disabled and runs only when that tag or its id is requested, so a copied example listing `wcag21aa` skips it silently) and asserts no element is wider than the viewport at 320 and 375px, since axe has no reflow rule. Lighthouse's `target-size` audit tests the 24px floor. The phone-specific passes are `REF-PhoneLayout.md` §9.

**Focus placement is asserted in the browser as well**, with Playwright's `toBeFocused`: the component tier's DOM has no layout engine, and a library's focus management can place focus differently there than in a browser.

**Automated tooling detects only a minority of real conformance failures.** Treat a green automated run as the absence of specific defects, never as conformance. The remaining criteria are met by review against §2 to §8 and by the manual passes:

1. **Keyboard only.** Unplug the pointer; complete each primary flow. Watch for: an unreachable control, a trap, a lost focus indicator, an order that contradicts the layout.
2. **Screen reader.** Run each primary flow with the platform's own reader, on the platforms the project supports. Three questions per flow: does every control announce a sensible name, role, and state; is every change announced exactly once; can the flow be completed without looking at the screen.
3. **Zoom and reflow.** 200% zoom and a 320px-wide viewport.
4. **Environment overrides.** Forced colours, increased contrast, reduced motion.

**The manual passes are recorded, not remembered**: date, flow, tool and version, findings. Without a named owner and a release cadence, these passes do not happen, and the conformance claim becomes unfounded the first time the UI changes. A finding that blocks a flow is a defect in the current release, not a backlog item.

---

## 11. Anti-Patterns

| # | Anti-Pattern | Correct Approach |
|---|---|---|
| 1 | Claiming conformance because the component library is described as accessible | The library supplies mechanics; conformance is the surface's, proven per §10 |
| 2 | `div` plus `role` plus handlers where a native element exists | Use the native element (§2) |
| 3 | `aria-label` as the default labelling mechanism | Visible text first; `aria-label` only with no visible label (§3) |
| 4 | An accessible name that disagrees with the visible label | The visible label is contained in the name (2.5.3, §3) |
| 5 | Status carried by colour alone (badge, chart series, validation, diff) | Pair colour with text, icon, or shape (1.4.1, §7) |
| 6 | Removing or suppressing the focus indicator | Restyle it to 3:1; never remove it (§5) |
| 7 | A hand-rolled dialog, menu, combobox, or tab set | Inherit the primitive's focus and keyboard behaviour (§5) |
| 8 | Reordering visually without reordering the DOM | DOM order is reading order (1.3.2, §2) |
| 9 | An async result that changes the screen silently | Announce it once through a pre-existing live region (4.1.3, §6) |
| 10 | A blocking error shown only as a timed toast | A persistent, associated, announced message (§4, §6) |
| 11 | A new semantic token without a validated contrast pair per appearance | The pair ships with the token, or the token does not ship (§7) |
| 12 | A chart or data visualisation with no non-visual equivalent | State the takeaway and expose the data (§8) |
| 13 | ARIA added to "improve" an already-correct native control | Remove it; incorrect ARIA is worse than none (§2, §3) |
| 14 | Treating a green automated check as conformance | It is the absence of specific defects; the manual passes decide (§10) |
| 15 | An accessibility finding filed as a backlog item while the flow stays broken | A blocked flow is a defect in the current release (§10) |
| 16 | An unrecorded gap against the target | Record the criterion, the reason, and the alternative (§1) |

---

## 12. Skills that instantiate this REF

Generated by `scripts/sync_backlinks.py` from skill frontmatter; do not edit by hand.

Skills whose frontmatter `refs:` includes `REF-Accessibility`:

- `bootstrap-react-mvvm` - Scaffold a new React + TypeScript + Tailwind frontend in MVVM (Model / ViewModel / View) form per REF-Frontend and REF-React, with its Model layer generated from a given OpenAPI spec.
