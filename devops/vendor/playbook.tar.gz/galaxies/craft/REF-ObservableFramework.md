---
domain: framework
---

# REF: Dashboarding with Observable Framework

> Read this REF when adding an interactive, code-first dashboard on top of a Data Pack (or any TSV/CSV/Parquet source of truth) - Observable Framework as the rendering layer, the data files as the unmoved canonical input.

---

## 1. Scope

This REF specializes `REF-DataPack.md` §7 (Views). A `views/generate.py` Markdown emitter is the lightweight default; this REF covers the heavier case: interactive filtering, charts (Plot/Vega/D3), and publish-quality aesthetics that a static `.md` can't deliver.

It does **not** redefine the Data Pack contract. The TSVs remain the source of truth. The dashboard is a derived projection, code-reviewed and deterministic, that never writes back.

When static `generate.py` output is enough, stay there. This REF adds infrastructure; don't pay it for a sortable table.

---

## 2. The contract

Five rules that make this dashboarding layer compatible with the Data Pack contract:

1. **The TSVs are canonical. The dashboard never writes them.** If a derived value the dashboard needs doesn't exist, add it as a TSV column with an `INT-NNN` claim - don't recompute it client-side and let it drift.
2. **The dashboard reads `Effective*` / canonical columns, not raw inputs**, when the Data Pack has them. The intent layer (tests) enforces the rollup invariant; the dashboard assumes it holds.
3. **No parallel store.** No SQLite, no DuckDB cache, no JSON dump. Loaders pass through TSVs at build time; pages read the copy via `FileAttachment`.
4. **Build is deterministic.** Same TSVs in → same `dist/` out; no data change, no diff.
5. **Source is diffable.** Markdown + JS code blocks. Notebooks and click-built dashboards fail review and break the CSD audit story.

If you can't keep all five, fall back to `generate.py` or pick a different rendering layer.

---

## 3. Project layout

A dashboard project - separate from the Data Pack, **not** nested in it (see §4):

```
<dashboard-project>/
├── package.json           # @observablehq/framework + minimal scripts
├── observablehq.config.js # title, pages, theme, interpreter overrides
├── .gitignore             # node_modules, dist, .observablehq/cache
├── README.md              # how to run; pointer to the source Data Pack
└── src/
    ├── index.md           # entry - KPIs, top-level summary, navigation
    ├── <view-1>.md        # additional pages - by-X, Y-explorer, etc.
    ├── <view-2>.md
    └── data/
        ├── <table-1>.tsv.py   # passthrough loader → emits canonical TSV
        └── <table-2>.tsv.py
```

Each page is its own `.md` file, declared in `observablehq.config.js`'s `pages` array.

---

## 4. Where the dashboard project lives

**Default: a separate sibling folder, outside the Data Pack** - typically `<pack-name>-dashboard/` next to the pack, or under a workspace-wide `dashboards/` directory. Loaders read the pack's TSVs by configurable path (see §6).

**Why not nest inside `<pack>/views/dashboard/`?**

1. **Cloud-synced vault incompatibility.** When the pack lives on actively-syncing cloud storage, `npm install` races the sync layer's file mirroring: `EBADF`, missing files, corrupt extractions, broken `node_modules/`. The dashboard project must live outside any active sync surface. *Validated empirically against a consumer cloud-sync client, 2026-05-01.*
2. **Concern separation.** A dashboard is *tooling*; the Data Pack is *data*. Co-locating ties their lifecycles - dep bumps shouldn't churn the data pack's diff.

If the pack is in a normal Git repo on a local filesystem and you accept the coupling, nesting is technically fine. But default sibling; override only with a reason.

---

## 5. Data loader pattern

Observable Framework runs `src/data/*.<ext>.<runtime>` scripts at build time, capturing stdout as the file pages consume via `FileAttachment("data/<file>")`. For a Data Pack source, the loader is a Python passthrough:

```python
#!/usr/bin/env python3
"""Observable data loader. Emits the canonical <table>.tsv at build time."""
import sys
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8")  # see §7
DATA_PACK = Path(<configured-pack-path>)  # see below
sys.stdout.write((DATA_PACK / "data" / "<table>.tsv").read_text(encoding="utf-8"))
```

**Path resolution.** Three options, in increasing decoupling:

| Option | When |
|---|---|
| Relative path (`Path(__file__).resolve().parents[N]`) | Dashboard nested inside pack - sibling layouts won't generally allow this |
| Absolute path constant at top of each loader | Spike / single-machine setup. **Don't commit to a shared repo.** |
| Environment variable / config file (`os.environ["DATA_PACK"]`) | Multi-machine, CI, or shared repo. Loader fails loudly if unset. |

For a SKILL-scaffolded single-machine dashboard, option 2 is fine; anything that crosses machines, option 3.

**Why a loader rather than direct `FileAttachment` to an external path?** `FileAttachment` only resolves files inside `src/`. Don't fight it.

**Pure passthrough, not transform.** The TSV is canonical; transforms belong either as TSV columns (with an INT claim) or as JS in the page. A loader that re-derives values is one more place that can drift.

---

## 6. Page authoring conventions

Pages are Markdown with fenced JS code blocks. Reactive: anything declared in one block is in scope for all others on the same page.

**Standard page skeleton:**

````markdown
---
title: <page title>
toc: false
---

# <Page heading>

```js
const tableA = await FileAttachment("data/tableA.tsv").tsv({typed: true});
const tableB = await FileAttachment("data/tableB.tsv").tsv({typed: true});
const num = v => Number(v) || 0;
const fmtCurrency = v => v.toLocaleString("<locale>", {style: "currency", currency: "<ISO>"});
```

```js
// Derived data - pure, no side effects.
const active = tableA.filter(r => r.Status === "Active");
```

<div class="grid grid-cols-N">
  <div class="card"><h2>...</h2><span class="big">${value}</span></div>
</div>

## Section heading

<div class="card">
  ${resize((width) => Plot.plot({width, height: ..., marks: [...]}))}
</div>
````

Conventions:

- **`toc: false`** in frontmatter unless the page is genuinely long-form.
- **`typed: true`** when calling `.tsv()` - auto-coerces numbers and dates. Booleans stay strings (`"True"`/`"False"`); add a predicate: `const isFlag = r => r.SomeFlag === "True"`.
- **Read canonical columns**, not raw: `EffectiveX` over `RawX` for cost/aggregation surfaces.
- **`resize((width) => Plot.plot({width, ...}))`** for responsive charts - plain `Plot.plot()` won't reflow.
- **Native classes** for layout: `grid grid-cols-N`, `card`, `big`, `muted small`. No custom CSS until these are exhausted.
- **`Inputs.search`/`checkbox`/`range`/`toggle`** for filters - declare with `view(Inputs.X(...))`; downstream cells subscribe to the resulting variable automatically.

---

## 7. Windows quirks

Two interpreter / encoding traps when building on Windows:

**Python on PATH hits the Microsoft Store alias.** A bare `python` command, when invoked by Node's `child_process.spawn`, often resolves to the Microsoft Store App Execution Alias and exits with code 9009 ("Python was not found…"). The Python Launcher `py` is reliable. Configure in `observablehq.config.js`:

```js
export default {
  // ...
  interpreters: {
    ".py": ["py", "-3"]
  }
};
```

Also fine on macOS/Linux when `py` is installed; if not, override per-machine. Defaulting to `py` makes the project portable to Windows with no per-user setup.

**stdout defaults to cp1252.** Loader `print` / `sys.stdout.write` will fail with `UnicodeEncodeError` the moment any TSV value contains a non-cp1252 character (`≥`, em-dash, accented characters, currency symbols outside €$£). Fix at the top of every loader:

```python
sys.stdout.reconfigure(encoding="utf-8")
```

The bootstrap SKILL emits this line in every loader by default. Don't remove it.

---

## 8. Determinism for CSD

- **Build determinism:** `npm run build` is reproducible - same TSVs in, same `dist/` out (modulo timestamps). A CI claim can assert it exits 0.
- **Numeric claims** are the high-value tests. Two ways to enforce a displayed headline number:
  - **Indirect (cleanest):** the page reads a precomputed column the Data Pack already validates (INT-NNN claims). The dashboard inherits correctness; no separate dashboard test.
  - **Direct:** parse the built HTML and assert equality with a re-derivation. Fragile; use only when the value isn't traceable to a single canonical column.
- **Visual regression** is out of scope; screenshot diffs cost more friction than a monthly-reviewed dashboard warrants.

**Make the dashboard a display of canonical columns and let the Data Pack's existing intent claims carry the correctness story.** New claims only when the dashboard introduces a calculation not already in the canonical TSV.

---

## 9. Anti-patterns

| # | Anti-pattern | Correct approach |
| - | ------------ | ---------------- |
| 1 | Materializing the TSVs into SQLite / DuckDB / JSON for the dashboard | Pass-through loader; TSV is the only source. |
| 2 | Recomputing derived values in JS instead of reading the canonical column | Read the canonical column; the intent test enforces correctness. |
| 3 | Nesting the dashboard inside a Data Pack on cloud-synced storage | Sibling location outside any active sync surface (§4). |
| 4 | A `dist/` folder committed alongside source | Gitignore `dist/`; build on demand. |
| 5 | Custom CSS before exhausting `card`/`grid grid-cols-N`/`big`/`muted` | Native classes first. |
| 6 | Bare `python` interpreter for `.py` loaders | Override to `["py", "-3"]` in config (§7). |
| 7 | Loader `sys.stdout.write` without `reconfigure(encoding="utf-8")` | Always reconfigure stdout; emit by template, never by hand. |
| 8 | Page-level state via global JS variables | Use `view(Inputs.X(...))` - reactive, framework-supported. |
| 9 | Adding a TSV column "for the dashboard" without an INT claim | Every derived column has a claim asserting how it's derived. |
| 10 | Treating the dashboard as a source of truth | Dashboard is a window. The TSVs and tests are truth. |

---

## 10. Cross-references

- `REF-DataPack.md` §7 - Views as a category. This REF specializes the Observable Framework branch.
- `REF-CSD.md` - methodology; the dashboard is a Synthesis Display surface, not a Synthesis Authoring one.
- `REF-Tests.md` - test philosophy. Numeric correctness on the dashboard inherits from the Data Pack's tests; new tests only when new calculation enters.

---

## 11. Skills that instantiate this REF

Generated by `scripts/sync_backlinks.py` from skill frontmatter; do not edit by hand.

Skills whose frontmatter `refs:` includes `REF-ObservableFramework`:

- `bootstrap-observable-dashboard` - Scaffold an Observable Framework dashboard project against an existing Data Pack.
