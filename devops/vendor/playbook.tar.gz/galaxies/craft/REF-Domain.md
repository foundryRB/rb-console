---
domain: architecture
---

# REF: Domain Layer

> When asked to create or modify domain entities, value objects, enums, constants, or services, follow these rules strictly.

---

## 1. What Lives in the Domain

The domain layer is the innermost ring. It contains:

| Sub-package     | Contents                                                  |
|-----------------|-----------------------------------------------------------|
| `model/aggregates/` | Aggregate roots - own child entities, coordinate behavior |
| `model/entities/`   | Entities - identity-based, mutable domain objects         |
| `model/value_objects/` | Value objects (`frozen=True`), enums, NewTypes          |
| `services/`     | Stateless domain services - complex logic spanning entities|
| `exceptions/`   | Domain exception hierarchy - see `REF-ExceptionHandling.md` |
| `constants.py`  | Ubiquitous language constants - file names, column names, colors |

---

## 2. Purity Rules

The domain layer is **pure Python, pure logic**:

- **No I/O** (files, network, database).
- **No third-party dependencies** - Python stdlib only. No framework code (Pydantic, FastAPI, SQLAlchemy).
- **No imports from application or adapter layers** - the domain knows nothing about ports, use cases, or infrastructure.

If you need I/O, define an outbound port in the application layer and implement it in an outbound adapter.

---

## 3. Entities vs. Value Objects

- **Entities**: identity-based, may be mutable - use `@dataclass` (not frozen).
- **Value objects**: no identity, structural equality - always `@dataclass(frozen=True)`.
- **Enums**: `StrEnum` for values needing string serialization, plain `Enum` for internal-only. Each enum class in its own file in `model/`.

---

## 4. The Aggregate Root

Rules for the aggregate root (the central entity owning the bounded context):

- Constructed by a repository (outbound adapter); use cases receive it from the repository - they never construct one manually.
- Writers/renderers receive it as a parameter - they never call the repository.
- Owns cross-entity behavior (e.g., `Order.calculate_total()`); children compute their own local logic.
- Child entities are accessed only through the aggregate root.

---

## 5. Domain Services

When business logic spans multiple entities or is too complex for a single entity method, extract it to a **domain service** in `services/`.

- Domain services are **stateless** - no instance state, no constructor dependencies. They receive domain entities as parameters and return domain types.
- **Prefer module-level functions** over classes when the service has no reason to be instantiated. A class with only static methods or a single public method should be a module instead. Use the class form only when grouping related algorithms with shared config (e.g. `PricingCalculator`).

```python
# ✅ Module-level functions (preferred for stateless logic)
def schedule(phase: Phase) -> PhaseRoadmap:
    """Run the full scheduling pipeline."""
    ...
```

---

## 6. Constants

`constants.py` is the **single source of truth** for all shared identifiers:

- Column names, status labels, currency codes, configuration keys - `UPPER_SNAKE_CASE`.
- Part of the Ubiquitous Language - both domain logic and adapters may import from here.
- **No duplication** - every identifier or token is defined exactly once.

---

## 7. File Organization

```
domain/
├── constants.py
├── model/
│   ├── __init__.py              # Barrel - re-exports all public types
│   ├── aggregates/
│   │   ├── __init__.py
│   │   ├── order.py             # Aggregate root
│   │   └── order_line.py        # Child aggregate (if complex)
│   ├── entities/
│   │   ├── __init__.py
│   │   ├── order_item.py        # Entity with identity
│   │   └── customer.py          # Entity with identity
│   └── value_objects/
│       ├── __init__.py
│       ├── money.py             # frozen=True dataclass
│       ├── address.py           # frozen=True dataclass
│       ├── order_status.py      # StrEnum
│       └── order_summary.py     # frozen=True dataclass
├── services/
│   ├── pricing_calculator.py
│   └── requirement_service.py   # Module-level utility functions
└── exceptions/
    └── (see REF-ExceptionHandling.md)
```

### Sub-folder Taxonomy

| Sub-folder       | Criteria                                                      |
|------------------|---------------------------------------------------------------|
| `aggregates/`    | Owns child entities; has lifecycle; coordinates behavior       |
| `entities/`      | Has identity (`*_id`); may be mutable; owned by an aggregate  |
| `value_objects/` | `frozen=True` dataclass, `StrEnum`, `Enum`, or `NewType`       |

**One class per file** - no exceptions. If a file has a `# --- Section ---` comment, it should be split.

---

## 8. The `model/__init__.py` Barrel

The model barrel file re-exports all public domain types (`from <package>.domain.model.order import Order`, etc.). Internal modules may import directly from individual files for explicit dependency graphs; external consumers (adapters) may import from the barrel when convenient.

---

## 9. Value Object Design Patterns

### VOs Don't Know External Formats

Value objects must **never** have factory methods that parse external formats. Format parsing belongs in adapters.

```python
# ❌ Wrong - VO knows about external formats
@dataclass(frozen=True)
class SomeVO:
    @classmethod
    def from_dict(cls, row: dict) -> SomeVO: ...

# ✅ Right - adapter constructs the VO
class CsvParserAdapter:
    def parse(self, content: bytes) -> list[SomeVO]:
        return [SomeVO(field=row["Field"], ...) for row in reader]
```

### VOs Can Have Behavior (But Not Format Parsing)

Value objects may have methods/properties that **derive information from their own data** (e.g. `Money.is_zero`) - that is domain logic, not format parsing.

### Prefer Unified Types with Status

Instead of separate types for different outcomes (`SuccessResult` / `FailedResult`), use one frozen dataclass with a status enum:

```python
class ResultStatus(StrEnum):
    SUCCESS = "success"
    FAILED = "failed"

@dataclass(frozen=True)
class ProcessingResult:
    status: ResultStatus
    reason: str | None = None
```

### One Field Per Asserted Fact

Store each fact a user asserts in its own field; derive the rendered or reported state from the set. Never store the derived form and infer the facts back out of it.

When one stored value stands in for two independent assertions, every transition has to guess which assertion the caller meant, and the guesses are wrong at the edges - the classic symptom is that undoing one action leaves the model in a state nobody asked for.

```python
# Wrong: one field serving two independent assertions
@dataclass
class Inspection:
    stage: InspectionStage          # which of "checked" and "confirmed" is this?

# Right: one field per assertion, each stamped; the stage is a calculation
@dataclass(frozen=True)
class Inspection:
    checked_at: datetime | None = None
    confirmed_at: datetime | None = None

    @property
    def stage(self) -> InspectionStage: ...
```

Ask, at modelling time: *how many distinct things is the caller telling me here?* The answer is the number of fields. The audit trail then falls out for free - a record can report when each fact was asserted only because the facts were stored separately.

---

## 10. Anti-Patterns

| #  | Anti-Pattern                                | Correct Approach                              |
|----|---------------------------------------------|-----------------------------------------------|
| 1  | I/O in domain code                          | Define an outbound port                       |
| 2  | `import fastapi` in domain                  | Domain uses only stdlib                       |
| 3  | `from <package>.application...` in domain      | Domain never imports from application layer   |
| 4  | Business logic in a use case                 | Move to entity method or domain service       |
| 5  | Mutable value object (`@dataclass` without `frozen=True`) | Use `frozen=True` for VOs      |
| 6  | Magic strings for domain concepts            | Create a `StrEnum` in `model/`               |
| 7  | Duplicated constant across files             | Single definition in `constants.py`          |
| 8  | Return type described by a comment           | Create a frozen dataclass                    |
| 9  | `from_dict()` / `from_json()` on a VO       | Adapter constructs the VO                     |
| 10 | Multiple types for different outcomes        | One type with a status enum                   |
| 11 | One field standing in for two independent assertions | One field per asserted fact; derive the combined state (§9) |

---

## 11. Skills that instantiate this REF

Generated by `scripts/sync_backlinks.py` from skill frontmatter; do not edit by hand.

Skills whose frontmatter `refs:` includes `REF-Domain`:

- `contentful-content-management` - Work a Contentful space: hunt for the type that already exists and show it before ever proposing a new one, rule on the standing question every content request really asks - reuse, extend, or create - and never touch an existing type without putting its entry counts, inbound links and outside consumers in front of the user first.
