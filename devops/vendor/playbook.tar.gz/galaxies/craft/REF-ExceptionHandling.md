---
domain: architecture
---

# REF: Exception Handling

> When asked to create, modify, or handle exceptions, follow these rules strictly. Covers the domain exception hierarchy, adapter mapping, and error propagation.

---

## 1. Exception Hierarchy

All application exceptions inherit from a single root:

```
AppError (root - catch-all for "something went wrong in the application")
├── EntityNotFoundError        (a required entity/record was not found)
├── DataLoadError              (data source exists but can't be loaded)
├── ResourceNotFoundError      (a required resource - file, config - is missing)
├── DataParseError             (a data source exists but can't be parsed)
├── TemplateNotFoundError      (a template file is missing)
├── ConfigurationError         (invalid configuration)
├── ProcessingError            (a pipeline/processor failed to produce output)
└── ExternalServiceError       (an external service call failed)
```

---

## 2. One Exception Per File

Every exception class lives in its own file under `domain/exceptions/`, named the `snake_case` version of the class name (e.g. `entity_not_found_error.py`). No exceptions share a file.

---

## 3. Exception Class Template

```python
from <package>.domain.exceptions.app_error import AppError


class EntityNotFoundError(AppError):
    """A required entity or record could not be found."""

    def __init__(self, entity_type: str, identifier: str) -> None:
        self.entity_type = entity_type
        self.identifier = identifier
        super().__init__(f"{entity_type} not found: {identifier}")
```

Rules:
- **Always inherit from `AppError`** (directly or transitively).
- **Carry structured context** - store relevant data (path, reason, etc.) as instance attributes, not just in the message string; `super().__init__()` with a human-readable message.
- Module docstring + class docstring, both describing the error condition.

---

## 4. The `__init__.py` Barrel

Unlike ports (which don't re-export), the exceptions package **does re-export** every exception via `__init__.py` with `__all__`: `from <package>.domain.exceptions import EntityNotFoundError` (or `AppError` as catch-all).

---

## 5. Where Exceptions Are Raised

| Layer              | Raises                                                     |
|--------------------|------------------------------------------------------------|
| **Outbound Adapter** | Catches infra errors → raises domain exceptions          |
| **Domain Entity**    | Validates invariants → raises domain exceptions           |
| **Domain Service**   | Detects algorithm failures → raises domain exceptions     |
| **Use Case**         | Rarely - only to re-wrap with more context                |

**Never raise raw Python exceptions** (`ValueError`, `FileNotFoundError`, `KeyError`) from domain or application code - always a domain exception with structured context.

---

## 6. Where Exceptions Are Caught

Exceptions propagate **outward** from domain → use case → adapter. The **adapter layer** catches and translates domain exceptions.

- **HTTP**: one generic `@app.exception_handler(AppError)` registered by `register_exception_handler(app)` in `exception_handlers.py`; it looks up `STATUS_MAP.get(type(exc), DEFAULT_STATUS)` and returns a JSON error body.
- **CLI**: the runner does the same lookup against `EXIT_CODE_MAP` with `DEFAULT_EXIT_CODE = 1`.
- Both dicts are typed `dict[type[AppError], int]` and live in `mappers/exception_mapper.py`; values in §8.

---

## 7. Exception Mapping Is a Mapper Concern

The mapping from domain exceptions to status codes / exit codes is a **mapper concern**, not a handler concern: the dict lives in `mappers/exception_mapper.py`; the handler (`exception_handlers.py` for HTTP, runner for CLI) stays thin - it registers the mechanism, imports the dict, and does the lookup. **Never** define the mapping inline in the handler, and never scatter individual `except` blocks per exception type.

---

## 8. Mapping Convention

| Domain Exception           | HTTP Status | CLI Exit Code | Semantic Group       |
|----------------------------|-------------|---------------|----------------------|
| `EntityNotFoundError`      | 404         | 2             | Not found            |
| `ResourceNotFoundError`    | 404         | 2             | Not found            |
| `TemplateNotFoundError`    | 404         | 2             | Not found            |
| `DataParseError`           | 422         | 3             | Invalid input        |
| `ConfigurationError`       | 422         | 3             | Invalid input        |
| `DataLoadError`            | 422         | 3             | Invalid input        |
| `ProcessingError`          | 500         | 4             | Processing failure   |
| `ExternalServiceError`     | 500         | 4             | Processing failure   |
| `AppError` (fallback)      | 500         | 1             | Unknown app error    |

---

## 9. Anti-Patterns

| #  | Anti-Pattern                                         | Correct Approach                                |
|----|------------------------------------------------------|-------------------------------------------------|
| 1  | `except Exception: pass`                             | Catch specific domain exceptions                |
| 2  | Raising `ValueError` from domain code                | Raise a domain exception with context           |
| 3  | Multiple `except` blocks in handler (one per type)   | Single handler + mapping dict                   |
| 4  | Mapping dict defined inside the handler file         | Mapping dict in `mappers/exception_mapper.py`   |
| 5  | Exception class with only a string message           | Store structured context as instance attributes |
| 6  | Multiple exception classes in one file               | One exception per file                          |
| 7  | `from None` omitted when wrapping infra exceptions   | `raise DomainError(...) from exc` or `from None`|
| 8  | Exception class not inheriting from `AppError`       | Always inherit from `AppError`                  |
| 9  | Use case catching and swallowing domain exceptions   | Let them propagate to the adapter               |

---

## 10. Skills that instantiate this REF

Generated by `scripts/sync_backlinks.py` from skill frontmatter; do not edit by hand.

Skills whose frontmatter `refs:` includes `REF-ExceptionHandling`:

- `bootstrap-hexagonal-backend` - Scaffold a new Python FastAPI service in hexagonal (ports and adapters) architecture, conforming to REF-CleanArchitecture / REF-FastAPI / REF-Python.
