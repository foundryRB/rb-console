---
domain: architecture
---

# REF: Pipeline

> When asked to build a system where data flows through ordered processing steps, follow these rules strictly.

---

## 1. When to Use This

Use when work flows through **ordered steps** (each step's output feeds the next), the same sequence runs **for multiple inputs**, and steps share state without depending on each other's internals.

Do **not** use for: a single one-input-one-output transform (plain function), fan-out/fan-in parallelism (DAG scheduler), or non-deterministic event-driven flows (event bus).

---

## 2. Core Concepts

### Context Bag

A **mutable dataclass** carried through every step. It is the single data channel - steps never communicate through imports, globals, or return values.

```python
@dataclass
class PipelineContext:
    input_dir: Path
    output_dir: Path
    current_item: str                  # name of the item being processed
    item_config: dict                  # configuration block for this item
    data: list[dict[str, str]]         # current working set
    metadata: dict[str, Any]           # step-produced metadata for later steps
```

Java: same shape as a `PipelineContext` class (final input/output paths, mutable working fields).

Rules:

| Rule | Rationale |
|------|-----------|
| Created fresh per iteration | No cross-iteration state leak |
| Steps mutate it - they do not return new contexts | Keeps signatures simple; avoids allocation churn |
| Contains everything a step might need | Steps should never reach outside the context for data |

### Steps

Each step is a **single module** (Python) or **single class** (Java) with one entry point:

**Python** - one module in `pipeline/steps/`, one function:

```python
def run(ctx: PipelineContext) -> None:
    """Load source data into the context."""
    ...
```

**Java** - one class implementing a `Step` interface:

```java
public interface Step {
    void run(PipelineContext ctx);
}
```

### Runner

The runner owns the step list and the iteration loop. It has **no conditional logic** - it always runs the same steps in the same order. Steps internally handle "nothing to do" gracefully (early return, not exception).

```python
STEPS = [load_input, validate, transform, write_output]

for i, (name, cfg) in enumerate(config["items"].items(), 1):
    logger.info("[%d/%d] Processing %s", i, total, name)
    ctx = PipelineContext(current_item=name, item_config=cfg, ...)
    for step in STEPS:
        step.run(ctx)
```

---

## 3. Rules

| Rule | Rationale |
|------|-----------|
| Step order is explicit in the runner - a flat list | No implicit ordering through dependency graphs |
| A step should be 10–30 lines | If larger, delegate to a helper or split into two steps |

The remaining rules (one module per step, no cross-step imports, no per-item runner logic) are enforced by the anti-patterns table in section 7.

---

## 4. Folder Layouts

**Python:**

```
<project>/
├── pipeline/
│   ├── context.py          # PipelineContext dataclass
│   ├── runner.py           # STEPS list + iteration loop
│   └── steps/
│       ├── load_input.py   # Step 1
│       ├── validate.py     # Step 2
│       ├── transform.py    # Step 3
│       └── write_output.py # Step 4
└── tools/                  # I/O helpers used by steps (readers, writers, parsers)
```

**Java:**

```
<module>/
├── pipeline/
│   ├── PipelineContext.java
│   ├── Step.java               # interface
│   ├── PipelineRunner.java     # STEPS list + iteration loop
│   └── steps/
│       ├── LoadInput.java
│       ├── Validate.java
│       ├── Transform.java
│       └── WriteOutput.java
└── adapter/                    # I/O adapters used by steps
```

---

## 5. Configuration

When items to process are known at configuration time (not discovered at runtime), declare them in a config file:

```yaml
items:
  <ItemA>:
    source: <input_file>
    option_x: value
  <ItemB>:
    source: <other_file>
    option_x: other_value
```

Rules:
- **One config file** - all items visible in one place.
- **Steps never parse the config file** - the runner loads it and injects into the context; steps read `ctx.item_config`.

---

## 6. Composition with Other Patterns

A pipeline is a skeleton; other patterns compose at the step level:

| Pattern | How it integrates |
|---------|-------------------|
| Plugin architecture (see `REF-PluginArchitecture.md`) | One step resolves and executes plugins from config |
| Strategy pattern | A step selects a strategy based on `ctx.item_config` |
| Adapter pattern | Steps delegate I/O to adapter modules in `tools/` or `adapter/` |
| Template method | The runner *is* a template method - fixed skeleton, varying step implementations |

The pipeline itself stays unaware of which patterns live inside its steps.

---

## 7. Anti-Patterns

| # | Anti-Pattern | Correct Approach |
|---|-------------|------------------|
| 1 | Steps importing other steps | Communicate through the context bag |
| 2 | Runner with if/else per item type | Steps handle variation internally; the runner runs the same sequence |
| 3 | Multiple steps in one file | One file per step - each step is independently locatable |
| 4 | Steps doing I/O directly (opening files, calling APIs) | Delegate to `tools/` or `adapter/` - steps orchestrate, they don't do raw I/O |
| 5 | Returning data from steps instead of mutating context | Mutate the shared context; this keeps the runner loop trivial |
| 6 | Reusing a context across iterations | Fresh context per item - no stale state |
| 7 | Hardcoding item-specific logic in steps | Per-item variation lives in config; steps read `ctx.item_config` |
