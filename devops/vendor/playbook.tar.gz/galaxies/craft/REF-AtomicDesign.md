---
domain: architecture
---

# REF: Atomic Design

> Read when building or structuring a frontend's View layer: the atoms-to-pages component taxonomy, the classification tests that decide a component's level, and the composition and state rules each level obeys. The framework-agnostic core that REF-Frontend.md specializes for React.

---

## 1. Scope

Atomic Design is the taxonomy for the **V** of MVVM: how View components are named, layered, and composed. It answers one question, "which level does this component belong to?", and enforces the rules that follow from the answer. It is framework-agnostic: the same five levels apply whether the primitives come from a component library, a headless-primitive kit, or hand-written elements.

This REF is the **core**; `REF-Frontend.md` §5 is its React/Tailwind specialization, and the composition standard of `REF-Authoring.md` §5 governs the split. Where a View connects to data belongs to the ViewModel boundary (`REF-Frontend.md` §2, §4), not here: this REF governs component structure, not state management.

One rule underpins the rest: **a component's level is a function of its composition and its dependencies, never its visual size or its apparent importance.** A tiny badge deep in a table is still an atom; a full-width but purely decorative divider is still an atom.

---

## 2. The five levels

| Level | What it is | Composes | Example |
| ----- | ---------- | -------- | ------- |
| **Atom** | The smallest useful unit; cannot be decomposed without losing meaning. | Nothing (wraps one primitive, or renders raw elements) | `StatusBadge`, `EmailInput`, `PriceTag` |
| **Molecule** | A small group of atoms working together as one reusable unit with a single responsibility. | Atoms | `SearchBar`, `LabeledInput`, `Pagination` |
| **Organism** | A distinct, self-contained section of an interface. | Atoms, molecules, and other organisms | `SiteHeader`, `DataTable`, `CommentThread` |
| **Template** | A page-level layout: the arrangement of organisms into a structure, with placeholder content. | Organisms (positioned, not filled) | `DashboardTemplate`, `ArticleTemplate` |
| **Page** | A concrete instance of a template, filled with real data for one route. | A template + data | `DashboardPage`, `ArticlePage` |

The levels form a strict ladder. Every component sits on exactly one rung, and the whole View layer is these five rungs and nothing else: there is no "shared" or "common" bucket holding View components that dodged classification.

### The primitive layer (below the ladder)

Beneath the atom sits the **primitive layer**: the buttons, inputs, and dialogs a component library, a headless-primitive kit, or the raw platform elements provide. It is not a sixth rung, because it is not yours. Primitives are **domain-unaware** (they know nothing of your entities) and **toolchain-owned** (a CLI writes them, or a package ships them), and they live wherever that toolchain puts them, outside the level folders.

| | Primitive | Atom |
| --- | --- | --- |
| Knows your domain | No | Yes |
| Authored by | The library or its CLI | You |
| Lives in | The package, or the folder its CLI owns | `atoms/` |
| Example | `Badge`, `TextField`, `<button>` | `StatusBadge`, `EmailInput` |

**An atom is the seam between the two: it wraps one primitive and gives it your domain's meaning.** `StatusBadge` maps an order status onto a `Badge`'s variants; the primitive knows about variants, the atom knows about orders.

**Customization lands in the atom, never in the primitive.** A primitive edited in place drifts from the version its toolchain will regenerate, and hand-edited copies maintained in parallel are the universe's first violation (`AI-PLAYBOOK.md`). Everything reachable through a primitive's props, class names, or variants belongs in the atom that wraps it; everything about *look* belongs in the design tokens (`REF-Design.md` §2), which restyle every primitive at once.

**When a wrapper cannot express it, fork down, do not edit up.** Structural changes (a slot inside the primitive's own markup, different underlying elements) are unreachable from a wrapper. Write that component as a hand-authored atom in `atoms/`, built on the raw elements or on the headless primitive directly, and stop importing the library's version for that case. Ownership then matches the folder it sits in, and the primitive layer stays regenerable.

---

## 3. The classification test

Decide a component's level by asking these in order; the first that fits wins.

1. **Can it be broken into smaller components that each carry their own meaning?** No, and it wraps a single primitive or element: **atom**. A component that only styles or configures one primitive (a `PrimaryButton` over a `Button`) is still an atom.
2. **Is it a small cluster of atoms with one job, reused as a unit?** **Molecule.** A label plus its input plus its error text is a molecule: three atoms, one responsibility (capture one field).
3. **Is it a standalone section a designer would name on its own, potentially holding molecules and atoms?** **Organism.** A header, a data table, a card list. Organisms are where a section becomes recognizable ("the nav", "the results grid").
4. **Does it define where organisms sit on the screen, without committing to real content?** **Template.** Structure and slots only; loading skeletons and placeholders live here.
5. **Is it a route's real instance, binding a template to actual data?** **Page.** One per route.

Two tie-breakers:

- **Size and complexity do not decide the level; composition does.** A visually heavy component built from one primitive is an atom; a visually plain component that assembles three atoms is a molecule.
- **Place a component at the lowest level that fits, and promote only on real reuse.** Do not pre-build a molecule for an atom used once. Extract upward when a second caller appears, not in anticipation of one (`REF-Authoring.md` §4, earn every addition).

---

## 4. The composition rule (the dependency ladder)

A component may compose components at its **own level or below**, never above.

```
Page      -> Template (+ data)
Template  -> Organisms
Organism  -> Organisms, Molecules, Atoms
Molecule  -> Atoms
Atom      -> primitives only
```

Rules:

- **No upward or skip-the-owner composition.** An atom never renders a molecule; a molecule never reaches for an organism. A template composes organisms, not loose atoms scattered around them.
- **Same-level composition is allowed only for organisms.** An organism may contain another organism (a toolbar inside a table). Atoms and molecules do not nest into their own level; if an atom seems to need another atom, it is a molecule.
- **One component per unit; the unit is named for the component.** The level folder the unit sits in (`atoms/`, `molecules/`, ...) is the single source of truth for its level; a component appears in exactly one level folder. Whether a unit is one file or a folder of files is the specialization's (`REF-Frontend.md` §9).

---

## 5. The purity gradient (where state and data are allowed)

Data and connected state enter the View at the top and flow down as inputs. The lower a level, the purer it is.

| Level | Local UI state (open, hovered) | Connected state / data fetching | Receives data as |
| ----- | ------------------------------ | ------------------------------- | ---------------- |
| Atom | No | No | Inputs only |
| Molecule | Minimal, self-contained | No | Inputs only |
| Organism | Yes | Allowed: may bind to a ViewModel | Inputs, or from its own ViewModel |
| Template | No (layout only) | No | Slots / placeholders |
| Page | Orchestration only | Owns data acquisition | Reads the ViewModel, passes down |

Rules:

- **Atoms and molecules are pure: inputs in, markup out.** They hold no reference to global or connected state and never fetch. This is what makes them reusable and testable in isolation. Transient, self-contained UI state (a dropdown's open flag) is the only state a molecule may keep.
- **Connection happens at organisms and pages, not below.** An organism may read its own slice of ViewModel state; a page acquires the data for its route and hands it down. The boundary they connect to is the ViewModel (`REF-Frontend.md` §2, §4), never a data source reached directly from the View.
- **No business logic in any View level.** Formatting a value for display is allowed anywhere; filtering, sorting, aggregating, or deciding is ViewModel work. If a component computes rather than presents, the computation belongs above the View.
- **Templates hold no real data.** They lay out organisms with placeholders and skeletons; the page supplies the content. A template that imports a domain type to render it has become a page.

---

## 6. Templates versus pages

The most-confused boundary. Keep them distinct:

| | Template | Page |
| --- | -------- | ---- |
| Owns | Layout and structure | Data and route binding |
| Content | Placeholders, skeletons, slots | Real values |
| Count | Reused across many pages | One per route |
| Knows the domain? | No | Yes |

A single template serves many pages; a page is a thin adapter that selects a template, pulls the route's data from the ViewModel, and fills the slots. When two routes share a layout, they share a template and differ only in their pages.

---

## 7. Folder layout and naming

```
views/
  atoms/        # Button, StatusBadge
  molecules/    # SearchBar, LabeledInput
  organisms/    # DataTable, SiteHeader
  templates/    # DashboardTemplate
  pages/        # DashboardPage  (one per route)
```

- **Level = folder.** A component's level is the level folder its unit sits in; moving levels means moving the unit, not renaming.
- **Name by role, not by page.** `SearchBar`, not `ProductsPageSearchBar`. A name that embeds a page or a domain term has usually mis-levelled the component (that coupling belongs to a page or an organism, not a reusable lower level).
- **A component's unit is PascalCase and matches the exported component name.** The unit's shape (file or folder), its file set, and the casing and extension rules live in the specialization (`REF-Frontend.md` §9).

---

## 8. Relationship to MVVM

Atomic Design structures the View; it does not replace the ViewModel. The clean seam:

- The **View** (this REF) decides *how components compose and where data may enter*.
- The **ViewModel** (`REF-Frontend.md` §4) decides *what the data is and how it changes*.
- Pages and connected organisms are the only View components that touch the ViewModel; everything below stays pure and reusable across projects and ViewModels alike.

Specialization: `REF-Frontend.md` §1 and §5 apply these levels to a React + Tailwind stack, adding the connected-state mechanism (SAM viewmodels) and the primitives source (a `ui/` primitives folder) as framework deltas over this core.

---

## 9. Anti-Patterns

| # | Anti-Pattern | Correct approach |
| - | ------------ | ---------------- |
| 1 | Levelling by visual size or importance ("it is big, so it is an organism") | Level by composition and dependencies (§3) |
| 2 | A "shared" or "common" bucket holding View components that dodged classification | Every View component sits on exactly one rung; the toolchain's primitive folder is not such a bucket (§2) |
| 3 | Editing a library primitive in place to customize it | Customize in the atom that wraps it, or in the design tokens; fork down to a hand-authored atom when structure is the problem (§2) |
| 4 | Filing a library primitive as an atom, or an atom that adds nothing to the primitive it re-exports | An atom carries domain meaning; a bare re-export is the primitive under a new name (§2) |
| 5 | An atom or molecule fetching data or reading connected state | Connect at organisms and pages; keep lower levels pure (§5) |
| 6 | Upward composition (an atom renders a molecule) | Compose own level or below only (§4) |
| 7 | Business logic (filter, sort, compute) inside a View component | Move it to the ViewModel; the View presents (§5, `REF-Frontend.md`) |
| 8 | A template that imports domain data to render it | Templates lay out with placeholders; pages fill them (§6) |
| 9 | Naming a reusable component after the page that first used it | Name by role; page coupling belongs to the page (§7) |
| 10 | Pre-building a molecule or organism for a single use | Place at the lowest level that fits; promote on real reuse (§3, §4) |
| 11 | The same component filed under two levels, or many components in one unit | One component per unit; level = folder (§4) |

---

## 10. Skills that instantiate this REF

Generated by `scripts/sync_backlinks.py` from skill frontmatter; do not edit by hand.

Skills whose frontmatter `refs:` includes `REF-AtomicDesign`:

- `bootstrap-atomic-mui` - Scaffold an Atomic-Design views/ tree (atoms, molecules, organisms, templates, pages) backed by MUI (@mui/material) primitives, per REF-AtomicDesign's levels, composition ladder, and purity gradient.
- `bootstrap-atomic-shadcn` - Scaffold an Atomic-Design views/ tree (atoms, molecules, organisms, templates, pages) backed by shadcn/ui primitives onto a React + Tailwind project, one exemplar per level demonstrating the composition ladder and purity gradient of REF-AtomicDesign; additive to an existing project, distinct from the whole-project bootstrap-react-mvvm.
