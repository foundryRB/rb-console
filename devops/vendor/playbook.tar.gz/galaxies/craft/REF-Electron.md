---
domain: framework
---

# REF: Electron desktop shell

> Read this REF when shipping a web frontend as an installable desktop app: the Electron shell around a Vite/React renderer, the main/preload/renderer boundary and its typed IPC, and packaging installers as release artifacts.

---

## 1. Scope

Electron wraps a web renderer in a native window and gives it an OS presence: a main process with Node and OS access, a windowed Chromium renderer, and a controlled bridge between them. This REF owns everything from the Electron shell outward: the main process, the preload bridge, window lifecycle, the IPC contract, and packaging the result into per-OS installers.

It does **not** own the renderer. The shell treats the UI inside the window as a guest it hosts, not code it authors, and the application's topology decides which REF governs that guest (`REF-CleanArchitecture.md` §1). A client-server application's renderer is a Vite/React MVVM frontend under `REF-Frontend.md` + `REF-React.md`, and is `bootstrap-react-mvvm`'s output. A standalone application's renderer is an inbound adapter of the application's own core, under `REF-TypeScript.md`. The shell composes around either (see §2). Nor is Electron the default answer to "we want a desktop feel": a PWA (`REF-PWA.md`) or a plain browser tab is lighter and updates without a reinstall. Pay for a bundled Chromium and a signing-and-packaging pipeline only when the app genuinely needs the local machine: the filesystem, native menus, a tray, OS notifications, background processes, or offline-first with no server.

---

## 2. The shell is a host, the renderer is a guest

The Electron shell and the web renderer are two projects with one boundary, not one project. Keep them separated the way the module/host boundary is kept in `REF-ThreeJS.md` §2:

- **The renderer runs without Electron.** It builds with Vite to static assets, runs in a browser during development, and knows nothing about Electron beyond a typed handle it is handed at runtime (§4). It never imports `electron`, never reaches for Node built-ins, and never assumes it is inside a window. This is what lets the same renderer serve both the browser and the desktop shell from one codebase.
- **The shell scaffolds around an existing renderer, it does not re-create one.** `bootstrap-electron` adds the `electron/` process code, the packaging config, and the release job to a project that already has a renderer: `bootstrap-react-mvvm`'s output for a client-server application, or the application's own UI adapter for a standalone one. It **composes** rather than scaffolding a second frontend, the way `bootstrap-mcp-adapter` adds an MCP surface to an existing `bootstrap-hexagonal-backend` service rather than standing up a new one.
- **Repo topology is a per-project decision.** Whether the shell shares a repo with its renderer or stands alone consuming other services over their APIs is recorded in that app's `docs/` ADRs, not standardised here. The boundary above holds either way.

A minimal shell layout, whatever the repo topology:

```
electron/
  main.ts        # main process: creates the BrowserWindow, owns OS access, registers IPC handlers
  preload.ts     # the ONLY code with a foot in both worlds; declares the contextBridge surface (§4)
renderer/        # the Vite/React MVVM app (bootstrap-react-mvvm output); builds to static assets
electron-builder.yml
```

---

## 3. Process boundaries: the security defaults are the scaffold

Electron runs three kinds of code with three different privilege levels, and the boundary between them is a security boundary, not a module boundary. The scaffold ships the locked-down posture as its default, not as advice a project opts into:

| Process | Privilege | Rule |
| ------- | --------- | ---- |
| **Main** | Full Node + OS | One per app. Owns the window lifecycle, native menus, and every OS-touching operation. All privileged work lives here. |
| **Preload** | Bridged | The only code that sees both worlds. Runs before the renderer loads and exposes a **narrow, typed** API over `contextBridge` (§4). Nothing else crosses. |
| **Renderer** | Sandboxed web | Ordinary web app. No Node, no `electron`, no filesystem. It asks the main process for what it needs through the preload surface. |

The `webPreferences` the scaffold sets on every `BrowserWindow`, and why each is load-bearing:

```ts
new BrowserWindow({
    webPreferences: {
        contextIsolation: true,   // renderer and preload get separate JS contexts; the bridge is the only link
        nodeIntegration: false,   // no `require`/`process`/Node globals in the renderer
        sandbox: true,            // renderer runs in an OS sandbox; a renderer compromise is contained
        preload: path.join(__dirname, "preload.js"),
    },
});
```

- **These three flags are not independent knobs to tune per feature.** `contextIsolation: true` and `nodeIntegration: false` together are what stop a compromised renderer (a bad dependency, an XSS in rendered content) from owning the user's machine. Turning either off to "make an import work in the renderer" is moving privileged work to the wrong side of the boundary; move the work to main and expose a method instead.
- **Load remote content in a normal browser, not in your privileged shell.** The window loads the app's own bundled assets (or the dev server in development). Arbitrary third-party URLs open in the OS browser via `shell.openExternal`, never in a `BrowserWindow` that carries your preload. Set a `will-navigate` / `setWindowOpenHandler` guard so a stray link cannot repoint the window.

---

## 4. The IPC contract is a typed contextBridge surface

Every path from the renderer to the main process crosses one declared surface in preload. There is no ambient `ipcRenderer` in the renderer, and there is no stringly-typed channel scattered across the codebase:

```ts
// preload.ts - the whole contract, in one file, typed once.
import { contextBridge, ipcRenderer } from "electron";

const api = {
    // request/response: renderer asks, main answers.
    readConfig: (): Promise<AppConfig> => ipcRenderer.invoke("config:read"),
    saveFile: (contents: string): Promise<string> => ipcRenderer.invoke("file:save", contents),
    // main-initiated stream: renderer subscribes, gets a disposer back.
    onUpdateProgress: (cb: (pct: number) => void): (() => void) => {
        const handler = (_e: unknown, pct: number) => cb(pct);
        ipcRenderer.on("update:progress", handler);
        return () => ipcRenderer.removeListener("update:progress", handler);
    },
};

contextBridge.exposeInMainWorld("desktop", api);
export type DesktopApi = typeof api;   // the renderer imports this type, never the impl
```

Conventions the scaffold ships:

- **`invoke`/`handle` for request-response; `send`/`on` only for genuine main-initiated streams.** A renderer that needs an answer uses `ipcRenderer.invoke` against a `ipcMain.handle`, so the reply is a promise, not a second channel the caller has to correlate by hand.
- **Channel names are namespaced `domain:action`** (`file:save`, `config:read`) and live only inside preload and main. The renderer sees methods (`window.desktop.saveFile`), never channel strings.
- **The surface is minimal and specific.** Expose `saveFile(contents)`, never `invoke(channel, ...args)`; a passthrough that lets the renderer call any channel hands back exactly the Node access `sandbox` and `nodeIntegration: false` just removed.
- **The renderer consumes the surface through one typed façade**, so the UI depends on `DesktopApi`, not on `window.desktop` reached for ad hoc. In a client-server application the façade wires into the MVVM layer as an outbound port the same way any other I/O adapter is. In a standalone application the surface carries the application's own inbound ports (`REF-TypeScript.md` §7), so the façade is derived from those declarations rather than hand-written once per process. When `window.desktop` is absent (the app running as a plain web build), the façade degrades to a web fallback rather than throwing, keeping the one-codebase-two-surfaces property of §2.
- **Validate every argument on the main side.** IPC input is untrusted input; a `file:save` handler checks the path is inside an allowed directory before writing. The boundary is a trust boundary in both directions.

---

## 5. Auth: a shell needs its own public OIDC client, separate from a fronting proxy's

A shell served from a registered custom scheme (`app://`) shares no origin, and so no cookie jar, with the backend's own origin - a browser fact, not a security posture, so it cannot ride a fronting auth proxy's session cookie in principle. It needs its own token-based OIDC flow instead (system browser + loopback redirect + PKCE), holding the bearer token in the main process and exposing it to the renderer through the `contextBridge` surface (§4) - never a cookie, and never storage the renderer reaches directly.

**That flow needs a public OIDC client, kept separate from the confidential client a fronting proxy needs for its own server-side exchange.** A fronting proxy uses a confidential client; a shell running a public PKCE flow against that same client sends no client secret, and Keycloak answers `401 unauthorized_client` at the token endpoint regardless of registered redirect URIs - a failure that reads like a redirect-URI misconfiguration and is neither (evidence: `alexandria#3`, eight Build+Ship attempts before the client-type mismatch was found). Register a second, public client for the shell's own flow, sharing the confidential client's audience mapper so the backend's `aud` check needs no change.

---

## 6. Packaging: installers are release artifacts

The installable app is a **build artifact attached to the repository's release**, produced by a per-OS matrix job in CI. Verify that each release carries installer assets for every supported target OS.

- **electron-builder is the packaging tool.** It builds the platform installers (`.exe`/NSIS on Windows, `.dmg` on macOS, `AppImage`/`.deb` on Linux) from one `electron-builder.yml`. The config, not a pile of per-OS scripts, is the source of truth for what ships.
- **The matrix runs one job per target OS.** electron-builder builds a platform's installer only on that platform (a macOS `.dmg` needs a macOS runner; a clean Windows installer needs Windows), so the job pins its own `runs-on` across `windows-latest`, `macos-latest`, and `ubuntu-latest` rather than inheriting an org default, which is commonly Linux-only and can produce neither a macOS nor a clean Windows artifact.
- **The OS matrix is a deliberate cost decision.** On private repositories the GitHub-hosted macOS runner bills at a 10x minute multiplier; a project that does not ship a Mac build drops that leg of the matrix on purpose, and records the choice.
- **The Windows target chosen here has consequences beyond packaging shape.** `win.target` also decides whether a future in-app updater is possible at all (§8); that consequence belongs beside the choice, not discovered after a project has shipped on it.

---

## 7. The release-trigger trap: do not run packaging on `release: published`

The single most common way a repo ships a release with **no installers attached**: triggering the packaging job from `on: release: published`. A GitHub Release created by a workflow authenticating as the default `GITHUB_TOKEN` **does not trigger new workflow runs** (GitHub's own recursion guard). So a packaging workflow keyed on that event silently never fires. Because most repos cut their release from CI, this is the default case, not the edge case, and it fails silently: the release exists, the tag exists, and the assets simply are not there.

Trigger packaging from **within the same workflow run that cuts the release** instead:

- A packaging job with **`needs:`** on the release job, so it runs in the same triggered run rather than waiting on an event that never comes.
- It **discovers the version from the tag the release job pushed**: `git tag --points-at HEAD` after a `fetch-depth: 0` checkout.
- It **no-ops when that is empty** (not every push to the default branch cuts a version), exiting cleanly rather than building an untagged artifact.
- It uploads with `gh release upload <tag> <files>`.

The second trap, once the trigger is right: detecting "did this push release?" by comparing `gh release view --json targetCommitish` to `$GITHUB_SHA` **also never fires** - semantic-release's tag-first flow records `targetCommitish` as the *branch name*, not a SHA (proven on live runs: a release with zero assets). The working detection is the tag itself, verbatim:

```bash
TAG=$(git tag --points-at "$GITHUB_SHA" | grep '^v' | head -1 || true)
if [ -n "$TAG" ] && gh release view "$TAG" >/dev/null 2>&1; then package; fi
```

Two permissions/placement constraints the job carries:

- It needs **`permissions: contents: write`** to upload assets to the release.
- It **pins its own `runs-on`** per OS (§6); the packaging matrix cannot inherit a Linux-only default.

```yaml
package:
    needs: release            # same run as the release job; NOT `on: release: published`
    permissions:
        contents: write
    strategy:
        matrix:
            os: [windows-latest, macos-latest, ubuntu-latest]
    runs-on: ${{ matrix.os }}
    steps:
        - uses: actions/checkout@v4
          with: { fetch-depth: 0 }
        - id: tag
          shell: bash
          run: echo "tag=$(git tag --points-at HEAD)" >> "$GITHUB_OUTPUT"
        - if: steps.tag.outputs.tag == ''
          run: echo "No tag on HEAD; nothing to package." && exit 0
        # ... npm ci, npm run build, npx electron-builder --publish never ...
        - if: steps.tag.outputs.tag != ''
          run: gh release upload "${{ steps.tag.outputs.tag }}" dist/*
          env: { GH_TOKEN: ${{ github.token }} }
```

---

## 8. The v1 floor: unsigned, no auto-updater - and what the target already decided

State the baseline plainly rather than gesturing at an enterprise story no one has built:

- **Artifacts are unsigned.** With no code-signing certificates, Windows SmartScreen and macOS Gatekeeper warn the user on first launch, and that is expected. Signing (an EV/OV cert on Windows, an Apple Developer ID plus notarization on macOS) is a per-project upgrade.
- **There is no auto-updater today.** Nothing checks for a new version on the operator's behalf. An in-app updater (`electron-updater` against a release feed) is a per-project upgrade - but whether that upgrade is even reachable later was already decided by the packaging target picked in §6, not by this section. The rest of §8 states that per target, because "no auto-updater" reads very differently depending on which of the two claims below it turns out to be.

**The NSIS target already buys the in-place upgrade, with no updater at all.** electron-builder's NSIS template runs the previous version's registered uninstaller silently, with flags that keep the app's data, before installing the new version over it (`uninstallOldVersion`, in electron-builder's own NSIS scripts). Running a newer setup exe over an installed app therefore upgrades it in place and keeps its profile, with no manual uninstall step; the template carries no version check, so running an older setup is the manual rollback. `electron-updater`'s Windows updater automates exactly this same step - it downloads the new setup and launches it silently with the same flags - so for this target "no auto-updater" means "no automatic download and trigger of the upgrade the installer already performs by hand," a materially smaller gap than the phrase alone suggests.

**A zip or portable Windows target forecloses that updater structurally, not just by omission.** electron-builder writes the update metadata an updater needs (`app-update.yml` into the packaged app, `latest.yml` beside the release artifact) only for NSIS-family targets and an updater-aware `appx`; every other Windows target gets none of it. A project that scaffolds onto `zip` has not merely skipped building an updater - it has removed the file a future one would read, and gets neither the file nor the installer's own uninstaller-driven in-place upgrade in exchange.

**macOS needs signing for either shape, and needs `zip` even when only `dmg` ships.** Electron's own auto-updater documentation requires the app be signed for automatic updates on macOS, a `Squirrel.Mac` requirement with no unsigned path around it. Separately, electron-builder's own target documentation states that Squirrel.Mac's mechanism needs both `dmg` and `zip` enabled even when `dmg` is the only shipped artifact, and that disabling `zip` breaks auto-update in the `dmg` package. A `mac.target: dmg` alone, the common case, forecloses macOS auto-update twice over.

**Linux's AppImage updates itself in place, and needs no signing to do it.** `electron-updater`'s Linux updater downloads the new AppImage, makes it executable, and replaces the running file at its own path - closer to the Windows installer's replace-and-relaunch than to macOS's signed-bundle requirement.

**A private repository has no update feed to point at.** `electron-updater`'s public GitHub provider reads a release feed unauthenticated; a private repo routes to its private-repo provider instead, which needs a token available at update-check time - shipped inside the app, or present on every operator's machine, neither of which is a sound default for a consumer desktop app. "Against the release feed" only describes a public repo.

**A real feed, once signing and a reachable repo exist, costs more than a `publish` block.** electron-builder writes the `latest*.yml` files and their blockmaps beside the installer; the release-upload glob has to catch those too, the same silent-miss §7 warns about from a different artifact. A per-machine install means a UAC prompt on every update; a per-user one means none. Neither shape guards against downgrade on its own, so a rollback story needs `allowDowngrade` stated explicitly, the same way the installer's own lack of a version check already leaves rollback to whoever runs the older setup.

**The unsigned floor and the updater floor are converging, not independent.** The Windows updater today skips verifying a downloaded update's signature when `app-update.yml` carries no `publisherName` - true of every unsigned build - and only logs that this is deprecated; a future electron-builder major makes that fail-closed. An unsigned, auto-updating Windows app already reads as a temporary state, which is one more reason signing is the real prerequisite for either upgrade, not the packaging target on its own.

Both upgrades are real and ordinary; a project that takes either records the decision in its own `docs/` ADRs (the certificate authority and secret handling for signing; the update feed's reachability given the repo's visibility, and the rollback story for the updater). Naming the floor precisely, per target, is worth more than pretending the floor is one fact.

---

## 9. Testing

Split by what the code needs to run, the same layering as `REF-Tests.md`:

- **Renderer logic is Electron-free and unit-tested.** ViewModels, mappers, and the `DesktopApi` port's web fallback run in jsdom/node with no Electron present; that is the §2 boundary paying off in the test layer.
- **The preload surface is contract-tested.** Assert the exposed API shape (the methods `contextBridge` publishes) and that no channel-passthrough leaked in; the surface is small enough to pin exhaustively.
- **The packaged app is smoke-tested end to end with Playwright driving Electron** (`_electron.launch({ args: ["."] })`): the window opens, the renderer's ready signal fires, no main-process or renderer console errors, and one representative IPC round-trip (`readConfig`) returns. That catches a broken preload path, a bad `webPreferences`, and a renderer that cannot reach main, which is most of what breaks the shell. When the shell itself owns an entry flow (a loopback listener for an OIDC redirect, a protocol handler), the smoke also drives that flow's abandon and retry, never only its success: a port or handle held past an abandoned attempt exists only in a running process, and it reads as a dead front door on every retry while a happy-path pass stays green.
- **Packaging is verified by the release job producing the assets**, and the delivery evidence chain (§6) asserts they are present on the release; do not re-run a full electron-builder pack in the unit suite.

---

## 10. Anti-Patterns

| # | Anti-Pattern | Correct Approach |
| - | ------------ | ---------------- |
| 1 | `nodeIntegration: true` or `contextIsolation: false` to make an import work in the renderer | Move the privileged work to main; expose a narrow method over the bridge (§3, §4) |
| 2 | A generic `invoke(channel, ...args)` on the bridge | Specific, typed methods per operation; the renderer never sees a channel string (§4) |
| 3 | Loading arbitrary remote URLs in a `BrowserWindow` that carries your preload | Own assets in the window; third-party links via `shell.openExternal` (§3) |
| 4 | The renderer importing `electron` or a Node built-in | Renderer stays a standalone web app; all OS access is main's, reached through the bridge (§2) |
| 5 | `bootstrap-electron` scaffolding its own frontend | Compose around the renderer the project already has (§2) |
| 6 | Triggering packaging from `on: release: published` | A `needs:`-on-release job in the same run; a `GITHUB_TOKEN` release triggers no workflow (§7) |
| 7 | A single Linux runner building all installers | Per-OS matrix, each job pinning its own `runs-on` (§6) |
| 8 | Gesturing at signing and auto-update as if shipped | State the unsigned, no-updater floor; upgrades are per-project ADRs (§8) |
| 9 | Trusting IPC arguments on the main side | Validate every argument; IPC input is untrusted input (§4) |
| 10 | An Electron shell's own OIDC flow sharing a client with a fronting proxy | Register a separate public client for the shell (§5) |

---

## 11. Cross-references

- `REF-Frontend.md` + `REF-React.md`: the renderer inside the window; the shell delegates the whole UI to them.
- `REF-Tests.md`: test layering; §9 here is its Electron specialization.
- `REF-Design.md`: visual identity applies to the renderer and any native chrome (menus, tray, about panel) alike.

---

## 12. Skills that instantiate this REF

Generated by `scripts/sync_backlinks.py` from skill frontmatter; do not edit by hand.

Skills whose frontmatter `refs:` includes `REF-Electron`:

- `bootstrap-electron` - Scaffold an Electron desktop shell around an existing Vite/React MVVM renderer per REF-Electron: a locked-down main process (contextIsolation on, nodeIntegration off, sandbox on), a typed contextBridge preload surface, an electron-builder config, a per-OS packaging job wired into the release run (not on: release: published), and a Playwright-drives-Electron smoke e2e.
