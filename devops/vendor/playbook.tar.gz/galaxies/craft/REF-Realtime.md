---
domain: architecture
---

# REF: Realtime

> Read this when a client must track a long-running operation, watch live output, or receive server events: the decision ladder from polling to streamed responses to SSE to WebSockets to webhooks, and when each is justified.

---

## 1. The Decision Ladder

The mechanisms are rungs on one ladder, ordered by infrastructure cost. Walk it top down and take the **first rung that fits**; every step down adds connection state, reconnect logic, and fan-out machinery that the rungs above get for free.

| # | Situation | Mechanism | Section |
|---|-----------|-----------|---------|
| 1 | The client initiated the operation and tolerates seconds of lag | Poll the status resource | §3 |
| 2 | The client initiated the operation and watches its incremental output | Stream the response, or a per-operation event stream | §4 |
| 3 | The server emits events at moments the client cannot predict | SSE, layered over the pollable resource | §5 |
| 4 | Both directions carry sustained, latency-sensitive traffic | WebSocket | §6 |
| 5 | The consumer is another server, not a browser | Webhook, plus scheduled reconciliation | §7 |

The axes that place a task on the ladder are **who initiates**, the **latency budget**, and the **watcher count**. Duration is not an axis: a three-hour batch job the client started still polls (rung 1, slow interval), while a rare event the client did not trigger is push (rung 3) no matter how quickly it arrives.

Rung 1 covers the overwhelming majority of "make it live" requests. Descending without a reason from the axes above is the top anti-pattern of this REF (§8).

---

## 2. The Reconciliation Invariant

Every push channel disconnects: deploys, proxies, laptop lids, mobile radios. The design must answer "what did I miss?" on reconnect, and the answer is always one of two things:

- **Replay**: the channel resumes from a client-held cursor (SSE `Last-Event-ID`, an event log offset).
- **Refetch**: the client re-reads the pollable status resource and resynchronizes from current state.

Rules:

| Rule | Rationale |
|------|-----------|
| The pollable resource is the source of truth; push is an optimization layered over it | A robust push system contains a polling system anyway; build that part first |
| Design the status resource before any push channel | The push layer can then be removed with a loss of latency only, never of correctness |
| Replay windows are finite; falling off the window degrades to refetch | An unbounded event log is a database, not a channel |
| Test by killing the connection mid-flow | A design that cannot survive its channel dropping is incomplete at every rung below 1 |

---

## 3. Polling

The default. Stateless, proxy-friendly, load-balances with no affinity, retries trivially, testable with a plain HTTP client, and needs no broker to fan out across replicas.

- Poll a **status resource**: an idempotent `GET /<resource>/{id}` returning current state, progress, and a terminal flag. Starting a long operation returns `202 Accepted` with that resource's location. Route design follows the stack's HTTP adapter REF (e.g. `REF-FastAPI.md`).
- **Interval = latency budget.** Seconds for interactive operations, tens of seconds for batch. Add jitter; back off exponentially (capped) on errors and on sustained no-change.
- **Deltas, not documents.** For growing output, poll with a cursor (`GET /<resource>/{id}/output?after=<cursor>`) so each poll returns only what is new. The "choppiness" attributed to polling is almost always full-document refetch at a coarse interval, not polling itself.
- **Terminal states live in the representation** (succeeded, failed, canceled). Completion is never inferred from a timeout, an empty response, or a closed connection.
- **One poller per client.** The frontend owns polling in one ViewModel-layer service or hook (`REF-Frontend.md` §4), not scattered timer calls per component.

Move down the ladder only when one of these holds: many idle clients polling tightly for rare events (cost scales with clients times frequency, regardless of change rate), a sub-second latency budget, or battery-constrained clients where each poll wakes a radio.

---

## 4. Streamed Responses

For watching the incremental output of an operation the client initiated: build logs, scan output, generated tokens. Still one-directional, so it lives on the HTTP rungs, not on a socket.

- **Simplest form: the initiating request streams its own response.** The server emits record-delimited units (NDJSON lines; a streaming response in the stack's HTTP framework) and the client consumes the byte stream incrementally. One connection, no id correlation, no second channel.
- **Weakness: the stream dies with the request.** A page refresh or dropped connection loses the tail. When the operation must outlive its viewer, or several viewers attach, split it: start the operation (`202` plus id), then attach to a per-operation event stream (`GET /<resource>/{id}/events`) with SSE mechanics (§5) so reconnect and replay come for free.
- **Emit units, not bytes.** Line- or record-delimited output lets the client render each unit as it lands and lets a cursor name a resume point.
- A cursor poll (§3) at a tight interval is visually indistinguishable from a stream for line-oriented output; prefer it when the infrastructure between client and server (buffering proxies, serverless timeouts) fights long-lived responses.

---

## 5. Server-Sent Events

For genuine notification: the server speaks at moments the client cannot predict, and the client's own traffic stays ordinary requests.

- **SSE is plain HTTP.** The browser `EventSource` brings auto-reconnect and `Last-Event-ID` resumption built in; assign every event an id so the replay half of §2 works.
- **One stream per client.** Multiplex logical channels inside it with event types; one `EventSource` per widget exhausts the HTTP/1.1 per-origin connection cap (HTTP/2 lifts it, but the one-stream rule keeps the design honest).
- **Upstream traffic stays requests.** Commands go up as ordinary `POST`s alongside the stream. Needing to send commands is not a reason to leave this rung; that reason is §6's litmus test, and it is rarely met.
- **Authenticate the stream** with the session cookie or a short-lived per-stream token; `EventSource` sets no custom headers, so the long-lived API credential never rides the stream URL.
- **Fan-out needs a broker.** With several server replicas, the SSE endpoint subscribes to a shared pub/sub channel; the connection holder owns no state, per §2.

---

## 6. WebSockets

The last rung, justified by a litmus test that all must hold:

| Test | Passes | Fails |
|------|--------|-------|
| Both directions carry **sustained** traffic | Continuous audio up, tokens down | Occasional commands up, events down |
| Both directions are **latency-sensitive** | Keystrokes up, terminal output down | A form submit that tolerates a request |
| Messages are **not replies**; request/response correlation breaks | Presence, cursors, concurrent edits | Every upstream message expects one answer |

When any row fails, the shape is requests up plus SSE down (§5), which keeps HTTP's auth, caching, load balancing, and reconnect semantics. A WebSocket abandons those: affinity-aware load balancing, upgrade-capable proxies, and hand-built heartbeat, reconnect, backoff, and replay, because §2 still applies and the socket provides none of it.

Workloads that pass: collaborative editing with presence and live cursors, web terminals, multiplayer state sync, continuous media in and streamed output back. The shape each shares is one persistent connection carrying sustained traffic both ways: frames up while frames stream down, neither side a reply to the other.

Chat apps, dashboards, notification feeds, and progress bars fail the test; they are rungs 1 to 3 wearing a "live" label.

---

## 7. Webhooks

Server-to-server notification: no browser, so no `EventSource`; the consumer registers a callback URL and the provider `POST`s deliveries to it.

- **Sign every delivery** (HMAC over the body with a shared secret) and verify before trusting it.
- **Handlers are idempotent.** Delivery is at-least-once; the delivery id is the dedupe key.
- **A delivery is a hint, not the truth.** On receipt, fetch the authoritative resource rather than acting on the payload alone; payloads go stale in the retry queue.
- **Reconcile on schedule.** Deliveries will be missed (downtime, expired retries), so the consumer periodically sweeps the provider's pollable event log per §2. A webhook consumer with no reconciliation sweep is an incomplete integration.

---

## 8. Anti-Patterns

| # | Anti-Pattern | Correct approach |
|---|--------------|------------------|
| 1 | WebSocket-first: reaching for a socket because the feature says "live" | Walk the ladder (§1); the socket is the last rung, earned by §6's full litmus test |
| 2 | Full-document refetch on a coarse interval, then blaming the choppiness on polling | Cursor deltas at an interval matching the latency budget (§3) or a streamed response (§4) |
| 3 | Push with no reconciliation path | Every push channel layers over a pollable resource with replay or refetch (§2) |
| 4 | Inferring completion from a closed connection, an empty poll, or a timeout | Terminal states live in the status representation (§3) |
| 5 | One `EventSource` (or socket) per widget | One stream per client; logical channels inside it (§5) |
| 6 | A WebSocket whose upstream traffic is occasional commands | Requests up, SSE down (§5, §6) |
| 7 | Trusting webhook deliveries as ordered, exactly-once, or fresh | Signed, idempotent handlers plus a scheduled reconciliation sweep (§7) |
| 8 | Timer calls scattered across components, each polling on its own | One ViewModel-layer polling service per client (§3, `REF-Frontend.md` §4) |
| 9 | Choosing the rung by duration ("long jobs need push") | Choose by initiator, latency budget, and watcher count (§1); duration only tunes the poll interval |
