---
domain: language
---

# REF: PowerShell CLI Conventions

> When writing or modifying PowerShell CLI scripts, follow these rules strictly. The PowerShell CLI is a **thin frontend** that consumes the engine's Python CLI adapter - it handles UI, orchestration, and user interaction, never business logic.

---

## 1. Architecture Role

The PowerShell CLI is a **presentation layer** - the outermost shell of the application. It invokes the Python CLI (`<package>/adapters/inbound/cli/`), which calls the engine (`<package>/application/` + `domain/`).

Rules:
- **Never implement business logic** in PowerShell - that belongs in the engine.
- **Never call Python scripts directly** - always go through the project's Python CLI entry point.
- **Never import domain types** - PowerShell knows about exit codes and text output, nothing else.
- The PowerShell CLI may be replaced by a Go/Rust binary later - keep it thin.

---

## 2. Folder Structure

```
cli/
├── Start.ps1                    # Entry point - param block, sourcing, dispatch
├── lib/                         # Shared infrastructure (reusable plumbing)
│   ├── Common.ps1               # Aggregator - shared state + dot-sources lib/* modules
│   ├── Resolve-Project.ps1      # Project discovery + encoding setup
│   ├── Resolve-Tools.ps1        # Tool discovery (Find-Tool, Python/npm paths)
│   ├── Write-UI.ps1             # Terminal UI helpers + Show-Help
│   ├── Invoke-Engine.ps1        # Python CLI invocation wrapper
│   ├── Format-<Report>.ps1      # Output parsing and grouped reporting
│   └── Registry.ps1             # Step / mode / dispatch table data
└── steps/                       # One step function per file (orchestrated actions)
    ├── Step-<Action>.ps1        # One file per orchestrated action
    └── ...
```

Rules:
- One concern per file. No god scripts, no section-separator comments.
- `Common.ps1` is a thin aggregator: it initialises shared state, then dot-sources sibling infrastructure modules in `lib/` (except `Registry.ps1`).
- `Registry.ps1` is sourced by `Start.ps1` *after* steps, because its dispatch table references `Step-*` functions.
- Infrastructure modules are named by their primary verb-noun.
- `Start.ps1` contains *only*: param block → path variables → dot-sourcing → dispatch. No functions, no data.
- Each `Step-*.ps1` contains exactly one `Step-*` function plus its `#Requires` comment-based help.
- If you feel the urge to add a `# ── Section ──` comment, that's a signal the file should be split.

---

## 3. Naming Conventions

### Functions

Use **approved PowerShell verbs** with `PascalCase` nouns:

| Pattern | Example | Purpose |
|---------|---------|---------|
| `Step-<Action>` | `Step-Generate`, `Step-Test` | Step functions called by the orchestrator |
| `Write-<Purpose>` | `Write-Header`, `Write-Banner` | UI output helpers |
| `Find-<Thing>` | `Find-Tool` | Tool/resource discovery |
| `Invoke-<Action>` | `Invoke-Engine` | Generic execution wrappers |
| `Parse-<Format>` | `Parse-PytestVerbose` | Output parsing |

### Variables

- **Script-scoped state:** `$script:VariableName` (e.g., `$script:TestResults`).
- **Configuration constants:** `$PascalCase` at script top (e.g., `$RepoRoot`, `$EngineRoot`).
- **Local variables:** `$camelCase` inside functions.
- **Environment variables:** `$env:UPPER_SNAKE` (e.g., `$env:PYTHONIOENCODING`).

### Parameters

- Use `PascalCase` names, declared in a `param()` block - never positional-only.
- Use `[switch]` for boolean flags, `[string]` for paths.

---

## 4. Script Structure

Every script follows this order: comment-based help block, `param()` block, then functions/code.

Rules:
- **Comment-based help** (`.SYNOPSIS`, `.DESCRIPTION`, `.PARAMETER`, plus `.NOTES` with project name and version) on every entry-point script.
- **Section comments** use the `# ── Label ──────` format for visual separation - but if a section grows beyond ~50 lines, extract it to its own file.
- **`param()` block** at the top of every script, with typed parameters.

---

## 5. Engine Invocation

All engine calls go through a shared runner function that handles Python discovery, working-directory management, exit-code propagation, and output capture:

```powershell
function Invoke-Engine {
    param(
        [Parameter(Mandatory)][string]$Command,
        [string[]]$Arguments,
        [string]$Label
    )
    Push-Location $EngineRoot
    try {
        $out = & $script:PythonCmd -m <package>.adapters.inbound.cli $Command @Arguments 2>&1
        $exitCode = $LASTEXITCODE
    } finally {
        Pop-Location
    }
    return ($exitCode -eq 0)
}
```

Rules:
- **Return `$true`/`$false`** or propagate exit codes - never swallow failures silently.
- Directory-change and error-handling rules per §6.

---

## 6. Error Handling

```powershell
# ✅ Right - try/finally with cleanup
try {
    Push-Location $SomeDir
    $out = & $script:PythonCmd -m pytest 2>&1 | Out-String
    $exitCode = $LASTEXITCODE
} catch {
    $out = $_.Exception.Message
    $exitCode = 1
} finally {
    Pop-Location -ErrorAction SilentlyContinue
}

# ❌ Wrong - no cleanup, swallowed failure
cd $SomeDir
python -m pytest
cd ..
```

Rules:
- **Never use bare `cd`** - use `Push-Location`/`Pop-Location`.
- **Always check `$LASTEXITCODE`** after external commands - PowerShell doesn't throw on non-zero exit.
- **Always capture stderr** with `2>&1` - don't let errors disappear.
- **`-ErrorAction SilentlyContinue`** on cleanup commands that might fail (e.g., `Pop-Location` when `Push-Location` didn't run).

---

## 7. UI Patterns

### Consistent Visual Language

| Element | Color | Purpose |
|---------|-------|---------|
| Headers/banners | `Cyan` / `Magenta` | Section boundaries |
| Success messages | `Green` | Completed actions, passed tests |
| Errors | `Red` | Failures, missing dependencies |
| Warnings | `Yellow` | Non-fatal issues |
| Info/hints | `DarkGray` | Secondary information |
| Labels | `White` | Primary content |

### Output Functions

Keep UI helpers in `Common.ps1`. Every UI function starts with `Write-` (e.g. `Write-Header` prints a 70-char `=` banner in Cyan).

---

## 8. Tool Discovery

Discover external tools at script startup, not inside step functions - a `Find-Tool` function tries each candidate (`python`, `python3`, `py`; `npm`, `npm.cmd`) with `--version` and returns the first that works:

```powershell
$script:PythonCmd = Find-Tool @("python", "python3", "py")
$script:NpmCmd    = Find-Tool @("npm", "npm.cmd")
```

Rules:
- **Discover once, store in `$script:` scope** - don't re-discover per step.
- **Fail gracefully** - if a tool isn't found, skip the step with a warning, don't crash.
- **Log which tool was found** when `-Verbose` is active.

---

## 9. Test Tracking

When running test suites, track results for a summary report:

```powershell
$script:TestResults   = @()   # Per-step results
$script:TotalPassed   = 0
$script:TotalFailed   = 0
```

Each test step appends a `[PSCustomObject]` (Name / Passed / Duration / Output) to `$script:TestResults`, enabling a consolidated `Write-TestSummary` at the end of a run.

---

## 10. Encoding

### Runtime output

Force UTF-8 everywhere; project data files are UTF-8:

```powershell
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$OutputEncoding            = [System.Text.Encoding]::UTF8
$env:PYTHONIOENCODING      = "utf-8"
```

Set this once at the top of `Start.ps1`, before any other code runs.

### Source file (PowerShell 5.1 gotcha)

Windows PowerShell 5.1 (`powershell.exe`) reads a `.ps1` file without a BOM as Windows-1252, not UTF-8. Non-ASCII characters (em-dashes, smart quotes, etc.) in a string literal then decode into multi-byte garbage that contains a stray `"`, which closes the preceding string literal early and produces confusing downstream errors. Typical symptom: `Cannot bind argument to parameter '<X>' because it is null` several lines later, because a `$tmp = ...` assignment silently produced `$null` and `$ErrorActionPreference = "Continue"` swallowed the warning.

Avoid it by:

- Sticking to ASCII in source files. No em-dashes, no smart quotes, no fancy whitespace. (Top Violation #2 in the playbook bans em-dashes for this reason among others.)
- If non-ASCII is unavoidable, save the file as UTF-8 with BOM, or run under PowerShell 7+ (`pwsh`), which defaults to UTF-8.

To diagnose a suspected case, scan a file for the UTF-8 em-dash byte sequence (`0xE2 0x80 0x94`):

```powershell
$b = [IO.File]::ReadAllBytes('<path>'); $i=0; while ($i -lt $b.Length-2) { if ($b[$i] -eq 0xE2 -and $b[$i+1] -eq 0x80 -and $b[$i+2] -eq 0x94) { "em-dash at $i" }; $i++ }
```

### Writing files for other tools to read

`Set-Content -Encoding UTF8` and `Out-File -Encoding UTF8` in Windows PowerShell 5.1 both produce **UTF-8 with BOM** (the three-byte `EF BB BF` prefix). Many tools that PowerShell hands files off to reject this:

- **Java compiler**: `illegal character: '﻿'` on the first line of every patched `.java` file.
- **YAML/JSON parsers**: "found character that cannot start any token".
- **Maven plugins reading `pom.xml`**: some silently treat the file as invalid XML; behaviour varies by plugin.

Use `[System.IO.File]::WriteAllText` with a no-BOM UTF-8 encoder:

```powershell
$utf8NoBOM = New-Object System.Text.UTF8Encoding $false
[System.IO.File]::WriteAllText($path, $content, $utf8NoBOM)
```

Or in PowerShell 7+, `Set-Content -Encoding utf8NoBOM` directly. To strip a BOM from an existing file, read its bytes and rewrite without the leading `EF BB BF`.

This is distinct from §10.2's source-file guidance: there, PS1 files that **PowerShell 5.1 itself** reads benefit from a BOM. Here, output files that **other tools** read must have no BOM. Same encoding name, opposite advice depending on the consumer.

(Top Violation #5 in the playbook bans BOMs in PowerShell-written output files.)

---

## 11. Step Registry Pattern

Steps and modes are declared as data structures, not scattered `if` chains:

```powershell
$Steps = [ordered]@{
    Generate = @{ Label = "Generate all outputs" }
    Test     = @{ Label = "Run tests (fast)"     }
    Serve    = @{ Label = "Launch Slidev server"  }
}

$Modes = [ordered]@{
    "(default)" = @{ Flag = "(none)";  Steps = @("Generate", "Test", "Serve") }
    "Build"     = @{ Flag = "-Build";  Steps = @("Generate") }
}
```

The orchestrator loops over `$stepsToRun` and dispatches via a function table - no hardcoded step chains.

---

## 12. Pre-Commit Checklist

Before considering any PowerShell change complete:

- [ ] Comment-based help present on entry-point scripts
- [ ] `param()` block with typed parameters
- [ ] `Push-Location`/`Pop-Location` used (never bare `cd`)
- [ ] `$LASTEXITCODE` checked after every external command
- [ ] Output captured with `2>&1`
- [ ] `try`/`finally` around directory changes
- [ ] UTF-8 encoding set at startup
- [ ] Step functions are single-purpose (one per file)
- [ ] No business logic - only UI, orchestration, tool discovery
