---
domain: practice
---

# REF: Publishable Python Package

> Read this when authoring or auditing any Python package intended for cross-project reuse - even if you don't plan to publish it to PyPI today, the bar is the same. Quality compounds; the cost of meeting the bar at start is far lower than retrofitting later.

---

## 1. Why this REF exists

A module shared across projects, developers, or machines is a package, and needs the structural pieces below - so consumers can install reliably, understand what's stable, contribute back, and debug failures.

Reference implementation: `../csd-library/pytest-intent/` - small package built to this bar; a working example of every section below.

---

## 2. Structural minimum

Every publishable package has:

```
<package-name>/
├── pyproject.toml          # full metadata - see §3
├── README.md               # see §10
├── LICENSE                 # explicit license (MIT, Apache 2.0, etc.) - REQUIRED
├── CHANGELOG.md            # see §11
├── ruff.toml               # lint config
├── mypy.ini (or pyproject) # type-check config
├── .github/workflows/test.yml  # CI - matrix Python versions, lint + types + tests
├── <package_name>/         # the actual module (snake_case of the package name)
│   ├── __init__.py         # __version__, __all__, public re-exports
│   └── <internal modules>
├── tests/                  # the package's own tests - NOT optional
│   └── test_*.py
└── examples/               # at least one realistic end-to-end example
```

Anti-pattern: a package with no `tests/` directory.

---

## 3. `pyproject.toml` - required fields

```toml
[build-system]
requires = ["setuptools>=61.0"]
build-backend = "setuptools.build_meta"

[project]
name = "<package-name>"               # required
version = "0.1.0"                     # required, SemVer
description = "..."                   # one-sentence purpose
readme = "README.md"                  # long_description source
requires-python = ">=3.10"            # explicit floor
license = {text = "MIT"}              # match LICENSE file
authors = [{name = "...", email = "..."}]
keywords = [...]                      # discoverability
classifiers = [...]                   # PyPI taxonomy - populate even if not publishing
dependencies = [...]                  # real deps, not "I think we need"

[project.optional-dependencies]
dev = ["pytest>=...", "ruff>=...", "mypy>=..."]

[project.urls]                        # Homepage, Documentation, Repository, Issues

[project.entry-points."pytest11"]    # ONLY if it's a pytest plugin
<plugin_name> = "<package_name>.plugin"

[tool.setuptools.packages.find]
where = ["."]
include = ["<package_name>*"]
exclude = ["tests*", "examples*"]
```

Anti-patterns:
- Missing `requires-python` floor - installs fail late on old interpreters
- Missing `license = {...}` - consumers can't see the license
- `dependencies = []` when the package actually needs deps - silent failures
- Including `tests*` or `examples*` in the wheel - bloat

---

## 4. Logging - library code never prints

Library code uses `logging`, never `print()`. Each module gets `logger = logging.getLogger(__name__)`.

Anti-patterns:
- `print()` in library code → consumers can't redirect or silence
- `logging.basicConfig()` in library code → mutates the consumer's root logger
- String concatenation in log messages → use `logger.info("processing %s", obj)` for lazy formatting
- `logger.error(str(e))` inside an `except` instead of `logger.exception(...)` → loses stack trace

---

## 5. Error handling

- **Domain exceptions** - base exception per package; raise specific subclasses, never `Exception`/`RuntimeError` directly from library code.
- **No bare `except:`**, no silent `except Foo: pass` - log + re-raise, or have a clear reason for swallowing.
- **Validate at boundaries** - validate at the public API edge; trust internal data after.

```python
# pkg/errors.py
class PackageError(Exception):
    """Base exception for this package."""

class ConfigError(PackageError):
    """Configuration could not be loaded or is invalid."""

class ValidationError(PackageError):
    """Input failed validation."""
```

---

## 6. Tests - non-negotiable

Per `REF-Tests.md`. Specifically for a package:

- `tests/` directory with `test_*.py` files; each public function/class has at least happy-path coverage plus edge cases (empty, None, malformed, boundary values)
- If the package adds a `pytest11` entry point, test that the plugin loads correctly

Coverage target: not 100%. Cover what *matters* - public API, error paths, parsing edges. Skip trivial getters/setters (per `REF-Tests.md` §1).

---

## 7. Type hints + `mypy`

- Every public function has type hints on parameters and return.
- `from __future__ import annotations` at top of every module.
- `mypy.ini` or `[tool.mypy]` in pyproject - `disallow_untyped_defs = True` minimum.
- Mark the package as typed for downstream consumers: add empty `<package_name>/py.typed` file.

```ini
[mypy]
python_version = 3.10
disallow_untyped_defs = True
warn_unused_ignores = True
warn_redundant_casts = True
warn_unreachable = True
no_implicit_optional = True
check_untyped_defs = True
```

---

## 8. Linting + formatting

- **`ruff`** for both linting and formatting, with per-file ignores for tests (e.g. `B011`).

Anti-pattern: configuring separate tools (flake8 + black + isort + bandit) when ruff covers all of them.

---

## 9. CI - GitHub Actions matrix

`.github/workflows/test.yml`: matrix over `python-version: ["3.10", "3.11", "3.12", "3.13"]`; steps: `pip install -e ".[dev]"`, then `ruff check <package_name> tests`, `mypy <package_name>`, `pytest tests/ -v`.

Run on every push + PR. Block merges on red. No "I'll fix the build later."

---

## 10. README - what consumers need

- **One-sentence purpose** at top.
- **What this package IS** - bullet list of capabilities.
- **What this package is NOT** - explicit non-goals; prevents misuse.
- **Hidden assumptions** - Python version, OS, runtime requirements, fixtures consumers must define, etc.
- **Install** - exact command.
- **Usage** - minimal end-to-end example, runnable as-is.
- **Why this and not [alternative]** - only if there's a likely alternative.
- **Roadmap** - planned and deferred.

Anti-patterns:
- README with no "what this is NOT" section
- "See the docs at..." with no inline example - users won't click
- Marketing copy without code in the README

---

## 11. CHANGELOG - Keep a Changelog

Keep-a-Changelog format: `## [Unreleased]` on top, then `## [x.y.z] - YYYY-MM-DD` entries with `### Added` / `### Changed` / `### Fixed` subsections.

SemVer: 0.x.y for "API may break"; 1.0+ for "API is committed."

---

## 12. Anti-patterns

| # | Anti-Pattern | Correct Approach |
| - | ------------ | ---------------- |
| 1 | `print()` in library code | Use `logging`. Library never owns the user's stdout. |
| 2 | `logging.basicConfig()` in library imports | Configure at the application entry point, never in library code |
| 3 | No `tests/` directory | Tests are non-negotiable for any shared code |
| 4 | No `LICENSE` file | Required even for internal-only sharing |
| 5 | Missing `pyproject.toml` author / license / classifiers | Consumers can't surface attribution; PyPI rejects on publish |
| 6 | Bare `except:` clauses | Always catch a specific class; `except Exception` if you must |
| 7 | Type hints absent on public API | Use type hints + `mypy --strict`; mark with `py.typed` |
| 8 | No CI / "I run tests locally" | CI is the only honest source of truth on green/red |
| 9 | Ad-hoc YAML / TOML / JSON parsing | Use the standard library or PyYAML; don't hand-roll a parser |
| 10 | Adding `requirements.txt` for a publishable package | Use `pyproject.toml` `dependencies`; `requirements.txt` is for deployment pinning, not packaging |
| 11 | `from package import *` in `__init__.py` | Be explicit: `from .module import X, Y`; use `__all__` to pin the public API |
| 12 | Mutable default arguments (`def f(x=[])`) | Use `None` and assign inside the function |

---

## 13. Cross-references

- `REF-Tests.md` - general test philosophy
- `REF-Python.md` - Python language conventions
- `REF-Documentation.md` - README + docstring patterns
- `REF-CSD.md` - if the package implements CSD-style intent testing, see also `REF-DataPack.md`

## 14. Reference implementation

`../csd-library/pytest-intent/` - a small (≈300 LOC) Python package that meets every section of this REF. Use as a copyable template.

---

## 15. Skills that instantiate this REF

Generated by `scripts/sync_backlinks.py` from skill frontmatter; do not edit by hand.

Skills whose frontmatter `refs:` includes `REF-Python-Package`:

- `bootstrap-python-package` - Scaffold a new publishable-quality Python package conforming to REF-Python-Package.
