---
domain: practice
---

# REF: User Guide (End-User Documentation, When a Customer Requires It)

> Read this when a customer has put user documentation down as a requirement and a guide for the app's users has to be produced: what comes before a guide, what the guide holds, the rules its words follow, and where it lives.

---

## 1. When a guide exists

A user guide has one trigger: a customer has put user documentation down as a requirement. No delivery phase, handoff, exit check or review standard requires or assumes one, and the absence of a guide is never a finding.

Guidance for a user has an order of preference, and each level is preferred to the one below it:

| # | What guides the user | Rule |
|---|---|---|
| 1 | The interface itself | A control carries its own meaning; a screen that needs a sentence to explain its own affordance has an affordance to fix (`REF-Design.md` §6) |
| 2 | Guidance inside the page | A fact the visual cannot carry is met where the question is asked: contextual help on the control, a first-run onboarding, an empty state that says what fills it, a modal the user opened on purpose |
| 3 | A standalone guide | Only when the customer requires it; then this REF |

A guide never stands in for the first two levels. A screen that needs the guide to be usable is the defect; the guide describes screens that already explain themselves.

## 2. What the guide holds

The guide says what the user sees and does, in the words the app shows. It is written for the app's users, and it restates nothing that belongs to the maintainer's documentation (`REF-Documentation.md` §7.11): no architecture, no data model, no rationale.

| Part | Holds |
|---|---|
| Orientation | What the system is for and where its boundary lies, then, when the app has a sign-in, how to get in and out |
| One part per role | When the app has more than one role, the everyday role first. Within a part, one entry per screen or task, in the order a user meets them |
| Reference | The behaviour a user must know and never clicks: what each status means, what each choice that triggers behaviour does, the rules the system runs on its own (an expiry, a scheduled job), the messages a user can meet and what to do next, and where to get help |

Each screen entry has one shape, learned once: the screen's name as the app labels it, one screenshot, one or two sentences on what the screen is for, and a table with one row per control whose first cell is the label verbatim and whose second cell is the consequence of using it. A note beside the table holds only the invariants a user would not guess ("A submitted record cannot be edited"). Completeness is coverage of what the user meets, never volume: every screen has an entry, every control whose label does not carry its consequence a row, every message the user can see a line in Reference.

## 3. The words

| Rule | Meaning |
|---|---|
| Descriptors, never narration | A row says what the control does for a reader who cannot see the code. A row that restates its label (`Sign out`: "signs out") is cut or given its consequence ("Ends the session on every device"). The test is `REF-Documentation.md` §8.6.1 |
| The users' language, the app's labels | Written in the language the users work in; every label and domain term exactly as the app renders it, including its count or ellipsis, never translated or paraphrased |
| No rationale, no developer surfaces | Why a panel sits where it does lives in the decision log (`AI-PLAYBOOK.md` violation 7). A repository path, a ticket id, a table name or an internal system name is nothing a user can open |
| Limits where the user meets them | A session length or an attempt cap is quoted where the user hits it, once |
| Screenshots on demonstration data | One per screen at one viewport, named after the screen it shows, with alt text; never a real customer's data. A second screenshot is a second state worth its own caption |

## 4. Form and identity

The requirement decides the form: a page the app serves, a document the customer files, a printed manual. Whatever the form, the guide wears the app's locked visual identity (`REF-Design.md` §8), never the workspace's palette and never a fresh one. A guide delivered as a standalone file renders with no external requests, under the CSP-safe and self-contained rules of `REF-Flyer.md` §7. The guide names the release it describes.

Where it lives follows its reader: a guide the app serves is reached from inside the app, at an address that does not change; a document lands where the customer asked for it. It is never a page of the maintainer's documentation set, whose reader is a maintainer.

## 5. Maintenance

A guide is a published claim about the app, so documentation audits check it against the application wherever one exists: a control renamed in the app and not in the guide, a screenshot of a screen a release changed, a status the code does not produce.

## 6. Anti-patterns

| # | Anti-pattern | Correct approach |
|---|---|---|
| 1 | Producing a guide because the app has users | The trigger is the customer's requirement, and nothing else (§1) |
| 2 | Writing a guide for a screen that needs one to be usable | Fix the affordance, or meet the question inside the page (§1, `REF-Design.md` §6) |
| 3 | A delivery phase, handoff or exit check requiring a guide | The customer's requirement is the only trigger (§1) |
| 4 | A part per feature | A part per role, the everyday role first (§2) |
| 5 | Control rows that restate their labels | Every row is a consequence, or it goes (§3) |
| 6 | Architecture, rationale or a repository path on the user's page | The maintainer's docs and the decision log hold those (§2, §3) |
| 7 | Screenshots of real data, or named by capture order | Demonstration data, named after the screen (§3) |
| 8 | A guide in the workspace's palette | The app's own identity (§4) |
| 9 | Fixing the guide's medium ahead of the requirement | The requirement decides the form (§4) |
