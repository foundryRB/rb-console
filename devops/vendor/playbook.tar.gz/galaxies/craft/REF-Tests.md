---
domain: practice
---

# REF: Software Tests

> When asked to create or modify **software tests** (engine code validation), follow these rules. We prioritize **useful, maintainable tests** over coverage metrics.

> **Scope:** This REF covers tests that verify *our code works* - unit, integration, E2E, and conformance guards. Two adjacent concerns route elsewhere:
> - **Validation suites** that verify *user-authored data* (config files, TSVs, spreadsheets) → see `REF-DataPack.md` for the Data Pack convention. Tests in a Data Pack derive 1:1 from intent claims (`INT-NNN`).
> - **CSD Intent Tests** (a methodology-aligned superset of "tests trace to intent") → see `REF-CSD.md` for the routing to the canonical CSD methodology source. CSD's Intent Tests can apply to either engine code or data; this REF's philosophy holds in both directions.

---

## 1. Philosophy

- **No 100% coverage target.** Test what matters, not what's easy to count.
- **Every test must justify its existence.** If a broken test has no obvious fix, it tests implementation, not behavior.
- **Too many tests is a liability.** Over-testing pins implementation details and makes refactoring painful.
- **Test the behavior, not the structure.** Assert on *what* the code produces, not *how*. Conformance guards (§2), whose job is enforcing structural invariants, are the sanctioned exception.

---

## 2. Test Layers

| Layer | What to Test | Where | I/O Allowed? |
|---|---|---|---|
| **Unit** | Domain entities, value objects, pure functions | `tests/unit/domain/` | No |
| **Unit** | Frontend API clients with mocked fetch | `<frontend>/tests/*.unit.test.ts` | No (mocked) |
| **Integration** | Outbound adapters with real I/O (tmp_path) | `tests/integration/` | Yes |
| **Integration** | HTTP API endpoints via TestClient (real app, real I/O) | `tests/integration/` | Yes |
| **E2E** | Full pipeline: CLI command → generated output | `tests/e2e/` (future) | Yes |
| **Conformance** | Repo-wide structural invariants, via `ast`/`inspect` | `tests/conformance/` | No (reads source only) |

### Unit Tests

Test **domain logic**: entity behavior (`Order.calculate_total()`), value object properties (`Money.is_zero`), domain service algorithms, pure functions.

Domain logic is the expected bulk of `tests/unit/`, but not its hard boundary: a pure function that legitimately lives in another layer (an adapter's exception-translation mapper) may be unit-tested under `tests/unit/<layer>/`, mirroring the source layout. The rule that stays absolute is **no I/O**. Substantial pure logic accumulating in an adapter is a design smell to raise (push it into the domain), not a reason to relax the layer rule.

**Do not unit-test:**
- Trivial getters/constructors (no "test_can_instantiate" for a frozen dataclass).

**Rarely unit-test** (the default home is integration, per §6):
- Mapping functions - covered indirectly by integration tests.
- Use cases - thin orchestrators, tested via integration or E2E.
- The exception that earns its place: a mapper or use-case unit test pinning a **demonstrated regression** that integration cannot reach cheaply (e.g. a defaulted constructor dependency that silently disabled cleanup, verified by reverting the fix and watching the test fail). Name the regression in the test's docstring.

### Conformance Guards

Repo-wide structural invariants, asserted by walking the codebase with `ast`/`inspect` rather than by exercising one unit's behavior. This is the category `REF-CleanArchitecture.md` §11 mandates as "boundary tests that break the build", generalized. Examples:

- Every injected collaborator stays private (`self._name`, never `self.name`).
- Every use case pairs with a Protocol port matching its `execute` signature.
- A name registered across several independent lookup sites stays consistent, so adding an item and forgetting one site fails the build instead of failing silently at runtime.

They live in `tests/conformance/`, run with the fast suite, and touch no runtime I/O - they read the source tree and nothing else.

**Each guard must name the invariant it enforces** (a REF section, a repo rule) and defend against a failure mode that would otherwise fail silently. Pinning structure is these tests' job - the sanctioned exception to §1 - but the exemption is per guard, not per directory: a guard that merely freezes the current layout is anti-pattern 1 at repo scale (§8).

### Integration Tests

Test **adapter behavior** with real I/O using `tmp_path`:

- Repository: load, exists, discover - verify file-to-domain mapping.
- Writers: write output → verify files exist, have expected content/headers.
- Error handling: missing files → domain exception raised.
- **HTTP endpoints**: Use FastAPI `TestClient` to exercise full request → response cycles through the real app with real file I/O (no mocking).

```python
# HTTP integration test - real app, real I/O, no mocks
class TestHealth:
    def test_health_returns_ok(self, client: TestClient) -> None:
        resp = client.get("/api/health")
        assert resp.status_code == 200
        assert resp.json()["status"] == "ok"
```

### E2E Tests (Future)

Full pipeline tests that invoke the CLI or HTTP endpoint and verify the generated output. Added when the pipeline is stable.

---

## 3. Test Structure

```
tests/
├── conftest.py               # Shared fixtures (sample_order, sample_customer)
├── unit/
│   └── domain/
│       ├── test_order.py
│       └── test_money.py
├── integration/
│   ├── test_order_repository.py
│   └── test_invoice_writer.py
└── conformance/
    └── test_ports_match_use_cases.py
```

---

## 4. Test File Conventions

```python
"""Tests for <entity/adapter name>."""

from __future__ import annotations

from <package>.domain.model.order_item import OrderItem
from <package>.domain.model.money import Money


class TestOrderItem:
    """Group tests by behavioral concern, not by method."""

    def test_subtotal_is_quantity_times_price(self) -> None:
        item = OrderItem(
            product_id="P1", name="Widget",
            quantity=3, unit_price=Money(amount=10.0),
        )
        assert item.subtotal == 30.0
```

Rules:
- `class Test*:` grouping by **behavioral concern**, not by method name.
- Test method names: `test_<condition>` or `test_<behavior>_when_<context>`.
- Return type `-> None`; `from __future__ import annotations` always present.
- No docstrings on individual tests unless the name isn't self-explanatory.

---

## 5. Fixtures

Shared fixtures live in `conftest.py` (e.g. `sample_customer`, `sample_money`, `sample_order_item`, `sample_order`).

**Build synthetic data, not fixture files.** Fixtures construct domain objects programmatically. This avoids maintaining test data files that go stale.

When an integration test needs file I/O, use `tmp_path` (pytest built-in) - never write to the project tree.

---

## 6. What to Test - Decision Guide

| Situation | Test It? | Why |
|---|---|---|
| Domain entity with computed property | ✅ Yes (unit) | Core business logic |
| Domain service with algorithm | ✅ Yes (unit) | Complex logic that can break |
| Adapter reads files → builds domain object | ✅ Yes (integration) | Mapping correctness |
| Adapter writes output → files exist with headers | ✅ Yes (integration) | Output correctness |
| Adapter raises domain exception for missing file | ✅ Yes (integration) | Error contract |
| Pure function in a non-domain layer (exception translation) | ✅ Yes (unit, `tests/unit/<layer>/`) | Pure logic, no I/O |
| Repo-wide invariant that breaks silently (registration sites, port pairing, naming) | ✅ Yes (conformance) | The build enforces what review would miss |
| Frozen dataclass with 3 fields | ❌ No | Dataclass runtime guarantees this |
| Use case calls reader then writer | ❌ Rarely | Thin orchestration - tested via integration; a demonstrated regression earns the exception (§2) |
| Mapper converts domain to DTO | ❌ Rarely | Tested indirectly via adapter tests; same exception bar (§2) |
| `__init__.py` re-exports | ❌ No | Import-time verification is enough |

---

## 7. Assertion Style

- **Use `assert` directly** - no `assertEqual`.
- **One logical assertion per test.** Multiple related `assert` calls are fine; unrelated assertions → separate tests.
- **`pytest.raises` for expected exceptions.**

---

## 8. What Not to Do

| # | Anti-Pattern | Why It Hurts |
|---|---|---|
| 1 | Testing every constructor / getter | Tests that mirror the code add no value |
| 2 | Mocking domain entities in unit tests | Test with real domain objects; mock only ports |
| 3 | 100% coverage target | Incentivizes bad tests that check trivial paths |
| 4 | Test names like `test_1`, `test_method_name` | Names should describe the behavior being verified |
| 5 | Fixture files that duplicate domain builders | Programmatic fixtures are easier to maintain |
| 6 | Testing private methods directly | Test via public API; privates are implementation |
| 7 | Integration test that hits a real network service | Use `tmp_path` and local files only |
| 8 | Asserting on exact string output | Brittle - assert on structure/content instead |
| 9 | One test class with 50 tests | Split by behavior concern (2–8 tests per class) |
| 10 | Calling a mocked test "integration" | Mocked = unit. Integration = real I/O, real deps |
| 11 | Conformance guard with no named invariant | Freezing incidental layout is anti-pattern 1 at repo scale |
| 12 | A test that cannot fail, attesting a claim | Ask what production defect the assertion would catch; if the honest answer is "a typo in a literal", the claim is unattested |
| 13 | Every structural gate green, no gate on the product's purpose | Something must exercise what the product is *for* (one end-to-end act of use), or the suite certifies a build that does not run |

---

## 9. Running Tests

> **All Python commands run from the directory holding `pyproject.toml`.**

```bash
# Backend - full suite
python -m pytest -v

# Frontend - full suite (from the frontend package root)
npm run test
```

---

> **Note:** Maintain a project-specific test count table in your project's `README.md` or `ARCHITECTURE.md` if useful for tracking coverage.

---

## 10. Skills that instantiate this REF

Generated by `scripts/sync_backlinks.py` from skill frontmatter; do not edit by hand.

Skills whose frontmatter `refs:` includes `REF-Tests`:

- `apply-intent-bundle` - Apply a reusable Intent Bundle to a target project.
- `audit-intent` - Audit any CSD intent project - validate intent.yaml against CSD-INTENT-01, check that every @intent / intent() test marker references a real claim, and report unattested claims.
- `bootstrap-account-spine-python` - Add the account spine to an existing Python hexagonal FastAPI backend per REF-Identity: an opaque non-derived user id, an accounts table carrying the federation link, digest-only sessions, one session-resolution choke point, a guess budget, and the credential rung named explicitly with --rung (no default, because a scaffold that picks the rung is advocacy with a code generator attached).
- `bootstrap-account-spine-typescript` - Add the account spine to an existing TypeScript backend (domain/ plus adapters/{http,pg}) per REF-Identity: an opaque non-derived user id, an accounts table carrying the federation link, digest-only sessions, one session-resolution choke point, a guess budget, and the credential rung named explicitly with --rung (no default, because a scaffold that picks the rung is advocacy with a code generator attached).
- `bootstrap-data-pack` - Scaffold a new Data Pack at a given path.
- `bootstrap-hexagonal-backend` - Scaffold a new Python FastAPI service in hexagonal (ports and adapters) architecture, conforming to REF-CleanArchitecture / REF-FastAPI / REF-Python.
- `bootstrap-hexagonal-typescript` - Scaffold a new TypeScript application in hexagonal (ports and adapters) architecture per REF-TypeScript: domain / application / adapters layers, ports as interfaces, a container.ts composition root, one exemplar use case wired end to end, and boundary tests asserting the dependency rule.
- `bootstrap-playwright-intent` - Scaffold Playwright + playwright-intent into a frontend project - install both packages, drop a CSD-INTENT-01 canonical intent.yaml stub (if missing), a playwright.config.ts, and an e2e/ directory with an example intent() test.
- `bootstrap-pytest-intent` - Scaffold pytest-intent into any Python project.
- `bootstrap-python-package` - Scaffold a new publishable-quality Python package conforming to REF-Python-Package.
- `bootstrap-react-mvvm` - Scaffold a new React + TypeScript + Tailwind frontend in MVVM (Model / ViewModel / View) form per REF-Frontend and REF-React, with its Model layer generated from a given OpenAPI spec.
- `bootstrap-vitest-intent` - Scaffold vitest-intent into any JS/TS project - install the package, write an intent.yaml stub and an example intent() test.
