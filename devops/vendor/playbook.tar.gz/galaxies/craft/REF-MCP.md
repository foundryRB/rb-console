---
domain: architecture
---

# REF: MCP Server as an Inbound Adapter

> Read this REF when exposing an application's use cases to AI agents over the Model Context Protocol: the server is an inbound adapter, tools mirror inbound ports, and client-side effects ship as content the calling agent executes.

---

## 1. Scope

Rules for adding an MCP server to an application that already has (or is getting) a hexagonal core. Covers the adapter's position in the architecture, tool design, transport and mounting, capability wiring, the client-executes idiom, and auth. Core architecture rules live in `REF-CleanArchitecture.md`; generic inbound-adapter rules in `REF-InboundAdapter.md`; this REF is the MCP specialization of both.

---

## 2. Position: a Door, Not a System

The MCP server is **one more inbound adapter** over the same use cases the HTTP API and UI already call. It is never a separate service, a wrapper around the REST API, or a second implementation of any behavior.

| Do | Not this |
| --- | -------- |
| Mount the MCP server on the same application, one deployable | A sidecar MCP service calling the app over HTTP |
| Tools call inbound ports directly | Tools re-implement use-case logic or shell out to the API |
| All invariants (validation, gating, rollback) enforced in the use case | Adapter-level checks that differ per door |

The payoff: every write, whether it arrives from a UI, a REST call, or an MCP tool, takes the identical path through the core. Trust calibration is enforced in one place.

### The three doors

A **management surface** (a studio: an app whose purpose is operating something on behalf of humans and agents alike) ships all three doors over the same inbound ports: the UI for the operator at a screen, the HTTP API for other systems, the MCP server for agents. The doctrine exists because every door that is missing becomes a workaround: an agent with no MCP door shells out to the API with hand-built payloads, a console with no API door screen-scrapes or reimplements, and each workaround is a second path around the use case's gates. Which apps are management surfaces is a judgment call, made when the app is conceived, and this REF does not pretend to mechanize it: a game ships no MCP door and loses nothing.

What IS mechanical is completeness once a door is declared. The `tools-mirror-inbound-ports` integration test (the `bootstrap-mcp-adapter` skill ships it) already pins one door's parity: the MCP tool set equals the app's inbound ports. The three-door form of the same claim is **door parity**: each door the app declares covers the same use-case set, asserted per repo by its own intent claim and installed by the bootstrap that adds the door. A repo that declares no MCP door installs no such claim; a repo that declares one and lets a new use case ship reachable by HTTP but absent from the tool list fails its own suite. Applicability stays prose; completeness is a gate.

New verbs land through all three doors in one change, or the parity claim fails: the door set is decided per surface, never per verb (a verb too dangerous for one door is too dangerous for the others, since every door runs the same use case and its gates).

---

## 3. Tool Design Mirrors Inbound Ports

- **One tool per inbound port** (or per port method), same noun/verb vocabulary: `get_<entity>`, `list_<entities>`, `update_<entity>`, `run_<operation>`.
- **The tool function is thin**: parse arguments, call the port, map the result. No business logic.
- **Docstrings are the tool descriptions** agents read; write them as one-line contracts ("the edit survives only if the gates pass"), not implementation notes.
- **Serialize through the same mappers/DTOs as the HTTP adapter.** The API contract is the single serialization surface; a parallel MCP-only shape is duplication that drifts (playbook Top Violation #1).
- **Failures carry the reason.** When a gated operation is rejected, the tool error message embeds the validation report so the agent can act on it, not just observe failure.

---

## 4. Transport and Mounting

- Use **streamable HTTP** (the current MCP standard for remote servers) from the official SDK for the stack; for Python, `mcp.server.fastmcp.FastMCP`.
- Mount at a **stable path on the existing app** (conventionally `/mcp`): build the server's ASGI/HTTP sub-app with its internal path set to `/` and mount it at `/mcp`, so the public URL is `https://<host>/mcp`.
- Prefer **stateless HTTP** unless the server genuinely needs per-session state; stateless keeps the pod restartable and load-balancer friendly.
- The SDK's **session manager must run inside the app's lifespan** (start it in the lifespan context that also owns your other background work).
- **DNS-rebinding protection must learn the deployment hostname**: the SDK default admits localhost only (right for a local run), so a deployed server answers 421 until the transport security settings allow the public Host value; feed it from deployment config, leave it unset locally.
- **The bare mount path must serve too**: clients connect to `/mcp` without a trailing slash, and a catch-all static mount at `/` can swallow it before any implicit redirect; register an explicit method-preserving 307 to `/mcp/`.

---

## 5. Capability Wiring

The composition root decides which tools exist, exactly as it decides which routes mount (`REF-CleanArchitecture.md`):

- Register a tool **wherever the composition wires the use case it mirrors**; skip registration when the capability is absent.
- Never register a tool that answers "not supported here": a tool advertising an operation its composition cannot perform is a lie to every connected agent.
- No mode flags inside tools or use cases; the tool list itself is the capability report.

---

## 6. The Client-Executes Idiom

**The server owns its datastore; client-side effects ship as content the calling agent executes.** An MCP server can never write the client's filesystem, and does not need to:

| Client-side effect | Tool shape |
| ------------------ | ---------- |
| Install an asset (skill, template, config) onto the client machine | Tool returns the file set (paths + contents) plus a target-directory hint; the agent writes them |
| Scaffold something in a repo the client owns | Ship an MCP **prompt** (the runbook, parametrized with live server facts); the agent runs it with its own hands |
| Configure the client to connect | The app's UI offers a copyable one-liner; the server never reaches out |

Symmetry rule: the server mutates only what it owns; everything on the caller's side is returned as content, never performed remotely.

---

## 7. Auth

- Gate `/mcp` with the **same fail-closed scheme as the rest of the app** (see the fail-closed pattern in `REF-FastAPI.md` if the app uses HTTP Basic). One credential story per app, not per door.
- MCP clients pass credentials as HTTP headers; for Basic auth that is a standard `Authorization` header supplied at connect time.
- When an interactive OIDC proxy fronts the app's human surfaces, `/mcp` is carved out of that proxy with a skip-auth route so the agent reaches the app's own key directly (the proxy would demand a browser login the agent cannot complete). Where a second proxy joins a host that already runs one, the two coordinate (distinct proxy prefix, shared cookie) rather than colliding: give each proxy its own callback prefix, share the cookie domain and secret for a shared login, and register each callback with the identity provider.
- Behind such a proxy, **the MCP door is the machine's path and HTTP is the human's.** The proxy answers a machine on any other route with its sign-in page, so **a `200` from the HTTP door is not success**: a sign-in page is a `200` carrying HTML, not a `401`, and a reader that checks the status alone records a login screen as content. **A link to a generated artifact is for a person**: it opens in a browser and stops anything else at the sign-in, so hand a person the link and a machine what it needs to read the artifact through the MCP door.
- Per-agent identity is usually premature: attribute agent actions in the artifacts they produce (e.g. commit messages or trailers) until a real multi-identity need appears.

---

## 8. Connecting Agents

Document one connect command next to the deployment (never inside this playbook's generic content):

```bash
claude mcp add --scope user --transport http <server-name> https://<host>/mcp --header "Authorization: Basic <credential>"
```

**An app with a UI serves that same one-liner as an in-app connect panel, by default.** `GET /api/agent-credential` returns the base64 of the machine door's own HTTP Basic pair, the pair the `/mcp` gate enforces, and answers 503 when none is provisioned. The route sits behind the same gate as the UI, whatever gate that is, so the key reaches only a person who can already use the app; the panel fetches it and fills the one-liner, and falls back to the documented command when the route answers 503. The panel is the convenience and the documented command is the reference: the command exists whether or not the app has a panel. A test fixture for the route never assigns a base64 literal to a credential-named constant, which the org's secrets scan reads as a key; it builds the pair at run time.

- Instance URLs and credentials live with the instance (the app's own docs site or registry), never in generic pattern docs.
- Verify the adapter with the SDK's protocol client in an integration test: start the real app, `initialize`, `list_tools`, call one read tool and one gated write tool, and assert the rejected-write path reports the gate output.

---

## 9. Prompts and Resources (When Tools Are Not Enough)

Tools are the default door and most servers need nothing else. The other two primitives differ by who initiates them, and each must earn its place:

| Primitive | Initiated by | Publish one when |
| --------- | ------------ | ---------------- |
| Tool | The agent, mid-task | Always the default: one per inbound port (§3) |
| Prompt | The user (clients surface prompts as slash commands) | A **recurring, multi-step, client-executed** procedure needs to run reliably on invocation |
| Resource | The client app, as attachable context | A client's attachment UX genuinely needs the content as context, and a tool read does not serve it |

Rules:

- A prompt is a **maintained runbook**: it returns the procedure as a message, parametrized with live server facts, and the calling agent executes it. It is the invocable form of the client-executes idiom (§6).
- **Never wrap a single tool call in a prompt.** The tool's own description already teaches the agent; a prompt adds a second artifact that drifts.
- Validate prompt arguments server-side (an unknown entity is a prompt error, not a runbook for a ghost).
- Do not mirror tool reads as resources by default; two read paths for the same content is duplication that drifts. Add a resource only for a demonstrated attachment need.

---

## 10. Anti-Patterns

| # | Anti-Pattern | Correct Approach |
| - | ------------ | ---------------- |
| 1 | Standing up a separate MCP service in front of the API | Mount the server on the same app; one deployable, one auth story (§2) |
| 2 | Tools that wrap HTTP endpoints of the same app | Tools call inbound ports directly (§3) |
| 3 | An MCP-only response shape maintained next to the API DTOs | Serialize through the same mappers/DTOs (§3) |
| 4 | Registering tools for capabilities the composition did not wire | Tool list derives from the wiring (§5) |
| 5 | Trying to write to the caller's machine from the server | Client-executes idiom: return content, the agent applies it (§6) |
| 6 | A second auth scheme just for MCP | Same fail-closed scheme and credential as the app's other surfaces (§7) |
| 7 | Testing tools by calling their functions directly | Protocol-level test through the SDK client against the running app (§8) |
| 8 | A prompt that wraps one tool call | Prompts are runbooks for multi-step client-side procedures only (§9) |
| 9 | Mirroring every tool read as a resource | Resources only for a demonstrated attachment need (§9) |

---

## 11. Skills that instantiate this REF

Generated by `scripts/sync_backlinks.py` from skill frontmatter; do not edit by hand.

Skills whose frontmatter `refs:` includes `REF-MCP`:

- `bootstrap-mcp-adapter` - Add an MCP inbound adapter to an existing hexagonal FastAPI backend: the tools-mirror-inbound-ports server module, streamable HTTP mounted on the same app, capability-derived tool registration, and a protocol-level integration test.
