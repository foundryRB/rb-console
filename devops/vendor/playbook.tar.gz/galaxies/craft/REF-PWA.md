---
domain: framework
---

# REF: Progressive web app

> Read this REF when making a web frontend installable: the web app manifest, the service worker and its update policy, the seam with a session-cookie auth proxy, web push, and what a PWA can and cannot reach without a store.

---

## 1. Scope

A progressive web app is the frontend the project already has, plus a manifest that lets a device install it and a service worker that lets it start without the network. This REF owns that addition: the manifest, the worker and its update policy, the install experience, the seam with a fronting auth proxy, web push, and the testing delta. It is the default route to phones and to installability, because it ships the code the project has, from the host it already runs on, with no store, no signing and no second build.

It does **not** own the frontend itself (`REF-Frontend.md` + `REF-React.md`), the desktop shell (`REF-Electron.md`, for an app that genuinely needs the local machine), or the auth gate in front of the app.

Two readings frame everything below:

- **The installable app is the small part.** A manifest, a rented build plugin and an update prompt make an app installable. The work particular to a project is where the worker meets whatever already sits in front of the app, and for an app behind a session-cookie auth proxy that seam is §8.
- **Rent the worker, author what cannot change.** An installed client is a copy of the app the project can no longer reach directly, so the decisions it makes permanent are the ones worth owning (§3).

---

## 2. Installable and offline are two decisions, taken separately

The manifest and the service worker are not halves of one step. They cost differently, they fail differently, and an app is entitled to take the first without the second. Decide them in order, and record the second as a decision rather than a default.

**The manifest is close to free.** It buys the app's identity on the device: the icon, the name under it, the standalone window on the engines that require a manifest to give one. It adds no code path that can fail at runtime and nothing that outlives a deploy except the identity §3 tells you to freeze.

**The worker is a trade.** It buys a shell that starts without the network and an offline state the app controls instead of the engine's error page, which in a standalone window is a dead end with no address bar to escape from. Against that it buys the whole of §8: a cached shell that can outrun a deploy, two ways to break an auth redirect, and a bad worker that persists on a device until the kill switch reaches it. Every rule in §8 exists because the worker exists.

So the question is not "should this be a PWA" but **what does this app do when the network is gone**. An app whose value is a live view of something remote (a console, a dashboard, a queue) shows nothing useful offline, and a worker there buys a fast launch in exchange for a staleness problem. An app the user reads, drafts in, or carries into a bad signal earns the worker outright.

| | Manifest only | Manifest and worker |
| --- | --- | --- |
| Icon, name, standalone window | yes | yes |
| Launches without the network | no | yes |
| Offline state the app controls | no | yes |
| Always serves the current deploy | yes, the engine fetches it | only once the worker updates (§7) |
| Can strand a session behind a cached shell | no | yes, unless §8 is followed |
| Web push | no | yes for the imperative path (§10) |

**Two traps at the ends of this.** A worker written only to satisfy an install check is waste: no engine has required a fetch handler to install since Chrome 108 on mobile and 112 on desktop, and a do-nothing handler is a caching layer nobody designed. And an engine that installs with no manifest at all, as Safari has since iOS 26, is not a reason to skip the manifest: the app still has no icon of its own and no name it chose, and the engines that do require one still refuse.

Adding the worker later is an ordinary change. Removing it after clients have installed is not, because they hold it until something unregisters it (§7). Start at manifest only when the answer is unclear.

---

## 3. Rent the worker, author what cannot change

**Rent**: the worker's generation and precache manifest come from a maintained build plugin, never a hand-written caching layer; `bootstrap-pwa` names the plugin its scaffold wires. A generated worker in the plugin's default strategy is the floor; a hand-written worker is taken on only when the app needs its own worker code (a push handler is the usual reason).

**Author, and freeze from the first release**:

| Decision | Why an installed client makes it permanent |
| -------- | ------------------------------------------ |
| The manifest `id` and `start_url` | They are the app's identity on the device (§4); changing either forks the installed icon into a second app the first one's users are never moved to |
| The worker's file name and scope | The kill switch only reaches clients that still look for the worker where it always was (§7) |
| The update policy | A client on an old worker runs the old policy; the first policy shipped decides how the next one arrives (§7) |
| The sign-out control | A standalone window has no address bar, so an app that ships without one cannot be signed out of at all (§8) |
| The boundary around offline and push | A later store shell may never run the worker (§11); code that reached past the boundary is re-authored, not moved |

---

## 4. The manifest

- **Set an explicit `id` and never change it, nor `start_url`.** `id` decides whether a fetched manifest updates the installed app or describes a second one. Engines without `id` support fall back to `start_url` as the identity, so both are frozen together.
- **Ship at least one icon with purpose `any`.** Safari ignores a manifest icon whose only purpose is `maskable`, so an icon set generated to the adaptive-icon guidance alone is invisible to it. An `apple-touch-icon` link, when present, wins over the manifest icons silently: keep the two in step or drop the tag.
- **Add `screenshots` (each tagged `form_factor` `wide` or `narrow`) and a `description`.** On Chromium one screenshot upgrades the install UI from an infobar to a store-like dialog; it is manifest-only work and costs nothing elsewhere.
- **A declared manifest takes over from the engine's defaults, so a broken one is worse than none.** From iOS 26 a site added to the Home Screen opens standalone by default with no manifest at all. Declare one and the engine reads the display mode from it instead; if it cannot be parsed, the app gets neither the default nor the declaration, and lands back in a browser window with no icon. The same file that adds the identity removes the fallback, which is why §5 treats serving it correctly as part of shipping it.
- **A standalone window has no browser chrome**, so every app carries its own navigation and its own way back from every screen.
- **On iOS, keep the two pre-manifest meta tags** alongside the manifest: `apple-mobile-web-app-capable` for a standalone window on anything older than iOS 26, and `apple-mobile-web-app-title`, without which the label under the icon comes from `<title>` and truncates.

---

## 5. Serving the PWA's own files

The manifest and the worker are ordinary static files, and the two rules about them fail only in production, never in a dev server or a preview. Both belong to whatever actually serves the build: a container's web server, a CDN, an ingress.

- **Serve the manifest as `application/manifest+json`.** Most servers' bundled type maps have no `.webmanifest` entry and fall back to `application/octet-stream`. Chromium parses it regardless, so the whole test layer can be green while Safari refuses it, and by §4 a refused manifest costs the engine default too. Scope the declaration to the one file; a server's type-map block usually **replaces** the inherited map at its level, so a global edit to add one entry can send every stylesheet and script out as `octet-stream`.
- **Serve the worker script uncached**, and verify it on the deployed URL rather than trusting the config. A cache between the browser and the build blocks every future update silently, and a CDN's browser-cache floor may raise a zero TTL while leaving an explicit long one alone, so hashed assets look correct while the worker does not.

**Verify both against the deployed origin, because nothing upstream covers them.** A build proves the files exist and a browser test proves the app parses them, but neither exercises the server that will actually answer. Two `curl -I` calls, once per environment, after the first deploy:

| Request | Expected |
| --- | --- |
| the manifest URL | `Content-Type: application/manifest+json` |
| the worker URL | a `Cache-Control` that permits no caching |

**Probing a URL before it exists can poison a CDN.** A request for a file the deploy has not shipped yet is answered by the SPA fallback, and an edge cache may keep that HTML under the asset's URL for hours, so the asset stays broken after the deploy for reasons the deploy cannot explain. Probe after shipping, or bust the cache with a query string while probing, and purge the path if it has already happened.

If a server config is the only thing standing between a correct build and a broken deploy, give it a gate: validating it during the image build costs one line and turns a crash-looping pod or a silently wrong media type into a failed build.

---

## 6. Install

- **Put the manifest on the page people install FROM, which is rarely the page you were thinking of.** An origin that serves more than one app by path, or that bounces a signed-out visitor to a login page, hands most first-time users a page that is not the app: the login screen is what a new user is looking at the first time they are given the address, and it may be a different deployable with no manifest of its own. An install taken there declares nothing, and produces an icon with no artwork that opens in a browser window, indistinguishable from the app being broken. Decide deliberately which pages are installable, and either give them the tags (same-origin paths mean they can reuse one manifest and one icon set) or say plainly in the app's own documentation that the user must reach the app first.
- **iOS has no install prompt event, on any browser.** Install there is a hint the app authors: shown only on iOS, only while `display-mode` is `browser`, naming the Share then Add to Home Screen steps, dismissible, and gone once the app runs standalone. On Chromium the same component may drive the browser's own prompt from its install event.
- **On Android, install from Chrome.** Chrome turns an install into a real app, with its own launcher icon and its own entry in the app switcher, packaged and signed by Google. Other Android browsers differ, and not only in polish: Firefox, Edge and Opera add a shortcut that reopens the site inside that browser, and Samsung Internet's own package was blocked outright by Play Protect as an app "built for an older version of Android" on a Galaxy Z Fold 7, where Chrome on the same phone installed cleanly (observed 2026-09-28). Install instructions and support answers name Chrome, and a blocked or browser-badged install from another browser is answered by reinstalling from Chrome, not by a change to the app.
- **On managed devices nobody installs by hand.** A Chromium enterprise policy force-installs a web app by URL, and an Apple device-management profile pushes a full-screen web clip. For a customer with a managed fleet that is the whole distribution story: no store, no instructions.
- **One store lists a PWA as it is.** The Microsoft Store accepts a packaged PWA with no native build. It is an optional listing, never a prerequisite.
- **The App Store does not.** Its review guidelines refuse a repackaged website and Apple offers no web-app wrapper. A requirement for an App Store listing is a requirement for a native shell, with the Mac, the toolchain and the developer account that come with it; a PWA cannot get there, and §11 states what that later move would cost.

---

## 7. The service worker: update and rollback

A new worker is detected by a byte comparison of the worker script on navigation into its scope, then waits until every window the old worker controls has closed. An installed app is almost never fully closed, so left alone it runs the old shell indefinitely and a refresh does not fix it.

- **Check for updates explicitly**: call the registration's `update()` when the app returns to the foreground and on an interval. Waiting for a navigation is waiting for something an installed app rarely does.
- **Prompt, never auto-update, unless the app has nothing to lose.** Auto-update reloads every open window the moment a new worker is found, and a user with a half-filled form loses it. The waiting worker is activated only from the user's action on a visible "update available" control.
- **The kill switch is a self-destroying worker served at the same URL**: a replacement whose only job is to delete the caches and unregister itself, which the build plugin generates from one option. It works only if the worker's file name and scope never changed (§3), so they never change.
- **Serve the worker script with `Cache-Control: no-cache`.** Browsers skip their own HTTP cache on the update check; a proxy or gateway cache between browser and app does not, and a stale worker script there blocks every future update silently. Hashed build assets stay immutable as usual.

---

## 8. Behind a session-cookie auth proxy

An app that sits whole behind a fronting auth proxy meets its worker in four places. None of them shows up in a browser tab during development; all of them show up installed.

- **The manifest request carries no cookies by default**, even same-origin, so the proxy answers it with a login redirect and installability fails with no visible error. Put `crossorigin="use-credentials"` on the manifest link (the build plugin has an option for it). Prefer this to exempting the manifest from auth: an exemption widens the gate to fix a request that only needed its cookie.
- **The cached shell answers a navigation before the proxy can redirect it.** With a navigation fallback in place, a signed-out user gets the precached shell, never reaches the proxy, and sits in an app whose every call fails. Exclude the proxy's own path prefix and the API prefix from the navigation fallback (the worker generator's denylist). Denied routes lose their offline fallback, which is the correct trade.
- **The proxy reports a dead session only when asked in JSON.** An unauthenticated request gets `401` only if it carries `Accept: application/json`; anything else gets a redirect to the identity provider's login page, which a background `fetch` cannot use. Every API call sends that header, and on `401` the app performs a full-page navigation to the proxy's own sign-in route, carrying the current location as the return target. Reloading the current route is not enough: the cached shell answers that navigation too (the bullet above), so only a path on the denylist reaches the proxy. Never a retry loop.
- **Whether the installed app shares the browser's session depends on the platform, and the app owns sign-out.** On iOS a standalone app's cookies and storage are separate from Safari's, though install may carry the browser's session in (observed on iOS 26, from a private tab too). On Android an app installed from Chrome shares Chrome's cookies: signing out in an ordinary Chrome tab ended the installed app's session as well (observed 2026-09-28). Rely on neither the sharing nor the isolation. What follows either way: the app ships a visible sign-out control, a plain full-page link to the proxy's sign-out route, never a router link or a `fetch`, because a standalone window has no address bar to reach that route any other way (evidence: `foundry-console#120`). The sign-in hop through the identity provider then stays inside the installed app on both platforms, so it needs no handoff to the system browser (a sign-out then sign-in on iOS 26.6, and a sign-out, sign-in and expired session on Android Chrome, both on `foundry-console`).

---

## 9. Storage

On iOS a site visited in a browser tab has its script-writable storage (IndexedDB, local storage, the worker registration and its caches) deleted after seven days without interaction. A Home Screen web app is exempt and gets the browser's own quota.

- **Offline features belong to the installed app.** Pitch and document them that way; a tab user loses the cache after a quiet week, without warning.
- **Local data is a cache of the server's truth either way.** Nothing the user cannot afford to lose lives only on the device.

---

## 10. Web push

- **On iOS push exists only for the installed app, and only after a tap.** A browser tab cannot subscribe at all, and the permission prompt can be raised only from a user gesture inside the installed app, never on load. iOS push is therefore two asks in sequence, install then permission, and a user who skips the first fails silently. Size every promise about notifications on iPhone to the users who will do both.
- **Re-send the subscription to the server on every launch.** iOS never fires the subscription-change event, so the client cannot be relied on to report a rotated or revoked subscription. The server stores what each launch reports and prunes any endpoint the push service rejects.
- **There is no silent push.** Every engine requires a push to show a notification; "wake the app quietly to sync" is not available on any platform, so sync is driven from the foreground.

---

## 11. Offline and push sit behind one boundary

If a store listing is ever required, the ladder from a PWA is lopsided. An Android Trusted Web Activity runs the real browser, so the worker, the manifest and the push subscriptions carry over whole. An iOS store shell runs its web view under a custom scheme where a service worker never registers, so offline and push are re-authored there against native plugins.

- **One module owns every touch of the service worker and push APIs**, and views consume it through a ViewModel hook like any other state (`REF-Frontend.md` §4). Nothing else in the frontend imports the plugin's virtual modules or reaches for `navigator.serviceWorker`.
- That boundary is what keeps the later move cheap: a shell swaps the module's inside and leaves the views alone, the same one-codebase-two-surfaces property `REF-Electron.md` §2 keeps for the desktop.

---

## 12. Coexisting with a desktop shell

The same renderer build may also run inside the desktop shell of `REF-Electron.md`. The shell bundles the code and gains nothing from an offline cache, and a page loaded from a file origin refuses worker registration with an error.

- **Guard registration**: register the worker only when the page is served over `http:` or `https:` and the shell's typed handle (`REF-Electron.md` §4) is absent. The guard lives in the one module of §11, so the shell build logs nothing and the web build is untouched.

---

## 13. Testing

Core: `REF-Tests.md`. The PWA delta:

- **There is no stock PWA audit.** Lighthouse removed its PWA category in version 12, so install-readiness is a smoke test the project owns: the manifest is served with its frozen `id` and an `any` icon, the manifest link carries its credentials attribute (§8), the worker registers and takes control, and a reload with the network off still renders the shell.
- **Playwright sees service workers on Chromium only.** Worker behaviour (precache, the denylist, the offline fallback) is asserted in the Chromium project, against the built app, because the worker exists only in a build.
- **Block workers where a test mocks the network.** A request the worker answers never reaches Playwright's routing, so an existing test that stubs responses stops intercepting the day a worker ships, silently. Those tests set `serviceWorkers: 'block'`.
- **The WebKit project is not an installed iPhone app.** Home Screen behaviour (install, storage, push) is observable only on a real device.

---

## 14. Anti-Patterns

| # | Anti-Pattern | Correct Approach |
| 1 | Shipping a service worker because the app is "becoming a PWA", with no answer to what the app does offline | Manifest and worker are separate decisions; take the manifest, then earn the worker (§2) |
| 2 | Skipping the manifest because the target engine installs without one | The app still has no icon or name of its own, and other engines refuse (§2) |
| 3 | Shipping a manifest without checking the media type the server actually gives it | `application/manifest+json`, declared for that one file; a default type map has no `.webmanifest`, and a declared-but-unparseable manifest is worse than none (§4, §5) |
| 4 | Adding a media type with a server-wide type-map block | It replaces the inherited map at its level; scope it to the file, or every stylesheet and script ships as `octet-stream` (§5) |
| 5 | Trusting a build or a browser test to prove the manifest and the worker are served correctly | Neither runs the production server; `curl -I` both against the deployed origin, once per environment (§5) |
| 6 | Probing an asset's URL before the deploy that ships it | The SPA fallback answers, and an edge cache can hold that HTML under the asset's URL for hours (§5) |
| 7 | Giving the manifest only to the app, on an origin whose login page or sibling app is what users actually install from | Decide which pages are installable and give them the tags, or document that the user must reach the app first; a manifest-less page installs as an unstyled browser shortcut (§6) |
| 8 | A fetch handler written only to satisfy an install check | No engine has required one since Chrome 108 and 112; a do-nothing handler is an undesigned caching layer (§2) |
| 9 | Changing the manifest `id` or `start_url` after a release | Frozen from the first release; they are the installed app's identity (§4) |
| 10 | A manifest whose icons are all `maskable`, or an `apple-touch-icon` that drifted from them | At least one `any` icon; the tag kept in step or dropped (§4) |
| 11 | Auto-update as a convenience switch | Prompt mode and a visible update control; auto-update only where nothing can be lost (§7) |
| 12 | Waiting for a navigation to find the new version | Explicit update checks on foreground and on an interval (§7) |
| 13 | Renaming the worker file or moving its scope | They stay put forever; the kill switch depends on it (§7) |
| 14 | A hand-written caching layer | A generated worker from a maintained build plugin (§3) |
| 15 | Exempting the manifest from auth to make install work | `crossorigin="use-credentials"` on the manifest link (§8) |
| 16 | A navigation fallback that covers the auth proxy's paths or the API | Both prefixes on the fallback denylist (§8) |
| 17 | API calls that let the proxy answer with a login redirect, or a `401` handled by reloading the current route | `Accept: application/json` on every call; on `401` a full-page navigation to the proxy's sign-in route (§8) |
| 18 | An installable app with no sign-out control | A plain full-page link to the proxy's sign-out route (§8) |
| 19 | Promising iPhone notifications to users who have not installed the app | Install, then a tapped permission request; re-send the subscription every launch (§10) |
| 20 | Views importing the plugin's modules or touching `navigator.serviceWorker` | One module behind a ViewModel hook (§11) |
| 21 | Registering the worker inside the desktop shell | Guard on protocol and the shell's handle (§12) |
| 22 | Network-mocking tests left running with a worker in play | `serviceWorkers: 'block'` in those tests (§13) |
| 23 | Treating an App Store listing as a PWA packaging step | It is a native shell project; say so when the requirement appears (§6, §11) |
| 24 | Telling Android users to install from whichever browser they have | Name Chrome; other browsers add a browser-bound shortcut, and Samsung Internet's package can be blocked by Play Protect (§6) |

## 15. Cross-references

- `REF-Frontend.md` + `REF-React.md`: the frontend being made installable; §11's module is an ordinary SAM ViewModel domain.
- `REF-Electron.md`: the desktop shell the same renderer may also run in (§12), and the route for an app that needs the local machine.
- `REF-Tests.md`: test layering; §13 here is its PWA specialization.
- `REF-Design.md`: the visual identity supplies the manifest's name, colours and icons.

---

## 16. Skills that instantiate this REF

Generated by `scripts/sync_backlinks.py` from skill frontmatter; do not edit by hand.

Skills whose frontmatter `refs:` includes `REF-PWA`:

- `bootstrap-pwa` - Make an existing Vite/React MVVM frontend installable per REF-PWA, in either of its two modes: --manifest-only (the app's identity on the device, no service worker) or the full PWA (a generated worker in prompt mode, the update banner, the auth-proxy denylist, the kill switch, the shell guard).
