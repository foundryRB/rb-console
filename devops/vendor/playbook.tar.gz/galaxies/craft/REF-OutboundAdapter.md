---
domain: architecture
---

# REF: Outbound Adapter Construction

> When asked to create or modify an outbound adapter (persistence, file writers, external services), follow these rules strictly.

---

## 1. What an Outbound Adapter Is

An outbound adapter **implements an outbound port** - it translates domain operations into infrastructure calls (e.g., `PostgresOrderRepository` implements `OrderRepository`, `PdfInvoiceWriter` implements `InvoiceWriter`).

---

## 2. Folder Structure

Each outbound adapter lives in its own sub-package under `adapters/outbound/`:

```
outbound/
├── persistence/
│   ├── postgres_order_repository.py  # Implements OrderRepository
│   └── db.py                        # Low-level database utilities
├── payments/
│   └── stripe_payment_gateway.py    # Implements PaymentGateway
├── invoices/
│   ├── pdf_invoice_writer.py        # Implements InvoiceWriter
│   ├── branding.py                  # Invoice-specific branding
│   └── templates/                   # Invoice template files
└── notifications/
    └── smtp_notification_service.py  # Implements NotificationService
```

Group by **infrastructure technology** or **output format** - each sub-package is cohesive around a single kind of I/O.

---

## 3. Implementation Pattern

```python
"""Outbound adapter: <what it does and which port it implements>."""

from __future__ import annotations

from pathlib import Path

from <package>.domain.model.order import Order


class PdfInvoiceWriter:
    """Generate PDF invoices using a template engine.

    Implements :class:`InvoiceWriter` port.
    """

    def __init__(self, templates_dir: Path) -> None:
        self._templates_dir = templates_dir

    def write(self, order: Order) -> Path:
        """Write an invoice for the given order."""
        ...
        return output_path
```

Key rules:
- The class docstring mentions which port it implements.
- Method signatures **exactly match** the port Protocol - same names, same types, same return types.
- Constructor may accept infrastructure-specific configuration (file paths, connection strings).
- Third-party imports are allowed - this is the infrastructure layer.

---

## 4. Domain Type Consumption

The adapter **reads** domain object properties and writes infrastructure output (rows, payloads, documents). It never modifies domain objects.

---

## 5. Mapping Responsibility

Unlike inbound adapters (which have explicit `mappers/` sub-packages), outbound adapters perform their mapping **inline** - the mapping *is* the adapter's purpose, and the adapter openly depends on domain types, so explicit mapper files are **not required**. If an adapter grows too large, extract helper modules within the same sub-package (e.g., `invoices/branding.py`, `invoices/layout.py`).

---

## 6. Error Handling

- Outbound adapters **catch infrastructure exceptions** (file I/O errors, parsing failures) and **translate them to domain exceptions**.
- Never let `FileNotFoundError`, `yaml.YAMLError`, or `openpyxl` errors leak to the use case.
- Use the appropriate domain exception class (see `REF-ExceptionHandling.md`).

```python
try:
    data = yaml.safe_load(path.read_text(encoding="utf-8"))
except FileNotFoundError:
    raise EntityNotFoundError("Config", str(path)) from None
except yaml.YAMLError as exc:
    raise DataParseError(path, reason=str(exc)) from exc
```

---

## 7. Naming

| Element       | Convention                                        | Example                        |
|---------------|---------------------------------------------------|--------------------------------|
| Sub-package   | Infrastructure technology or output format        | `persistence/`, `excel/`       |
| Main file     | `<port_name>.py` (technology in class name)       | `invoice_writer.py`              |
| Class         | `<Technology><PortName>`                          | `PdfInvoiceWriter`               |
| Helpers       | Semantic names for the sub-concern                | `branding.py`, `layout.py`       |

---

## 8. Adapters Can Be Simple

An adapter is defined by its **responsibility** (translating between domain and infrastructure), not its **complexity**. A one-liner adapter is still an adapter - **don't skip the pattern because the code is short.**

---

## 9. Anti-Patterns

| #  | Anti-Pattern                                    | Correct Approach                              |
|----|-------------------------------------------------|--------------------------------------------|
| 1  | Letting infrastructure exceptions propagate      | Catch and wrap in domain exception         |
| 2  | Adapter modifying domain objects                 | Adapters only read domain objects          |
| 3  | Adapter importing from another adapter           | Adapters are independent                   |
| 4  | Adapter importing inbound port or use case       | Outbound adapters know only domain + stdlib|
| 5  | Business logic in the adapter                    | Move to domain entity or service           |
| 6  | Single god adapter doing everything              | Split by output format / technology        |
| 7  | Hardcoded file paths or config values            | Accept via constructor injection           |

## 10. Semantic Package Layout

When an adapter package has multiple files, the **directory tree must communicate** which files pair together and where any type can be found - without opening a single file.

### Principle: separate behavior from data shapes

Keep **behavioral** files (functions that do work) at the package root. Group **structural** types (data carriers) in a `models/` sub-package.

```
<adapter_package>/
  __init__.py              # public API
  orchestrator.py          # thin coordinator (or generate.py, write.py, etc.)
  prepare.py               # domain → adapter types
  render_overview.py       # output unit 1
  render_detail.py         # output unit 2
  models/
    __init__.py            # re-exports all types
    overview.py            # types consumed by render_overview
    detail.py              # types consumed by render_detail
    bundle.py              # aggregate wrapper for all prepared data
```

### Semantic pairing

Model files are named to **mirror the behavioral files that consume them**: `render_overview.py` pairs with `models/overview.py`, `write_timeline.py` with `models/timeline.py`.

### Rules

| Rule | Rationale |
|------|-----------|
| `models/` files mirror behavioral file names | Semantic pairing - find any type by knowing which behavior uses it |
| One `models/*.py` per output unit | Each file groups the types that travel together |
| `models/__init__.py` re-exports all types | Short import paths: `from .models import OverviewData` |
| Constants belong in the model file for their concern | No generic `constants.py` junk drawers |
| Behavioral files at package root | Opening the folder shows the pipeline immediately |

### When `models/` is overkill

With ≤ 2 structural types total, keep them in a single `models.py` at the package root; promote to a `models/` directory when a third concern appears.

### Anti-patterns

| # | Anti-Pattern | Correct |
|---|---|---|
| 1 | Structural types scattered flat alongside behavior | Group in `models/` sub-package |
| 2 | Type filenames that don't correspond to behavioral files | Name model files to mirror the files that consume them |
| 3 | Generic `constants.py` in adapter packages | Constants go in the model file for their concern |
| 4 | Single `models.py` when there are 3+ distinct concerns | `models/` directory - files provide semantic scoping |
| 5 | Behavioral files importing domain objects deep in rendering logic | Prepare step extracts; behavior consumes adapter types |

---

## 11. Splitting Overloaded Adapters

Section separators inside any adapter file - class-based or functional - are a **mandatory split signal** (see REF-Python "Semantic Structure"). No exceptions for "cohesion". Split along separator boundaries.

### 11a. Class-based adapters → thin orchestrator + sibling modules

When a class-based adapter file has section separators, extract each section into a **sibling module** with standalone functions; the class becomes a thin delegator.

```
# BEFORE - god class with section separators:
persistence/
  file_project_repository.py   # 480 lines, 4 sections

# AFTER - thin class + focused loader modules:
persistence/
  file_project_repository.py   # ~100 lines, thin orchestrator class
  config_loader.py             # load_config(), save_config_data()
  phase_loaders.py             # load_phases(), per-phase loaders
  requirement_loaders.py       # load_brd_index(), load_requirements()
  domain_loaders.py            # load_assumptions(), load_guidelines(), …
```

Rules:
- The class **stays in its original file** - callers don't change.
- Extracted functions are **standalone** (no `self`); they receive explicit arguments.
- The class imports and delegates: `config = load_config(project_path)`.
- If extracted functions share a utility, it lives in whichever module *defines* it and others import from there.
- Same pattern applies to stateless class methods: extract to module functions, class delegates.

### 11b. Functional adapter modules → packages

An adapter may consist of **module-level functions** with a public `render()` entry point - no class, no instance state. This is acceptable when:
- The adapter has no constructor-injected dependencies.
- The module naturally reads top-down: domain → helpers → render.
- An orchestrator imports the module and calls `module.render(...)`.

When a functional module outgrows a single file, convert it to a **package** (directory with `__init__.py`):

```
# BEFORE - one god module with section separators:
slidev/
  roadmap_slides.py    # 650 lines, 7 sections

# AFTER - package with focused modules:
slidev/
  roadmap_slides/
    __init__.py          # re-exports render(), contains orchestrator
    colors.py            # colour palette + conversion helpers
    labels.py            # label parsing helpers
    phase_headers.py     # phase column detection + HTML header row
    gantt_builders.py    # Gantt HTML table builders
    resource_table.py    # resource allocation mini-table
    slide_renderers.py   # slide render functions
```

The `__init__.py` exposes the same `render()` function, so **callers are unaffected** whether it is a module or a package.

### Key rules for both patterns:
- Dependency flow is layered: helpers → builders → orchestrator.
- Each file has a clear, single concern - the filename describes what it provides.
- `__all__` in every public module.
