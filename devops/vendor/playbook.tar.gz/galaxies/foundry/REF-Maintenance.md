---
domain: methodology
---

# REF: Maintenance

> Read this when tending a live app: the ticket loop, the three ceremony modes, the verdict gate, and the derived state that makes the whole 1-to-n process followable from any Claude session.

---

## 1. The two modes of a project's life

A live project runs two always-on modes at will; neither is a graduation out of the other.

| Mode | Question | Unit | Arc | Pattern source |
| ---- | -------- | ---- | --- | -------------- |
| Delivery | How does 0 become 1 (or a new major)? | the engagement | five phases, four gates, ends at reconcile | `REF-Delivery.md` |
| Maintenance | How does 1 become n? | the ticket | a standing loop, one gate per ticket, no end | this REF |

A delivery line's close opens this loop at first ship (`REF-Delivery.md`); this REF is that loop's process. First ship does not close the engagement, so the close also creates the loop's **tracking surface**: the open tickets on the repo host, which is what the queue in §7 is read against; a project board with milestones toward the customer's full target, where anyone keeps one, is a view over those tickets and never what the queue reads. Who creates the board is a delivery decision, credentials permitting; moving the customer onto working from it stays with the operator. The customer's acceptance (UAT) feedback becomes new requirement IDs at the next scope, never edits to the delivered spine, and the items descoped or delivered as a bonus are filed as tickets, the seed of the next scope, which a board shows where one is kept. A change too large for a ticket (a rework, a new module, a new major) is not a big ticket: open a delivery line instead. The resolve step can make that call itself: when it judges a ticket delivery-scale it hands the ticket off instead of forcing a PR, preparing the delivery brief on the ticket and offering the operator a switch to a delivery line (`resolve-ticket`'s Delivery-scale handoff).

The whole process is followable by any team member with a Claude session, this playbook, and the repo host's CLI. Any frontend over it (a console, a dashboard) is a convenience that renders and drives the same acts; it is never a dependency of the loop (`REF-Delivery.md` §1: the accelerator principle).

## 2. The unit and the vocabulary

- The unit of maintenance is the **ticket**: a real issue on the repo host. Real issues only, never in-conversation work items: work agreed in a chat gets an issue before it gets a branch. (Direct mode, which branches nothing, is the deliberate exemption: its record is the commit, §4.)
- **One ticket = one branch = one PR = one concern.** A PR that fixes three things is three PRs. The operator-invoked backlog run in section 4.1 is the explicit batching specialization: batch issues retain the concerns, and one combined PR carries their shared review.
- **Dependency and Dependabot tickets load `REF-AppContract.md` section 4, "Accepted advisories and Dependabot alerts", before triage or resolution.** It owns the acceptance policy, schema source and explicit alert-dismissal procedure.
- **A ticket lives in the repo whose code it changes.** The whole loop is repo-scoped - the branch, the conformance suite, `Closes #n`, the review, the rebase merge, the version the pipeline derives - so a ticket filed on repo A whose fix lives in repo B breaks every one of those: the closing keyword does not close across repos, the release lands under B's history, and A's line never goes green. The fix is to move the ticket (`gh issue transfer` inside an org keeps the thread and leaves a redirect), never to open a cross-repo PR and hope the paperwork catches up. Filing is where this is cheapest to get right: **file against the repo that holds the file you intend to change**, not the repo the subject makes you think of. An app that *serves* a corpus is not the repo that *contains* it.
- Names carry the ticket end to end:

| Artifact | Form | Example |
| -------- | ---- | ------- |
| Branch | `{type}/{n}-{slug}` | `fix/41-portal-links` |
| Commit | `type: subject (#n)` + the closing keyword in the body | `fix: relative links under the portal base (#41)` / `Closes #41` |
| PR title | `type(#n): subject` | `fix(#41): relative links under the portal base` |

- `type` is a Conventional Commit type under the platform's commit convention (`REF-AppContract.md` §4); the release pipeline derives the version from it.
- The closing keyword on the default branch means the pipeline's own grammar closes the ticket; no separate act closes it.
- **The closing keyword also goes in the PR body**: the body is what links the PR to its ticket on the repo host, and a keyword there closes the ticket on merge however the merge lands (`resolve-ticket` step 5).

## 3. The loop

| Step | Act | What survives, and where |
| ---- | --- | ------------------------ |
| File | create the issue on the repo host | the ticket: intent, labels, the conversation |
| Triage | the inbox habit (§7): order what needs attention | priority and assignment, on the issue |
| Resolve | branch, edit, run the repo's conformance, commit conventionally, open the PR | the branch and the PR |
| Review | the gate (§5): fresh eyes write findings and the verdict; a PASS closes the gate, the merge records it, and the closing keyword on the merge ties the ticket - **the merge is where the ticket closes and is done** (§2, §6) | the verdict on the PR; the closed ticket; the merged commit |
| (promotion) | beyond the ticket: the pipeline cuts the release and it deploys automatically into the entry environment, and moving it further is the **promotion line** (`REF-Promotion.md`), not a step of the ticket loop and not part of the ticket's done-definition | the tag, the deployed revision |

Ship costs no one anything: merging a conventional commit to the default branch is the whole trigger. Most maintenance therefore needs no orchestration at all; the loop's only human moments are resolve and the gate.

## 4. The three ceremony modes

The ceremony is chosen **per act**, exactly as a delivery chooses its run mode: all the gates, or none. The default is gated.

| Mode | Ceremony | Who merges | When |
| ---- | -------- | ---------- | ---- |
| **gated** (default) | ticket, branch, PR, verdict, merge | a human; the merge is the sign | the team default; always for a contributor's PR |
| **one-shot** | ticket, branch, PR, verdict, merge on PASS | `resolve-ticket` (its step 7) runs the merge helper (`merge_on_pass.py`, its folder), which independently re-checks the verdict and CI before merging (§5), under the operator's standing authorization for the drive | the operator's own driven tickets, pre-authorized |
| **direct** | a conventional commit on the default branch, conformance green | nobody; no PR exists | changes smaller than the ceremony, at the operator's judgment |

- A **contributor's** PR always takes the gated mode: their merge waits for a maintainer.
- In direct mode a fix needs no issue; the conventional commit is its record. Reference the ticket (`(#n)`) when one exists.
- Direct is chosen per act; it is never a repo's standing default.
- **Three modes, exactly - and the interaction axis is orthogonal to them** (`REF-Delivery.md` §1): the ceremony mode picks who merges; `manual`/`auto` only decides whether the running skill may ask. At a terminal (`manual`) the loop may ask the operator; headless (`auto`) it never prompts, posting its open question to the ticket and parking rather than waiting. A **gated act run headless parks at the verdict for the human merge** - it never self-merges to avoid waiting. Either way a driven ticket merges only on a recorded PASS, or parks on a FAIL for the operator.
- Delivery siblings, loosely: gated pairs with interactive, one-shot with one-shot. Direct has none; the pipeline itself (§8) is its safety net.

### 4.1 A repository backlog run

`resolve-backlog` is the operator's repository-wide act: judge the visible tickets with `earn-it`, consolidate overlapping survivors, resolve the batches with a selected implementation model, obtain one combined review from the same model in fresh context, fix its findings, then rebase and fast-forward. It has real invocation scope; an ordinary ticket run never infers permission to clear the repository. Load section 2's dependency-work routing before judging any dependency or Dependabot concern.

The run uses the delivery vocabulary, `mode=interactive|one-shot` (`REF-Delivery.md` section 1), with **interactive as the default**. At a terminal, interaction defaults to manual. These are the backlog run's dials, not a fourth single-ticket ceremony mode. Invoking the complete run authorizes its ticket consolidation, implementation and eventual integration within the accepted scope; it does not answer an unresolved product or scope decision.

| Run mode | Decisions |
| --- | --- |
| interactive (default) | In manual execution, raise genuine unresolved choices when they arise, including triage/batch scope, outward-facing behavior and material review tradeoffs. Wait only on dependent work and retain prior explicit authorization. |
| one-shot | The operator pre-authorizes the run's gates. Use the smallest reasonable assumption, record it on the affected issue or PR, and continue under `REF-Autonomy.md`. External failures remain named blockers. |

Interaction remains the launcher's separate fact (`REF-Delivery.md` section 1). An explicitly headless `interaction=auto` run never prompts inside the worker: it applies the assumption protocol and records decisions, in either mode, while any external interactive gate remains ungranted until its authorized signal arrives. Missing mode or interaction is never inferred as one-shot or auto; an interactive/manual run that loses its human channel parks the dependent decision.

The model is a runtime binding: Sol or Opus as selected by the operator, resolved from the available catalog rather than a version pinned in the corpus. Omission prefers the runtime's configured Sol/Opus coding model, then available Sol, then available Opus. The implementation workers and fresh reviewer use the **same actual binding**. No requested model is silently replaced. A reviewer receives the artifacts and requirements, never the implementation conversation, and has no hand in the change.

Batch on overlap in the work, not on the original ticket boundaries or an arbitrary batch size. Related docs form one reader-facing batch. A batch issue holds its source IDs, accepted scope and acceptance criteria; superseded tickets link to it and close as superseded, never as delivered. Drops retain evidence and revisit triggers, already-done rulings point to the fix, and wrong-home findings name the owner. `foundry-hidden` exclusions from section 7 apply before any ticket mutation. The run's record lives on issues and its combined PR (section 6).

### 4.2 Backlog integration authority

The combined run uses section 5.1's recorded agent review and fast-forward integration. The single-ticket approving-review object and squash helper in section 5 serve the ordinary ticket loop. The batch path records agent independence explicitly and never fabricates a forge approval or changes repository protection. An external approval required by the host remains required.

## 5. The verdict gate

The gate is the **verdict**: the one artifact this process adds to the repo host's own machinery. A fresh-eyes reviewer - an agent or person with no hand in the change - reads the PR against the linked ticket, the routed REFs for the touched stack, and the CI evidence, posts findings as a PR review, and ends with the verdict as the last line. **The authoritative record is one object**: an approving PR review (or request-changes, on FAIL) carrying the verdict as the last `VERDICT:` token its body holds, matched wherever it lands and tolerant of markdown emphasis and trailing prose. An approval with no verdict token, or a `VERDICT: PASS` in a plain comment, is not a verdict - one object carries both the review state and the verdict, so every checker (a human, the merge helper, the cockpit, the delivery worker, CI) reads the same gate. The merge is the gate's recorded consequence, not the gate.

**The vocabulary is three states, and the third is not a failure.** PASS and FAIL each assert something about the change. A review can also complete and find that it cannot *record* either, because the reviewing identity is the PR's author or the identity that would merge - the host refuses an approve or a request-changes on one's own PR, and §5 independently forbids a PASS from either identity. That is `VERDICT: UNRECORDED`:

| State | What it asserts | Review object | What it authorizes |
| ----- | --------------- | ------------- | ------------------ |
| `VERDICT: PASS` | the change is correct | an **approving** review | the merge |
| `VERDICT: FAIL` | the change is defective; the findings are the work order | a **request-changes** review | a return to resolve |
| `VERDICT: UNRECORDED` | the analysis is complete and posted, and no authoritative object could carry it: the reviewing identity is the PR's author or the merger | a **commented** review (never approve, never request-changes) | nothing; the PR waits for an independent reviewer |

UNRECORDED is **not a FAIL**: it makes no claim that the change is defective, it is not a work order, and it never sends the change back to resolve. Nor is it a verdict anything merges on - the merge helper still requires an APPROVED `VERDICT: PASS` from fresh eyes, and names an UNRECORDED review in its refusal so the park reads as *awaiting an independent reviewer* rather than *nobody looked*. Every reader that renders the queue (§7) files it in the `awaiting-review` family for the same reason. The failure this state exists to prevent is a terminal-driven loop, where the driving session and the PR's author are one identity, recording a clean review as FAIL for want of anything else to say: a defect claim with no findings behind it, on a green PR, blocking the merge for the wrong reason (#75).

Rules:

- **Nothing merges unreviewed.** Every PR waits for a fresh-eyes `VERDICT: PASS` before any merge, in gated and one-shot alike.
- **Identity overlap records UNRECORDED, never FAIL.** A reviewer who is the PR's author or the merging identity posts its findings as a commented review carrying `VERDICT: UNRECORDED`, and the PR waits; the review's analysis survives on the PR either way.
- **The reviewer is never the merger, and the producer is never the reviewer.** Who merges is the mode's choice: the operator (gated), or, in one-shot, `resolve-ticket` (its step 7) running the **merge helper** (`merge_on_pass.py`, its folder) - the maintenance analog of the delivery line's gate helper (`REF-Delivery.md` §1, "How a gate closes"). The helper independently re-reads the PR and merges only over an APPROVED review carrying `VERDICT: PASS` as its verdict whose author is neither the PR's author nor the merging identity, with green checks; an agent never fires the merge by hand. And the PASS itself must come from fresh eyes: a one-shot drive obtains it from a session that had no hand in the change, never by running `review-pr` over its own output (§9, anti-pattern 7).
- **A red CI blocks the merge in every mode.** No verdict overrides a failing check.
- A failing verdict goes back to resolve; the reviewer's findings are the work order. An UNRECORDED one does not: it needs an independent reviewer, not a change.

### 5.1 The combined backlog review

The batch gate is one substantive review of the complete integration diff against all accepted batches and their interactions. Its record on the combined PR names the base and reviewed head, the model binding, the independent reviewer session, findings, checks and verdict. A shared forge login can transport that record; it does not establish or invalidate the separate agent's fresh context. Record it honestly as an agent review, not an approving forge review when the host cannot grant one. The reviewer neither implements repairs nor merges.

Findings return to the implementers. Every actionable finding gets a disposition and verification evidence; the same reviewer confirms the repairs against the resulting head. This targeted closure belongs to the one review, and unresolved findings keep the gate open. A clean initial review needs no invented repair round. Changes outside the reviewed scope require a scope decision, not a stale PASS.

After repair, fetch the default branch and rebase the combined branch onto it. Green checks must describe the resulting tree. A conflict that changes behavior gets focused verification from the reviewer; a content-equivalent rebase needs no second broad review. Before integration verify that the remote default is still the checked base, the current head has the review and repair evidence, required checks passed, and all required host approvals exist. Fast-forward to that head and use a normal push: no merge commit, squash or force-push of the default branch. A racing remote update returns to rebase and verification. If the host cannot accept this strategy, retain the branch and surface the decision.

## 6. Derived state and the two truths

Maintenance stores no state of its own: no status files, no `.maintenance/` directory, no tracker copy. Every record already has a home, and the loop's position is derivable from those homes at any moment:

| Record | Home |
| ------ | ---- |
| Intent | the issue: what and why |
| Review | the PR: the diff, the verdict, who merged |
| Shipping | the merged commit, the tag that contains it, the deployed revision, the live probe |

A ticket is **done** when it is **merged**: the verdict recorded and the closing commit on the default branch (the closing keyword ties the ticket, §2). Fail-closed, both truths hold:

| Truth | Evidence |
| ----- | -------- |
| Process | the CI run concluded green (and, for a driven run, the worker exited zero) |
| Work | conformance green, the verdict present (gated and one-shot), the closing commit on the default branch |

Anything short of that reads as not-done: an issue closed by hand with no commit, or a PASS verdict with no merge. What happens **after** the merge - the release cut, the automatic deployment, the promotions beyond it - is the concern of the **promotion line** (`REF-Promotion.md`), not the ticket's done-definition; a merged ticket is done whether or not promotion has caught up. Unreleased or drifted merges are surfaced by the inbox sweep (§7) and by that line's own sweep, not held against the closed ticket.

## 7. Activities beyond tickets

- **The inbox habit.** Periodically sweep every maintained repo in one pass and order the result by attention; work the queue. The sweep is followable by hand with the repo host's CLI, and nothing curates it. One derivation serves every reader - a session, a console, a desk - and the rules below are that contract; `maintenance-inbox` carries the deterministic sweep that produces it. The promotion line shares this queue rather than keeping its own (`REF-Promotion.md` section 6): what a proven release has not yet reached is one more thing needing attention this morning, not a second list.

  **The signals, in attention order.** What is being worked *right now* leads, so a reader does not put a second worker on it; then what is broken, then what waits on a human, then what merged but never shipped, then what a proven release has not reached, then open intent.

  | # | Signal | What it is | The act |
  | - | ------ | ---------- | ------- |
  | 1 | `running` | a maintenance run in flight for this concern | watch |
  | 2 | `red-ci` | a PR's checks red, or the default branch red | investigate |
  | 3 | `drift` | a deployment unhealthy or behind its release, or a declared target that serves the proven release and does not answer | investigate |
  | 4 | `pr-review` | a PR awaiting a verdict, or carrying a PASS awaiting merge | review / merge |
  | 5 | `unreleased` | commits on the default branch past the last tag | release |
  | 6 | `promotion` | a declared target behind the proven release, its door in flight, or its state unreadable (`REF-Promotion.md` section 6) | promote / watch / investigate |
  | 7 | `issue` | an open ticket | its stage's act, below |

  Within one signal, rows run by repo name and then by number, names compared code point by code point and never through a locale, so every reader orders the same names the same way; one repo's promotion rows keep `REF-Promotion.md`'s attention order among themselves.

  `running` is **supplied by the caller, never discovered by the derivation**. Its source differs by reader (a workflow engine, a desk's own live agents, nothing at all in a plain session), and a derivation that went looking for it would be inventing state rather than deriving it (§6).

  **One concern, one row.** Two folds, both load-bearing: without them one piece of work appears twice and the reader cannot tell the rows are the same thing.

  - A live run is *the* row for the concern it works, and that ticket's own row folds into it. A run's number is its **act's** target, which is the ticket for a resolve but the PR for a review, so a review's number resolves back to the ticket it serves before the fold.
  - A PR that resolves a still-open ticket folds into that ticket's row. The concern surfaces once, as the issue, never as an issue and a PR.

  **An issue's stage** is its linked PR's state folded onto the ticket, so a ticket already at a gate stops reading as untouched work: `open` (resolve), `awaiting-review` (review), `awaiting-merge` (merge), `changes-requested` (resolve - §5: the findings are the work order), `checks-red` (investigate).

  **Archived repos appear in no signal**: a tombstone's open issues are noise by definition. Anything marked `foundry-hidden` is held off the queue on the same principle, and the count says how many, so the exclusion reads as a choice rather than a loss. The mark has **two scopes**: the *label*, on one ticket, holds that ticket back and leaves the rest of its repo alone; the *topic*, on one repo, holds back **every signal that repo raises** - its red CI, its drift, its unshipped tail, not its tickets alone. A repo taken off the Foundry's surfaces takes its whole queue with it, or the hide is only half meant. Neither scope DROPS a row: the derivation marks, and the reader holds back and counts, because a reader handed an already-shortened queue cannot tell a deliberate exclusion from a signal nobody raised.

  **A signal whose source is unreachable is reported unchecked**, never omitted and never guessed. An absent row and a healthy row look identical on the surface, and a silent gap reads as "nothing needs me".
- **Docs reconciliation.** Audit every published claim about the repo against the code (`REF-Documentation.md`): its `docs/`, its README, and, when the workspace publishes them, any flyer (`REF-Flyer.md`) that describes this repo or its offering. Every drift found becomes a filed ticket (operator-confirmed, labeled), then flows through the ordinary loop; a flyer the code contradicts is filed like any other drift, routed to whichever side is wrong (the code fell short, or the flyer went stale). A flyer is outward-facing, so its drift misrepresents the offering to a customer, not just a maintainer. Docs drift is maintenance work, not a side errand.
- **Codify.** A lesson learned in a review or a resolution goes to the playbook (a REF or a skill, per `REF-Authoring.md`), never to per-project memory. The review that taught it is the trigger; the codification is its own small act, often its own ticket.

  **A closing delivery line files its lessons here, and it proposes rather than writes.** A run captures lessons, defects and customer sentiment as it goes, but no run edits a REF or a skill from inside itself: nothing it captured is reviewed yet, and its report is a claim, not a result. At its close the line triages what it logged and files only the survivors as tickets, which land in this loop and are reviewed like any other change. Which repo takes a ticket follows §2 - the repo whose content it changes - so a proposed REF or skill change is an issue on the playbook repo carrying the proposed text and the run's evidence, while a forward recommendation about the app is an issue on the delivery repo, its permanent home once the line is closed. **A defect that dies in a report is paid for again on the next delivery**, which is why the filing is the phase's output and not its optional extra.

  **The first delivery through any new bridge sets precedent.** Propose its codification as a ticket before a second delivery needs it, while the run that learned it is still the evidence.

## 8. Enforcement homes

Enforcement is mechanical, never hoped for:

| Rule | Enforced by |
| ---- | ----------- |
| Commit convention | the shared CI's commit-hygiene job, which the release job needs; the repo's commit-msg hook locally |
| Conformance | the repo's own suite, in CI |
| No release from a red branch | the pipeline: CI failure cuts no release |
| The verdict contract | one object: an approving PR review carrying `VERDICT: PASS` as its verdict (the last one its body holds, markdown and trailing prose tolerated); the merge helper refuses a review with none, and a missing verdict is a FAIL - unless the reviewing identity could post no authoritative object at all, which is `VERDICT: UNRECORDED` on a commented review (§5): still unmergeable, but named as such in the refusal rather than read as a defect claim |
| The one-shot merge | the merge helper (`resolve-ticket/merge_on_pass.py`): verdict, fresh-eyes authorship, and green checks re-checked deterministically at the merge act |
| The inbox contract (§7) | the sweep (`maintenance-inbox/sweep.py`): the signals, their order, and both folds derived in one place, over a fixture corpus each reader's own suite is pinned to - a frontend that renders the queue is attested against the same vectors rather than trusted to have read the prose |
| PR-before-merge, green-checks-before-merge | optional: the repo host's branch protection, per team's choice |

Branch protection is an enhancement a team may opt into, not a requirement of the loop (the gated merge is the human's own judgment act, and it needs no machinery); the modes stay the operator's choice either way. The one-shot merge is where the mechanical guard is load-bearing, and that home is the merge helper above.

## 9. Anti-Patterns

| # | Anti-Pattern | Correct approach |
| - | ------------ | ---------------- |
| 1 | Rebuilding ticketing inside a tool, console, or document | The repo host's issues are the store; everything else links out and derives (§6) |
| 2 | Merging unreviewed, or the reviewer merging its own verdict | Nothing merges without a fresh-eyes PASS, and the reviewer is never the merger: the operator merges (gated) or the merge helper fires on the recorded PASS (one-shot, `merge_on_pass.py`) (§5) |
| 3 | Working from in-conversation items ("also fix the header while you're at it") | File the issue first; real issues only (§2) |
| 4 | A `.maintenance/` directory, status files, or a tracker copy | Derive state from the issue, the PR, and the pipeline (§6) |
| 5 | Forcing the gated ceremony onto typo-class work | Direct mode exists; choose the ceremony per act (§4) |
| 6 | Making direct mode a repo's standing default | The default is gated; direct is a per-act judgment (§4) |
| 7 | The reviewer had a hand in the change | Fresh eyes only; otherwise the verdict is the author grading their own work (§5) |
| 8 | Closing a ticket by hand when a commit should close it | The closing keyword ties the record; hand-close only wontfix or duplicate, with the reason (§2) |
| 9 | Growing a ticket into a rework, module, or major | Open a delivery line; maintenance is ticket-sized (§1) |
| 10 | A verdict overriding a red CI | A red CI blocks the merge in every mode (§5) |
| 11 | Fixing found docs drift silently, with no ticket | File the drift, then resolve it through the loop (§7) |
| 12 | Codifying a lesson into per-project memory | Durable lessons go to REFs and skills (§7, `REF-Authoring.md`) |
| 13 | Treating the verdict as coordination - a sign-off that exists to clear the merge | The verdict is epistemic: a claim that the change is correct, earned against the diff, the ticket, the routed REFs, and the CI evidence (§5); a PASS that only unblocks the merge is a rubber stamp, and a rubber stamp is a FAIL that has not admitted it |
| 14 | Reclassifying non-trivial work as "direct" to skip the gate | Direct is typo-class only, chosen per act at the operator's judgment (§4); a change you would rather not have reviewed is exactly the change that needs the ceremony. When in doubt, gated |
| 15 | Resolving a ticket by opening the PR in whichever repo happens to hold the code | A ticket belongs to the repo whose code it changes (§2). Discovering otherwise mid-resolve is a **locus stop**, not a licence to work cross-repo: name the owning repo on the ticket, label it, and park (`resolve-ticket`'s wrong-repo park). The intellectually right patch in the wrong repo is invisible to the ticket's own loop - which will then report that nothing shipped, and retry until its budget is gone |
| 16 | Guessing which repo a proposal belongs to from a name | Resolve it from the thing that owns it, mechanically: the playbook repo is what the playbook door reports as its own upstream (`get_sync_status`'s `repo`), never inferred from an app called `<something>-studio`. A guessed repo files real work where no one is looking for it |
| 17 | Recording `VERDICT: FAIL` because the reviewing identity could not approve its own PR | FAIL is a defect claim, and a FAIL with no findings on a green PR is one the merge helper then enforces. The state for a review that happened but could not be recorded is `VERDICT: UNRECORDED`, posted as a commented review (§5); the PR waits for an independent reviewer rather than going back to resolve |

---

## 10. Skills that instantiate this REF

Generated by `scripts/sync_backlinks.py` from skill frontmatter; do not edit by hand.

Skills whose frontmatter `refs:` includes `REF-Maintenance`:

- `maintenance-inbox` - One sweep across every maintained repo: open issues, PRs awaiting review, unreleased commits on the default branch, red CI, drifted deployments, promotions a proven release has not reached - ordered into one attention queue.
- `reconcile-docs` - Audit a repo's docs/, plus any published flyer that makes claims about it, against its code, and file every drift found as a ticket (operator-confirmed): the docs-reconciliation activity of REF-Maintenance.
- `resolve-backlog` - Clear a repository backlog: earn-it triage, consolidate overlapping tickets, resolve with Sol or Opus, review once in fresh context with the same model, fix findings, rebase and fast-forward.
- `resolve-ticket` - Resolve one ticket through the maintenance loop: read the issue, branch (or main in direct mode), edit, run the repo's conformance, commit conventionally referencing the ticket, and open the PR (or push); in one-shot it merges on a passing review, never in gated mode.
- `review-pr` - Fresh-eyes review of a maintenance PR: read the diff against the linked ticket, the routed REFs for the touched stack, and CI evidence; post findings as a PR review ending VERDICT: PASS, VERDICT: FAIL, or - when the reviewing identity is the PR's author or the merger - VERDICT: UNRECORDED.

---

## 11. Agents that orbit this REF

Generated by `scripts/sync_backlinks.py` from agent frontmatter; do not edit by hand.

Agents whose frontmatter `refs:` includes `REF-Maintenance`:

- `librarian` - Closes a finished delivery line and files its lessons as tickets for the maintenance loop; hand it a run that reached done.
- `programmer` - Works the maintenance loop: sweeps the inbox, takes one ticket to a pull request, audits docs against code; hand it a ticket, a repo to sweep, or docs to reconcile.
- `reviewer` - Reviews with fresh eyes what it had no hand in, a phase artifact or a pull request, and returns findings and a verdict; hand it anything that needs an outsider's read before a gate or a merge.
