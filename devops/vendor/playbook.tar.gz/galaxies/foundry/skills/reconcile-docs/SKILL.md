---
name: reconcile-docs
description: "Audit a repo's docs/, plus any published flyer that makes claims about it, against its code, and file every drift found as a ticket (operator-confirmed): the docs-reconciliation activity of REF-Maintenance. Produces the drift report; resolution flows through the ordinary ticket loop."
galaxy: foundry
refs:
  - REF-Maintenance
  - REF-Documentation
---

# Reconcile docs

Invoked on a repo whose `docs/`, or a published flyer that makes claims about it, may have drifted from its code: the docs-reconciliation activity of `REF-Maintenance.md` §7. The output is a drift report and, operator-confirmed, one filed ticket per drift; the fixes themselves flow through the ordinary ticket loop, never through this skill.

## Pre-flight

1. **Read** `REF-Maintenance.md` §7 and `REF-Documentation.md` (and `REF-StarlightDocs.md` when the site is Starlight, `REF-Flyer.md` when the repo has published flyers) if not already in context.
2. **Locate the docs surface**: the repo's `docs/` (site or plain markdown), the README, any doc-bearing frontmatter contracts the repo declares, and, when the workspace publishes flyers, any published flyer that makes claims about this repo or its offering. Flyers are a *when-relevant* limb: most repos have none; a flyer enters scope only when it names this repo, app, or offering, and only its concrete claims (a named capability, a command, a stated guarantee) are auditable, never its positioning prose.
3. **Establish the truth side**: the code, the config, the intent claims (`intent.yaml` when present), and the repo's actual behavior are the reference; the docs, and any in-scope flyer, are the audited side.

## Steps

1. **Run the mechanical checks first**: the docs site's own build, its intent tests when present (doc frontmatter contracts), and the repo's link checker. Mechanical failures are drift items already proven.
2. **Audit claim by claim**: read each docs page and test its statements against the code - named flags, routes, commands, defaults, diagrams, port numbers, file layouts. A statement that cannot be traced to current code is drift; so is current behavior with no docs home. Apply the same test to every in-scope flyer's concrete claims (a named capability, a stated guarantee, a command it says the product runs): a flyer claim the implementation contradicts is drift too, and because a flyer is an outward-facing published claim, that drift outranks a stale internal page.
3. **Write the drift report**: one line per drift - the page or flyer, the claim, what the code actually says, the suggested fix type (`fix:`, `docs:`, or a flyer revision). No edits are made in this pass.
4. **File the tickets, operator-confirmed**: present the report; for each drift the operator confirms, `gh issue create` with a `docs` label, the page and claim in the body, and the report line as the description. A flyer drift is filed where its fix lands, which may be another repo: a `fix:` against this repo when the code fell short of what the flyer promises, or a revision against the flyer's own repo (or straight through the flyer workshop when one is connected) when the offering has moved past the flyer. Batch-confirm is fine; silent filing is not.
5. **Hand off to the loop**: the filed tickets are ordinary maintenance work (`resolve-ticket`); this skill ends at the filing.

## Failure modes

- **The docs build itself is red**: report that first and file it as its own ticket; auditing prose on a broken build buries the lead.
- **A drift is really a code bug** (the docs describe the intended behavior, the code disagrees): file it as `fix:` against the code, citing the docs page as the spec.
- **A flyer contradicts the implementation**: decide which side is the spec, then file, never edit inline. If the flyer states the intended promise and the code fell short, file `fix:` against this repo citing the flyer. If the offering has genuinely moved past the flyer, the flyer is the stale side: file a revision against the flyer's own repo, or take it through the flyer workshop when one is connected (`REF-Flyer.md` §9). Either way it is a filed ticket; a flyer is published outward, so silently leaving the contradiction is worse than a stale internal doc.
- **Temptation to patch small drifts inline**: decline (§7: docs drift is filed, then resolved through the loop); an untracked docs edit is invisible maintenance.
- **No docs surface exists**: report that as the finding; whether to bootstrap one is the operator's call, not this skill's.
