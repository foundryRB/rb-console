"""Mechanical entry gate for run-delivery-plan.

Refuses (exit 1, one line per failure) when the delivery repo is not ready for
an autonomous build run: no build handoff in the delivery scratch
(.delivery/handoff.md), missing handoff anchors (authorization, not-authorized
list, done-definition, degraded stop-states), a hollow handoff (a ship section
with no substance - the first-release sequence, the evidence chain, the degraded
stop-states), no locked visual identity (.delivery/design.md, so the design phase
produced none), or a gate still recorded as PENDING. Prints PASS lines for what it
verified so a refusal names exactly what remains.

It reads a handoff's structure and its gate records and never judges its prose: the
signed plan gate over its recorded fresh-eyes review is what attests every decision
in the plan is made (INT-GATE-001).

The handoff and the design record live in the committed delivery scratch
(REF-Delivery.md section 1): they are ephemeral, assembled from the durable
sources, committed on the line's own delivery/<line-id> ref so a cancelled run
resumes, and retired with the line at reconcile. The
maintained spec (intent.yaml) sits at the repo root, or at the subproject root
the handoff names when a multi-domain repo keeps one spec per domain.

Stdlib only. Usage:

    python preflight.py --repo <repo-root>
"""

from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

if sys.stdout.encoding and sys.stdout.encoding.lower() != "utf-8":
    sys.stdout.reconfigure(encoding="utf-8")

_SCRATCH = ".delivery"

# A gate's state is its record's FRONTMATTER `signed:` field, and only that
# (REF-Delivery.md section 1, anti-pattern 24: the frontmatter beats the prose,
# always). A date is a signature; `pending`, empty, or absent is not. The body is
# never read for gate state: a design-rubric row or a sentence narrating a gate as
# "pending" is prose, and prose must never hold a run whose gate is signed.
_SIGNED_FIELD = re.compile(r"^\s*signed\s*:\s*(.*?)\s*$", re.IGNORECASE)

# Anchors every REF-Delivery handoff carries (handoff-template.md section 0 and 10).
# The not-authorized list accepts the template's bold anchor and the older
# "Nothing else is authorized" phrasing of pre-template handoffs.
_PLAN_ANCHORS = (
    ("authorization", re.compile(r"\*\*Authorization", re.IGNORECASE)),
    (
        "not-authorized list",
        re.compile(r"\*\*Not authorized|Nothing else is authorized", re.IGNORECASE),
    ),
    ("done-definition", re.compile(r"\*\*Done-definition", re.IGNORECASE)),
    ("degraded stop-states", re.compile(r"degraded stop-state", re.IGNORECASE)),
)

# The ship sections a build actually executes; a heading that exists with an
# empty body is a handoff assembled but never filled, and the build it launches
# improvises the whole ship (the hollow-handoff defect). Headings only; the
# anchors above still catch pre-template handoffs that phrase these inline.
_SHIP_SECTIONS = (
    ("first-release and onboarding sequence", re.compile(r"First-release and onboarding", re.IGNORECASE)),
    ("evidence chain", re.compile(r"evidence chain", re.IGNORECASE)),
    ("degraded stop-states", re.compile(r"Degraded stop-state", re.IGNORECASE)),
)


# The substance floor a ship section's body must carry to count as filled. It
# measures characters, never physical lines: a substantive one-sentence answer
# ("n/a, already onboarded - the app is live since P0") is a decision made, however
# it wraps, while a heading over nothing, a dash, or a TODO is the hollow-handoff
# defect whatever its line count. A real run was refused over line-wrapping alone
# and worked around by reformatting settled prose after the gate closed - the
# check-appeasement failure INT-GATE-001 exists to prevent (a check that makes a
# run edit the delivery's text to pass has stopped measuring the delivery).
_MIN_SECTION_CHARS = 20


def section_body(text: str, heading: re.Pattern[str]) -> int | None:
    """The section's substance: non-whitespace-padded character count of the body
    between the matching heading and the next `## ` heading, or None when no
    heading line matches."""
    lines = text.splitlines()
    start = next(
        (i for i, line in enumerate(lines) if line.startswith("#") and heading.search(line)),
        None,
    )
    if start is None:
        return None
    count = 0
    for line in lines[start + 1 :]:
        if line.startswith("## "):
            break
        count += len(line.strip())
    return count


def _front_field(text: str, name: str) -> str | None:
    """A frontmatter field's stripped value, or None when the block or field is absent.
    Only the leading `--- ... ---` block is read; the body is prose and never a gate
    (anti-pattern 24)."""
    if not text.startswith("---"):
        return None
    end = text.find("\n---", 3)
    front = text[3:end] if end != -1 else text[3:]
    pat = re.compile(rf"^\s*{name}\s*:\s*(.*?)\s*$", re.IGNORECASE)
    for line in front.splitlines():
        m = pat.match(line)
        if m:
            return m.group(1).strip().strip('"').strip("'")
    return None


def maintained_spec(repo: Path, handoff: str) -> Path | None:
    """The maintained spec's home, or None when no candidate holds a file.

    The spec defaults to the repo root, but a real multi-domain repo keeps one per
    subproject root (`system/intent.yaml` beside `docs-site/intent.yaml`, each its own
    intent domain), and the handoff's own Inputs table names which one this delivery's
    claims live in. That pointer beats a hardcoded repo-root guess - a gate that
    asserts the literal path refuses a repo whose layout is deliberate (the same
    principle as the exit gate's resolved docs homes) - with the root as the fallback
    when the handoff names none. A pointer resolving outside the repo is ignored: the
    handoff is data, never a licence to read past the checkout.
    """
    candidates = [repo / m.group(1) for m in re.finditer(r"`([\w./-]*intent\.yaml)`", handoff)]
    candidates.append(repo / "intent.yaml")
    for candidate in candidates:
        try:
            candidate.resolve().relative_to(repo.resolve())
        except ValueError:
            continue
        if candidate.is_file():
            return candidate
    return None


def _gate_unsigned(text: str) -> bool:
    """True when the record's frontmatter gate is not signed: its `signed:` field is
    absent, empty, or the literal PENDING (any case)."""
    value = _front_field(text, "signed")
    return value is None or value.lower() in ("", "pending")


_DATE_VALUE = re.compile(r"^\d{4}-\d{2}-\d{2}$")


def _review_unrecorded(text: str) -> bool:
    """True when the record carries no dated `reviewed:` field. Every gate closes over
    its recorded fresh-eyes review (REF-Delivery.md section 1), so a signed gate with
    no review date was closed outside the gate helper."""
    value = _front_field(text, "reviewed")
    return value is None or not _DATE_VALUE.match(value)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", required=True, help="Delivery repo root (holds .delivery/ and intent.yaml)")
    args = parser.parse_args()

    repo = Path(args.repo)
    failures: list[str] = []

    if not repo.is_dir():
        print(f"FAIL: repo root not found: {repo}")
        return 1

    scratch = repo / _SCRATCH
    handoff_path = scratch / "handoff.md"
    if not handoff_path.is_file():
        print(f"FAIL: no {_SCRATCH}/handoff.md at {repo} (run intent-session first)")
        return 1
    handoff = handoff_path.read_text(encoding="utf-8")
    print(f"PASS: {_SCRATCH}/handoff.md found ({len(handoff.splitlines())} lines)")

    for label, pattern in _PLAN_ANCHORS:
        if pattern.search(handoff):
            print(f"PASS: handoff carries its {label}")
        else:
            failures.append(f"FAIL: {_SCRATCH}/handoff.md is missing its {label} (handoff-template.md)")

    for label, pattern in _SHIP_SECTIONS:
        body = section_body(handoff, pattern)
        if body is None:
            failures.append(
                f"FAIL: {_SCRATCH}/handoff.md has no {label} section heading (handoff-template.md)"
            )
        elif body < _MIN_SECTION_CHARS:
            failures.append(
                f"FAIL: the handoff's {label} section is hollow ({body} body chars < "
                f"{_MIN_SECTION_CHARS}) - a heading over no substance ships nothing; "
                "fill it or point it at its owner (handoff-template.md)"
            )
        else:
            print(f"PASS: handoff {label} section carries content ({body} body chars)")

    # The design phase is not optional: a build with no locked visual identity
    # would invent a look (REF-Delivery.md section 3). Enforce it here.
    identity_path = scratch / "design.md"
    if identity_path.is_file():
        print(f"PASS: visual identity locked ({_SCRATCH}/design.md)")
    else:
        failures.append(
            f"FAIL: no {_SCRATCH}/design.md (design phase locked no visual identity; run design-session)"
        )

    # The maintained spec: the home the handoff names, or the repo root (a
    # multi-domain repo keeps one spec per subproject root; see maintained_spec).
    spec = maintained_spec(repo, handoff)
    if spec is not None:
        print(f"PASS: intent.yaml present ({spec.relative_to(repo).as_posix()}, the maintained spec)")
    else:
        failures.append(
            "FAIL: no intent.yaml at the repo root or any home the handoff names "
            "(the only maintained spec)"
        )

    # The plan gate (handoff.md) and the design gate (design.md) must be signed in
    # their frontmatter for the build to start. Read the frontmatter only; the body's
    # prose is never the gate (anti-pattern 24), so a signed gate whose prose still
    # narrates itself as pending proceeds - the run does not re-litigate a signature.
    for label, path in (("plan", handoff_path), ("design", identity_path)):
        if not path.is_file():
            continue
        text = path.read_text(encoding="utf-8")
        if _gate_unsigned(text):
            failures.append(
                f"FAIL: the {label} gate is unsigned ({path.name} frontmatter `signed:` is pending or absent)"
            )
        elif _review_unrecorded(text):
            failures.append(
                f"FAIL: the {label} gate is signed but `reviewed:` carries no date ({path.name}); "
                "every gate closes over its recorded fresh-eyes review (REF-Delivery.md section 1), "
                "so this record was closed outside the gate helper - re-review and re-stamp it"
            )
        else:
            # A signature's evidence is the committed review artifact the stamp helper
            # verified (REF-Delivery.md section 1). A dated `signed:` with no matching
            # artifact is the self-sign forgery the contract exists to stop: hand-written
            # fields pass a frontmatter read, but they cannot conjure the file.
            reviews_dir = scratch / "reviews"
            matches = sorted(reviews_dir.glob(f"{path.stem}-*")) if reviews_dir.is_dir() else []
            if not matches:
                failures.append(
                    f"FAIL: the {label} gate is signed but {_SCRATCH}/reviews/ holds no "
                    f"{path.stem}-* artifact; a signature without its committed review is a "
                    "self-sign (REF-Delivery.md section 1) - re-review and re-stamp through the helpers"
                )
            else:
                print(f"PASS: the {label} gate is signed, reviewed, and evidenced ({matches[-1].name})")

    if failures:
        print()
        for failure in failures:
            print(failure)
        print("\nNO-GO: the run must not start (REF-Delivery.md section 1: every gate is recorded before its phase).")
        return 1

    print(f"\nGO: entry conditions satisfied; execute {_SCRATCH}/handoff.md.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
