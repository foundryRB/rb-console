"""Mechanical exit check for run-delivery-plan.

Refuses (exit 1, one line per failure) when the build reached its
done-definition without landing its durable decisions in `docs/` - the visual
identity as a brand page and the architecture target plus first ADR as an
architecture page or a decisions collection (REF-Delivery.md section 5a) - or
without a passing intent audit (`csd-intent`, the attestation gate: "active and
attested" is the audit's verdict, never a narrated claim, REF-Delivery.md
anti-pattern 22). Prints PASS lines naming where each page resolved, so a
refusal names exactly what remains and a pass names the home it accepted.

The homes are resolved, not hardcoded: `docs/brand.md` and `docs/architecture.md`
in a plain docs folder, and the content root's equivalents when `docs/` is itself
a docs site. See `docs_roots` below for why.

This is the counterpart to preflight.py. Preflight is the ENTRY gate (the
handoff, the signed gates, the locked visual identity are in place before the
build starts); postflight is the EXIT gate (the build's durable outputs reached
their homes before the run may claim done). Landing them is the build's job:
reconcile CONFIRMS these homes (REF-Delivery.md section 6), it does not author
them, so a run that leaves its decisions in the scratch for reconcile to migrate
has not reached its done-definition (REF-Delivery.md anti-pattern 31).

There is deliberately no `docs/quality.md` check: the done-definition and
evidence chain are ephemeral (.delivery/build.md, retired with the line at
reconcile) and
quality bars attest as intent claims (REF-Delivery.md section 4a), so this run's
evidence is never frozen into a maintained page (anti-pattern 13, 31).

The audit's counts are recorded where the delivery analytics read them: when the
installed `csd-intent` emits its machine-readable summary (`csd-intent --json`)
and every maintained spec's audit passes, `attested` and `claims` land in the
build record's frontmatter as `claims_attested:` and `claims_total:`, written
through the record helper (`deliver-engagement/reach_gate.py`, resolved as
`$FC_REACH_HELPER` when a runner baked it in, else from the sibling skill folder),
never by hand (anti-pattern 30). The count is the audit's verdict, not the
gate's: a docs-home failure in the same run still records it. Each maintained
spec counts once, however many audits walked it, and a summary missing for any
spec records nothing. A `csd-intent` that predates the flag (0.6.0 carries it)
records nothing, and this check says so; whatever stops the write is a NOTE, never a failure.

Stdlib only. Usage:

    python postflight.py --repo <repo-root>
"""

from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

if sys.stdout.encoding and sys.stdout.encoding.lower() != "utf-8":
    sys.stdout.reconfigure(encoding="utf-8")

# The minimum body length (characters, frontmatter and whitespace-only lines
# excluded) a durable page must carry to count as landed. A heading-only stub
# (`# Visual Identity` and nothing else) is not a landed durable decision; this
# floor rejects it without grading the page's quality.
_MIN_BODY_CHARS = 100

# `docs/` is a folder of markdown in most app repos and a docs SITE in some (an
# Astro/Starlight app, whose maintained pages live in a content collection). The
# claim this check makes is that the visual identity and the architecture target
# have a durable home in the app's docs - not that two files sit at two literal
# paths. Asserting the paths instead drives a docs-app repo into a shape its
# maintainers then revert: one repo landed the flat files, deleted them as orphans
# once the rendered pages existed, and landed them again on the next delivery line.
# So the home is RESOLVED: the flat path first (unchanged for a plain docs folder),
# then the app's own content root.
_DOCS_DIR = "docs"
_APP_MARKERS = ("package.json", "astro.config.mjs", "astro.config.ts", "astro.config.js")
_CONTENT_ROOTS = ("src/content/docs", "src/content", "content", "src/pages")
_PAGE_SUFFIXES = (".md", ".mdx")


def _body_chars(text: str) -> int:
    """Count of non-whitespace body characters, a leading `--- ... ---`
    frontmatter block excluded, so a page's real content is measured and a stub
    with only frontmatter and a heading does not pass."""
    if text.startswith("---"):
        end = text.find("\n---", 3)
        if end != -1:
            nl = text.find("\n", end + 1)
            text = text[nl + 1:] if nl != -1 else ""
    return sum(len(line.strip()) for line in text.splitlines())


def docs_roots(repo: Path) -> list[tuple[Path, bool]]:
    """The directories a durable page may land in, nearest first, each paired with
    whether it is searched recursively.

    The flat `docs/` folder is checked shallow: `docs/brand.md` is an exact home, and
    walking a docs app's whole tree from there would wander into node_modules. When
    `docs/` carries an app marker it is a docs SITE, so its content root joins the list
    and IS searched recursively - a site nests its pages by section, and
    `src/content/docs/decisions/architecture.md` is as landed as a top-level page.

    A repo may also keep `docs/` as the brand page's plain home while the maintained
    architecture/ADR pages live in a SEPARATE top-level docs app - two homes, both
    real: a plain `docs/` beside a Starlight app named `docs-site/`, a split a
    handoff's own Inputs table calls out explicitly. When `docs/` is not itself that
    app, the other top-level directories are checked, and one qualifies only by
    carrying an app marker AND a content root - a marker with no content is an
    ordinary JS app, never a docs home. An Astro config outranks a bare
    `package.json` for the same reason, and the first qualifier in that order wins.
    """
    docs = repo / _DOCS_DIR
    roots: list[tuple[Path, bool]] = []
    if docs.is_dir():
        roots.append((docs, False))
        if any((docs / marker).is_file() for marker in _APP_MARKERS):
            roots += [(docs / r, True) for r in _CONTENT_ROOTS if (docs / r).is_dir()]
            return roots
    astro_markers = tuple(m for m in _APP_MARKERS if m.startswith("astro.config"))
    candidates = sorted(
        (c for c in repo.iterdir() if c.is_dir() and c != docs),
        key=lambda c: (not any((c / m).is_file() for m in astro_markers), c.name),
    )
    for candidate in candidates:
        if not any((candidate / marker).is_file() for marker in _APP_MARKERS):
            continue
        content = [(candidate / r, True) for r in _CONTENT_ROOTS if (candidate / r).is_dir()]
        if content:
            roots += content
            break
    return roots


def intent_projects(repo: Path) -> list[Path]:
    """Every project root holding a maintained spec, the repo root included when it
    holds one.

    `csd-intent <dir>` asserts an intent.yaml AT that directory, so handing it the
    repo root treats the root as a project needing its own spec - and a multi-domain
    repo (`system/intent.yaml` beside `docs-site/intent.yaml`, deliberately no root
    spec) reports a phantom schema violation for the root while every real project
    underneath audits clean. Auditing each spec at its own root is what the
    multi-domain convention prescribes. Vendored and generated trees are excluded:
    the specs they carry belong to other projects.
    """
    excluded = {"node_modules", ".venv", "venv", "__pycache__", ".git", "dist", "build"}
    return sorted(
        {
            p.parent
            for p in repo.rglob("intent.yaml")
            if not excluded & set(p.relative_to(repo).parts)
        }
    )


def find_page(roots: list[tuple[Path, bool]], stem: str) -> Path | None:
    """The landed page for a durable decision, or None. Every root is tried at its own
    top level before any recursive walk, so a page at the conventional home wins over a
    same-named one buried in a subsection."""
    candidates = [f"{stem}{suffix}" for suffix in _PAGE_SUFFIXES]
    for root, _ in roots:
        for name in candidates:
            if (root / name).is_file():
                return root / name
    for root, recursive in roots:
        if not recursive:
            continue
        for name in candidates:
            found = sorted(root.rglob(name))
            if found:
                return found[0]
    return None


def find_adr_index(roots: list[tuple[Path, bool]]) -> Path | None:
    """The largest decision page of a `decisions/` collection, or None.

    The architecture target and the first ADR land as one page in a plain docs folder;
    a docs site splits them into a decisions section, where no single `architecture.md`
    exists and demanding one would refuse a repo that did the more maintained thing.
    The largest entry stands for the collection at the body-length floor - an empty or
    stub-only section still fails. The collection's index, the page whose filename stem is
    `index` in any case (the ADR bundle's own definition), lists the decisions and is not
    one, so it never stands in for an ADR.
    """
    entries: list[Path] = []
    for root, recursive in roots:
        directory = root / "decisions"
        if directory.is_dir():
            walk = directory.rglob if recursive else directory.glob
            entries += [
                p for s in _PAGE_SUFFIXES for p in walk(f"*{s}") if p.stem.lower() != "index"
            ]
    if not entries:
        return None
    return max(entries, key=lambda p: _body_chars(p.read_text(encoding="utf-8")))


# --- The attestation audit, and the counts it leaves in the record -------------


def _find_cli() -> str | None:
    """The audit CLI on PATH; one seam, so a test can stand a CLI in."""
    return shutil.which("csd-intent")


def _run(command: list[str], repo: Path) -> subprocess.CompletedProcess:
    """Run the audit CLI in the repo; one seam, so a test can stand its output in."""
    return subprocess.run(command, cwd=repo, capture_output=True, text=True, encoding="utf-8")


def audit_command(cli: str, project: str, summary: bool) -> list[str]:
    """The audit invocation: `csd-intent <project>`, with `--json` when the summary is wanted."""
    return [cli, project, "--json"] if summary else [cli, project]


def predates_json(audit: subprocess.CompletedProcess) -> bool:
    """True when the installed csd-intent has no `--json` flag: argparse refuses an
    unknown argument with exit 2 and names it, before any audit runs."""
    return audit.returncode == 2 and "--json" in (audit.stderr or "")


def claims_summary(stdout: str | None) -> dict | None:
    """The object `csd-intent --json` prints, or None when stdout is not one (the human
    report, or nothing at all)."""
    try:
        parsed = json.loads(stdout or "")
    except ValueError:
        return None
    if not isinstance(parsed, dict) or not {"claims", "attested"} <= set(parsed):
        return None
    return parsed


def claim_counts(summaries: list[dict]) -> tuple[int, int]:
    """(attested, total) over the audited specs, each counted once by its `intent_path`.

    An audit handed a root that holds a spec walks the nested specs too, and this gate
    also audits each nested spec at its own root (INT-GATE-011), so one spec can sit in
    two summaries; summing the top-level keys would count it twice. A summary that names
    no projects contributes its own counts once.
    """
    seen: dict[str, tuple[int, int]] = {}
    for index, summary in enumerate(summaries):
        projects = summary.get("projects")
        if not isinstance(projects, list) or not projects:
            seen[f"summary-{index}"] = (int(summary.get("attested", 0)), int(summary.get("claims", 0)))
            continue
        for position, project in enumerate(projects):
            key = str(project.get("intent_path") or f"summary-{index}-{position}")
            seen[key] = (int(project.get("attested", 0)), int(project.get("claims", 0)))
    return sum(a for a, _ in seen.values()), sum(t for _, t in seen.values())


def record_helper() -> Path | None:
    """The record helper, resolved the two ways every phase resolves it: `$FC_REACH_HELPER`
    when a runner baked it in, else the sibling `deliver-engagement` skill folder."""
    baked = os.environ.get("FC_REACH_HELPER", "")
    if baked and Path(baked).is_file():
        return Path(baked)
    sibling = Path(__file__).resolve().parent.parent / "deliver-engagement" / "reach_gate.py"
    return sibling if sibling.is_file() else None


def record_claims(repo: Path, attested: int, total: int) -> str:
    """Write the passing audit's counts into the build record through the record helper,
    never by hand (REF-Delivery.md anti-pattern 30); the line to print.

    The delivery analytics read `claims_attested:` off the record's frontmatter. The
    call is evidence-only (no `--status`), so the record's status carries. Whatever
    stops the write is a NOTE rather than a failure: the gate's verdict is the audit's,
    and a count the record does not carry renders as waiting on a capture, never as a
    wrong number.
    """
    if not (repo / ".delivery" / "build.md").is_file():
        return (
            "NOTE: no .delivery/build.md to record the audit's counts into; open the record "
            "through the record helper first (run-delivery-plan, the record's opening)"
        )
    helper = record_helper()
    if helper is None:
        return (
            "NOTE: the record helper (reach_gate.py) is not resolvable here (no $FC_REACH_HELPER, "
            "no sibling deliver-engagement folder), so the audit's counts are not recorded"
        )
    # The helper runs with cwd=repo and resolves `--repo` against it, so it is handed the
    # ABSOLUTE root: an invoker-relative one (`--repo myrepo` from the parent) would be
    # resolved against the repo a second time, writing a stray `myrepo/myrepo/.delivery/`
    # record while the real one stays blank and this check reports a write that never
    # happened (the audit CLI's argument carries the same trap, above).
    written = subprocess.run(
        [
            sys.executable, str(helper), "--repo", str(repo.resolve()), "--record", "build.md",
            "--phase", "build+ship", "--skill", "run-delivery-plan", "--gate", "delivery",
            "--claims-attested", str(attested), "--claims-total", str(total),
        ],
        cwd=repo, capture_output=True, text=True, encoding="utf-8",
    )
    if written.returncode != 0:
        detail = ((written.stdout or "") + (written.stderr or "")).strip().splitlines()
        reason = detail[-1] if detail else f"exit {written.returncode}"
        return (
            f"NOTE: the record helper declined to record the audit's counts ({reason}); a "
            "helper that does not take --claims-attested is a vendored pin awaiting its refresh"
        )
    return (
        f"PASS: recorded claims_attested: {attested}, claims_total: {total} in "
        ".delivery/build.md through the record helper"
    )


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--repo", required=True, help="Delivery repo root (holds docs/ and intent.yaml)"
    )
    args = parser.parse_args()

    repo = Path(args.repo)
    failures: list[str] = []

    if not repo.is_dir():
        print(f"FAIL: repo root not found: {repo}")
        return 1

    roots = docs_roots(repo)
    searched = ", ".join(str(root.relative_to(repo).as_posix()) for root, _ in roots) or "docs/"

    # The two durable decisions the build must land before done (REF-Delivery.md
    # section 1 "What survives", section 5a), each named by what it holds so a refusal
    # points at the source the build already has in hand.
    for label, holds, page, note in (
        (
            "the visual identity",
            "the visual identity (from .delivery/design.md)",
            find_page(roots, "brand"),
            "",
        ),
        (
            "the architecture target and first ADR",
            "the architecture target and first ADR (from the handoff)",
            find_page(roots, "architecture") or find_adr_index(roots),
            "; a decisions collection's index page lists decisions and is not an ADR",
        ),
    ):
        if page is None:
            failures.append(
                f"FAIL: no home for {label} - the build did not land {holds} "
                f"(searched {searched}{note}; REF-Delivery.md section 5a; reconcile confirms "
                "this home, it does not author it)"
            )
            continue
        rel = page.relative_to(repo).as_posix()
        chars = _body_chars(page.read_text(encoding="utf-8"))
        if chars < _MIN_BODY_CHARS:
            failures.append(
                f"FAIL: {rel} is a stub ({chars} body chars < {_MIN_BODY_CHARS}) - "
                f"it must carry {holds}"
            )
        else:
            print(f"PASS: a home for {label} at {rel} ({chars} body chars)")

    # The attestation gate (REF-Delivery.md anti-pattern 22): a claim is "active and
    # attested" only when the mechanical audit says so, here, at the exit - never in a
    # later CI stage the run itself may skip, and never as the run's own narration.
    cli = _find_cli()
    if cli is None:
        failures.append(
            "FAIL: csd-intent not found on PATH - the attestation gate cannot run, so "
            "'all claims active and attested' cannot be claimed (REF-Delivery.md anti-pattern 22); "
            "install the csd-intent CLI and re-run"
        )
    else:
        # One audit per maintained spec, each at its own project root: `csd-intent .`
        # asserts a spec AT the root, which a multi-domain repo deliberately does not
        # keep (see intent_projects).
        projects = intent_projects(repo)
        if not projects:
            failures.append(
                "FAIL: no intent.yaml found anywhere in the repo - the attestation gate "
                "has nothing to audit, so 'all claims active and attested' cannot be "
                "claimed (REF-Delivery.md anti-pattern 22)"
            )
        # The audit is asked for its machine-readable summary, whose counts the record
        # takes; the exit code follows --fail-on either way, so one run gates and counts.
        summaries: list[dict] = []
        with_summary = True
        audits_passed = True
        for project in projects:
            # The child resolves its argument against cwd=repo, so it is handed the
            # repo-relative path: an invoker-relative one would be resolved against the
            # repo a second time, doubling the path whenever --repo is itself relative.
            rel = project.relative_to(repo).as_posix()
            audit = _run(audit_command(cli, rel, summary=with_summary), repo)
            if with_summary and predates_json(audit):
                # An older csd-intent: the gate runs on the human report as before, and
                # the counts go unrecorded - said once, here, so a record carrying none
                # reads as a CLI that could not say rather than a gate that forgot.
                with_summary = False
                print(
                    "NOTE: the installed csd-intent predates --json, so the audit's counts "
                    "(claims_attested, claims_total) are not recorded in the record; upgrade "
                    "to csd-intent >= 0.6.0, the release carrying the flag, to record them"
                )
                audit = _run(audit_command(cli, rel, summary=False), repo)
            summary = claims_summary(audit.stdout) if with_summary else None
            if audit.returncode == 0:
                if summary is not None:
                    line = (
                        f"{summary['claims']} claims, {summary['attested']} attested, "
                        f"{summary.get('violations', 0)} violation(s)"
                    )
                    vacuous = int(summary["claims"]) == 0
                    summaries.append(summary)
                else:
                    tail = (audit.stdout or "").strip().splitlines()
                    line = tail[-1] if tail else "csd-intent exit 0"
                    vacuous = "0 claims" in line
                # A clean audit over zero claims is vacuous: a delivery with no claims
                # has no attestable done-definition (REF-Delivery.md section 4a).
                if vacuous:
                    audits_passed = False
                    failures.append(
                        f"FAIL: the intent audit at {rel} is clean but vacuous ({line}) - "
                        "the spec holds zero claims, so nothing attests the delivery "
                        "(REF-Delivery.md section 4a)"
                    )
                else:
                    print(f"PASS: intent audit clean at {rel} ({line})")
            else:
                audits_passed = False
                if summary is not None:
                    # The object carries counts, not the report's per-violation lines,
                    # so a refusal is re-read as the report the operator fixes from.
                    audit = _run(audit_command(cli, rel, summary=False), repo)
                detail = ((audit.stdout or "") + (audit.stderr or "")).strip().splitlines()
                failures.append(
                    f"FAIL: the intent audit at {rel} refuses (csd-intent exit "
                    f"{audit.returncode}: {detail[-1] if detail else 'no output'}) - "
                    "fix the claims or their tests before claiming done (REF-Delivery.md section 5a)"
                )
        # The counts are the audit's verdict, not the gate's: they are recorded when every
        # spec's audit passed, whatever the docs-home checks above found (a docs NO-GO is
        # fixed and re-run, and the re-run records the same numbers). A refused audit
        # records nothing, and so does a summary missing for any spec, since a count
        # over some of the specs would read as the count over all of them.
        if audits_passed and summaries and len(summaries) < len(projects):
            print(
                f"NOTE: the audit's summary was read for {len(summaries)} of {len(projects)} "
                "specs, so the counts are not recorded; a partial count would read as the whole"
            )
        elif audits_passed and summaries:
            attested, total = claim_counts(summaries)
            print(record_claims(repo, attested, total))

    if failures:
        print()
        for failure in failures:
            print(failure)
        print(
            "\nNO-GO: the build has not reached its done-definition "
            "(REF-Delivery.md section 5a: the durable decisions are landed in docs/ by the build, "
            "not backfilled by reconcile)."
        )
        return 1

    print("\nGO: the durable decisions are landed in docs/; the build may claim its done-definition.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
