"""Close the design gate: lock the visual identity into the delivery scratch, stamp it.

Given the delivery repo and the customer's picks from the live session, this:
  1. obtains the prototype project's chosen theme tokens (whatever palette the
     customer settled on and the operator saved) - via `--tokens-file` (the tokens
     the caller already fetched over the Protopane MCP `get_project` tool, the door
     a non-interactive agent speaks), or, failing that, a direct `GET /api` fetch
     for a Basic-auth or local instance,
  2. writes them, with the logo and typography, into
     `.delivery/design.md` (the committed delivery scratch): the design phase's
     record, holding the locked visual identity (REF-Delivery.md section 3).
     The build lands it into the app's docs/; reconcile confirms it there and
     closes the line, its records retained behind the delivered tag, so nothing
     ephemeral is maintained,
  3. writes the record's frontmatter block (the closed, flat REF-Delivery.md section 1
     schema) with `signed: pending`, and under `--date` runs the gate stamp over it:
     deliver-engagement/stamp_gate.py, the single gate stamper, resolved as
     `$FC_STAMP_HELPER` when a runner baked it in, else from the sibling skill folder,
so a fresh agent can close the gate with none of this session's context. Refuses
if it cannot obtain the theme or if ANY design.md already exists, signed or not:
the body is fully REGENERATED from the template and the flags on every run, never
merged, so every content flag must be passed again on a re-run and an existing
record is only ever overwritten through an explicit delete. It never records an
approval it could not populate.

The gate's state lives in the frontmatter `signed:` field, and only there
(REF-Delivery.md section 1, anti-pattern 24: the frontmatter beats the prose), and
stamp_gate.py is its only writer, in any mode (anti-pattern 30). Under `--date`
(interaction=manual) this helper hands the stamp the customer's approval date and
signer, the review's `--review-verdict pass` and `--review-log`, and the signer's
`--outcome` when stated; the stamp writes `signed:`, `signed_at:`, `outcome:` and
`reviewed:`, promotes the status, fills `finished:`, and freezes the prototype's
screens and theme into the scratch (the gate export). A refused stamp leaves no
record behind: this helper removes what it wrote and surfaces the refusal. Under
`--auto` (interaction=auto, a pod) it writes `signed: pending` and stops; the
one-shot engine runs the same stamp over the phase's fresh-eyes review. This helper
is design's composition of the transaction: the identity lock plus the canonical
record block, then the stamp.

The scratch is the line's committed worktree (REF-Delivery.md section 1): the
record is committed on the delivery/<line-id> branch so a cancelled run resumes
by reading which records exist, and reconcile closes the line at the end.

The logo is the tell: a delivery that locks no logo has skipped this step
(REF-Delivery.md section 3). --logo is required and must name an existing,
repo-committed asset; the helper refuses to close without it. An asset is
always producible in-phase (the logo ladder in this skill): worst case, the
deterministic wordmark helper beside this script (make_wordmark.py) renders
one from the app name and the theme tokens, so the refusal never stalls a run.

Stdlib only. Usage:

    # interaction=auto (a pod): tokens fetched over the MCP, engine stamps the gate
    python close_gate.py --repo <repo-root> --layout "cartoes" --auto \
        --tokens-file theme.json --logo docs/logo.svg [--project-slug <slug>]

    # interaction=manual: the review passed, then the customer approved live
    PROTOPANE_AUTH_USER=... PROTOPANE_AUTH_PASSWORD=... \
    python close_gate.py --repo <repo-root> --layout "cartoes" \
        --date 2026-07-11 --by "the customer" --review-verdict pass \
        --review-log .delivery/reviews/design-2026-07-11-r1.md \
        --logo docs/logo.svg [--outcome "with edits"] \
        [--tokens-file theme.json] [--export-file export.json] [--project-slug <slug>] \
        [--base-url https://...]

    # a headless line (surface: none on the proposal record): no prototype at all;
    # the tokens file is a vendored design system's theme, the logo by its ladder
    python close_gate.py --repo <repo-root> --layout "docs site" --no-prototype \
        --tokens-file theme.json --logo docs/logo.svg [--auto | --date ... --by ... \
        --review-verdict pass --review-log ...]
"""

from __future__ import annotations

import argparse
import base64
import json
import os
import re
import shutil
import subprocess
import sys
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

if sys.stdout.encoding and sys.stdout.encoding.lower() != "utf-8":
    sys.stdout.reconfigure(encoding="utf-8")

_DATE = re.compile(r"^\d{4}-\d{2}-\d{2}$")
_SCRATCH_DIRNAME = ".delivery"
_IDENTITY_NAME = "design.md"
_FONT_PREFIX = "--font"


def _stamp_helper() -> Path | None:
    """The gate stamp, resolved the two ways every phase resolves a lifecycle helper
    (REF-Delivery.md anti-pattern 30, run the true helper): `$FC_STAMP_HELPER` when a
    runner baked it in, else the sibling `deliver-engagement` skill folder."""
    baked = os.environ.get("FC_STAMP_HELPER", "")
    if baked and Path(baked).is_file():
        return Path(baked)
    sibling = Path(__file__).resolve().parent.parent / "deliver-engagement" / "stamp_gate.py"
    return sibling if sibling.is_file() else None


def _scratch_refusal(repo: Path) -> str | None:
    """The refusal line when the delivery scratch or its journal is absent, or None. The
    close writes into the scratch and never mints it: `.delivery/` is the line's worktree,
    mounted by establish_scratch.py (REF-Delivery.md section 1, anti-pattern 30), and its
    journal is a phase-exit obligation every gate helper enforces before it writes
    anything, in both modes (REF-Delivery.md section 1; INT-GATE-004)."""
    scratch = repo / _SCRATCH_DIRNAME
    if not scratch.is_dir():
        return (
            f"REFUSED: no {_SCRATCH_DIRNAME}/ at {repo}. The scratch is the line's worktree, "
            "mounted by establish_scratch.py (REF-Delivery.md section 1); a gate helper writes "
            "into it and never creates it. Mount the line and re-run."
        )
    if not (scratch / "journal.md").is_file():
        return (
            f"REFUSED: no {_SCRATCH_DIRNAME}/journal.md. Every phase logs its lessons, defects "
            "and sentiment as they happen (REF-Delivery.md section 1); a phase with nothing to "
            "report still leaves the file, with an entry saying so. Write this phase's entry, "
            "commit it, and re-run."
        )
    return None


def _signed_is_date(text: str) -> bool:
    """True when the record's leading frontmatter carries a dated `signed:` field: an
    already-locked identity (REF-Delivery.md section 1). Reads only the frontmatter,
    the authoritative gate state (anti-pattern 24); the body's prose is never the gate."""
    if not text.startswith("---"):
        return False
    end = text.find("\n---", 3)
    front = text[3:end] if end != -1 else text[3:]
    for line in front.splitlines():
        m = re.match(r"^\s*signed\s*:\s*(.*?)\s*$", line, re.IGNORECASE)
        if m:
            return bool(_DATE.match(m.group(1).strip().strip('"').strip("'")))
    return False


def _tokens_from_payload(data: dict) -> dict[str, str]:
    """Pull the token map out of whatever shape the caller handed us: a full project
    (`{"theme": {"tokens": {...}}}`), a theme (`{"tokens": {...}}`), or a flat token
    map (`{"--primary": "...", ...}`)."""
    if isinstance(data.get("theme"), dict) and isinstance(data["theme"].get("tokens"), dict):
        return dict(data["theme"]["tokens"])
    if isinstance(data.get("tokens"), dict):
        return dict(data["tokens"])
    if data and all(isinstance(k, str) and k.startswith("-") for k in data):
        return dict(data)
    return {}


def _load_tokens_file(path: str) -> dict[str, str]:
    """Load theme tokens from a JSON file the caller fetched over the Protopane MCP
    `get_project` tool (the door a non-interactive agent speaks; REF-MCP.md
    section 7). This is the OIDC-safe path: it touches no HTTP endpoint, so the
    instance's browser-SSO wall on `/api` never applies."""
    payload = json.loads(Path(path).read_text(encoding="utf-8"))
    return _tokens_from_payload(payload)


def _fetch_theme(base_url: str, slug: str, user: str, password: str) -> dict[str, str]:
    """Fetch theme tokens over the instance's HTTP `/api` door with Basic auth.

    Works for a local or Basic-gated instance. On a deployed, Keycloak-gated instance
    `/api` is browser-SSO only (it answers a non-interactive Basic request with an
    HTML login page or a redirect to the identity provider, never JSON); detect that
    and fail with a message that points at the `--tokens-file` / MCP door, rather than
    letting a JSON parse error bury the real cause.
    """
    req = urllib.request.Request(f"{base_url}/api/projects/{slug}", method="GET")
    token = base64.b64encode(f"{user}:{password}".encode()).decode()
    req.add_header("Authorization", f"Basic {token}")
    req.add_header("Accept", "application/json")
    req.add_header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) DesignClose/1.0")
    with urllib.request.urlopen(req, timeout=30) as resp:
        final_url = resp.geturl()
        content_type = (resp.headers.get("Content-Type") or "").lower()
        raw = resp.read().decode("utf-8", "replace")
    # A browser-SSO wall answers with HTML (a login page) or has redirected us off
    # the API host to the identity provider - either way, not the project JSON.
    looks_like_html = raw.lstrip()[:1] == "<" or "text/html" in content_type
    redirected_away = base_url.split("://", 1)[-1].split("/", 1)[0] not in final_url
    if looks_like_html or redirected_away or "application/json" not in content_type:
        raise RuntimeError(
            f"`GET {base_url}/api/projects/{slug}` did not return JSON "
            f"(content-type {content_type or 'unknown'}, landed at {final_url}). "
            "This instance is almost certainly Keycloak/OIDC-gated, so `/api` is a "
            "browser-login door and a non-interactive Basic request cannot pass it. "
            "Fetch the theme over the Protopane MCP `get_project` tool (the machine "
            "door, same credentials; REF-MCP.md section 7) and pass it with "
            "--tokens-file, or point --base-url at a Basic-auth/local instance."
        )
    return _tokens_from_payload(json.loads(raw))


def _frontmatter(
    status: str,
    signed: str,
    reviewed: str,
    run: str,
    attempt: int,
    mode: str,
    started: str,
    credential_ref: str,
) -> str:
    """The REF-Delivery.md section 1 record frontmatter for the design gate: the closed,
    flat key/value block the resolver and the run's pre-flight read gate state from.
    The record reaches the gate as `status: gate` / `signed: pending`, with `reviewed:`
    and `finished:` empty, in both modes; the stamp (stamp_gate.py) is the one writer of
    the closure: it records the review, writes `signed:` with `signed_at:` and
    `outcome:`, promotes the status to `complete`, and fills `finished:`. Under `--date`
    this helper runs the stamp itself; under `--auto` the one-shot engine runs it.
    """
    return (
        "---\n"
        "phase: design\n"
        "skill: design-session\n"
        f"status: {status}\n"
        "gate: design\n"
        f"signed: {signed}\n"
        f"reviewed: {reviewed}\n"
        f"run: {run}\n"
        f"attempt: {attempt}\n"
        f"mode: {mode}\n"
        f"started: {started}\n"
        "finished: \n"
        f"credential_ref: {credential_ref}\n"
        "---\n\n"
    )


def _identity_markdown(
    app: str,
    tokens: dict[str, str],
    logo: str,
    layout: str,
    date: str | None,
    by: str,
    base_url: str,
    slug: str,
    front: str,
    auto: bool = False,
    art_direction: str | None = None,
    interaction_model: str | None = None,
    accessibility: str | None = None,
    no_prototype: bool = False,
) -> str:
    palette = {k: v for k, v in tokens.items() if not k.startswith(_FONT_PREFIX)}
    fonts = {k: v for k, v in tokens.items() if k.startswith(_FONT_PREFIX)}

    css_lines = "\n".join(f"    {k}: {v.strip()};" for k, v in palette.items())
    css = ":root {\n" + css_lines + "\n}" if palette else "(no palette tokens returned)"

    if fonts:
        type_block = "\n".join(f"- `{k}`: {v.strip()}" for k, v in fonts.items())
        type_block += (
            "\n\nThe docs site renders the pinned face"
            if no_prototype
            else "\n\nThe prototype renders system stacks"
        ) + (
            ". Any brand webfont (a curated display or body face) is pinned here and "
            "self-hosted at build, never a CDN."
        )
    else:
        type_block = (
            "- Display: <brand display face, self-hosted at build>\n"
            "- Body: <brand body face, self-hosted at build>\n\n"
            + ("The tokens file" if no_prototype else "The prototype")
            + " carried no font tokens; pin the brand faces here."
        )

    logo_block = f"`{logo}` (committed asset; the build lands it into docs/ as the app's logo)"
    theme_home = "the docs theme tokens" if no_prototype else "the frontend theme tokens"

    if auto:
        approval_line = (
            "- Design approved: the design gate closes over this phase's fresh-eyes "
            "review, not a live approval (interaction=auto); the frontmatter `signed:` "
            "field above is the authoritative gate state (REF-Delivery.md section 1). "
            "The look is validated at the delivery gate (REF-Delivery.md section 1); the "
            "customer's acceptance follows the close.\n"
        )
    else:
        where = (
            "over the docs identity locked without a session (a headless line)"
            if no_prototype
            else "in the live design session"
        )
        approval_line = (
            f"- Design approved: {date} - approved by {by} {where}, "
            "over the phase's passing fresh-eyes review (both recorded in the frontmatter "
            "`signed:` and `reviewed:` fields above, the authoritative gate state; "
            "REF-Delivery.md section 1)\n"
        )

    # The closure line at the TOP of the body is the stamp's (anti-pattern 24: the stamp
    # creates the contradiction with the prose below, so the stamp reconciles it).
    return (
        front
        + f"# Design - {app}\n\n"
        + ("Prototype: none\n\n" if no_prototype else "")
        + "The design phase's record: the locked visual identity, the one design artifact "
        "that survives (REF-Delivery.md section 3). The design phase locks it here in the "
        "committed delivery scratch; the build lands it into the app's `docs/` (a brand "
        f"page, the committed logo asset, and these values as {theme_home}); "
        "reconcile confirms it in `docs/` and closes the line, the records staying "
        "readable behind the delivered tag. `docs/` is its durable "
        "home; do not maintain this scratch copy.\n\n"
        "## Logo\n\n"
        f"{logo_block}\n\n"
        "## Colour scheme\n\n"
        "```css\n"
        f"{css}\n"
        "```\n\n"
        "## Typography\n\n"
        f"{type_block}\n\n"
        "## Art direction\n\n"
        f"{art_direction or '<the phase replaces this line: one falsifiable paragraph that guides the build (REF-Delivery.md section 3)>'}\n\n"
        "## Interaction model\n\n"
        f"{interaction_model or '<the phase replaces this line: what is clickable, what happens, what is out of scope - the prototype cannot show state>'}\n\n"
        "## Accessibility\n\n"
        f"{accessibility or '<the phase replaces this line: the bar the build must meet - WCAG 2.2 AA unless a deviation is recorded with its criterion, reason and what the user does instead (REF-Accessibility.md section 1); the validated contrast pair of every token in both appearances (section 7 there); the owner and cadence of the manual keyboard, screen-reader, zoom and forced-colours passes (section 10 there)>'}\n\n"
        "## Design approval (the design gate, REF-Delivery.md section 1)\n\n"
        f"{approval_line}"
        f"- Approved layout: {layout}\n"
        + (
            "- Prototype: none (a headless line: no screens; the docs site is the only DOM "
            "surface this identity governs)\n"
            if no_prototype
            else (
                f"- Prototype (legacy reference, kept live): {base_url}/p/{slug}; read its "
                f"screens later via the Protopane MCP ({base_url}/mcp) or "
                f"`GET {base_url}/api/projects/{slug}`, credentials from the environment "
                "(the protopane door's guide). The MCP/deployed instance is the door, never a "
                "local clone.\n"
            )
        )
    )


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", required=True, help="Delivery repo root")
    parser.add_argument("--layout", required=True, help="The layout chosen, e.g. a page name")
    parser.add_argument("--date", help="Approval date, YYYY-MM-DD (required unless --auto)")
    parser.add_argument("--by", default="the customer", help="Who approved, for the record")
    parser.add_argument(
        "--auto",
        action="store_true",
        help="interaction=auto (a pod, no customer): lock the identity and write "
        "`signed: pending`, leaving the design gate for the one-shot engine to stamp "
        "over the phase's fresh-eyes review (REF-Delivery.md section 1); --date and "
        "--by are not used.",
    )
    parser.add_argument(
        "--review-verdict",
        help="The design phase's fresh-eyes review verdict. Required (and only 'pass' "
        "closes) with --date: every gate closes over its recorded review "
        "(REF-Delivery.md section 1). Not used with --auto, where the engine's stamp "
        "records it.",
    )
    parser.add_argument(
        "--review-log",
        help="Repo-relative path of the committed review artifact: the fresh-eyes review's "
        "verbatim output (conventionally .delivery/reviews/design-<date>-r<N>.md). Required "
        "with --date; the helper reads the file's LAST VERDICT token, so the claimed "
        "verdict and the on-disk evidence cannot disagree. Not used with --auto.",
    )
    parser.add_argument(
        "--outcome",
        help="How the gate closed, handed to the stamp: exactly one of 'as it stood', "
        "'with edits', 're-driven'. Omitted, the stamp derives it from the record and its "
        "committed review rounds; 'with edits' is only ever the signer's word. Not used "
        "with --auto, where the engine's stamp decides it.",
    )
    parser.add_argument(
        "--logo",
        required=True,
        help="Repo-relative path to the locked logo asset. Required: the design phase "
        "produces the logo (REF-Delivery.md section 3); when none was handed in, "
        "generate the wordmark floor with make_wordmark.py (this folder) first.",
    )
    parser.add_argument(
        "--art-direction",
        help="One falsifiable paragraph guiding the build (REF-Delivery.md section 3); "
        "absent, the record carries a replace-me line the phase must fill before review.",
    )
    parser.add_argument(
        "--interaction-model",
        help="What is clickable, what happens, what is out of scope; absent, the record "
        "carries a replace-me line the phase must fill before review.",
    )
    parser.add_argument(
        "--accessibility",
        help="The bar the build must meet: WCAG 2.2 AA or a recorded deviation, the token "
        "contrast pairs, and the owner of the manual passes (REF-Accessibility.md); absent, "
        "the record carries a replace-me line the phase must fill before review.",
    )
    parser.add_argument("--project-slug", help="Prototype project slug, also the record's app name (default: repo folder name)")
    parser.add_argument(
        "--no-prototype",
        action="store_true",
        help="The line has no prototype (a headless line, `surface: none` on the proposal "
        "record; REF-Delivery.md section 3): the record carries `Prototype: none` in place "
        "of the pointer, so the stamp freezes no screens, and the identity is locked from "
        "--tokens-file (a vendored design system's theme), which is then required.",
    )
    parser.add_argument(
        "--tokens-file",
        help="JSON file of theme tokens the caller fetched over the Protopane MCP "
        "`get_project` tool (a full project, a theme, or a flat token map). The "
        "OIDC-safe door: preferred whenever the instance is Keycloak-gated.",
    )
    parser.add_argument(
        "--export-file",
        help="JSON file of the prototype's export_project DTO, fetched over the "
        "Protopane MCP: the gate export's OIDC-safe door, pairing with "
        "--tokens-file whenever the instance's /api is browser-gated.",
    )
    parser.add_argument(
        "--base-url",
        default=os.environ.get("PROTOPANE_BASE_URL", "https://protopane.example.invalid"),
    )
    # Record-frontmatter provenance (REF-Delivery.md section 1). The launcher/skill knows
    # the real run context and passes it; the defaults keep a bare invocation honest.
    parser.add_argument("--run", default="", help="Opaque run id for the record frontmatter")
    parser.add_argument("--attempt", type=int, default=1, help="1-based attempt for the frontmatter")
    parser.add_argument(
        "--mode",
        choices=("interactive", "one-shot"),
        help="Run mode for the frontmatter (default: one-shot with --auto, else interactive)",
    )
    parser.add_argument(
        "--credential-ref",
        default="protopane (from environment)",
        help="Citation of the driving credential (never the secret value) for the frontmatter",
    )
    parser.add_argument("--started", help="ISO start timestamp for the frontmatter (default: now)")
    args = parser.parse_args()

    if not args.auto and (not args.date or not _DATE.match(args.date)):
        print(f"FAIL: --date must be YYYY-MM-DD (or pass --auto), got {args.date!r}")
        return 1
    if not args.auto:
        verdict = (args.review_verdict or "").strip().lower()
        if verdict not in ("pass", "passed"):
            print(
                "REFUSED: a manual close signs the design gate, and a gate closes only over "
                "its passing fresh-eyes review (REF-Delivery.md section 1). Run the "
                "adversarial-review skill (kind=design), then pass --review-verdict pass; "
                "a failing review is re-driven, never signed over."
            )
            return 1
    if args.auto and args.outcome is not None:
        print(
            "REFUSED: --outcome is the signer's word at the stamp; under --auto the engine's "
            "stamp decides it. Nothing is recorded."
        )
        return 1
    if args.no_prototype and not args.tokens_file:
        print(
            "REFUSED: --no-prototype locks the identity from a tokens file (a vendored design "
            "system's theme, REF-Design.md section 5), so --tokens-file is required; there "
            "is no prototype to fetch a theme from. Nothing is recorded."
        )
        return 1
    repo = Path(args.repo)
    if not repo.is_dir():
        print(f"FAIL: repo root not found: {repo}")
        return 1
    scratch_refusal = _scratch_refusal(repo)
    if scratch_refusal:
        print(scratch_refusal)
        return 1
    stamp = None
    if not args.auto:
        stamp = _stamp_helper()
        if stamp is None:
            print(
                "REFUSED: the gate stamp (stamp_gate.py) is not resolvable here: no "
                "$FC_STAMP_HELPER, and no sibling deliver-engagement skill folder. A manual "
                "close runs the stamp over the record it writes (REF-Delivery.md section 1, "
                "anti-pattern 30); install the deliver-engagement skill beside this one, or "
                "set FC_STAMP_HELPER to the stamp. Nothing is recorded."
            )
            return 1
    if not (repo / args.logo).is_file():
        print(
            f"REFUSED: --logo {args.logo!r} not found under {repo}. The design phase "
            "produces the logo (REF-Delivery.md section 3): use the handed-in asset, an "
            "authored SVG candidate, or generate the deterministic wordmark floor: "
            'python make_wordmark.py --name "<display name>" --tokens-file theme.json '
            f"--out {args.logo}"
        )
        return 1
    # A manual close signs in the same transaction (the stamp runs right after this
    # write), AFTER its fresh-eyes review - so a placeholder it writes here is one no
    # downstream chokepoint will ever read.
    # Under --auto the review reads the finished record before the engine stamps, so
    # the placeholders may stand for it to catch; a manual close has nothing after it,
    # and a real record shipped signed over three unfilled replace-me lines.
    if not args.auto:
        missing = [
            flag
            for flag, value in (
                ("--art-direction", args.art_direction),
                ("--interaction-model", args.interaction_model),
                ("--accessibility", args.accessibility),
            )
            if not (value or "").strip()
        ]
        if missing:
            print(
                "REFUSED: a manual close signs the record it writes, and a signed visual "
                "identity carries its three prose sections, not replace-me placeholders "
                f"(REF-Delivery.md section 3): pass {', '.join(missing)}. The body is "
                "fully regenerated from the flags on every run, so a flag set on a prior "
                "run must be passed again on this one."
            )
            return 1
    scratch = repo / _SCRATCH_DIRNAME
    identity_path = scratch / _IDENTITY_NAME
    if identity_path.is_file():
        if _signed_is_date(identity_path.read_text(encoding="utf-8")):
            print(f"FAIL: visual identity already locked and signed at {identity_path} (delete it to re-lock).")
            return 1
        # The body is fully regenerated from the template and the flags - never merged -
        # so overwriting an existing record silently discards whatever its body carries
        # beyond this invocation's flags. A real re-run missing three flags replaced
        # drafted prose with placeholders and dropped a hand-written prototype-pointer
        # fix, exit 0, caught only by a close reading of the output. The discard is
        # authorized by the delete, the explicit act the signed guard already speaks -
        # deliberately not a --force flag, which a launcher template would cargo-cult
        # into every invocation until the guard gated nothing.
        print(
            f"REFUSED: {identity_path} already exists (unsigned). This helper fully "
            "regenerates the record body from its template and flags - it never merges - "
            "so re-closing would silently discard whatever the existing body carries "
            "beyond this invocation's flags. Carry its content into the flags "
            "(--art-direction, --interaction-model, --accessibility, --project-slug, "
            "--layout, --logo), then delete the record and re-run: the deletion is the "
            "explicit act that authorizes the discard."
        )
        return 1

    slug = args.project_slug or repo.resolve().name

    # Obtain the theme tokens: the --tokens-file door first (OIDC-safe, MCP-fetched),
    # else the HTTP /api fetch (local or Basic-gated instances).
    try:
        if args.tokens_file:
            tokens = _load_tokens_file(args.tokens_file)
            source = f"--tokens-file {args.tokens_file}"
        else:
            user = os.environ.get("PROTOPANE_AUTH_USER")
            password = os.environ.get("PROTOPANE_AUTH_PASSWORD")
            if not user or not password:
                print(
                    "FAIL: no --tokens-file, and PROTOPANE_AUTH_USER / PROTOPANE_AUTH_PASSWORD "
                    "are unset for the /api fetch. On a Keycloak-gated instance, fetch the theme "
                    "over the Protopane MCP `get_project` tool and pass --tokens-file."
                )
                return 1
            tokens = _fetch_theme(args.base_url, slug, user, password)
            source = f"GET {args.base_url}/api/projects/{slug}"
    except Exception as exc:  # noqa: BLE001 - report any fetch failure plainly
        print(f"FAIL: could not obtain theme tokens for project {slug!r}: {exc}")
        return 1
    if not tokens:
        print(f"FAIL: no theme tokens for project {slug!r} (source: {source})")
        return 1

    # The record reaches the gate as `status: gate` / `signed: pending` in both modes;
    # the stamp promotes it, and the gate export (the prototype's screens and theme,
    # Phases and Artifacts principle 02) is the stamp's, the signature moment.
    mode = args.mode or ("one-shot" if args.auto else "interactive")
    started = args.started or datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    front = _frontmatter(
        "gate", "pending", "", args.run, args.attempt, mode, started, args.credential_ref
    )

    identity_path.write_text(
        _identity_markdown(
            slug, tokens, args.logo, args.layout, args.date, args.by,
            args.base_url, slug, front, args.auto,
            art_direction=args.art_direction,
            interaction_model=args.interaction_model,
            accessibility=args.accessibility,
            no_prototype=args.no_prototype,
        ),
        encoding="utf-8",
    )

    if not args.auto:
        # The stamp: the one writer of the closure, run over the record just written. It
        # exports the prototype (the MCP-door DTO when the caller fetched one, else the
        # instance's /api by slug), then signs. A refusal leaves nothing behind: the
        # record goes, and an export folder this run created goes with it.
        design_dir = scratch / "design"
        design_dir_existed = design_dir.exists()
        command = [
            sys.executable, str(stamp), "--repo", str(repo), "--record", _IDENTITY_NAME,
            "--date", args.date, "--by", args.by, "--review-verdict", "pass",
        ]
        if args.review_log:
            command += ["--review-log", args.review_log]
        if args.outcome is not None:
            command += ["--outcome", args.outcome]
        if args.export_file and not args.no_prototype:
            command += ["--tool-export", args.export_file, "--tool-slug", slug]
        elif not args.no_prototype:
            command += ["--tool-url", args.base_url, "--tool-slug", slug]
        stamped = None
        try:
            stamped = subprocess.run(
                command, capture_output=True, text=True, encoding="utf-8", errors="replace"
            )
            sys.stdout.write(stamped.stdout or "")
            sys.stderr.write(stamped.stderr or "")
        finally:
            # Whatever happens to the stamp, a record it did not sign does not stay.
            if stamped is None or stamped.returncode != 0:
                identity_path.unlink(missing_ok=True)
                if not design_dir_existed:
                    shutil.rmtree(design_dir, ignore_errors=True)
        if stamped.returncode != 0:
            print(
                "REFUSED: the gate stamp refused (above), so the design record it would have "
                "signed was not kept; nothing is left behind. Resolve what the refusal names "
                "and re-run the close. Where it names the stamp's --tool-export or "
                "--tool-url/--tool-slug, this helper's flags are --export-file and "
                "--base-url/--project-slug."
            )
            return 1

    palette_count = sum(1 for k in tokens if not k.startswith(_FONT_PREFIX))
    print(f"Design gate closed for {slug}.")
    print(f"  design record written: {identity_path}")
    print(f"  theme source: {source}")
    print(f"  palette tokens captured: {palette_count}")
    print(f"  logo: {args.logo}")
    print(f"  approved layout: {args.layout}")
    if args.auto:
        print("  gate: signed: pending (interaction=auto; the engine stamps the date over the fresh-eyes review)")
    else:
        print(f"  gate: stamped by stamp_gate.py over the review (signed: {args.date} by {args.by})")
    print("\nCommit and push the scratch record. The run's pre-flight and the engine's")
    print("stamper both read the frontmatter `signed:` field from the pushed record.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
