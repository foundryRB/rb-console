"""Generate the deliberate-wordmark logo floor: a deterministic SVG from the theme tokens.

The bottom rung of the design phase's logo ladder (the design-session skill;
REF-Delivery.md section 3): when no logo was handed in and no candidate was
authored, this renders the app's display name as a wordmark SVG using the
locked visual identity's own tokens - the badge in `--primary` carrying the
initial in `--primary-foreground`, the name in `--foreground`, the typeface
from `--font-sans` - so the asset derives from the identity instead of
inventing a look, and a gate-satisfying logo exists with no model, no design
tool, and no human in the loop. close_gate.py refuses to close the design gate
without a logo asset; this helper is why that refusal can never stall a run.

Deterministic: the same inputs produce byte-identical output (no timestamps,
no randomness), so a re-run never churns the committed asset. The SVG carries
resolved literal colours on purpose: a committed brand asset is the *product*
of the tokens, not prototype markup, so the token-discipline write gate
(REF-Design.md section 2) does not apply to it.

Fonts: the wordmark names the theme's font stack and falls back through it;
the build self-hosts any brand webfont beside the asset (the visual-identity
contract, REF-Delivery.md section 3), and a viewer without the font renders
the stack's fallback rather than nothing.

Stdlib only. Usage:

    python make_wordmark.py --name "<display name>" --tokens-file theme.json \
        --out docs/logo.svg [--height 96] [--plain]

`--tokens-file` takes the same JSON shapes as close_gate.py (a full project,
a theme, or a flat token map); `--fill` / `--font` override the token-derived
values when a record carries none.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from xml.sax.saxutils import escape, quoteattr

if sys.stdout.encoding and sys.stdout.encoding.lower() != "utf-8":
    sys.stdout.reconfigure(encoding="utf-8")

_FALLBACK_FILL = "#111827"
_FALLBACK_FONT = "system-ui, sans-serif"


def _tokens_from_payload(data: dict) -> dict[str, str]:
    """Pull the token map out of whatever shape the caller handed us: a full project
    (`{"theme": {"tokens": {...}}}`), a theme (`{"tokens": {...}}`), or a flat token
    map (`{"--primary": "...", ...}`). Mirrors close_gate.py so the two helpers accept
    the same theme.json."""
    if isinstance(data.get("theme"), dict) and isinstance(data["theme"].get("tokens"), dict):
        return dict(data["theme"]["tokens"])
    if isinstance(data.get("tokens"), dict):
        return dict(data["tokens"])
    if data and all(isinstance(k, str) and k.startswith("-") for k in data):
        return dict(data)
    return {}


def _as_css_color(value: str) -> str:
    """Resolve a token value to a CSS colour an SVG attribute accepts. Canonical
    themes often store bare HSL component triples (`222 47% 11%`); wrap those in
    `hsl()`. Anything already a colour function or hex passes through."""
    v = value.strip()
    if not v:
        return ""
    if v.startswith("#") or "(" in v:
        return v
    parts = v.split()
    if len(parts) == 3 and any(p.endswith("%") for p in parts):
        return f"hsl({v})"
    return v


def _color(tokens: dict[str, str], name: str, fallback: str) -> str:
    return _as_css_color(tokens.get(name, "")) or fallback


def _wordmark_svg(name: str, tokens: dict[str, str], fill: str | None,
                  font: str | None, height: int, plain: bool) -> str:
    primary = fill or _color(tokens, "--primary", _FALLBACK_FILL)
    on_primary = _color(tokens, "--primary-foreground", "#ffffff")
    text_fill = fill or _color(tokens, "--foreground", _FALLBACK_FILL)
    stack = (font or tokens.get("--font-sans") or _FALLBACK_FONT).replace('"', "'").strip()

    h = height
    fs = round(h * 0.52)
    baseline = round(h * 0.66)
    pad = round(h * 0.25)
    text_w = round(len(name) * fs * 0.60)

    if plain:
        width = pad + text_w + pad
        body = (
            f'  <text x="{pad}" y="{baseline}" font-family={quoteattr(stack)} '
            f'font-size="{fs}" font-weight="700" letter-spacing="0.5" '
            f'fill="{escape(text_fill)}">{escape(name)}</text>\n'
        )
    else:
        badge = h
        rx = round(h * 0.22)
        initial = name.strip()[:1].upper() or "?"
        gap = round(h * 0.25)
        text_x = badge + gap
        width = text_x + text_w + pad
        body = (
            f'  <rect x="0" y="0" width="{badge}" height="{badge}" rx="{rx}" '
            f'fill="{escape(primary)}"/>\n'
            f'  <text x="{badge // 2}" y="{baseline}" text-anchor="middle" '
            f'font-family={quoteattr(stack)} font-size="{fs}" font-weight="700" '
            f'fill="{escape(on_primary)}">{escape(initial)}</text>\n'
            f'  <text x="{text_x}" y="{baseline}" font-family={quoteattr(stack)} '
            f'font-size="{fs}" font-weight="700" letter-spacing="0.5" '
            f'fill="{escape(text_fill)}">{escape(name)}</text>\n'
        )

    return (
        f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {width} {h}" '
        f'width="{width}" height="{h}" role="img" aria-label={quoteattr(name)}>\n'
        f"{body}"
        "</svg>\n"
    )


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--name", required=True, help="The app's display name, as the wordmark reads")
    parser.add_argument("--out", required=True, help="Output SVG path (repo-relative; commit it)")
    parser.add_argument(
        "--tokens-file",
        help="JSON theme tokens (same shapes close_gate.py accepts: a full project, a "
        "theme, or a flat token map). Colours and typeface derive from it.",
    )
    parser.add_argument("--fill", help="Override colour (used for badge and text) when no usable token exists")
    parser.add_argument("--font", help="Override font stack when the theme carries no --font-sans token")
    parser.add_argument("--height", type=int, default=96, help="Asset height in px (default 96)")
    parser.add_argument(
        "--plain",
        action="store_true",
        help="Text-only wordmark (default renders an initial badge in --primary before the name)",
    )
    args = parser.parse_args()

    name = args.name.strip()
    if not name:
        print("FAIL: --name is empty; the wordmark is the display name rendered in the identity's tokens.")
        return 1

    tokens: dict[str, str] = {}
    if args.tokens_file:
        try:
            tokens = _tokens_from_payload(json.loads(Path(args.tokens_file).read_text(encoding="utf-8")))
        except Exception as exc:  # noqa: BLE001 - report any read/parse failure plainly
            print(f"FAIL: could not read tokens from {args.tokens_file!r}: {exc}")
            return 1
    if not tokens and not args.fill:
        print(
            "FAIL: no theme tokens and no --fill override. The wordmark derives from the "
            "locked identity, never from an invented colour: pass --tokens-file (the theme "
            "the close reads) or an explicit --fill."
        )
        return 1

    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    svg = _wordmark_svg(name, tokens, args.fill, args.font, args.height, args.plain)
    out.write_text(svg, encoding="utf-8", newline="\n")

    print(f"Wordmark written: {out}")
    print(f"  name: {name}")
    print(f"  style: {'plain text' if args.plain else 'initial badge + name'}")
    print("  derived from the theme tokens (deterministic; a re-run is byte-identical).")
    print("Commit the asset and pass it to close_gate.py as --logo.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
