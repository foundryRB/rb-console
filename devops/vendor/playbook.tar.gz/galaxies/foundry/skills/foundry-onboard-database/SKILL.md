---
name: foundry-onboard-database
description: Grant an admitted application its own isolated database and verify its application-owned connection under the platform runbook.
galaxy: foundry
refs:
  - REF-AppContract
---

# Foundry: onboard database

## Pre-flight

1. Read `REF-AppContract.md` sections 2 and 3, the `platform-studio` door and the platform's current onboard-a-database runbook. Discover the bound door's interface; when it is unavailable, use that runbook's by-hand path.
2. Verify the app is already admitted to the intended install (`foundry-onboard-app`) and identify it by fleet name. Read its current grants; an existing grant needs the runbook's update path, never a duplicate grant.
3. Confirm the capability is in the operator request or priced delivery scope. Existing authorization is sufficient; do not prompt again for it.

## Steps

1. Perform the capability grant through the current runbook. Read the change, conformance evidence and admission pull request. Repair a refusal rather than weakening its checks.
2. Wait for the platform CI's automatic merge within the runbook's bounds. Never merge an admission pull request yourself.
3. Complete the app-owned integration below using the grant's actual coordinates and credential references. Do not invent a Secret name or carry a secret through git, CI or the conversation.
4. Verify the capability's isolation and the application's use of it, then report the admission and application evidence.

## App-owned integration

Configure the app with the granted database and least-privilege role; only the password is secret. Use the grant's current credential reference. Verify that the app can connect to its own database and cannot connect to another app's database. The public-schema ownership and connection lockdown remain required even when a connection test succeeds.

## Failure modes

- The app is absent: admit it first. The platform capability is absent: report the platform dependency.
- A grant, credential or isolation check fails: use the runbook's diagnostics and repair the named cause; a green admission does not prove the app consumed its grant.
- An existing grant needs a change: follow its update procedure, preserving data and existing credentials.
- Neither the bound studio nor the current platform guide is available: report the missing authoritative procedure.
