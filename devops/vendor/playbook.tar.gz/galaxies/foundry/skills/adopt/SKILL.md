---
name: adopt
description: "Enter an app whose home is another organization's repository: stand up the foundry-side repo the line runs in, declare the home as the promotion contract's door back, and name its credential - the instantiation and its done-bar then derive from what exists, never from a claim."
galaxy: foundry
refs:
  - REF-Delivery
  - REF-Promotion
---

# Adopt

Invoked as `adopt <home-repo> [--runnable]`: the entry act for an app the foundry does not hold, the sibling of establishing a line on one it does (`REF-Delivery.md` §1). Adopting changes nothing about how the lines work; it gives them a place to run and a door to land through, and lets the app's done-bar derive honestly from what actually exists.

## Pre-flight

1. Confirm the home repository and the base branch changes land on, and that the platform **already holds** a credential reaching it with branch-push and pull-request-open - registered under the very name this adoption will declare (the console's Settings -> Pair credentials). Registering it is the operator's own act and it happens BEFORE the contract names it: the token is theirs to grant and ours to register, never ours to mint, so a name declared over an empty registry is a door that reads open and cannot be opened. Name the credential; never read, copy, or inline its value.
2. Decide with the operator whether the app can **run on a foundry** (`--runnable`). It is the only judgement this act needs, and it decides how much is stood up, not what anything is called: the instantiation derives afterwards.
3. Check the home repository for what the lines will need: its own tests (they are what proven-in-CI means for it) and its build. Report what is missing rather than scaffolding into someone else's repository.
4. Find out where the customer's work **arrives** - their tracker, or their repo's issues - and agree with the operator who bridges it. The line's own tickets live on the **foundry-side repository**, always: that is where the loop reads, comments, labels, parks, and records the pull request it opened on the home. Their tracker is upstream input, never the loop's surface. This is a decision, not a limitation - the loop WRITES to its tickets (`foundry-hidden`, `foundry-delivery-scale`, `foundry-wrong-repo`, its machine markers, its parks), and putting that bookkeeping inside someone else's tracker is the same act as scaffolding the foundry's conformance into their repository, which this skill forbids one failure mode below. Bridging arrives-there to tracked-here is an edge concern: a hand at first, and a sync of real issues later if it earns one. Nothing in the line changes either way, which is the point.

## Steps

1. Stand up the **foundry-side repository**: the place the line runs and the scratch lives. For a non-runnable app it holds only the pointer and its records - no copy of their code, which each act clones on demand into its own workspace. For a runnable one, it holds the app the ordinary way, and it is onboarded to an install like any other (`foundry-onboard-app`).
2. Declare the **door back** in the foundry-side repo's promotion contract: a `repository` target naming the home repo, its base branch, and the credential's name (`REF-Promotion.md` §2). Every change the lines produce crosses back through it as a reviewed pull request.
3. The derivation is read off what steps 1 and 2 left, by every line and by a console alike. A foundry-side repo holding only the pointer, with the door declared, reads **Managed**, and its done-bar is proven-in-CI-and-merged; one holding the app, onboarded, with the door, reads **Hybrid**, proven live here and promoted there; onboarded with no door reads **Complete**. Say the bar in the handover message, so the operator hears it before the first act, and write where their work arrives and who bridges it (pre-flight step 4) into the foundry-side repo's README, the one place the first ticket will look.
4. Hand over the ordinary acts. Maintenance works its tickets, delivery opens a line when there is one, and promotion runs only where an entry environment exists to prove a release first.

## Failure modes

- **The credential does not reach the home repository, or the platform does not hold it yet**: stop. Every act after this one depends on it, and a line that cannot open its pull request produces work nobody can land. The two failures read the same from here and are fixed the same way - by the operator registering what the pair granted - so neither is worked around by pasting a token into the act.
- **The operator wants proven-live for an app nothing can run**: refuse the bar, not the adoption. The app is Managed, its line closes at merged, and saying so at entry is the whole point of deriving the tier (`REF-Delivery.md` §1).
- **The home repository has no tests of its own**: adopt anyway and name it plainly - proven-in-CI means that repository's CI, so an empty suite makes the bar weaker than it reads, and the operator decides whether that is acceptable before the first act, not after.
- **Someone proposes pointing the loop at the customer's tracker**: no - the line's tickets live foundry-side (pre-flight step 4). Reading theirs would be half the story anyway, since the loop writes as much as it reads, and those writes belong on our side of the pair. What a tracker integration may legitimately do is create REAL issues on the foundry-side repo that the loop then derives from natively; what it must never become is a copy of records whose truth lives elsewhere, which is `REF-Maintenance.md` §6 anti-pattern 4 and leaves two sources of truth for one ticket.
- **Someone asks to scaffold the foundry's conformance into their repository**: never. Adoption changes nothing in a home the foundry does not own; what the foundry requires of its own repos is not a demand it makes of theirs.
