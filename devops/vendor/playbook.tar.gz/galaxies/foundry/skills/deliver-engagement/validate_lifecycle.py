"""Validate a versioned delivery definition and render its reference table."""
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

DEFINITION = Path(__file__).with_name("lifecycle.json")
SUPPORTED_ARTIFACTS = frozenset(json.loads(
    Path(__file__).with_name("artifact-handlers.json").read_text(encoding="utf-8")
))
ROOT = Path(__file__).resolve().parents[4]
START = "<!-- lifecycle-table:start -->"
END = "<!-- lifecycle-table:end -->"


def validate(definition: dict, root: Path = ROOT) -> None:
    """Reject unsupported execution handlers and unresolved catalog dependencies."""
    if definition.get("schema_version") != 1:
        raise ValueError("unsupported lifecycle schema")
    if not isinstance(definition.get("id"), str) or not definition["id"]:
        raise ValueError("lifecycle identity is required")
    if not re.fullmatch(r"\d+\.\d+\.\d+", str(definition.get("version", ""))):
        raise ValueError("lifecycle version must be semantic")
    phases = definition.get("phases")
    if not isinstance(phases, list) or not phases:
        raise ValueError("ordered phases are required")
    skills = {path.parent.name for path in (root / "galaxies").glob("*/skills/*/SKILL.md")}
    agents = {path.stem for path in (root / "galaxies").glob("*/agents/*.md")}
    seen: set[str] = set()
    records: set[str] = set()
    gates: set[str] = set()
    for phase in phases:
        if not isinstance(phase, dict):
            raise TypeError("phase must be an object")
        for field in ("id", "label", "skill", "agent", "record", "question", "completion", "tool"):
            if not isinstance(phase.get(field), str) or not phase[field]:
                raise ValueError(f"phase {field} is required")
        identity = phase["id"]
        if identity in seen:
            raise ValueError("duplicate phase identity")
        inputs = phase.get("inputs")
        if not isinstance(inputs, list) or any(not isinstance(item, str) or item not in seen for item in inputs) or len(inputs) != len(set(inputs)):
            raise ValueError("phase inputs must name distinct earlier phases")
        if phase["skill"] not in skills or phase["agent"] not in agents:
            raise ValueError("phase catalog reference is missing")
        if phase["completion"] not in {"record", "journal"}:
            raise ValueError("unsupported completion handler")
        record = phase["record"]
        if not re.fullmatch(r"[a-z][a-z0-9_-]*\.md", record) or record in records:
            raise ValueError("phase record must be a distinct scratch filename")
        gate = phase.get("gate")
        if gate is not None and (not isinstance(gate, str) or not gate or gate in gates):
            raise ValueError("phase gate must be a distinct identity")
        if phase["completion"] == "journal" and (record != "journal.md" or gate is not None):
            raise ValueError("journal completion requires the ungated journal")
        if not isinstance(phase.get("studio"), str):
            raise TypeError("studio must be a string")
        if "artifact" not in phase:
            raise ValueError("phase artifact field is required")
        artifact = phase["artifact"]
        if not isinstance(artifact, str) and artifact is not None or artifact not in SUPPORTED_ARTIFACTS:
            raise ValueError("unsupported artifact handler")
        seen.add(identity)
        records.add(record)
        if gate:
            gates.add(gate)


def table(definition: dict) -> str:
    """Generate the phase table solely from the canonical definition."""
    rows = [START, "| # | Phase | Delivery skill | Drives (the tool underneath) | Question it answers | Gate it closes |", "| - | ----- | -------------- | ---------------------------- | ------------------- | -------------- |"]
    for number, phase in enumerate(definition["phases"], 1):
        cells = [str(number), phase["label"], f"`{phase['skill']}`", phase["tool"], phase["question"], phase["gate"] or "(closes the loop)"]
        rows.append("| " + " | ".join(cell.replace("|", "\\|") for cell in cells) + " |")
    rows.append(END)
    return "\n".join(rows)


def render_reference(text: str, definition: dict) -> str:
    start, end = text.index(START), text.index(END) + len(END)
    return text[:start] + table(definition) + text[end:]


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--definition", type=Path, default=DEFINITION)
    parser.add_argument("--write", action="store_true")
    args = parser.parse_args()
    definition = json.loads(args.definition.read_text(encoding="utf-8"))
    validate(definition)
    reference = ROOT / "galaxies/foundry/REF-Delivery.md"
    text = reference.read_text(encoding="utf-8")
    rendered = render_reference(text, definition)
    if args.write:
        reference.write_text(rendered, encoding="utf-8", newline="\n")
    elif rendered != text:
        parser.error("lifecycle phase table differs; run with --write")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
