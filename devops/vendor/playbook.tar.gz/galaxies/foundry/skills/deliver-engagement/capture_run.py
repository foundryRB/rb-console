"""Write an interactive phase's run figures into its record, captured from the local agent
session logs: the terminal twin of the console worker's `record_run.py` (playbook#508).

A worker run writes the `run` and `run_*` frontmatter keys from `claude -p`'s final
`result` event. A phase driven at a terminal has no such event, so its record carried a
bare `run:` and the delivery analytics read its agent run time, spend and agents view as
waiting on a capture for the whole line. The figures exist all the same, in the session
logs the agent runtimes keep on the operator's machine; this helper reads them.

Run it at a terminal (`interaction=manual`) when the phase reaches its gate, on the
machine the work ran on - the logs live nowhere else, which is why the gate stamp (that a
cockpit Sign runs on the console server) does not call it:

    python capture_run.py --repo <repo-root> --record handoff.md

What it reads:

- **Claude Code**: `$CLAUDE_CONFIG_DIR` (else `~/.claude`), every `projects/**/*.jsonl`,
  subagent transcripts included - they hold most of a phase's spend. Sessions are filed
  by the folder they were launched from, not the repo they worked in, so selection is by
  each event's own `cwd`, never by the folder name. Usage repeats on every content-block
  line of one message, so each message counts once (its `message.id`; a resumed session
  that copies history counts it once too). A transcript whose LAST event predates the
  window is skipped, read from the file's tail: the logs are appended in time order, and
  a file's modified time is not reliable (Codex leaves it at the creation moment on some
  systems while the file keeps growing).
- **Codex**: `$CODEX_HOME` (else `~/.codex`), every `sessions/**/rollout-*.jsonl`. Its
  `token_count` events carry a session's RUNNING total, so a phase's spend is the sum of
  the increases inside the window, attributed to the model the latest `turn_context`
  names. A session continues across files, so every rollout is read for the totals that
  precede the window. A forked or resumed session opens its total at its parent's, so the
  first total a session shows (and one that drops, a restart) counts only that call's own
  `last_token_usage`, never the whole total from zero. Its `input_tokens` already includes
  the cached (and cache-written) input, so those are split out rather than added: the
  four types the record carries never overlap.

An event counts when its `cwd` is inside the delivery repo (or a `--cwd` root) and its
timestamp is inside the phase window: the record's `started` to now, or `--since` /
`--until`. Work done from another folder or another machine is not seen; nothing here
guesses at it.

What it writes, beside the record helper's block (the keys `record_run.py` writes, so
the analytics read both the same way):

    run                     local-<record>-<window start>, stable across re-runs
    run_capture             local-logs: these figures came from session logs, not a worker
    run_agent               --agent, else the catalog agent of the record's phase
    run_model               the model with the most tokens in the window
    run_started/_finished   the first and last counted event
    run_seconds             ACTIVE time: the union of activity across every log, a gap
                            longer than --idle (300s) not counted - parallel subagents
                            count once, and an idle evening counts nothing
    run_tokens, run_tokens_input/_output/_cache_read/_cache_creation, run_turns
    run_model_<slug>_tokens per model
    run_cost, run_model_<slug>_cost
                            API-equivalent, each call priced on its own (a prompt-length
                            tier is billed per request), and only when every model in the
                            window has a price: the Anthropic and OpenAI list prices
                            below, or a --prices file (a JSON map of model id to USD per
                            million tokens for input, output, cache_read, cache_write and,
                            optionally, cache_write_1h, plus `over` and a `long` tier)
                            that adds or overrides models. A cost that leaves a model out
                            would read as the whole spend, so then no cost is written at
                            all

Re-running REPLACES what this helper wrote before: the window only grows, so a phase
that reaches its gate again after a review round is re-measured, never counted twice.
Figures it did not write are left alone: a record carrying `run_*` figures is touched
only while it holds `run_capture: local-logs` AND a `run` id this helper minted
(`local-...`), so a worker's exact capture - a first one, or a worker re-drive over an
earlier terminal capture - is never overwritten.

Under the console worker (`FC_SIGNAL_DIR` set) it writes nothing: the entrypoint records
that run exactly, and reading the pod's own transcripts too would count it twice.

Figures are telemetry, never a reason a phase stalls. A log or a line that cannot be read
is skipped and the rest are read. A record that does not exist, a window that cannot be
read, logs that hold no usage for the window, and any other error each write nothing,
say so on one line, and exit 0. Only the helper's own arguments are refused. `--dry-run`
prints the figures and writes nothing - the way to look at a closed line's phases, whose
records sit behind a delivered tag.

Stdlib only. Examples:

    python capture_run.py --repo . --record build.md
    python capture_run.py --repo . --record design.md --cwd ~/Documents/Codex/2026-10-09 \\
        --since 2026-10-09T21:31:58Z --until 2026-10-09T22:22:36Z --dry-run
"""

from __future__ import annotations

import argparse
import json
import os
import re
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

if sys.stdout.encoding and sys.stdout.encoding.lower() != "utf-8":
    sys.stdout.reconfigure(encoding="utf-8")

_SCRATCH = ".delivery"
#: The marker this helper writes, and the only `run_capture` value it will overwrite.
MARKER = "local-logs"
#: A frontmatter line this helper owns: `run`, or any `run_*` key, at column 0.
_OWNED = re.compile(r"^(run(?:_[A-Za-z0-9_]+)?)\s*:\s*(.*?)\s*$")
_FIELD = re.compile(r"^([A-Za-z_][A-Za-z0-9_]*)\s*:\s*(.*?)\s*$")
_STAMP = re.compile(
    r"^(\d{4}-\d{2}-\d{2})[T ](\d{2}:\d{2}:\d{2})(?:\.(\d+))?(Z|[+-]\d{2}:?\d{2})?$"
)
_TAIL_STAMP = re.compile(r'"timestamp"\s*:\s*"([^"]+)"')
_ORDER = (
    "run",
    "run_capture",
    "run_agent",
    "run_model",
    "run_started",
    "run_finished",
    "run_seconds",
    "run_tokens",
    "run_cost",
    "run_tokens_input",
    "run_tokens_output",
    "run_tokens_cache_read",
    "run_tokens_cache_creation",
    "run_turns",
)
_TYPES = ("input", "output", "cache_read", "cache_creation")
#: The catalog agent that runs each phase (`agents/`), named on the record so the
#: analytics' usage-by-agent view groups an interactive phase with the worker's.
_AGENTS = {
    "scope": "architect",
    "design": "designer",
    "intent+plan": "planner",
    "build+ship": "builder",
    "learn": "librarian",
}
IDLE_SECONDS = 300


def _rates(
    input_rate: float,
    cache_write: float,
    cache_write_1h: float,
    cache_read: float,
    output_rate: float,
    **tiers: object,
) -> dict[str, object]:
    """A model's rates in the providers' own column order (input, 5-minute cache write,
    hour cache write, cache read, output). A `long` tier, priced on its own, applies to
    one call whose prompt - input, cache reads and cache writes - is over `over` tokens."""
    return {
        "input": input_rate,
        "cache_write": cache_write,
        "cache_write_1h": cache_write_1h,
        "cache_read": cache_read,
        "output": output_rate,
        **tiers,
    }


#: List prices, USD per million tokens, read 2026-10-12. An absent model writes no cost
#: rather than a guessed one; `--prices` adds or overrides models.
#: - Anthropic: https://platform.claude.com/docs/en/about-claude/pricing. The cache-read
#:   rate is per model (0.025x input on Fable 5.1, 0.05x on Opus 5.5 and Sonnet 5.5, 0.1x
#:   elsewhere), and Haiku 5.5 alone is priced by prompt length, over 100,000 tokens.
#: - OpenAI: https://developers.openai.com/api/docs/pricing, the standard tier. Its cache
#:   writes have one rate, and gpt-6.1-sol is long context over 272K input tokens.
PRICES: dict[str, dict[str, object]] = {
    "claude-fable-5-1": _rates(10.0, 12.50, 20.0, 0.25, 50.0),
    "claude-fable-5": _rates(10.0, 12.50, 20.0, 1.0, 50.0),
    "claude-opus-5-5": _rates(4.0, 5.0, 8.0, 0.20, 20.0),
    "claude-opus-5": _rates(5.0, 6.25, 10.0, 0.50, 25.0),
    "claude-sonnet-5-5": _rates(2.0, 2.50, 4.0, 0.10, 10.0),
    "claude-sonnet-5": _rates(2.0, 2.50, 4.0, 0.20, 10.0),
    "claude-haiku-5-5": _rates(
        0.10, 0.125, 0.20, 0.01, 0.50, over=100_000, long=_rates(0.50, 0.625, 1.0, 0.05, 2.50)
    ),
    "gpt-6.1-sol": _rates(
        2.0, 2.50, 2.50, 0.10, 10.0, over=272_000, long=_rates(4.0, 5.0, 5.0, 0.20, 15.0)
    ),
}


def parse_stamp(value: str) -> datetime | None:
    """An ISO stamp as an aware UTC datetime, or None.

    Read by hand rather than by `datetime.fromisoformat`, which before Python 3.11
    refuses both the `Z` suffix and a fraction of other than three or six digits - and
    the logs carry both.
    """
    m = _STAMP.match(value.strip()) if isinstance(value, str) else None
    if not m:
        return None
    day, clock, fraction, zone = m.groups()
    try:
        moment = datetime.strptime(f"{day}T{clock}", "%Y-%m-%dT%H:%M:%S")
    except ValueError:
        return None
    if fraction:
        moment = moment.replace(microsecond=int(fraction[:6].ljust(6, "0")))
    offset = timedelta(0)
    if zone and zone != "Z":
        sign = -1 if zone[0] == "-" else 1
        digits = zone[1:].replace(":", "")
        offset = sign * timedelta(hours=int(digits[:2]), minutes=int(digits[2:]))
    return (moment - offset).replace(tzinfo=timezone.utc)


def _iso(moment: datetime) -> str:
    return moment.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _slug(model: str) -> str:
    return re.sub(r"[^a-z0-9]", "_", model.lower())


def _int(value: object) -> int:
    if value is None or isinstance(value, bool):
        return 0
    try:
        return int(value)  # type: ignore[arg-type]
    except (TypeError, ValueError):
        return 0


def _norm(path: str) -> str:
    return os.path.normcase(os.path.normpath(os.path.abspath(os.path.expanduser(path))))


def _inside(cwd: object, roots: list[str]) -> bool:
    """Whether a logged working directory is one of the roots or below one."""
    if not isinstance(cwd, str) or not cwd:
        return False
    here = _norm(cwd)
    return any(here == root or here.startswith(root.rstrip(os.sep) + os.sep) for root in roots)


def _last_stamp(path: Path) -> datetime | None:
    """The timestamp of a log's last event, read from its tail, or None when none reads."""
    try:
        with path.open("rb") as handle:
            handle.seek(0, os.SEEK_END)
            handle.seek(max(handle.tell() - 65536, 0))
            tail = handle.read().decode("utf-8", errors="replace")
    except OSError:
        return None
    for line in reversed(tail.splitlines()):
        m = _TAIL_STAMP.search(line)
        stamp = parse_stamp(m.group(1)) if m else None
        if stamp is not None:
            return stamp
    return None


def _logs(root: Path, pattern: str, since: datetime | None = None) -> list[Path]:
    """The logs under `root`; with `since`, only those whose last event is not before it
    (a log whose tail reads no stamp is kept)."""
    if not root.is_dir():
        return []
    found = []
    for path in sorted(root.rglob(pattern)):
        last = _last_stamp(path) if since is not None else None
        if last is None or since is None or last >= since:
            found.append(path)
    return found


def _events(path: Path):
    """Each JSON object on a log, skipping a line that is not one (a truncated tail)."""
    try:
        with path.open(encoding="utf-8", errors="replace") as handle:
            for raw in handle:
                line = raw.strip()
                if not line.startswith("{"):
                    continue
                try:
                    obj = json.loads(line)
                except ValueError:
                    continue
                if isinstance(obj, dict):
                    yield obj
    except OSError:
        return


class Capture:
    """Usage per model and the activity stamps the window holds, across both runtimes.

    Each call is priced as it is added, on its own: a provider bills a prompt-length
    tier per request, so the tier is decided by that call's prompt, never by a total.
    """

    def __init__(self, prices: dict[str, object] | None = None) -> None:
        self.prices = PRICES if prices is None else prices
        self.models: dict[str, dict[str, float]] = {}
        self.stamps: list[datetime] = []

    def add(self, model: str, counts: dict[str, int], price_as: str = "") -> None:
        """Count a call under `model`; price it as `price_as` when given (a Codex
        guardian runs on its parent session's model, so it bills at that model's rates)."""
        counts = {key: max(value, 0) for key, value in counts.items()}
        entry = self.models.setdefault(
            model, {key: 0 for key in (*_TYPES, "cache_creation_1h", "turns", "cost", "unpriced")}
        )
        for key, value in counts.items():
            entry[key] = entry.get(key, 0) + value
        entry["turns"] += 1
        cost = call_cost(self.prices, price_as or model, counts)
        if cost is None:
            entry["unpriced"] += 1
        else:
            entry["cost"] += cost


def read_claude(home: Path, roots: list[str], since: datetime, until: datetime, into: Capture) -> None:
    """Claude Code transcripts: each message once, by its id, at its largest usage."""
    messages: dict[str, tuple[str, dict[str, int]]] = {}
    for path in _logs(home / "projects", "*.jsonl", since):
        for event in _events(path):
            moment = parse_stamp(event.get("timestamp", ""))
            if moment is None or not since <= moment <= until or not _inside(event.get("cwd"), roots):
                continue
            into.stamps.append(moment)
            message = event.get("message")
            if event.get("type") != "assistant" or not isinstance(message, dict):
                continue
            usage = message.get("usage")
            model = str(message.get("model") or "").strip()
            if not isinstance(usage, dict) or not model or model.startswith("<"):
                continue
            key = str(message.get("id") or event.get("requestId") or event.get("uuid") or "")
            if not key:
                continue
            split = usage.get("cache_creation")
            counts = {
                "input": _int(usage.get("input_tokens")),
                "output": _int(usage.get("output_tokens")),
                "cache_read": _int(usage.get("cache_read_input_tokens")),
                "cache_creation": _int(usage.get("cache_creation_input_tokens")),
                # The hour-TTL share of the cache writes: a rate, not a type of its own.
                "cache_creation_1h": _int(split.get("ephemeral_1h_input_tokens")) if isinstance(split, dict) else 0,
            }
            prior = messages.get(key)
            if prior is not None:
                counts = {k: max(counts[k], prior[1][k]) for k in counts}
            messages[key] = (model, counts)
    for model, counts in messages.values():
        into.add(model, counts)


def _codex_usage(usage: object) -> tuple[int, int, int, int]:
    """Input, cached input, cache-written input and output, from one Codex usage object."""
    if not isinstance(usage, dict):
        return (0, 0, 0, 0)
    return (
        _int(usage.get("input_tokens")),
        _int(usage.get("cached_input_tokens")),
        _int(usage.get("cache_write_input_tokens")),
        _int(usage.get("output_tokens")),
    )


def read_codex(home: Path, roots: list[str], since: datetime, until: datetime, into: Capture) -> None:
    """Codex rollouts: the increases of each session's running total inside the window.

    A session continues across files and a resumed one can replay its history into a
    second, so the running totals are gathered per session id across EVERY rollout and
    de-duplicated before they are differenced. The first total a session shows, and a
    total that drops (a restart), may open at a parent session's figure, so each counts
    only its own call (`last_token_usage`).

    A guardian session - Codex's automatic approval review, `source.subagent.other:
    guardian`, logged under the model name `codex-auto-review` - runs on the model of
    the session it reviews for. Its calls are counted under its own model name and
    priced as the parent's model at that moment (`parent_thread_id`); a guardian whose
    parent this machine's logs do not hold is left unpriced, never guessed.
    """
    points: dict[str, set] = {}
    sessions: dict[str, dict] = {}
    for path in _logs(home / "sessions", "rollout-*.jsonl"):
        session, cwd, model = str(path), "", ""
        for event in _events(path):
            payload = event.get("payload") if isinstance(event.get("payload"), dict) else {}
            kind = event.get("type")
            moment = parse_stamp(event.get("timestamp", ""))
            if kind == "session_meta":
                session = str(payload.get("id") or session)
                cwd = str(payload.get("cwd") or cwd)
                meta = sessions.setdefault(session, {"parent": "", "guardian": False, "models": []})
                meta["parent"] = str(payload.get("parent_thread_id") or meta["parent"])
                source = payload.get("source")
                subagent = source.get("subagent") if isinstance(source, dict) else None
                if isinstance(subagent, dict) and subagent.get("other") == "guardian":
                    meta["guardian"] = True
            elif kind == "turn_context":
                cwd = str(payload.get("cwd") or cwd)
                model = str(payload.get("model") or model)
                if moment is not None and model:
                    sessions.setdefault(session, {"parent": "", "guardian": False, "models": []})[
                        "models"
                    ].append((moment, model))
            if moment is None:
                continue
            counted = since <= moment <= until and _inside(cwd, roots)
            if counted:
                into.stamps.append(moment)
            info = payload.get("info") if payload.get("type") == "token_count" else None
            total = info.get("total_token_usage") if isinstance(info, dict) else None
            if not isinstance(total, dict):
                continue
            last = _codex_usage(info.get("last_token_usage"))
            points.setdefault(session, set()).add((moment, _codex_usage(total), last, model, counted))
    for session, series in points.items():
        prior = None
        for moment, figures, last, model, counted in sorted(series):
            if prior is None or any(now < before for now, before in zip(figures, prior)):
                delta = list(last)
            else:
                delta = [now - before for now, before in zip(figures, prior)]
            prior = figures
            if not counted or not any(delta) or not model:
                continue
            fresh_input, cached, written, output = delta
            into.add(
                model,
                {
                    "input": fresh_input - cached - written,
                    "output": output,
                    "cache_read": cached,
                    "cache_creation": written,
                },
                price_as=_guardian_price_model(sessions, session, moment),
            )


def _guardian_price_model(sessions: dict[str, dict], session: str, moment: datetime) -> str:
    """The model a guardian session's call bills as: its parent session's model at that
    moment (the latest it named at or before it, else its first). Empty for a session
    that is no guardian; a guardian whose parent is not in the logs gets a name no price
    list carries, so its call stays unpriced."""
    meta = sessions.get(session)
    if not meta or not meta["guardian"]:
        return ""
    parent = sessions.get(meta["parent"])
    if not parent or not parent["models"]:
        return "unknown-guardian-parent"
    timeline = sorted(parent["models"])
    earlier = [name for at, name in timeline if at <= moment]
    return earlier[-1] if earlier else timeline[0][1]


def active_seconds(stamps: list[datetime], idle: int) -> int:
    """The union of activity: the gaps between consecutive events, each no longer than
    `idle`, summed. One timeline across every log, so parallel work counts once."""
    ordered = sorted(stamps)
    total = 0.0
    for before, after in zip(ordered, ordered[1:]):
        gap = (after - before).total_seconds()
        if gap <= idle:
            total += gap
    return int(total)


def _rate(rates: dict, name: str) -> float | None:
    rate = rates.get(name)
    return None if isinstance(rate, bool) or not isinstance(rate, (int, float)) else float(rate)


def call_cost(prices: dict[str, object], model: str, counts: dict[str, int]) -> float | None:
    """One call's cost in USD, or None when any rate it needs is missing.

    A model with a `long` tier is priced at it when this call's prompt - its input,
    cache reads and cache writes - is over the tier's `over` tokens.
    """
    rates = prices.get(model)
    if not isinstance(rates, dict):
        return None
    over = rates.get("over")
    prompt = counts.get("input", 0) + counts.get("cache_read", 0) + counts.get("cache_creation", 0)
    if isinstance(over, (int, float)) and not isinstance(over, bool) and prompt > over:
        rates = rates.get("long")
        if not isinstance(rates, dict):
            return None
    needed = {name: _rate(rates, name) for name in ("input", "output", "cache_read", "cache_write")}
    if any(rate is None for rate in needed.values()):
        return None
    hour = _rate(rates, "cache_write_1h")
    if hour is None:
        hour = needed["cache_write"]
    written = counts.get("cache_creation", 0)
    written_1h = min(counts.get("cache_creation_1h", 0), written)
    cost = (
        counts.get("input", 0) * needed["input"]
        + counts.get("output", 0) * needed["output"]
        + counts.get("cache_read", 0) * needed["cache_read"]
        + (written - written_1h) * needed["cache_write"]
        + written_1h * hour
    )
    return cost / 1_000_000


def figures(capture: Capture, idle: int) -> dict[str, str]:
    """The keys to write, rendered, from what the capture holds (empty when it holds none)."""
    if not capture.models:
        return {}
    totals = {key: sum(entry[key] for entry in capture.models.values()) for key in _TYPES}
    out: dict[str, str] = {}
    busiest = max(capture.models, key=lambda m: (sum(capture.models[m][k] for k in _TYPES), m))
    out["run_model"] = busiest
    if capture.stamps:
        out["run_started"] = _iso(min(capture.stamps))
        out["run_finished"] = _iso(max(capture.stamps))
    out["run_seconds"] = str(active_seconds(capture.stamps, idle))
    out["run_tokens"] = str(int(sum(totals.values())))
    for key in _TYPES:
        out[f"run_tokens_{key}"] = str(int(totals[key]))
    out["run_turns"] = str(int(sum(entry["turns"] for entry in capture.models.values())))
    costs = {}
    for model, entry in sorted(capture.models.items()):
        out[f"run_model_{_slug(model)}_tokens"] = str(int(sum(entry[k] for k in _TYPES)))
        costs[model] = None if entry["unpriced"] else entry["cost"]
    if costs and all(cost is not None for cost in costs.values()):
        out["run_cost"] = f"{sum(costs.values()):.6f}"
        for model, cost in costs.items():
            out[f"run_model_{_slug(model)}_cost"] = f"{cost:.6f}"
    return out


def _front_end(lines: list[str]) -> int | None:
    if not lines or lines[0].strip() != "---":
        return None
    for i in range(1, len(lines)):
        if lines[i].strip() == "---":
            return i
    return None


def _block(lines: list[str], end: int) -> dict[str, str]:
    fields: dict[str, str] = {}
    for i in range(1, end):
        m = _FIELD.match(lines[i].rstrip("\r\n"))
        if m:
            fields[m.group(1)] = m.group(2).strip().strip('"').strip("'")
    return fields


def rewrite(lines: list[str], end: int, keys: dict[str, str]) -> list[str]:
    """The record with every owned line replaced by `keys`: a key already there is
    rewritten on its own line with that line's own ending, a stale one (a model no longer
    in the window) is dropped, and a new one is appended before the closing fence with the
    fence's ending. Every other byte is the record's: a record written on another machine
    can carry CRLF, or a mix, and a capture that touched its endings would rewrite every
    line in the diff and the blame (playbook#513)."""

    def ending(line: str) -> str:
        return line[len(line.rstrip("\r\n")) :]

    fence = ending(lines[end]) or ending(lines[end - 1]) or "\n"
    pending = dict(keys)
    head = [lines[0]]
    for i in range(1, end):
        m = _OWNED.match(lines[i].rstrip("\r\n"))
        if not m:
            head.append(lines[i])
        elif m.group(1) in pending:
            head.append(f"{m.group(1)}: {pending.pop(m.group(1))}{ending(lines[i]) or fence}")
    ordered = [k for k in _ORDER if k in pending] + sorted(k for k in pending if k not in _ORDER)
    head.extend(f"{key}: {pending[key]}{fence}" for key in ordered)
    return head + lines[end:]


def _load_prices(path: str | None) -> dict[str, object]:
    """The built-in list prices, with a `--prices` file's models added or overriding."""
    prices: dict[str, object] = dict(PRICES)
    if not path:
        return prices
    try:
        loaded = json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        print(f"NOTE: --prices {path} could not be read ({exc}); only the built-in prices apply.")
        return prices
    if isinstance(loaded, dict):
        prices.update(loaded)
    return prices


def capture(args: argparse.Namespace) -> int:
    if os.environ.get("FC_SIGNAL_DIR"):
        # Only the console worker sets it (resolve-ticket, the delivery-scale signal): a
        # worker's run is recorded exactly by its own entrypoint, from the result event,
        # and a pod's transcripts read here as well would count the run twice.
        print("Run figures not captured: this is a worker run; its entrypoint records them.")
        return 0
    record = Path(args.repo) / _SCRATCH / args.record
    try:
        # newline="" keeps every line's ending as written: read_text would translate a
        # CRLF to LF before the rewrite ever saw it.
        with record.open(encoding="utf-8", newline="") as handle:
            text = handle.read()
    except OSError:
        print(f"Run figures not captured: {_SCRATCH}/{args.record} does not exist.")
        return 0
    lines = text.splitlines(keepends=True)
    end = _front_end(lines)
    if end is None:
        print(f"Run figures not captured: {_SCRATCH}/{args.record} has no frontmatter block.")
        return 0
    block = _block(lines, end)
    figured = [k for k in block if k.startswith("run_") and k != "run_capture" and block[k]]
    ours = block.get("run_capture") == MARKER and block.get("run", "").startswith("local-")
    if figured and not ours:
        print(
            f"Run figures not captured: {_SCRATCH}/{args.record} already carries figures this "
            "helper did not write (a worker's, which are exact); they are left alone."
        )
        return 0
    since = parse_stamp(args.since or block.get("started", ""))
    until = parse_stamp(args.until) if args.until else datetime.now(timezone.utc)
    if since is None or until is None or until < since:
        print(
            f"Run figures not captured: no readable window (since {args.since or block.get('started')!r}, "
            f"until {args.until!r}); pass --since/--until."
        )
        return 0
    roots = [_norm(args.repo)] + [_norm(extra) for extra in args.cwd]
    found = Capture(_load_prices(args.prices))
    read_claude(Path(args.claude_home), roots, since, until, found)
    read_codex(Path(args.codex_home), roots, since, until, found)
    keys = figures(found, args.idle)
    if not keys:
        print(
            f"Run figures not captured: no session log under this machine's agent homes "
            f"holds usage inside the repo between {_iso(since)} and {_iso(until)}."
        )
        return 0
    stem = Path(args.record).stem
    identity = {"run": f"local-{stem}-{since.strftime('%Y%m%dT%H%M%SZ')}", "run_capture": MARKER}
    agent = args.agent or _AGENTS.get(block.get("phase", ""), "")
    if agent:
        identity["run_agent"] = agent
    keys = {**identity, **keys}
    summary = (
        f"{keys['run_tokens']} tokens, {int(keys['run_seconds']) // 60} active min, "
        f"{keys['run_turns']} turns, model {keys['run_model']}"
        + (f", cost {keys['run_cost']} USD" if "run_cost" in keys else ", no cost (unpriced model)")
    )
    if args.dry_run:
        print(f"Dry run, nothing written: {summary}")
        for key, value in keys.items():
            print(f"  {key}: {value}")
        return 0
    record.write_text("".join(rewrite(lines, end, keys)), encoding="utf-8", newline="")
    print(f"Run figures captured into {_SCRATCH}/{args.record}: {summary}.")
    return 0


def main(argv: list[str] | None = None) -> int:
    claude_home = os.environ.get("CLAUDE_CONFIG_DIR") or str(Path.home() / ".claude")
    codex_home = os.environ.get("CODEX_HOME") or str(Path.home() / ".codex")
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--repo", required=True, help="Delivery repo root (holds .delivery/)")
    parser.add_argument("--record", required=True, help="Scratch record filename: proposal.md / design.md / handoff.md / build.md")
    parser.add_argument("--since", help="Window start, ISO-8601 (default: the record's started)")
    parser.add_argument("--until", help="Window end, ISO-8601 (default: now)")
    parser.add_argument("--cwd", action="append", default=[], help="Another folder whose sessions count as this phase's (repeatable)")
    parser.add_argument("--agent", default="", help="Catalog agent to record (default: the phase's)")
    parser.add_argument("--idle", type=int, default=IDLE_SECONDS, help="Seconds of silence that end an active stretch (default 300)")
    parser.add_argument(
        "--prices",
        help="JSON price map adding to or overriding the built-in Anthropic and OpenAI list "
        "prices: model -> USD per million tokens for input, output, cache_read, cache_write, "
        "optionally cache_write_1h, and optionally `over` with a `long` tier priced on its own",
    )
    parser.add_argument("--claude-home", default=claude_home, help="Claude Code home (default: $CLAUDE_CONFIG_DIR or ~/.claude)")
    parser.add_argument("--codex-home", default=codex_home, help="Codex home (default: $CODEX_HOME or ~/.codex)")
    parser.add_argument("--dry-run", action="store_true", help="Print the figures; write nothing")
    args = parser.parse_args(argv)
    if args.idle <= 0:
        parser.error("--idle must be a positive number of seconds")
    try:
        return capture(args)
    except Exception as exc:  # noqa: BLE001 - telemetry never stalls a phase
        print(f"Run figures not captured: {type(exc).__name__}: {exc}")
        return 0


if __name__ == "__main__":
    sys.exit(main())
