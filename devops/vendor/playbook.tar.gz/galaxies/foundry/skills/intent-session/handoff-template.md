# handoff.md - <app>, one-shot autonomous delivery handoff

<!-- Template: intent-session writes this into the delivery scratch as .delivery/handoff.md,
     NOT the repo root. This is the EPHEMERAL build handoff (REF-Delivery.md section 4b):
     assembled from the durable sources (the estimation project, docs/, intent.yaml),
     committed with the rest of the scratch so a cancelled run resumes, consumed by the build,
     and retired with the line at reconcile. It restates none of the durable sources; it points at them and
     adds only the run-scoped decisions below. Replace every <placeholder>. Structure mirrors
     REF-Delivery.md; delete nothing, mark inapplicable rows "n/a: <why>" so the reviewer can
     tell decided-empty from forgotten. -->

This is the complete handover for an autonomous implementation run. Every decision is pinned or pointed at its durable home, this run is authorized by the standing profile or per-run grant in §0, every external dependency has a pre-flight and a degraded stop-state, and any point that genuinely needs a human becomes a §10 degraded stop-state. If executing this handoff ever requires a decision not written or pointed to here, that is a handoff defect: make the smallest reasonable choice, record it in the final report under "plan defects", and continue. Do not stop to ask.

## 0. Mission, authorization, done-definition

**Mission.** <one paragraph: what ships, for whom; where the verbatim request and requirement IDs live>

**Gates already passed** (`REF-Delivery.md` §1): proposal accepted <date, recorded in `.delivery/proposal.md` + the estimation project>; design approved <date, in `.delivery/design.md`>; plan signed <date/profile, this handoff>.

**Authorization.** The operator pre-authorizes this run, under <the standing autonomous-delivery profile | this per-run grant>, to:

1. <push targets: which repo, which branches>
2. <platform-repo actions: registry, manifests, merge rights>
3. <secret/infrastructure actions, each named individually>
4. <repo-host actions: milestones, issues>

When the done-definition requires the app live, executing §8 end to end - the first-release and onboarding sequence, including conforming the app repo to the §7 contract so the shared CI can release - is in-grant by this section without further enumeration: a done-definition the grant cannot reach is a contradiction this template does not permit, and a run discovering mid-flight that the pipeline was never wired finishes the wiring rather than stopping (a Phase-2 run once stopped degraded on exactly this). Strike this paragraph only for a run that deliberately ends before live.

**Not authorized** (restate this list verbatim in the §13 kickoff prompt): <only prohibitions tied to THIS delivery, each with its reason: other repos, boards, scope beyond v1>. A stock prohibition copied in without a this-run reason is a plan defect, not a safeguard: the build treats this list as binding even when obeying it is what fails the run (`run-delivery-plan` step 1), so an unreasoned line becomes a wall.

**Done-definition.** The run ends successfully when the §9 evidence chain is complete and every claim in `intent.yaml` is active with a passing test. It ends acceptably at a §10 degraded terminal state, evidence collected and reported plainly. There is no third way to end.

## 1. Inputs and references

| Input | Where |
|---|---|
| Requirements + traceability | <estimation project slug + instance; credentials location>. Read-only for this run (a legacy artifact). |
| Visual identity (locked) | `.delivery/design.md`; the build lands it into `docs/` (brand page, logo asset, theme tokens). It wins conflicts on look. Behavioral surfaces the e2e claims also assert (the post-login landing route, navigation flow) are the CLAIMS' contract, not "visual": if the approved layout and an e2e claim disagree on such a surface, name which is authoritative here before the build starts |
| Frozen gate exports | `.delivery/architecture/`, `.delivery/assumptions/`, `.delivery/design/screens/`: the phase's engineering deliverables as the gate froze them at signature. Read-only. |
| Architecture and decisions | `docs/` (this repo): the ADRs in the decisions collection, and the architecture target where `REF-Documentation.md` §7.11 puts it (the index and the module pages, or the architecture page of a site not in that shape); every deviation is an ADR authored before code |
| Intent claims | `intent.yaml` (this repo), draft; activate as tests pass |
| Delivery lifecycle | `REF-Delivery.md` |
| Playbook routing ("n/a: ships no code" only on a line that ships none) | <per component: the REFs and scaffold skills the craft galaxy's routing table (`GALAXY.md`) names for what the component builds, from only the table rows whose task an ADR or a requirement says this line performs>. They join the standard this run and its reviews are held to |
| Recast source (a recast line; "n/a: not a recast" otherwise) | `_recast/` on the scratch: the oracle of the surface (`REF-Recast.md` §5), read for the surface and never for the substance (§3). `REF-Recast.md` §3 to §5 join the standard this run and its review are held to, beside the REFs the Playbook routing row names |
| Repo contract | `REF-AppContract.md` §4 (or the platform's equivalent contract doc) |
| Exemplar app(s) to mirror | <sibling repo path(s) + what each is the exemplar for> |
| Onboarding procedure | the `foundry-onboard-app` skill, then `foundry-onboard-database` / `foundry-onboard-keycloak` as §2 prices them: each drives the platform's onboarding studio over its MCP and falls back to the platform's by-hand runbook (`REF-AppContract.md` §2). <replace only for a non-Foundry target platform> |

## 2. Pinned decisions

| Decision | Value |
|---|---|
| Identity | <name, repo, slug, namespace, hostname - operator-confirmed here. The NAME is the app's fleet name and the namespace and hostname label derive from it; the REPO is the repository it ships from, a separate fact that equals the name only where an organisation names its repositories for the apps they hold; the SLUG is the delivery key, which is the repo's name and keys estimatekit and protopane. State all three even when they coincide, so the build phase onboards against a recorded decision rather than inferring one.> |
| Repo strategy | <greenfield, retrofit, or rebuild (a recast: into the scaffold the repo was born with, the layout the stack's REFs prescribe named, `_recast/` as reference, the frontend markup carried where it holds under `REF-Frontend.md`, never "in place"; `REF-Recast.md` §3, §6); the fate of existing code and history> |
| Stack | <frameworks, key libraries, with the rejected alternative named> |
| Backend / database | <or "none", with the public-by-design justification if applicable> |
| App SSO (identity realm) | <yes: gate the app's human surfaces via a per-app Keycloak realm + oauth2-proxy sidecar (a shared-instance grant); or "none", with the public-by-design or self-auth justification> |
| Registry visibility | <public or private, and the consequence the ship sequence must absorb> |
| Language(s) | <user-facing content languages> |
| Security and data | <auth model; data classification; dependency-audit gate> |
| Quality bars | <accessibility: WCAG 2.2 AA is the default target (REF-Accessibility.md section 1); name the owner and the cadence of the manual keyboard, screen-reader, zoom and forced-colours passes (section 10 there), since the automated tiers alone are not a conformance claim. Plus performance budget; browser/device matrix> |
| Autonomy level | <supervised .. full one-shot, and why it is earned here> |
| Data and licensing | <every dataset/asset: exact source, license, attribution obligation, committed vs fetched> |
| Asset budget | <size ceiling and the trade rule when it binds> |

## 3. Architecture (deviations become ADRs before code)

<!-- These ADRs and the layout sketch live in `docs/` (their durable home); this
     table is the pointer the ephemeral handoff carries, not a second copy to maintain. -->

| ADR | Decision |
|---|---|
| ADR-001 | <first architecture decision, mirroring the exemplar's ADR format> |

<layout sketch: the directory shape the run builds, with one line per top-level entry>

## 4. Data pipeline / integrations (exact sources)

| Dataset / integration | Source (exact URL or endpoint) | Transform / notes |
|---|---|---|
| <dataset> | <pinned URL, exact file or query> | <field-level gotchas the run would otherwise rediscover mid-flight> |

## 5. Requirements traceability

| REQ | Attested by |
|---|---|
| <REQ-001> | <claim ids, or "explicitly descoped: attested operationally by §9"> |

Claim lifecycle: implement the test, see it pass, then activate the claim. All claims active is part of the done-definition.

## 6. Build sequence

1. **Pre-flight** (abort only on a genuine wall the run cannot pass, the worker's `exit 64`): <the app's build/test tooling (Node/package manager), git push access, and the onboarding-studio MCP reachability. Do NOT require a local Docker daemon or a local container build: the container image is built by CI on push (`REF-AppContract.md` §4/§5), never by the run, so a missing local Docker is not a blocker, and `PACKAGES_READ_TOKEN` is a CI secret (for CI's image build), not the run's. The only local infra to name here is one the app genuinely needs at build/test time, e.g. a local database for its tests, with its start/recovery command.>
2. **Land the visual identity** into `docs/` first (`.delivery/design.md` becomes a brand page, the committed logo asset, and the palette/type as the frontend theme tokens): the look is fixed before any surface is built, so nothing is invented (`REF-Design.md` §8). On a headless line (`surface: none`) the landing is the brand page and the docs theme; there are no frontend tokens to wire.
3. <ordered build steps, each ending in a verifiable state>
4. **Land the documentation set** in `docs/` (`REF-Documentation.md` §7.11): <the pages this increment adds or updates: a Module page for each bounded context it builds or changes, a Flow page for each key sequence it adds, and the index's At-a-glance when the topology changes; on a site not in that shape, the architecture page's update>. A new page starts from its type's template in the STARLIGHT bundle (`bundles/starlight/templates/` in the `apply-intent-bundle` skill), and the why lands in the decisions collection only. The step ends with the docs site's suite green on the whole bundle (`npm test` in the docs site): a site still on the platform scaffold's one-claim floor takes the bundle once its pages are written (`REF-AppContract.md`, the contract table).
5. **Adversarial review** (fresh-eyes, the `adversarial-review` skill): review the built software for correctness, security, and contract conformance (`REF-Delivery.md` §1), and the pages step 4 landed against `REF-Documentation.md` §7.11; fix every blocker and re-run the tests. Distinct from the plan review that hardened this handoff before the run.
6. **Local verification**: <the app build and the unit + e2e suites, and the `csd-intent` audit (the attestation gate). A local container run + probe is OPTIONAL: the authoritative image build is CI's on push, so skip it when no local Docker is present rather than stopping.>

Commit style: Conventional Commits, coherent units, no co-author trailers.

## 7. Repo contract checklist

<file-by-file list the platform's conformance gate enforces, copied from the contract doc - including the exact strings/patterns the gate greps for. The gate's own checks are the authority; an exemplar app illustrates the shapes, it never overrides the gate.>

## 8. First-release and onboarding sequence (order is load-bearing)

The mechanics of this sequence - the bootstrap ordering, the commands, the post-merge contract, the sync diagnosis - are the platform's, stated once and read at run time: the onboarding skills load the current studio runbook through its MCP door, with `REF-AppContract.md` §2 as the contract. This handoff never restates them; it pins only what varies per run:

1. **The grants this delivery prices**, each pre-authorized in §0: `foundry-onboard-app` always; <`foundry-onboard-database`: yes per §2 | n/a with the reason>; <`foundry-onboard-keycloak`: yes per §2 | n/a with the reason>. Each grant ships as its own conformance-gated pull request the platform CI merges moments after it opens; the run polls the PR to merged and continues (then follows the platform runbook's verification, `REF-AppContract.md` sections 2 and 5).
2. **The released image set** the promotion bindings must cover: <the compose `build:` services plus the docs image, each with the values path its alias writes; or "single image">.
3. **The one genuinely-external step**, only when §2 prices SSO: registering the realm's callback with the shared IdP is an IdP-console change no run or studio can perform - an operator gate with its §10 degraded stop-state. A cluster or repo step is never a stop-state.

## 9. Verification: the evidence chain that means "live"

Collect ALL of these; a bare 200 proves nothing behind an edge cache:

1. CI green on the shipping commit (which workflow counts, and which may be honestly amber per §10)
2. Registry artifacts at the released version
3. The automatic deployment visible in git (the entry environment's values carry the released version)
4. Orchestrator reports the app synced/healthy; pods running at the released version
5. Origin probe of the public URL (prefer `Cache-Control: no-cache` request headers over a `?cachebust=` parameter - an edge auth proxy may match its allowlist against the query string) with freshness metadata postdating the release. Accepted, in preference order: the served document's `last-modified` header; the running pod's image tag + start time; a build-stamped runtime endpoint. NOT accepted: a hardcoded app version string, or content-addressed asset hashes (identical inputs across releases produce identical hashes - they identify inputs, not the release). On a headless line (`surface: none`) the public URL is the service's own route (a health or version route) and the docs host, each probed the same way
5b. Un-busted edge probe at the real URLs of the page and each release-varying asset, recording `CF-Cache-Status`/`Age`: a HIT whose Age predates the release means users see the previous release - purge and re-probe, or stop degraded; a cache-busted result is recorded as "origin serves X", never "verified live"
6. <app-specific smoke: e2e specs against the deployed artifacts - and state what the green proves. A suite that mocks the API proves the deployed bundle is served and navigable, nothing about the live backend; a live-backend probe (e.g. one authenticated-or-rejected route) belongs in item 5; on a headless line the smoke is the claims' integration suite against the deployed service, no browser>
7. <if §2 prices an identity realm> the identity round-trip, attested by the sign-in claims (`REF-CSD.md` §6): name them here, one per shipped shell, each run against the deployed realm. Rejecting unauthenticated traffic is a different claim and does not satisfy this item. Mark it "n/a: no identity grant" when §2 prices none
8. <if the run imports/seeds data> the import evidence records BOTH the source counts (input file/sheet rows) AND the resulting table counts, with their expected relationship pinned. When the importer derives rows (e.g. an owned item whose name is absent from the catalog creates a catalog entry), the resulting count legitimately EXCEEDS the source - verify `resulting >= source`, never equality, or reconciliation raises a false discrepancy. Prove idempotency with a distinct-key count, not the row total.

## 10. Degraded stop-states (stop, collect, report; never loop, never claim live)

| Dependency down | Terminal state and required evidence |
|---|---|
| <dependency> | <the approved end state, what remains, and the exact evidence to attach> |
| Authorized-but-interactive cluster access (kubeconfig needs an OIDC/browser login an unattended run cannot complete; the cluster is UP, the app may be serving - this is NOT the tunnel-off row) | Fall back to the public-surface + platform-studio read path and record which evidence items that path cannot satisfy; if a PINNED evidence relation is only reachable through the interactive path, end degraded on evidence completeness and name the smallest authenticated read that would close it - never write the item off, never claim the chain complete |

## 11. Post-ship (in scope for the run)

1. <one issue per §12 evolution-seed item, under one milestone per proposal phase §12 maps it to>
2. Explicitly NOT in scope: <the operator's reserved steps; the customer's acceptance (UAT) follows the close and holds nothing; the evolution board can sit on either side - pin the choice>
3. Final report: evidence chain with URLs, claim table, plan defects encountered, and a customer demo blurb (live URL only in a fully-done end; a degraded end names where it WILL be live and says so plainly). Record the build-and-ship log in `.delivery/build.md`. Its last line tells the operator the next command, and it DIFFERS by ending (`run-delivery-plan` step 5, `REF-Delivery.md` AP-26): done-definition reached - validate against the claims table, stamp the delivery gate on the operator's acceptance, then `reconcile-delivery <repo-root>`; degraded - name the blocker and the action that clears it, then re-drive this phase; reconcile only closes a finished or deliberately abandoned run

> Degraded-then-fixed: if the run stops at a §10 state and the operator later authorizes a fix that takes it live, that fix-up MUST re-arm the post-ship steps it skipped - close the resolved blocker issue with the fixing commit, and return the milestone to its normal close path (still gated on the delivery gate per §1, never closed early). A degraded run correctly leaves these open; once the app is live they are easy to forget. reconcile-delivery re-checks and flags any left stale.

## 12. Evolution seed (do not build now)

<backlog items mapped to the proposal's later phases>

## 13. Operator kickoff (trigger the run)

Name the repo here, never a local path. This section is authored days before the build runs, and the build may run from another machine or a fresh clone - so a filesystem path pinned at authoring time is stale by the time anything reads it, while the invoker always knows their own clone. `owner/name` is the same value everywhere; the operator (or the pod's checkout) resolves it to a directory at trigger time.

Primary form - invoke the builder skill in a fresh session (its mechanical pre-flight re-checks the §0 gates and refuses on any PENDING one):

> <orchestration keyword(s), if any> `/run-delivery-plan` against your clone of <the delivery repo, as owner/name>

Fallback - for an environment without the skill installed, the self-contained paste-blob (keep it filled in; it is the audit trail of what the trigger authorized):

> <trigger keyword(s)> - Execute `.delivery/handoff.md` in your clone of <the delivery repo, as owner/name> end to end, autonomously. The authorization in the handoff §0 applies: <one-line recap of grants>. NOT authorized: <the §0 not-authorized list, verbatim>. Consult `.delivery/design.md`, `docs/` (the ADRs and the visual identity), `intent.yaml`, and the REFs the handoff references. Never stop to ask; if the handoff is silent, make the smallest reasonable choice and log it as a plan defect. Finish only at the §0 done-definition or a §10 degraded terminal state, then write the §11 final report and record it in `.delivery/build.md`.
