---
name: demo-line
description: "The demo line's deterministic helpers per REF-Demo: pin the source at scope, copy its estimation project, its prototype, its claims and its tree into a demo-<x> line's own key, rename the identity, and write each gate's fidelity check as the review artifact the stamp closes over. Run by every phase of a demo line, from a pod or a terminal."
galaxy: foundry
refs:
  - REF-Demo
  - REF-Delivery
---

# Demo line

Invoked by each phase of a demo line (`REF-Demo.md`) for the mechanical half of its work, and by an operator driving one by hand at a terminal. The helper is `demo_line.py` in this folder: one script, one subcommand per act. It pins the source, copies the source line's deliverables into the demo's own key, carries the tree with its identity renamed, and writes each gate's fidelity check as the review artifact the gate helpers read. It never writes a record's frontmatter and never stamps a gate: the record helper and the gate helper of `deliver-engagement` stay the only writers of those (`REF-Delivery.md` §1, AP-30).

A phase pulls only its own skill, so a worker pod fetches this script over the playbook door (`get_skill_file` on the skill `demo-line`, path `demo_line.py`) and writes it **beside** the repo, never inside it; at a terminal it runs from this folder. The five phase skills say when to run which subcommand; this page says what each does and what it needs.

## Arguments

Every subcommand takes `--repo <repo-root>`, the demo line's checkout with its `.delivery/` mounted. The rest:

| Subcommand | Phase | Takes | Does |
|---|---|---|---|
| `open` | scope, once | `--source <owner/name>`; optional `--sha`, `--source-app`, `--app`, `--logo`, `--key` | resolves the source's default branch head and writes the pin, `.delivery/demo.json`: source, commit, the two keys, the two app names, the locked logo's path. Refuses a key that is not `demo-<source name>`, and refuses to re-pin a different source without `--force` |
| `copy-estimation` | scope | `--tool-url <estimation base>`; optional `--display`, `--no-generate` | exports the source's estimation project, scaffolds and imports the demo's, prunes the scaffold's leftovers, sets the display name, audits the copy, generates its artifacts. Exits 1 on a red audit and repairs nothing |
| `copy-prototype` | design | `--tool-url <prototype base>`; optional `--tokens-out`, `--work` | copies the theme (with its design-system provenance), every scheme and every screen into the prototype `demo-<x>`, writes `theme.json` for the close helper, and carries the locked logo from the source at the pinned commit into the repo's `docs/` |
| `copy-intent` | intent + plan | optional `--work` | carries every `intent.yaml` and every file that names one of its claims, from the source at the pinned commit, into the repo's tree, the identity renamed exactly as `carry-repo` renames it (a terminal's partial carry; a pod runs `carry-repo`) |
| `carry-repo` | intent + plan | optional `--keep <path>` (repeatable), `--work` | lands the source tree at the pinned commit over the repo's skeleton (skeleton files the source does not hold are removed, kept paths excepted, env files left behind), then renames the identity as whole tokens in every text file, the locked logo excluded |
| `attest` | every gated phase | `--phase scope|design|plan|build`; `--tool-url` for scope and design; optional `--date`, `--keep`, `--work` | compares the copy with the source at the pinned commit and writes `.delivery/reviews/<record-stem>-<date>-r<N>.md` ending `VERDICT: PASS` or `VERDICT: FAIL`. Exits 1 on FAIL; the artifact is written either way |

Doors: the studio base URL is `--tool-url`, which a pod takes from `$FC_TOOL_URL` on the phase whose gate freezes that studio (scope: the estimation engine; design: the prototyping hub) and a terminal from `ESTIMATEKIT_BASE_URL` / `PROTOPANE_BASE_URL`, with Basic credentials from `ESTIMATEKIT_AUTH_USER` / `ESTIMATEKIT_AUTH_PASSWORD` and `PROTOPANE_AUTH_USER` / `PROTOPANE_AUTH_PASSWORD` when the door asks. The source repository is fetched over git at the pinned commit with the credentials git already holds, into `--work` (default: `demo-source/` beside the repo), once per commit.

## Pre-flight

1. **Read** `REF-Demo.md` end to end and `REF-Delivery.md` §1 (the gate mechanism this helper's artifact feeds).
2. **Confirm the line is a demo.** The repo is named `demo-<x>` and the organisation holds `<x>` carrying a `delivery/*` ref or a `delivered/*` tag; a console derives this and says so in the worker's prompt, naming the source and the app names, and a terminal reads it with the repo host's CLI. After scope, `.delivery/demo.json` is the fact every later phase reads (`REF-Demo.md` §2), and every subcommand but `open` refuses without it.
3. **Confirm the doors this phase needs** (above): the studio base URL for scope and design, git read access to the source for design, plan, and build.
4. **Resolve the record and gate helpers** as any phase does (`$FC_REACH_HELPER`, `$FC_STAMP_HELPER`, or the `deliver-engagement` folder): this script writes neither the record block nor the signature.

## Steps

Each phase skill names its own demo clause; the sequence per phase is:

1. **Scope**: `open`, then `copy-estimation`, then the proposal record through the record helper (`--delivers` the newest phase the copy names, which `copy-estimation` prints), the journal line, then `attest --phase scope`.
2. **Design**: `copy-prototype`, commit the carried logo on the default branch as `docs(design): carry the source line's locked logo` (a conventional subject; the hygiene check refuses any other type), then `attest --phase design`, then the close helper with `--tokens-file theme.json --logo <the carried logo>` and the review flags the mode takes (`design-session`).
3. **Intent + plan**: `carry-repo`, the audit, commit the carry on the default branch as one `feat(demo): carry <owner/source> at <sha>` commit and push it (a releasing type: a `delivery(...)` or `docs(...)` subject merges and ships nothing; the claims and their attesting files arrive with the tree, and the release builds while the plan gate is signed), the handoff from the template with the demo's pins, the journal line, then `attest --phase plan`.
4. **Build + ship**: `carry-repo` only when the default branch does not yet hold the carry, then the two writes of `REF-Demo.md` §5, both this phase's on a demo line whatever the handoff lists: the repair (one empty `fix(release): release the carried tree` commit, only when `git tag --contains <carried sha> --list 'v[0-9]*'` prints nothing and no such commit already follows the carry, its release run waited on, red or tagless being a degraded stop) and the chart pin (`deploy-<install>`'s entry-environment `Chart.yaml` set to the released chart version, `chore(deploy): pin the <app> chart at <version>`), then `attest --phase build` once the carried commit's CI is green and before any platform act, then the handoff's onboarding sequence as any line, reconciling the app when the sync holds a comparison from before the release, the four reads of the evidence chain (`REF-Demo.md` §5), the record, the journal line.
5. **Learn**: nothing here; `reconcile-delivery` on a demo files nothing (`REF-Demo.md` §6).

The attestation artifact is the gate's review (`REF-Demo.md` §4): the stamp closes over it exactly as over a fresh-eyes review, in both modes, through the gate helper. Commit it with the record. A FAIL round is committed too, and the phase stops on it: the copy is repaired by re-running the copy subcommand, never by hand-editing the copy or the source.

## Retirement

Not a phase and not this script: an operator's acts after the show, in the order of `REF-Demo.md` §6. On the Foundry, with `<app>` the demo's app name:

1. **Runs and console state**: every Argo Workflow named `delivery-demo-<x>-*` in the console's namespace, deleted (not stopped), with the ConfigMap `fc-target-demo-<x>` and the Secret `fc-delivery-demo-<x>`.
2. **Offboard**: `foundry-offboard-app` for `<app>`, when the platform manifest carries it, with the retirement recorded as the disposition of its volumes and grants; then drop the database and realm `<app>` was granted and retire its events grant, from the platform's tear-down-a-grant guide.
3. **Studio projects**: the `demo-<x>` project deleted on the estimation engine and on the prototyping hub; archiving keeps the key.
4. **Packages**: `<app>-app`, `<app>-docs`, and `charts/<app>` in the organisation's container registry.
5. **Repo**: deleted last.

Done when the name appears nowhere: no workflow, ConfigMap, or Secret in the console's namespace, no manifest entry or `teams/<app>/` folder, no database or realm named `<app>` on the shared instances, no bus secret `nats-jwt-<app>` or `nats-<app>-pub` and no durable consumer of the app's on the event bus, no studio project (active or archived), no package, no repository.

## Failure modes

- **`open` refuses the key** - the repo's name is not `demo-` followed by the source's name; establish the line under the right name (`REF-Demo.md` §2), or pass `--key` when the checkout folder does not carry the repo's name (a pod's `/work/repo`; the console sets `$FC_SLUG`).
- **The source's estimation project audits red** - `copy-estimation` exits 1 after the copy and says so. The demo stops at scope; the source is repaired through its own maintenance loop, never from here (`REF-Demo.md` §2).
- **The source carries no prototype, no locked logo, or no `intent.yaml`** - the source line never locked that deliverable; the corresponding subcommand refuses and names it. A demo copies what shipped; it authors nothing in its place (`REF-Demo.md` §3).
- **`attest` writes a FAIL** - a comparison did not hold: a file the copy lacks, a token the rename missed, a screen the hub did not save. Re-run the phase's copy subcommand and attest again; each round is its own artifact. Never edit the artifact.
- **A studio door is unreachable** - the subcommand refuses (exit 2) naming the URL; in a pod, the phase's `$FC_TOOL_URL` is the door, and a phase whose gate freezes no studio carries none.
- **The source cannot be fetched at the pinned commit** - git holds no credential for the source's host, or the commit was garbage-collected; the pin names the commit, so the fix is the credential, never a fresh resolution (`REF-Demo.md` AP-4).
- **Right after establish the cockpit parks on a gate it never offers to sign, or offers Re-drive on a line that never ran** - a run from an earlier `demo-<x>` survived its retirement, and the console attached it to this line by name. Delete it (Retirement, act 1), then drive scope.
- **The first release dies at the image push with `permission_denied`** - a package from an earlier `demo-<x>` survived its retirement and stays bound to the deleted repository. Delete the three packages (Retirement, act 4), then re-run the release.
