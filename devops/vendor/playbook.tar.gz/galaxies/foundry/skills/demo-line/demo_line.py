#!/usr/bin/env python3
"""The demo line's deterministic helpers (REF-Demo): one script, one subcommand per act.

A demo line rehearses a shipped line `<x>` under the key `demo-<x>`. Nothing is
authored: each phase copies the source line's deliverable into the demo's own key and
attests that the copy is faithful, and the gates close by the one mechanism every line
uses. This script is the mechanical half of every phase:

    open             pin the source (repository, commit, keys, app names, logo) into
                     .delivery/demo.json on the line's scratch; scope runs it once
    copy-estimation  the source's estimation project into the demo's key, file for
                     file, then the audit and the artifacts on the copy
    copy-prototype   the source's theme, schemes and screens into the demo's prototype,
                     the locked logo into docs/, the theme tokens beside the repo
    copy-intent      intent.yaml and every file attesting one of its claims, at the
                     pinned commit, onto the default branch
    carry-repo       the source tree at the pinned commit over the repo's skeleton, the
                     identity renamed as whole tokens, the locked logo kept verbatim
    attest           the phase's fidelity check, written as the gate's review artifact
                     (.delivery/reviews/<record-stem>-<date>-r<N>.md) ending in a
                     VERDICT line; a failing round is written too

Stdlib only, so it runs in a worker pod and at a terminal alike. Studio doors are
reached over their base URL (a pod: $FC_TOOL_URL on the phase whose gate freezes that
studio; a terminal: ESTIMATEKIT_BASE_URL / PROTOPANE_BASE_URL) with optional Basic
credentials from the environment (ESTIMATEKIT_AUTH_USER/PASSWORD,
PROTOPANE_AUTH_USER/PASSWORD). The source repository is read over git at the pinned
commit: a GitHub URL carries the token the environment holds (GH_TOKEN, FC_GIT_TOKEN, or
GITHUB_TOKEN, the pod's own phase identity) as the fixed x-access-token user, and any
other URL relies on the credentials git already holds. The token never lands in a remote,
a pin, or a message.

Exit codes: 0 done, 1 a check or an audit did not pass (the artifact is still written),
2 a refusal (missing pin, unreachable door, wrong key).
"""

from __future__ import annotations

import argparse
import base64
import io
import json
import os
import re
import shutil
import subprocess
import sys
import urllib.error
import urllib.request
import zipfile
from datetime import date as _date
from pathlib import Path, PurePosixPath
from typing import NamedTuple

__all__ = ["main"]

SCRATCH = ".delivery"
PIN_FILE = "demo.json"
REVIEWS_DIR = "reviews"
DEFAULT_LOGO = "docs/logo.svg"
DEMO_PREFIX = "demo-"

#: The record each phase's gate closes over, by the phase name attest takes.
RECORD_STEMS = {"scope": "proposal", "design": "design", "plan": "handoff", "build": "build"}

#: Directories no tree read or write ever enters: the repository's own metadata, the
#: line's scratch, and build or dependency output that is never part of a deliverable.
SKIP_DIRS = frozenset({".git", ".delivery", "node_modules", "__pycache__", ".venv", ".pytest_cache", "dist", "build", ".astro"})

#: project.yaml keys the estimation copy legitimately changes: the display identity.
PROJECT_IDENTITY_KEYS = ("name", "short_name")

_ENV_FILE = re.compile(r"^\.env(\..+)?$")
# The intent id grammar csd-intent accepts: INT- and any run of upper-case letters, digits
# and hyphens, so a multi-segment family (INT-HELLO-SPA-001) and a lettered number
# (INT-FC-R149) are both ids.
_CLAIM_ID = re.compile(r"\bINT-[A-Z0-9]+(?:-[A-Z0-9]+)*\b")
#: A claim an intent file declares: the id as a top-level key at the start of a line.
_DECLARED_CLAIM = re.compile(r"^(INT-[A-Z0-9]+(?:-[A-Z0-9]+)*)\s*:", re.MULTILINE)
# A name is renamed wherever it stands as a whole hyphen-delimited token: inside a word it
# is another word, but after a hyphen it is the app's name in a compound the platform
# derives from it (keycloak-<app>, pg-app-<app>, <app>-docs). A name the mapping knows
# under a longer key (an organisation's prefixed repository) is taken once, as that key,
# because the alternation tries the longest key first at every position.
_TOKEN_HEAD = r"(?<![A-Za-z0-9_])"
_TOKEN_TAIL = r"(?![A-Za-z0-9_])"
_MAX_LISTED = 40


class Check(NamedTuple):
    """One comparison the fidelity check made."""

    name: str
    ok: bool
    detail: str


# ---------------------------------------------------------------------------
# Pure helpers (tested by the playbook's own suite)
# ---------------------------------------------------------------------------


def demo_key(source_key: str) -> str:
    """The demo's delivery key for a source key: the prefix, then the source's name."""
    return f"{DEMO_PREFIX}{source_key}"


def rename_mapping(pin: dict) -> dict[str, str]:
    """What the identity rename replaces: the source key by the demo key, and the source
    app's fleet name by the demo app's where the two facts differ (REF-Demo section 3)."""
    mapping = {pin["source_key"]: pin["key"]}
    if pin["source_app"] != pin["source_key"]:
        mapping[pin["source_app"]] = pin["app"]
    return mapping


def rename_pattern(mapping: dict[str, str]) -> re.Pattern[str]:
    """Whole-token alternation, longest key first, so `org-<x>` is taken as one token
    before `<x>` can match inside it, and `<x>` never matches inside `<x>y`."""
    keys = sorted(mapping, key=len, reverse=True)
    return re.compile(_TOKEN_HEAD + "(" + "|".join(re.escape(k) for k in keys) + ")" + _TOKEN_TAIL)


def rename_text(text: str, mapping: dict[str, str]) -> tuple[str, int]:
    """The text with every whole-token occurrence of a mapping key replaced, and the count."""
    if not mapping:
        return text, 0
    pattern = rename_pattern(mapping)
    count = 0

    def _sub(match: re.Match[str]) -> str:
        nonlocal count
        count += 1
        return mapping[match.group(1)]

    return pattern.sub(_sub, text), count


def is_text(data: bytes) -> bool:
    """A file the rename may touch: no NUL in its head and decodable as UTF-8."""
    if b"\x00" in data[:8000]:
        return False
    try:
        data.decode("utf-8")
    except UnicodeDecodeError:
        return False
    return True


def is_env_file(name: str) -> bool:
    """An env file the carry leaves behind (REF-Recast section 2); examples travel."""
    return bool(_ENV_FILE.match(name)) and not name.endswith(".example")


def walk_tree(root: Path, *, skip_dirs: frozenset[str] = SKIP_DIRS) -> dict[str, bytes]:
    """Every file under root as posix-relative path -> bytes, skipping the excluded
    directories at any depth and the env files that never ride."""
    out: dict[str, bytes] = {}
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = sorted(d for d in dirnames if d not in skip_dirs)
        for filename in sorted(filenames):
            if is_env_file(filename):
                continue
            path = Path(dirpath) / filename
            rel = PurePosixPath(path.relative_to(root).as_posix())
            out[str(rel)] = path.read_bytes()
    return out


def renamed_tree(tree: dict[str, bytes], mapping: dict[str, str], logo: str) -> dict[str, bytes]:
    """The source tree as the carry lands it: text files renamed, the locked logo and
    every binary file byte-identical."""
    out: dict[str, bytes] = {}
    for path, data in tree.items():
        if path == logo or not is_text(data):
            out[path] = data
            continue
        text, _ = rename_text(data.decode("utf-8"), mapping)
        out[path] = text.encode("utf-8")
    return out


def claim_ids(intent_text: str) -> set[str]:
    """Every claim an intent file declares: its top-level keys, and only those. A claim id
    mentioned in a comment or a rationale is a reference, never a claim of this file."""
    return {m.group(1) for m in _DECLARED_CLAIM.finditer(intent_text)}


def intent_files(tree: dict[str, bytes]) -> list[str]:
    """Every intent.yaml in the tree, wherever it sits."""
    return sorted(p for p in tree if PurePosixPath(p).name == "intent.yaml")


def attesting_files(tree: dict[str, bytes], ids: set[str]) -> list[str]:
    """Every text file that names one of the claims: the test surface that attests them."""
    if not ids:
        return []
    pattern = re.compile(r"\b(" + "|".join(re.escape(i) for i in sorted(ids)) + r")\b")
    out: list[str] = []
    for path, data in tree.items():
        if PurePosixPath(path).name == "intent.yaml" or not is_text(data):
            continue
        if pattern.search(data.decode("utf-8")):
            out.append(path)
    return sorted(out)


def intent_surface(tree: dict[str, bytes]) -> list[str]:
    """The claims and what attests them: every intent.yaml plus every file naming a claim."""
    files = intent_files(tree)
    ids: set[str] = set()
    for path in files:
        ids |= claim_ids(tree[path].decode("utf-8", errors="replace"))
    return sorted(set(files) | set(attesting_files(tree, ids)))


def intent_landing(tree: dict[str, bytes], mapping: dict[str, str], logo: str) -> dict[str, bytes]:
    """The claims surface as the carry lands it: every file of intent_surface, the
    identity renamed exactly as renamed_tree renames the whole tree. One landing for
    the copy and for the check, so the two can never demand different bytes: a claims
    file names the app, the carry renames it, and the plan check compares against
    the renamed bytes it will actually find."""
    landed = renamed_tree(tree, mapping, logo)
    return {path: landed[path] for path in intent_surface(tree) if path in landed}


_NAME_LINE = re.compile(r"^name:.*$", re.MULTILINE)


def set_project_name(project_yaml: bytes, name: str) -> bytes:
    """The project file with its top-level ``name:`` line replaced by the given display
    name and every other byte kept: comments, order, and quoting included. A rename
    through the engine's own door would re-serialise the file, which is exactly the
    difference the fidelity check must not see."""
    text = project_yaml.decode("utf-8", errors="replace")
    quoted = '"' + name.replace("\\", "\\\\").replace('"', '\\"') + '"'
    replaced, count = _NAME_LINE.subn(f"name: {quoted}", text, count=1)
    return (replaced if count else text).encode("utf-8")


def strip_identity(project_yaml: bytes) -> bytes:
    """project.yaml without its display-identity lines, which the copy legitimately renames."""
    keep: list[str] = []
    for line in project_yaml.decode("utf-8", errors="replace").splitlines():
        key = line.split(":", 1)[0].strip() if ":" in line else ""
        if key in PROJECT_IDENTITY_KEYS and not line.startswith((" ", "\t")):
            continue
        keep.append(line)
    return "\n".join(keep).encode("utf-8")


def compare_maps(expected: dict[str, bytes], actual: dict[str, bytes], *, subject: str) -> list[Check]:
    """Path-by-path equality of two byte maps, summarised: presence, equality, and one
    line per difference up to a cap. Extra paths in `actual` are a difference too."""
    missing = sorted(p for p in expected if p not in actual)
    extra = sorted(p for p in actual if p not in expected)
    differs = sorted(p for p in expected if p in actual and expected[p] != actual[p])
    total = len(expected)
    checks = [
        Check(f"{subject}: every source file present", not missing, f"{total - len(missing)} of {total}"),
        Check(f"{subject}: every present file byte-identical", not differs, f"{total - len(missing) - len(differs)} of {total - len(missing)}"),
        Check(f"{subject}: nothing beyond the source", not extra, f"{len(extra)} extra"),
    ]
    for label, paths in (("missing", missing), ("differs", differs), ("extra", extra)):
        for path in paths[:_MAX_LISTED]:
            checks.append(Check(f"{subject}: {path}", False, label))
        if len(paths) > _MAX_LISTED:
            checks.append(Check(f"{subject}: and {len(paths) - _MAX_LISTED} more", False, label))
    return checks


def compare_exports(source: dict[str, bytes], copy: dict[str, bytes]) -> list[Check]:
    """The estimation copy against the source's export: byte-identical but for the
    project's own display identity."""

    def _norm(entries: dict[str, bytes]) -> dict[str, bytes]:
        return {p: (strip_identity(d) if PurePosixPath(p).name == "project.yaml" else d) for p, d in entries.items()}

    return compare_maps(_norm(source), _norm(copy), subject="estimation project")


def compare_prototypes(source: dict, copy: dict) -> list[Check]:
    """The prototype copy against the source project: theme tokens, design-system
    provenance, every scheme and every screen by slug, and nothing beyond them."""
    checks = [
        Check("prototype: theme tokens equal", source.get("theme", {}).get("tokens") == copy.get("theme", {}).get("tokens"), f"{len(source.get('theme', {}).get('tokens') or {})} tokens"),
        Check(
            "prototype: design-system provenance equal",
            (source.get("design_system") or {}).get("slug") == (copy.get("design_system") or {}).get("slug"),
            (source.get("design_system") or {}).get("slug") or "none",
        ),
    ]
    for kind, fields in (("schemes", ("name", "tokens")), ("screens", ("name", "html", "css"))):
        src = {s["slug"]: s for s in source.get(kind, [])}
        dst = {s["slug"]: s for s in copy.get(kind, [])}
        expected = {k: json.dumps({f: v.get(f) for f in fields}, sort_keys=True).encode("utf-8") for k, v in src.items()}
        actual = {k: json.dumps({f: v.get(f) for f in fields}, sort_keys=True).encode("utf-8") for k, v in dst.items()}
        checks.extend(compare_maps(expected, actual, subject=f"prototype {kind}"))
    return checks


def next_review_path(repo: Path, stem: str, day: str) -> Path:
    """The next round's artifact path for this record and date: r1, then r2, and so on."""
    reviews = repo / SCRATCH / REVIEWS_DIR
    rounds = [
        int(m.group(1))
        for p in (reviews.glob(f"{stem}-{day}-r*.md") if reviews.is_dir() else ())
        if (m := re.fullmatch(rf"{re.escape(stem)}-{re.escape(day)}-r(\d+)\.md", p.name))
    ]
    return reviews / f"{stem}-{day}-r{max(rounds, default=0) + 1}.md"


def render_review(stem: str, pin: dict, checks: list[Check], day: str) -> str:
    """The review artifact: what was compared, against what, and the verdict as its last
    line, in the shape the gate helpers read (the last VERDICT token decides)."""
    verdict = "PASS" if all(c.ok for c in checks) else "FAIL"
    lines = [
        f"# Fidelity check: {stem} on a demo line",
        "",
        f"Written by `demo_line.py attest` on {day}, deterministically (REF-Demo section 4). "
        f"This line rehearses `{pin['source']}` at `{pin['sha']}` under the key `{pin['key']}`; "
        "the quality evidence for what it copies is the source line's own signed gates, and this "
        "check asserts only that the copy is faithful to the source at that commit.",
        "",
        "| Check | Result | Detail |",
        "| --- | --- | --- |",
    ]
    for c in checks:
        lines.append(f"| {c.name} | {'PASS' if c.ok else 'FAIL'} | {c.detail} |")
    failing = [c for c in checks if not c.ok]
    lines += ["", "Findings: " + ("none." if not failing else f"{len(failing)} comparison(s) did not hold; see the table.")]
    lines += ["", f"VERDICT: {verdict}", ""]
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# The pin
# ---------------------------------------------------------------------------


def pin_path(repo: Path) -> Path:
    return repo / SCRATCH / PIN_FILE


def load_pin(repo: Path) -> dict:
    path = pin_path(repo)
    if not path.is_file():
        _refuse(f"no {SCRATCH}/{PIN_FILE} under {repo}: the line was not opened as a demo; scope runs `open` first (REF-Demo section 2).")
    return json.loads(path.read_text(encoding="utf-8"))


# ---------------------------------------------------------------------------
# Doors
# ---------------------------------------------------------------------------


def _auth(prefix: str) -> str | None:
    user = os.environ.get(f"{prefix}_AUTH_USER", "")
    password = os.environ.get(f"{prefix}_AUTH_PASSWORD", "")
    if not user and not password:
        return None
    return "Basic " + base64.b64encode(f"{user}:{password}".encode("utf-8")).decode("ascii")


def _http(method: str, url: str, *, data: bytes | None = None, content_type: str | None = None, auth: str | None = None) -> tuple[int, bytes]:
    headers = {"Accept": "application/json, application/zip, */*"}
    if content_type:
        headers["Content-Type"] = content_type
    if auth:
        headers["Authorization"] = auth
    request = urllib.request.Request(url, data=data, method=method, headers=headers)
    try:
        with urllib.request.urlopen(request, timeout=300) as response:  # noqa: S310  the door the caller named
            return response.status, response.read()
    except urllib.error.HTTPError as err:
        return err.code, err.read()
    except (urllib.error.URLError, OSError) as err:
        _refuse(f"{method} {url} unreachable ({err}).")


def _json(method: str, url: str, *, body: dict | None = None, auth: str | None = None) -> tuple[int, object]:
    data = json.dumps(body).encode("utf-8") if body is not None else None
    status, raw = _http(method, url, data=data, content_type="application/json" if data is not None else None, auth=auth)
    try:
        return status, json.loads(raw.decode("utf-8")) if raw else None
    except json.JSONDecodeError:
        return status, raw.decode("utf-8", errors="replace")


def _base(arg: str | None, env: str) -> str:
    base = (arg or os.environ.get(env, "")).rstrip("/")
    if not base:
        _refuse(f"no studio base URL: pass --tool-url or set {env} (a pod: $FC_TOOL_URL on this phase).")
    return base


def _multipart(field: str, filename: str, data: bytes, content_type: str) -> tuple[bytes, str]:
    boundary = "demo-line-" + base64.b16encode(os.urandom(8)).decode("ascii").lower()
    body = (
        f"--{boundary}\r\nContent-Disposition: form-data; name=\"{field}\"; filename=\"{filename}\"\r\n"
        f"Content-Type: {content_type}\r\n\r\n"
    ).encode("utf-8") + data + f"\r\n--{boundary}--\r\n".encode("utf-8")
    return body, f"multipart/form-data; boundary={boundary}"


def zip_map(data: bytes) -> dict[str, bytes]:
    with zipfile.ZipFile(io.BytesIO(data)) as zf:
        return {i.filename: zf.read(i.filename) for i in zf.infolist() if not i.is_dir()}


def map_zip(files: dict[str, bytes]) -> bytes:
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for path in sorted(files):
            zf.writestr(path, files[path])
    return buf.getvalue()


# --- the estimation engine ---


def estimation_export(base: str, slug: str, auth: str | None) -> dict[str, bytes]:
    status, raw = _http("GET", f"{base}/api/projects/{slug}/export", auth=auth)
    if status != 200:
        _refuse(f"estimation project {slug!r} did not export from {base} (HTTP {status}).")
    return zip_map(raw)


def estimation_scaffold(base: str, slug: str, auth: str | None) -> str:
    status, body = _json("POST", f"{base}/api/projects/scaffold", body={"slug": slug, "force": False}, auth=auth)
    if 200 <= status < 300:
        return "created"
    if "exist" in json.dumps(body).lower():
        return "exists"
    _refuse(f"estimation project {slug!r} could not be scaffolded at {base} (HTTP {status}: {body}).")


def estimation_import(base: str, slug: str, files: dict[str, bytes], auth: str | None) -> None:
    body, content_type = _multipart("file", f"{slug}.zip", map_zip(files), "application/zip")
    status, raw = _http("POST", f"{base}/api/projects/{slug}/import", data=body, content_type=content_type, auth=auth)
    if not 200 <= status < 300:
        _refuse(f"estimation project {slug!r} did not accept the import (HTTP {status}: {raw[:200]!r}).")


def estimation_files(base: str, slug: str, auth: str | None) -> list[str]:
    status, body = _json("GET", f"{base}/api/projects/{slug}/files", auth=auth)
    if status != 200 or not isinstance(body, dict):
        _refuse(f"estimation project {slug!r} did not list its files (HTTP {status}).")
    return sorted(str(f.get("path")) for f in body.get("files", []) if f.get("path"))


def estimation_delete(base: str, slug: str, path: str, auth: str | None) -> None:
    status, _ = _http("DELETE", f"{base}/api/projects/{slug}/files/{path}", auth=auth)
    if not 200 <= status < 300:
        _refuse(f"estimation project {slug!r}: could not delete {path!r} (HTTP {status}).")


def estimation_audit(base: str, slug: str, auth: str | None) -> dict:
    status, body = _json("POST", f"{base}/api/projects/{slug}/audit", auth=auth)
    if status != 200 or not isinstance(body, dict):
        _refuse(f"estimation project {slug!r} did not audit (HTTP {status}).")
    return body


def estimation_generate(base: str, slug: str, auth: str | None, phase: str | None = None) -> object:
    """Run every pipeline; *phase* names the phase the deck sells (the newest in the copy)."""
    payload: dict[str, object] = {"pipelines": None}
    if phase:
        payload["phase"] = phase
    status, body = _json("POST", f"{base}/api/projects/{slug}/generate", body=payload, auth=auth)
    if not 200 <= status < 300:
        _refuse(f"estimation project {slug!r} did not generate (HTTP {status}: {body}).")
    return body


# --- the prototyping hub ---


def prototype_get(base: str, slug: str, auth: str | None) -> dict | None:
    status, body = _json("GET", f"{base}/api/projects/{slug}", auth=auth)
    if status == 404:
        return None
    if status != 200 or not isinstance(body, dict):
        _refuse(f"prototype {slug!r} did not read from {base} (HTTP {status}).")
    return body


def prototype_create(base: str, name: str, auth: str | None) -> dict:
    status, body = _json("POST", f"{base}/api/projects", body={"name": name, "template": None}, auth=auth)
    if status == 409:
        existing = prototype_get(base, name, auth)
        if existing is None:
            _refuse(f"prototype {name!r} reads as existing and absent at once at {base}.")
        return existing
    if not 200 <= status < 300 or not isinstance(body, dict):
        _refuse(f"prototype {name!r} could not be created at {base} (HTTP {status}: {body}).")
    return body


def prototype_put(base: str, slug: str, kind: str, sub: str | None, body: dict, auth: str | None) -> None:
    url = f"{base}/api/projects/{slug}/{kind}" + (f"/{sub}" if sub else "")
    status, answer = _json("PUT", url, body=body, auth=auth)
    if not 200 <= status < 300:
        _refuse(f"prototype {slug!r}: {kind}{'/' + sub if sub else ''} was not saved (HTTP {status}: {answer}).")


def prototype_delete(base: str, slug: str, kind: str, sub: str, auth: str | None) -> None:
    status, answer = _json("DELETE", f"{base}/api/projects/{slug}/{kind}/{sub}", auth=auth)
    if not 200 <= status < 300:
        _refuse(f"prototype {slug!r}: {kind}/{sub} was not deleted (HTTP {status}: {answer}).")


# --- the source repository over git ---


_TOKEN_ENV = ("GH_TOKEN", "FC_GIT_TOKEN", "GITHUB_TOKEN")
_TOKEN_IN_URL = re.compile(r"//x-access-token:[^@/]+@")


def authed_url(url: str) -> str:
    """The source's clone URL as git should reach it: a GitHub https URL carrying no
    credential takes the token the environment holds, under the fixed x-access-token
    user a worker's own clone uses; any other URL is returned as it is."""
    if not url.startswith("https://github.com/") or "@" in url.split("//", 1)[1].split("/", 1)[0]:
        return url
    token = next((os.environ.get(k, "").strip() for k in _TOKEN_ENV if os.environ.get(k, "").strip()), "")
    if not token:
        return url
    return url.replace("https://github.com/", f"https://x-access-token:{token}@github.com/", 1)


def redact(text: str) -> str:
    """Any token a URL carries, hidden before the text reaches a message."""
    return _TOKEN_IN_URL.sub("//x-access-token:***@", text)


def _git(*args: str, cwd: Path | None = None) -> str:
    result = subprocess.run(["git", *args], cwd=cwd, capture_output=True, text=True, check=False)
    if result.returncode != 0:
        _refuse(redact(f"git {' '.join(args)} failed: {result.stderr.strip() or result.stdout.strip()}"))
    return result.stdout


def resolve_head(url: str) -> str:
    out = _git("ls-remote", authed_url(url), "HEAD")
    sha = out.split()[0] if out.split() else ""
    if not re.fullmatch(r"[0-9a-f]{40}", sha):
        _refuse(f"could not resolve the default branch head of {url}.")
    return sha


def source_checkout(pin: dict, work: Path) -> Path:
    """The source tree at the pinned commit, fetched once per commit into the work dir
    and reused: a fresh pod fetches, a terminal reuses."""
    target = work / f"source-{pin['sha'][:12]}"
    if (target / ".git").is_dir():
        head = subprocess.run(["git", "rev-parse", "HEAD"], cwd=target, capture_output=True, text=True, check=False).stdout.strip()
        if head == pin["sha"]:
            return target
        shutil.rmtree(target, ignore_errors=True)
    target.mkdir(parents=True, exist_ok=True)
    _git("init", "-q", cwd=target)
    # The URL is passed to the fetch itself and never recorded as a remote, so the token
    # it may carry lives in the process and nowhere on disk.
    _git("fetch", "-q", "--depth", "1", authed_url(pin["source_url"]), pin["sha"], cwd=target)
    _git("checkout", "-q", "FETCH_HEAD", cwd=target)
    return target


# ---------------------------------------------------------------------------
# Commands
# ---------------------------------------------------------------------------


def cmd_open(args: argparse.Namespace) -> int:
    repo = Path(args.repo).resolve()
    if not (repo / SCRATCH).is_dir():
        _refuse(f"no {SCRATCH}/ under {repo}: establish the line first (the scratch helper), then open the demo.")
    source = args.source.strip().strip("/")
    if source.count("/") != 1:
        _refuse(f"--source must be owner/name, got {source!r}.")
    source_key = source.split("/")[1]
    key = (args.key or os.environ.get("FC_SLUG") or repo.name).strip()
    if key != demo_key(source_key):
        _refuse(f"the key {key!r} is not {demo_key(source_key)!r}: a demo line's key is the prefix and the source's name (REF-Demo section 2).")
    source_app = (args.source_app or source_key).strip()
    app = (args.app or demo_key(source_app)).strip()
    source_url = args.source_url or f"https://github.com/{source}.git"
    sha = args.sha or resolve_head(source_url)
    if not re.fullmatch(r"[0-9a-f]{40}", sha):
        _refuse(f"--sha must be a full commit id, got {sha!r}.")
    pin = {
        "source": source,
        "source_url": source_url,
        "sha": sha,
        "source_key": source_key,
        "key": key,
        "source_app": source_app,
        "app": app,
        "logo": args.logo,
        "opened": args.date,
    }
    path = pin_path(repo)
    if path.is_file() and not args.force:
        existing = json.loads(path.read_text(encoding="utf-8"))
        if {k: v for k, v in existing.items() if k != "opened"} != {k: v for k, v in pin.items() if k != "opened"}:
            _refuse(f"{SCRATCH}/{PIN_FILE} already pins a different source; a phase never re-resolves the source (REF-Demo section 2). Pass --force only to re-open the line deliberately.")
        print(f"Demo pin already present at {path} (unchanged).")
        return 0
    path.write_text(json.dumps(pin, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(f"Demo pin written: {path}")
    for k in ("source", "sha", "key", "app", "source_app", "logo"):
        print(f"  {k}: {pin[k]}")
    return 0


def cmd_copy_estimation(args: argparse.Namespace) -> int:
    repo = Path(args.repo).resolve()
    pin = load_pin(repo)
    base = _base(args.tool_url, "ESTIMATEKIT_BASE_URL")
    auth = _auth("ESTIMATEKIT")
    files = estimation_export(base, pin["source_key"], auth)
    print(f"Exported {len(files)} file(s) from estimation project {pin['source_key']!r} at {base}.")
    display = args.display or f"{pin['key']} (demo of {pin['source_key']})"
    if "project.yaml" in files:
        # The display name is set in the exported text itself, so the copy's project file
        # differs from the source's in that one line and nothing else.
        files = {**files, "project.yaml": set_project_name(files["project.yaml"], display)}
    print(f"Scaffold {pin['key']!r}: {estimation_scaffold(base, pin['key'], auth)}.")
    estimation_import(base, pin["key"], files, auth)
    pruned = [p for p in estimation_files(base, pin["key"], auth) if p not in files]
    for path in pruned:
        estimation_delete(base, pin["key"], path, auth)
    print(f"Imported {len(files)} file(s) into {pin['key']!r} as {display!r}; pruned {len(pruned)} scaffold leftover(s).")
    phases = _phases(files)
    if phases:
        print(f"Phases in the copy: {', '.join(phases)}; newest: {phases[-1]}.")
    report = estimation_audit(base, pin["key"], auth)
    failed = [c for c in report.get("checks", []) if str(c.get("outcome", "")).lower() not in ("pass", "passed", "skip", "skipped")]
    print(f"Audit on the copy: {'passed' if report.get('passed') else 'FAILED'} ({report.get('passed_count')} passed, {report.get('failed_count')} failed, {report.get('skipped_count')} skipped).")
    if not report.get("passed"):
        for c in failed[:_MAX_LISTED]:
            print(f"  FAIL {c.get('node_id')}: {c.get('message')}")
        print("The source's estimation project audits red; a demo copies and stops, it never repairs the source (REF-Demo section 2).")
        return 1
    if not args.no_generate:
        newest = phases[-1] if phases else None
        estimation_generate(base, pin["key"], auth, phase=newest)
        deck = f"the deck for {newest}" if newest else "deck"
        print(f"Generated the copy's artifacts (roadmap, workbooks, {deck}).")
    return 0


def _phases(files: dict[str, bytes]) -> list[str]:
    """The P<n> phases the project's data names, in order."""
    found: set[str] = set()
    for path in files:
        m = re.search(r"(?:^|/)(P\d+)-", path)
        if m:
            found.add(m.group(1))
    return sorted(found, key=lambda p: int(p[1:]))


def cmd_copy_prototype(args: argparse.Namespace) -> int:
    repo = Path(args.repo).resolve()
    pin = load_pin(repo)
    base = _base(args.tool_url, "PROTOPANE_BASE_URL")
    auth = _auth("PROTOPANE")
    source = prototype_get(base, pin["source_key"], auth)
    if source is None:
        _refuse(f"prototype {pin['source_key']!r} is absent at {base}; the source line locked no prototype to copy.")
    copy = prototype_create(base, pin["key"], auth)
    if copy.get("slug") != pin["key"]:
        _refuse(f"the hub named the copy {copy.get('slug')!r}, not {pin['key']!r}; the cockpit could not link it (REF-Delivery AP-33).")
    theme = {"tokens": source["theme"]["tokens"]}
    if source.get("design_system"):
        theme["design_system"] = source["design_system"]["slug"]
    prototype_put(base, pin["key"], "theme", None, theme, auth)
    for scheme in source.get("schemes", []):
        prototype_put(base, pin["key"], "schemes", scheme["slug"], {"name": scheme["name"], "tokens": scheme["tokens"]}, auth)
    for screen in source.get("screens", []):
        prototype_put(base, pin["key"], "screens", screen["slug"], {"name": screen["name"], "html": screen["html"], "css": screen["css"]}, auth)
    after = prototype_get(base, pin["key"], auth) or {}
    for kind in ("schemes", "screens"):
        wanted = {s["slug"] for s in source.get(kind, [])}
        for item in after.get(kind, []):
            if item["slug"] not in wanted:
                prototype_delete(base, pin["key"], kind, item["slug"], auth)
    print(f"Prototype {pin['key']!r} carries the source's theme, {len(source.get('schemes', []))} scheme(s) and {len(source.get('screens', []))} screen(s).")
    tokens_out = Path(args.tokens_out)
    tokens_out.write_text(json.dumps({"theme": {"tokens": source["theme"]["tokens"]}}, indent=2) + "\n", encoding="utf-8")
    print(f"Theme tokens written for the close helper: {tokens_out}")
    checkout = source_checkout(pin, Path(args.work))
    logo_src = checkout / pin["logo"]
    if not logo_src.is_file():
        _refuse(f"the source carries no locked logo at {pin['logo']} ({pin['source']}@{pin['sha'][:12]}); the design close cannot lock without one.")
    logo_dst = repo / pin["logo"]
    logo_dst.parent.mkdir(parents=True, exist_ok=True)
    logo_dst.write_bytes(logo_src.read_bytes())
    print(f"Locked logo carried verbatim: {pin['logo']} (commit it on the default branch before the close).")
    return 0


def cmd_copy_intent(args: argparse.Namespace) -> int:
    repo = Path(args.repo).resolve()
    pin = load_pin(repo)
    checkout = source_checkout(pin, Path(args.work))
    tree = walk_tree(checkout)
    surface = intent_surface(tree)
    if not surface:
        _refuse(f"the source carries no intent.yaml at {pin['sha'][:12]}; there are no claims to carry.")
    for intent_path in intent_files(tree):
        ids = claim_ids(tree[intent_path].decode("utf-8", errors="replace"))
        if ids and not attesting_files(tree, ids):
            # A copy that silently carries no test surface is worse than one that stops:
            # the audit would be the only thing to catch it, one phase later.
            _refuse(f"{intent_path} declares {len(ids)} claim(s) and no file in the source attests any of them; nothing to carry for it, which is a source defect, never one to author around.")
    landing = intent_landing(tree, rename_mapping(pin), pin["logo"])
    for path, data in landing.items():
        dst = repo / path
        dst.parent.mkdir(parents=True, exist_ok=True)
        dst.write_bytes(data)
    print(f"Carried the claims and their test surface from {pin['source']}@{pin['sha'][:12]}, the identity renamed as the carry renames it ({len(landing)} file(s)):")
    for path in landing:
        print(f"  {path}")
    return 0


def cmd_carry_repo(args: argparse.Namespace) -> int:
    repo = Path(args.repo).resolve()
    pin = load_pin(repo)
    checkout = source_checkout(pin, Path(args.work))
    source_tree = walk_tree(checkout)
    keep = set(args.keep or [])
    mapping = rename_mapping(pin)
    landed = renamed_tree(source_tree, mapping, pin["logo"])
    current = walk_tree(repo)
    removed = [p for p in current if p not in landed and p not in keep]
    for path in removed:
        (repo / path).unlink()
    for path, data in landed.items():
        if path in keep and (repo / path).exists():
            continue
        dst = repo / path
        dst.parent.mkdir(parents=True, exist_ok=True)
        dst.write_bytes(data)
    renamed: list[tuple[str, int]] = []
    for path, data in source_tree.items():
        if path == pin["logo"] or not is_text(data):
            continue
        _, count = rename_text(data.decode("utf-8"), mapping)
        if count:
            renamed.append((path, count))
    print(f"Carried {len(landed)} file(s) from {pin['source']}@{pin['sha'][:12]}; removed {len(removed)} skeleton file(s) the source does not hold; kept {len(keep & set(current))} as told.")
    print(f"Identity rename ({', '.join(f'{k} -> {v}' for k, v in mapping.items())}), whole tokens, the locked logo excluded: {sum(c for _, c in renamed)} occurrence(s) in {len(renamed)} file(s).")
    for path, count in renamed:
        print(f"  {count:4d} {path}")
    return 0


def cmd_attest(args: argparse.Namespace) -> int:
    repo = Path(args.repo).resolve()
    pin = load_pin(repo)
    stem = RECORD_STEMS[args.phase]
    checks = _checks_for(args, repo, pin)
    path = next_review_path(repo, stem, args.date)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(render_review(stem, pin, checks, args.date), encoding="utf-8")
    verdict = "PASS" if all(c.ok for c in checks) else "FAIL"
    print(f"{path.relative_to(repo).as_posix()}: VERDICT: {verdict} ({sum(c.ok for c in checks)} of {len(checks)} checks hold)")
    for c in checks:
        if not c.ok:
            print(f"  FAIL {c.name}: {c.detail}")
    return 0 if verdict == "PASS" else 1


def _checks_for(args: argparse.Namespace, repo: Path, pin: dict) -> list[Check]:
    if args.phase == "scope":
        base = _base(args.tool_url, "ESTIMATEKIT_BASE_URL")
        auth = _auth("ESTIMATEKIT")
        checks = compare_exports(estimation_export(base, pin["source_key"], auth), estimation_export(base, pin["key"], auth))
        report = estimation_audit(base, pin["key"], auth)
        checks.append(Check("estimation project: audit clean on the copy", bool(report.get("passed")), f"{report.get('failed_count')} failed"))
        return checks
    if args.phase == "design":
        base = _base(args.tool_url, "PROTOPANE_BASE_URL")
        auth = _auth("PROTOPANE")
        source = prototype_get(base, pin["source_key"], auth) or {}
        copy = prototype_get(base, pin["key"], auth) or {}
        checks = [Check("prototype: the copy exists under the demo key", bool(copy), pin["key"])]
        checks += compare_prototypes(source, copy)
        checkout = source_checkout(pin, Path(args.work))
        src_logo, dst_logo = checkout / pin["logo"], repo / pin["logo"]
        checks.append(Check("locked logo: byte-identical to the source's", src_logo.is_file() and dst_logo.is_file() and src_logo.read_bytes() == dst_logo.read_bytes(), pin["logo"]))
        return checks
    checkout = source_checkout(pin, Path(args.work))
    source_tree = walk_tree(checkout)
    if args.phase == "plan":
        repo_tree = walk_tree(repo)
        expected = intent_landing(source_tree, rename_mapping(pin), pin["logo"])
        actual = {p: repo_tree[p] for p in expected if p in repo_tree}
        checks = compare_maps(expected, actual, subject="claims and their tests")
        handoff = repo / SCRATCH / "handoff.md"
        checks.append(Check("handoff: present and non-empty", handoff.is_file() and handoff.stat().st_size > 0, str(PurePosixPath(SCRATCH, "handoff.md"))))
        return checks
    expected = renamed_tree(source_tree, rename_mapping(pin), pin["logo"])
    actual = walk_tree(repo)
    for path in args.keep or []:
        actual.pop(path, None)
        expected.pop(path, None)
    return compare_maps(expected, actual, subject="carried tree")


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------


def _refuse(message: str) -> None:
    print(f"REFUSED: {redact(message)}", file=sys.stderr)
    sys.exit(2)


def _add_common(parser: argparse.ArgumentParser, *, tool: bool = False, work: bool = False) -> None:
    parser.add_argument("--repo", required=True, help="the demo line's repo root (its .delivery/ mounted)")
    if tool:
        parser.add_argument("--tool-url", default=None, help="the studio's base URL (a pod: $FC_TOOL_URL)")
    if work:
        parser.add_argument("--work", default=None, help="where the source is fetched at the pinned commit (default: beside the repo)")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="demo_line.py", description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("open", help="pin the source into .delivery/demo.json")
    _add_common(p)
    p.add_argument("--source", required=True, help="the source repository as owner/name")
    p.add_argument("--source-url", default=None, help="the source's clone URL (default: https://github.com/<owner/name>.git)")
    p.add_argument("--sha", default=None, help="the commit to copy from (default: the source's default branch head)")
    p.add_argument("--key", default=None, help="this line's delivery key (default: $FC_SLUG, else the repo folder's name)")
    p.add_argument("--source-app", default=None, help="the source app's fleet name when it differs from the source repo's name")
    p.add_argument("--app", default=None, help="this line's app name (default: demo-<source app>)")
    p.add_argument("--logo", default=DEFAULT_LOGO, help="the locked logo's path in the source (default: docs/logo.svg)")
    p.add_argument("--date", default=_date.today().isoformat())
    p.add_argument("--force", action="store_true", help="re-open over a different pin, deliberately")
    p.set_defaults(func=cmd_open)

    p = sub.add_parser("copy-estimation", help="copy the source's estimation project into the demo key")
    _add_common(p, tool=True)
    p.add_argument("--display", default=None, help="the copy's display name (default: '<key> (demo of <source key>)')")
    p.add_argument("--no-generate", action="store_true", help="skip generating the copy's artifacts")
    p.set_defaults(func=cmd_copy_estimation)

    p = sub.add_parser("copy-prototype", help="copy the source's prototype into the demo key and carry the logo")
    _add_common(p, tool=True, work=True)
    p.add_argument("--tokens-out", default="theme.json", help="where to write {theme:{tokens}} for the close helper")
    p.set_defaults(func=cmd_copy_prototype)

    p = sub.add_parser("copy-intent", help="carry intent.yaml and every file attesting a claim")
    _add_common(p, work=True)
    p.set_defaults(func=cmd_copy_intent)

    p = sub.add_parser("carry-repo", help="carry the source tree, identity renamed, logo verbatim")
    _add_common(p, work=True)
    p.add_argument("--keep", action="append", default=[], help="a repo-relative path the carry leaves as it is (repeatable)")
    p.set_defaults(func=cmd_carry_repo)

    p = sub.add_parser("attest", help="write the phase's fidelity check as its review artifact")
    _add_common(p, tool=True, work=True)
    p.add_argument("--phase", required=True, choices=sorted(RECORD_STEMS))
    p.add_argument("--date", default=_date.today().isoformat())
    p.add_argument("--keep", action="append", default=[], help="paths the carry kept, excluded from the build comparison (repeatable)")
    p.set_defaults(func=cmd_attest)

    args = parser.parse_args(argv)
    if getattr(args, "work", None) is None and hasattr(args, "work"):
        args.work = str(Path(args.repo).resolve().parent / "demo-source")
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
