---
name: adversarial-review
description: "Fresh-context adversarial review of a delivery artifact (a scope trace, a visual identity, a build handoff, or the built code) against its standard: a second agent that had no hand in producing the artifact hunts what its author's context made invisible and returns findings only, never edits. It also carries the judged attestation: a claim binding at `llm` scope is attested by this review's recorded verdict, because no runner can decide it. The per-phase adversarial-review reflex of REF-Delivery §1 made a reusable primitive: every phase runs it against its output before it closes its gate, and the caller resolves the findings (autonomously when it runs interaction=auto, with the operator when interaction=manual). The same primitive REF-Maintenance's verdict gate applies to a PR diff."
galaxy: foundry
refs:
  - REF-Delivery
  - REF-Autonomy
---

# Adversarial review

Invoked to run a **fresh-context, skeptical pass over a produced artifact** and return what is wrong with it. It is the per-phase reflex `REF-Delivery.md` §1 requires ("adversarial review is a reflex of every phase, not a step of one") lifted out of the five phase skills into one primitive they all call, so the review is described once and run uniformly: no phase hands to the next on its own first draft.

Two properties are the whole point, and both are load-bearing:

- **Fresh context.** The reviewer must be a *different* agent from the one that produced the artifact, with no share of its working context. A producer reviewing its own output re-reads its own assumptions and passes them; the value is entirely in the second, clean pass seeing what the first could not. The caller spawns this as a subagent (or a person runs it in a clean session); it never runs inline in the producer's context. In a runner that cannot spawn one (a bare terminal, a small model), the operator opens a NEW session with only this skill, the target, and the standard - the producing conversation is never reused.
- **Report-only.** This skill **returns findings, it does not fix them.** A reviewer that starts editing begins to own the artifact and loses the outside stance that made it useful. It hands a list back to the caller; the caller acts.

Resolution is the **caller's** job and depends on the caller's `interaction` (`REF-Delivery.md` §1): under `interaction=auto` the caller fixes the mechanical findings and resolves the judgment calls by the assumption protocol (`REF-Autonomy.md` §1), logging each; under `interaction=manual` the caller surfaces the findings to the operator and resolves them in a back-and-forth. This skill therefore takes **no** `interaction` argument of its own: it produces the same findings either way, and only what the caller does next differs.

## Arguments

Usage is `<target> against=<standard> kind=<scope|design|plan|code|record> [prior=<path>|none]`:

| Parameter | Meaning |
|---|---|
| `<target>` | the artifact under review: a path (`.delivery/proposal.md`, `.delivery/design.md`, `.delivery/handoff.md`), a diff or working tree (the built code), or a named record |
| `against=` | the standard the target must satisfy: the routed REFs, the platform app-repo contract, the requirement IDs, the intent claims, the visual identity, whatever the artifact is answerable to |
| `kind=` | which lens set to apply (below); it follows from which phase produced the target |
| `prior=` | optional: the previous round's committed review of the same target, read as part of the standard (Pre-flight). Defaults to the newest `.delivery/reviews/<record-stem>-*.md` by version order when one exists; `prior=none` forces a first-round pass |

The caller passes what it is reviewing and what to review it against; this skill supplies the lenses and the discipline.

## Pre-flight

1. **Confirm you are fresh.** You must not have produced the target. If this pass is running in the same context that authored the artifact, it is not a review; stop and have the caller spawn a clean agent (this is the one refusal that matters, `REF-Delivery.md` §1).
2. **Read the standard, then the target, in that order.** Load `against=` first so the review is anchored to what the artifact must satisfy, not to the artifact's own framing of what it set out to do. An artifact that is internally consistent but wrong against its standard is exactly what a same-context review misses.
3. **Read the prior, when there is one, after the standard and before the target.** The prior is the previous round's report on this same target (`prior=`, or derived: the newest `.delivery/reviews/<record-stem>-*.md` by version order). Its blockers are part of what the target must now satisfy; its non-blocking findings are carried, not re-raised. A first round has none.
4. **Select the lens set from `kind=`** (Steps). Apply the lenses for that kind; do not review a plan as if it were code.

## Steps

1. **Review across the lenses for the kind.** Each kind hunts a different failure the producing phase is prone to:

   | `kind` | Produced by | Hunt for |
   |---|---|---|
   | `scope` | Scope (`deliver-engagement`) | a meaningful line of the request that traces to no requirement ID; an unpriced ask; a silent scope drop; a requirement that does not survive back to the verbatim request; a priced surface with no statement of what the user can do through it |
   | `design` | Design (`design-session`) | a build-relevant dimension neither shown nor written down; a missing logo (or an undeliberate one); a token-discipline break; a look the build will have to invent (`REF-Design.md` §8); an identity still wearing scaffold defaults - `--font-sans` or `--radius` untouched, or a captured design system whose guidance shaped nothing (the default-look defect); on a headless line (`surface: none` on the proposal record) the vendored system is the deliberate choice and the docs site the only surface, so the hunt is the mark, the docs theme's contrast and the machine-to-machine statement |
   | `plan` | Intent + plan (`intent-session`) | a decision the build could ask that the handoff neither pins nor points to; a cross-document contradiction between the handoff, the visual identity, and the claims; a requirement mapped to no claim and not descoped; a claim no planned test can attest; an operational assertion that does not match the real platform, CI, or an exemplar app |
   | `code` | Build + ship (`run-delivery-plan`) | correctness, security, and contract conformance defects the builder's own context made invisible; a claim marked `active` without a passing test, or with a test that would pass against a broken implementation (`REF-Tests.md` §8 anti-pattern 12); a conformance-gate break; a docs page the build landed that breaks the documentation set's rules (`REF-Documentation.md` §7.11): state narration outside the decisions collection, a why that left it, a module page off its neighbours' shape |
   | `record` | any phase, for a one-shot gate close | whether the record's own evidence actually supports closing its gate, or narrates a pass it did not earn (`REF-Delivery.md` §1) |

   Three rules apply under every lens. **Evidence is what you actually read**: every finding cites content this review reached through an available tool; a finding quoting a file, an instance, or an output no available tool can read is a fabrication, not a finding - do not emit it. **A narrated act is verified, never trusted**: anything the artifact claims already happened (committed, pushed, recorded, applied, onboarded) is checked against its primary surface (the git log, the file, the instance), because claiming an act before performing it is a recurring producer defect the review exists to catch. **An assertion about the shipped surface resolves to a claim id or a source path**: on a follow-on line the record characterises what already exists ("the existing X, untouched", a delivered claim restated in the record's own words), and each such assertion is checked against the claim's statement as written or the path it names (fact-check the existing, not only the new).

   **With a prior, review the delta.** Verify each of the prior's blockers closed in the current bytes (open the file, run the check; a commit message is not evidence). Apply the lenses to what changed since the commit the prior's first line names, not to bytes the prior already read: re-reading unchanged content is duplicated evidence (`REF-Delivery.md` AP-32), and a second reviewer's different taste over the same bytes is variance, not a finding. A prior blocker still open is a blocker again, with the evidence; a prior non-blocking observation stays non-blocking unless the delta made it bite.

2. **Judge the `llm`-scoped claims whose subject you just read.** Read the project's `intent.yaml`, select the claims whose subject this pass actually reached, and judge each against its statement and any project rubric. Return a YAML mapping keyed by claim ID, each containing a `review` record conforming to CSD-INTENT-01 §3.5:

   ```yaml
   INT-NNN:
     review:
       verdict: PASS
       commit: <full lowercase SHA of the reviewed revision>
   ```

   Keep the reasoning and findings in this review report. Use FAIL for a violated claim and include it among the findings. Judge only content at the named commit; commit the artifact before commissioning this pass. A review can touch no `llm` claim. An active `llm` claim requires a current PASS; draft and deprecated claims can be unreviewed.

   **The durable verdict lives on the claim in `intent.yaml`.** The reviewer returns the record and edits nothing. The caller copies each returned record into its claim verbatim and commits it after the reviewed revision, then runs the intent audit. Specification review and lifecycle status fields are excluded from freshness; other repository content changes require a fresh judgement. A new record replaces the claim's previous record. Git carries the record's history.

3. **Return findings, ranked most-severe first.** The report's first line names the target and the commit it read (`# Adversarial review - <target> @ <sha>, round <N>`), so the next round can anchor its delta. Each finding names: where it is (file and line, or the artifact and the claim), what is wrong in one sentence, and the concrete failure it causes (the input or state that makes it bite). Separate **blockers** (the gate must not close until fixed) from **non-blocking** observations. If nothing survives an honest pass, return an empty finding set and say so plainly; a review that always finds something is padding, and a review that never does is not looking. **End the report with a single machine-readable last line: `VERDICT: PASS` (no blockers) or `VERDICT: FAIL` (blockers remain)**, so any caller - a phase skill, a one-shot engine, a console worker - gates on it mechanically (`REF-Delivery.md` §1). An empty finding set is a PASS. The report's verdict is about the artifact under review; a judged claim's own pass or fail is recorded in step 2 and read from there. The whole report is the return value, in the bytes the caller files at `.delivery/reviews/<record-stem>-<date>-r<N>.md` (N counts that record's rounds on that date from 1).

4. **Hand the findings to the caller and stop.** Do not fix, do not edit, do not close the gate. The caller resolves per its `interaction` (above) and re-runs its build-and-test loop before the gate closes. **Every round's report is committed and pushed verbatim before the caller acts on a finding, FAIL included**: the caller's first act on the return is writing the report to its home, committing it and pushing it on the line's ref (`REF-Delivery.md` §1), because a report that exists only in a live context or an unpushed tree is lost the moment that context is interrupted or its worker is re-cloned; a FAIL is the next round's prior and a retried attempt's warm start, and the record's newest artifact is what the runner closes the gate over, reading its last VERDICT token as the evidence (`REF-Delivery.md` §1; `stamp_gate.py --review-only`, or the stamp itself, both taking `--review-log` pointing at it). **A re-review is owed only after a FAIL**: once its blockers are fixed the caller spawns a fresh instance over the prior (derived, or `prior=`; under `manual` the operator drives that). A PASS is the review: non-blocking findings the caller chooses to fold in are ordinary commits on the same attempt and earn no further round, because a review that re-verifies nits, and the nits that pass emits, is the loop that never converges.

## Failure modes

- **The reviewer produced the artifact** - it is not a fresh pass and its verdict is the author grading their own work (`REF-Delivery.md` §1). Refuse; the caller spawns a clean agent.
- **Fixing instead of reporting** - editing the artifact abandons the outside stance and couples the review to the producer's context. Report the finding; the caller fixes.
- **Reviewing against the artifact's own framing instead of the standard** - an artifact that meets its own stated goal can still fail its requirements, its contract, or its claims. Anchor every finding to `against=`, not to what the artifact says it was trying to do.
- **Padding or rubber-stamping** - inventing findings to look thorough, or waving the artifact through to be agreeable. Both defeat the gate. Report what is actually there, and nothing that is not.
- **Fabricated evidence** - a finding quoting content from a surface no available tool can read (a generated file on a remote instance, another agent's output). Live reviews have produced these; the caller cannot distinguish them from real findings except by re-deriving from primary sources, so the review itself must not emit them (the evidence rule in step 1).
- **Applying the wrong lens** - reviewing a handoff for code bugs, or code for scope traceability, misses the failure the phase actually risks. Take the lens set from `kind=`.
- **Re-reading bytes the prior already read** - a fresh reviewer's different taste over unchanged content is variance, not a finding, and it is what turns a two-round gate into five. Review the delta, verify the prior's blockers, carry its non-blocking observations (step 1).
- **A verification round over a PASS** - non-blocking findings folded in earn no review; the PASS stands and the fixes ride the attempt (step 4).
- **Judging a claim whose subject you did not read** - a verdict on an `llm` claim is worth exactly what the reading behind it is worth, and a claim about a surface this pass never opened is a guess wearing an attestation. Judge what is in scope; leave the rest unjudged and say so.

## See also

- `REF-Delivery.md` §1 - the per-phase adversarial-review reflex this skill makes reusable, and the `interaction` flag that decides how the caller resolves the findings.
- `run-delivery-plan` - the build phase whose fresh-eyes code review is the most visible instance of this skill.
- `review-pr` - `REF-Maintenance.md`'s verdict gate: the same fresh-context review discipline applied to a pull-request diff, **plus** the recorded verdict (an approving review ending `VERDICT: PASS`). The merge act stays with the merge helper (`resolve-ticket/merge_on_pass.py`), never the reviewer - review and stamp split the same way this skill splits from `stamp_gate.py`. Per-claim judgements live in the project's `intent.yaml`; the reports carry findings and their gate verdict.
