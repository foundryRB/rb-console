---
name: maintenance-inbox
description: "One sweep across every maintained repo: open issues, PRs awaiting review, unreleased commits on the default branch, red CI, drifted deployments, promotions a proven release has not reached - ordered into one attention queue. The maintenance inbox habit, followable from any session with the repo host's CLI, and carrying the deterministic sweep (sweep.py) that derives the queue for every reader: a session, a console, a desk."
galaxy: foundry
refs:
  - REF-Maintenance
---

# Maintenance inbox

Invoked as the inbox habit of `REF-Maintenance.md` §7: "what needs me today, anywhere". One derived sweep; nothing is curated, nothing is stored.

The queue's rules - the signals, their attention order, the two folds, the issue stages, the exclusions, and the unchecked-not-omitted rule - live in `REF-Maintenance.md` §7, not here. This skill runs them. `sweep.py`, beside this file, is where they are implemented once so that a session, a console and a desk cannot each drift into their own queue (§8: the inbox contract's enforcement home).

## Pre-flight

1. **Read** `REF-Maintenance.md` §3 and §7 if not already in context. §7 is the contract; a queue that disagrees with it is wrong, not a variant.
2. **Confirm the scope**: an org (`--org <name>`), a list of repos (`--repos <owner/name,...>`), or the current repo. Default to the org that owns the current repo when one is discernible.
3. **Check tool reach**: `gh` must be authenticated. A cluster CLI (for deployment drift) is optional; absent, that signal is reported unchecked, never guessed.

## Steps

1. **Run the sweep**: `python sweep.py --org <org>` (or `--repos <owner/name,...>`). It shells the reads through `gh`, derives the queue under §7's rules, and prints it most urgent first, one line per row carrying repo, signal, stage, detail, and the act that moves it. `--json` prints the same queue as data, which is what a frontend reads. Rows marked `foundry-hidden` (§7: the label on one ticket, the topic on a whole repo) are held back from the printed report and counted on a `HELD BACK` line; `--show-hidden` prints them, flagged with a leading `*`.

   Work in flight is the one input the sweep cannot discover for itself (§7): pass it with `--running <owner/name>:<act>:<number>,...` when the caller knows of any, and omit it in a plain session, where there is none to know.

2. **Read the queue and report it.** Say plainly which signals were unchecked and why: an unreachable source is a hole in the answer, and a hole presented as an empty result reads as "nothing needs me".

3. **Stop.** Working an item is its own act (`resolve-ticket`, `review-pr`, or a look by hand); the inbox never starts work on its own.

## The reads, by hand

What `sweep.py` shells, so the queue is checkable and the habit survives without it.

- the repos in scope, the archived and the `foundry-hidden` among them read as their own facts off the one page: `gh repo list <org> --limit 500 --json nameWithOwner,isArchived,repositoryTopics`
- open issues: `gh search issues --owner <org> --state open --limit 200 --json number,title,repository,labels,createdAt` (or `--repo <owner/name>`, repeatable, for a named list)
- open PRs with their reviews and checks, one call per account:
  `gh api graphql -f query='query($q:String!){search(query:$q,type:ISSUE,first:100){issueCount nodes{... on PullRequest{number title repository{nameWithOwner} isDraft headRefName body updatedAt author{login} statusCheckRollup{state} reviews(last:20){nodes{state body author{login} authorAssociation}}}}}}' -f q='org:<org> is:open is:pr'`
- each live repo's train, twenty repos to a call: the checks on the default branch's head, the tag its last release cut (or its newest tag), and that tag compared against `HEAD`, which the host resolves to the default branch, with the subjects of the tail past it:
  `gh api graphql -f query='query{r0: repository(owner:"<owner>",name:"<name>"){...train}} fragment tail on Ref{name compare(headRef:"HEAD"){aheadBy commits(first:100){nodes{messageHeadline}}}} fragment train on Repository{nameWithOwner defaultBranchRef{name target{... on Commit{statusCheckRollup{state}}}} latestRelease{tag{...tail}} refs(refPrefix:"refs/tags/",first:1,orderBy:{field:TAG_COMMIT_DATE,direction:DESC}){nodes{...tail}}}'`
- deployment drift: the cluster CLI, when one is reachable

**The scope belongs in the flags, and the archived set is read, not filtered.** `archived:` is a *repository*-search qualifier. Inside a GraphQL issue search it is inert, and handed to `gh search issues` as raw query text it is read as a search term and takes the scope down with it, so the sweep answers with issues from repositories nobody asked about. Exclude tombstones by passing the archived list to the derivation instead: the listing carries the flag, a fact read from the host, not a hope about how a qualifier parses.

**The train is read for every live repo, and its next version is derived, not read.** A repo with no open issue or PR still has a default branch that can be red and a tail that can be unshipped, so the train read does not wait for a search to mention the repo. No host exposes what a tail would cut, so the sweep derives it by the rule the shared CI's release engine runs (semantic-release's commit-analyzer defaults over the Conventional Commits grammar): a breaking change (the `!` marker on the subject) cuts a major, a `feat` a minor, a `fix`, a `perf` or a `revert` a patch, and any other type nothing. A tail that cuts nothing raises no row: `release` is not an act anyone can take on a docs commit. A run still in progress on the branch reads `pending`, not red. A repo with no tag, or a tag that is not semver, is reported unchecked for `unreleased` by name rather than read as shipped.

**The searches are one page deep** (200 issues, 100 PRs) and the listing one page of 500 repos. A scope larger than a page is reported as unchecked, never trimmed in silence: a queue that quietly dropped its tail reads exactly like a queue that had none.

## The queue as data

`--json` prints `{"queue": [...], "unchecked": [...]}`. Each row carries `repo`, `signal`, `stage`, `detail`, `act`, `number`, `ts`, and `hidden`; `unchecked` names each signal no source could answer for, with the reason. The shape is pinned by `fixtures/`, the corpus every reader's own suite is attested against: a frontend that re-implements the derivation in another runtime is pinned to those vectors rather than trusted to have read this file. `--json` carries EVERY row, hidden ones included and marked: holding a row back is the reader's own act, and a consumer handed a pre-shortened queue could not make it.

## Promotion rides this queue

A repo's position may carry its declared promotion targets (`REF-Promotion.md` section 6),
and they derive into the same queue rather than a second one:

- a target that has not received the proven release is work sitting unshipped, so it reads
  as **promotion**, beside `unreleased`, and its act is `promote <repo> <target>`;
- a door someone else is reviewing reads as **promotion** too, ordered ahead of the
  pending rows, with `watch` as its act: a second promotion is not the next move;
- a target whose state could not be read reads as **promotion**, ordered ahead of a door in
  flight, with `investigate` as its act: unseen is reported as unseen, never as current;
- a target that carries the release while the signal it declared says nothing is not
  promotion work at all. It is a deployment that does not answer, which this queue already
  calls **drift**, and it keeps drift's urgency rather than earning a second word.

A reader that holds no contracts omits the key, derives no promotion rows, and names
`promotion` in `unchecked`, as this sweep does: it reads no contract.

## Failure modes

- **`gh` unauthenticated or rate-limited**: report which signals are missing rather than presenting a partial queue as complete; a silent gap reads as "nothing needs me".
- **No cluster reach**: mark deployment drift unchecked; never infer health from the release state alone.
- **A train that could not be read**: `unchecked` names `red-ci (default branch)` and `unreleased` for the repos it lost; report them as holes, never as a green branch and a shipped tail.
- **The queue is empty**: say so plainly; an empty inbox is a result, not an error.
- **Tempted to fix something small found mid-sweep**: file it (§2: real issues only), keep sweeping; the inbox is read-only.
- **The queue disagrees with §7**: the queue is wrong. Fix the derivation in `sweep.py` and add the case to `fixtures/`, so every reader inherits the fix; never correct a row by hand in the report.
