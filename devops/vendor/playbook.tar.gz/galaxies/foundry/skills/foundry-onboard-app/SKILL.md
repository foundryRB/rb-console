---
name: foundry-onboard-app
description: Onboard an application onto an install of the Foundry through its conformance-gated admission path, then verify the released application serves with its intended capabilities.
galaxy: foundry
refs:
  - REF-AppContract
---

# Foundry: onboard app

Invoked to admit an application to a specific install under `REF-AppContract.md` sections 1, 2 and 4. The operator request or pre-authorized delivery scope supplies the admission decision.

## Pre-flight

1. Read `REF-AppContract.md` sections 1 to 5 and the `platform-studio` door. Connect through the environment's binding and read the studio's current onboarding runbook and self-declared interface. When no studio is reachable, use the platform repository's own onboard-an-app guide.
2. Resolve the app's fleet name, source repository, install and hostname from the request or handoff. Read an existing admission record before deciding the app is absent; a repository name is not a fleet name.
3. Settle the display metadata, icon, application role, machine-door exposure and complete released image set, including the docs image. Use the runbook's current fields and validation. Declare the source repository explicitly.
4. Use the platform scaffold for a greenfield repository. For an existing one, verify the section 4 contract. Decide authentication and each capability from the authorized scope. No deployable docs means no admission.

## Steps

1. Perform the runbook's admission act against the intended install. Read its resulting change, conformance evidence and pull request. Rendering uses the install's own facts; never copy a neighboring app's record.
2. Repair any named failure at its owner and retry. Do not weaken the gate or use a bootstrap waiver to bypass missing docs or a known red check.
3. Wait for the platform CI's merge using the runbook's bounded wait. Nobody merges this pull request by hand. If the wait fails, record the actual state and the next action rather than claim success.
4. Complete the runbook's team-owned steps: application deployment configuration, external secrets where required, and the scoped capability skills. Preserve the human/machine authentication split and fail-closed readiness.
5. Verify the released application, chart and documentation at their intended addresses, the deployed revision, credentials and intended authentication. Report the admission record and live evidence.

## Failure modes

- An existing app needs new image bindings or current templates: follow the platform's reconciliation runbook. Never offboard and re-onboard to repair it; preserve grants and data. The released image set is read from the app's default branch, so the app-side change must land before reconciliation can attest it.
- A studio is unavailable: verify its environment binding; use the platform's current by-hand guide if necessary. If neither authoritative path is available, report the missing dependency.
- The gate or live verification fails: repair the named cause. A merged record, green install report or published image alone is not application readiness.
