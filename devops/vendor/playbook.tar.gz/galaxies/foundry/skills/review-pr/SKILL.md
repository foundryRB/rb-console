---
name: review-pr
description: "Fresh-eyes review of a maintenance PR: read the diff against the linked ticket, the routed REFs for the touched stack, and CI evidence; post findings as a PR review ending VERDICT: PASS, VERDICT: FAIL, or - when the reviewing identity is the PR's author or the merger - VERDICT: UNRECORDED. It also carries the judged attestation on the maintenance line: a claim the diff touches that binds at `llm` scope is attested by a verdict recorded in this review. Never merges: the verdict authorizes the merge act, it does not perform it."
galaxy: foundry
refs:
  - REF-Maintenance
---

# Review PR

Invoked with a PR to review: `review-pr <pr-number>`. The first marker of the merge gate (`REF-Maintenance.md` §5). The reviewer must be fresh eyes: no hand in the change under review. A session (or worker) that authored the fix does not review it.

## Pre-flight

1. **Read** `REF-Maintenance.md` §5 (the gate) and §2 (the naming contract) if not already in context.
2. **Confirm fresh eyes**: if this session produced any part of the change, stop and have a clean session or worker run the review.
3. **Check the identity before writing anything**: `gh api user --jq .login` against the PR's author (`gh pr view <n> --json author`). When they are the same login - the ordinary case for a loop driven from a terminal, where the driving session and the PR's author are one identity - the host will refuse `--approve` and `--request-changes`, so **no authoritative verdict object can exist for this reviewer**. Review anyway and record `VERDICT: UNRECORDED` (step 5c); the analysis is worth having, and it is what an independent reviewer picks up. What is never correct is a `VERDICT: FAIL` standing in for the missing object (§5, anti-pattern 17).
4. **Gather the evidence**: `gh pr view <n> --comments` (title, body, the review conversation), `gh pr diff <n>`, the CI state (`gh pr checks <n>`), and the linked ticket itself with `gh issue view <ticket> --comments`. The ticket is evidence, not a reference: step 2 judges the diff against what was asked, and the ask includes the scoping guidance and clarifications that land on a ticket as comments. Both `--comments` flags are load-bearing: a bare view prints the body alone and gives no sign a comment exists.
5. **Load the routed REFs** for the stack the diff touches (the playbook routing table): the review judges against the same patterns the author was bound to.

## Steps

1. **Check the frame before the content**:
   - the PR maps to exactly one ticket and one concern (§2); the title reads `type(#n): subject`;
   - the commit(s) are conventional and carry the closing keyword;
   - CI is green. A red CI is an automatic `VERDICT: FAIL` (§5): no review overrides a failing check.
2. **Read the diff adversarially** against the ticket: does the change resolve what the ticket asks, all of it, and nothing else? Drive-by changes, scope creep, and silent extras are findings. A change that only **defers** the ask - a decision, ADR, or plan to do the work later or elsewhere in place of doing it - does not resolve the ticket and does not earn its `Closes`: `VERDICT: FAIL`. (A genuine wontfix, a decision not to do it at all, is a legitimate close.)
3. **Judge conformance** against the routed REFs and the repo's idiom: layering, naming, tests for the changed behavior, docs updated when the change touches documented behavior.
4. **Judge the `llm`-scoped claims the diff touches, if any.** Read only claims whose subject this diff and review actually reached. Return each judgement as a YAML mapping keyed by claim ID with `review: {commit, verdict}`, conforming to CSD-INTENT-01 §3.5. Use PASS or FAIL and the full lowercase PR head SHA actually read. Keep reasons and findings in the review body. A new record replaces the previous one. The reviewer edits nothing. The caller copies the returned records verbatim into the claims' `intent.yaml` entries, commits them, and runs the intent audit. An active `llm` claim needs a current PASS; draft and deprecated claims can be unreviewed. Test markers cannot attest these claims. The per-claim verdict is separate from the PR gate verdict below.
5. **Post the review** with `gh pr review <n>` - findings first, each one concrete (file, line, what is wrong, what right looks like), then the verdict as the review's final line:
   - a. `VERDICT: PASS` (submit as an **approving** review), or
   - b. `VERDICT: FAIL` (submit as **request-changes**; the findings are the work order), or
   - c. `VERDICT: UNRECORDED` (submit as a plain **comment** - `gh pr review <n> --comment`) when pre-flight step 3 found the identity overlap. Say so in the body: the review is complete, the findings (or their absence) stand, and the only thing missing is the authoritative object, which this identity cannot post. Never approve and never request-changes on this path.

   The verdict is **one object**: the review state and the verdict travel together (§5). A plain comment carrying `VERDICT: PASS`, or an approval with no verdict token, is not a verdict - the merge helper (`resolve-ticket/merge_on_pass.py`) keys on the approving review carrying the verdict (the last `VERDICT:` token its body holds, markdown emphasis and trailing prose tolerated), and refuses a review with none. UNRECORDED is the one state that is *deliberately* not that object: it merges nothing and it fails nothing, and the merge helper names it in its refusal so the park reads as awaiting an independent reviewer.
6. **Stop.** The verdict authorizes the merge act; it never performs it (§5: the reviewer is never the merger).

## Failure modes

- **No linked ticket** (gated or one-shot mode): `VERDICT: FAIL` with the one finding that the ticket is missing (§2: real issues only).
- **CI still running**: wait or say so; a verdict over unknown checks is a guess, and the gate fail-closes on guesses.
- **The change is right but mis-sized** (three concerns in one PR): FAIL with the split as the work order.
- **Asked to also fix the findings**: decline in the same session; fresh eyes end at the verdict. The fix returns through `resolve-ticket`.
- **A missing verdict line is a FAIL** (`REF-Maintenance.md` §8): if the review cannot reach a verdict, it has not happened. The distinct case is the review that *reached* one and cannot record it - the identity overlap of pre-flight step 3, which is `VERDICT: UNRECORDED`, not FAIL.
- **The reviewer is the PR's author, or the identity that will merge**: `VERDICT: UNRECORDED` on a commented review (step 5c). This recurs on every terminal-driven loop, so it is a state of the vocabulary rather than an accident to paper over; the PR then waits for an independent reviewer, and a later real PASS supersedes it under the last-verdict-wins read.
- **Judging an `llm` claim whose subject the diff did not touch** - the verdict is worth exactly what the reading behind it is worth, and a claim about a surface this review never opened is a guess. Judge what the diff put in front of you; leave the rest unjudged and say so.
