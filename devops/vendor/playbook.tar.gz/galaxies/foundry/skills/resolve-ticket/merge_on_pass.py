"""Merge a maintenance PR on its recorded verdict: the deterministic merge act of the
one-shot ceremony, and the only way a driven loop merges (REF-Maintenance.md
section 5).

The maintenance analog of the delivery line's gate helper (stamp_gate.py): the agent
never decides the gate and never fires the merge by hand; it runs this file, which
re-reads the PR from the repo host and refuses unless ALL of:

  - the PR's verdict is PASS, read by the one verdict reader (`decision_of` in the
    sibling `maintenance-inbox/sweep.py`), given the PR's author and the identity
    merging now (section 5). A FAIL or an UNRECORDED verdict is named in the refusal
    with the review that decided it, never merged on;
  - every status check has concluded, none red (a red CI blocks the merge in every
    mode; anti-pattern 10) - pending checks refuse too, so a race never merges
    ahead of CI;
  - no commit on the branch carries a `Co-authored-by:` trailer (INT-GATE-002).

On satisfaction it merges with `--rebase`: the branch's commits land as they are, so
what reaches the default branch is what the checks and this helper read, and the PR
body's closing keyword closes the ticket (section 2). Anything short refuses with the
reason, one line each.

Needs the repo host CLI (`gh`) authenticated; stdlib only otherwise. Usage:

    python merge_on_pass.py --repo <owner>/<name> --pr <number>
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import re
import subprocess
import sys
from pathlib import Path

if sys.stdout.encoding and sys.stdout.encoding.lower() != "utf-8":
    sys.stdout.reconfigure(encoding="utf-8")

_GREEN = {"SUCCESS", "NEUTRAL", "SKIPPED"}

# The verdict reader every maintenance surface calls, loaded from the inbox skill's folder:
# the two skill folders sit side by side, installed and in the repo alike.
_SWEEP = Path(__file__).resolve().parent.parent / "maintenance-inbox" / "sweep.py"
sweep = None
if _SWEEP.is_file():
    _spec = importlib.util.spec_from_file_location("maintenance_inbox_sweep", _SWEEP)
    sweep = importlib.util.module_from_spec(_spec)
    _spec.loader.exec_module(sweep)


# A `Co-authored-by:` trailer fails the shared CI's commit-hygiene on the default branch,
# and `release` depends on that job, so a PR that lands one merges green and ships nothing
# (INT-GATE-002). A rebase lands each commit as written, and not every repo runs hygiene on
# its pull requests, so the helper reads the branch's commits itself.
_COAUTHOR = re.compile(r"(?im)^[ \t]*co-authored-by:")


def _gh(*args: str) -> str:
    result = subprocess.run(
        ["gh", *args], capture_output=True, text=True, encoding="utf-8"
    )
    if result.returncode != 0:
        raise RuntimeError(result.stderr.strip() or f"gh {' '.join(args)} failed")
    return result.stdout


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", required=True, help="Repository as <owner>/<name>")
    parser.add_argument("--pr", required=True, type=int, help="Pull request number")
    args = parser.parse_args()

    if sweep is None:
        print("FAIL: the verdict reader is missing: install the maintenance-inbox skill beside resolve-ticket")
        return 1

    try:
        pr = json.loads(
            _gh(
                "pr", "view", str(args.pr), "--repo", args.repo,
                "--json", "state,author,reviews,statusCheckRollup,title,body,commits",
            )
        )
        me = json.loads(_gh("api", "user"))["login"]
    except RuntimeError as exc:
        print(f"FAIL: could not read the PR or the merging identity: {exc}")
        return 1

    refusals: list[str] = []
    if pr.get("state") != "OPEN":
        refusals.append(f"the PR is {pr.get('state', 'unknown')}, not OPEN")

    author = (pr.get("author") or {}).get("login", "")
    verdict, decided = sweep.decision_of(pr.get("reviews") or [], author, me)
    who = ((decided or {}).get("author") or {}).get("login") or "?"
    if who == author:
        recorded = f"{who} is the PR's author, so that review is UNRECORDED"
    elif who == me:
        recorded = f"{who} is the merging identity, so that review is UNRECORDED"
    else:
        recorded = f"{who}'s review is `VERDICT: UNRECORDED`"
    if verdict == sweep.VERDICT_UNRECORDED:
        # Section 5's third state, named rather than lumped into "nobody looked": an
        # UNRECORDED review IS a completed review, so the park is "find an independent
        # reviewer", not "run review-pr". Merging on it stays impossible either way.
        refusals.append(
            f"no mergeable verdict: {recorded} - the review "
            "happened but its identity could not record it (REF-Maintenance.md section 5); "
            "this PR awaits an independent reviewer, not a rework"
        )
    elif verdict == sweep.VERDICT_FAIL:
        refusals.append(
            f"the verdict is {who}'s `VERDICT: FAIL` - its findings are the work order "
            "(REF-Maintenance.md section 5); resolve them and obtain a fresh verdict"
        )
    elif verdict != sweep.VERDICT_PASS:
        refusals.append(
            "no verdict: the gate is an APPROVED review whose body ends `VERDICT: PASS`, from the "
            "repo's owner, a member of its organisation or a collaborator who is neither the PR's "
            "author nor the merging identity (REF-Maintenance.md section 5); run review-pr from "
            "fresh eyes first"
        )

    checks = pr.get("statusCheckRollup") or []
    for check in checks:
        name = check.get("name") or check.get("context") or "check"
        conclusion = (check.get("conclusion") or "").upper()
        state = (check.get("state") or "").upper()
        outcome = conclusion or state
        if not outcome or outcome in ("PENDING", "IN_PROGRESS", "QUEUED", "EXPECTED", "WAITING"):
            refusals.append(f"check `{name}` has not concluded; the merge never races CI")
        elif outcome not in _GREEN:
            refusals.append(f"check `{name}` is {outcome}; a red CI blocks the merge in every mode")

    for commit in pr.get("commits") or []:
        message = f"{commit.get('messageHeadline') or ''}\n{commit.get('messageBody') or ''}"
        if _COAUTHOR.search(message):
            sha = (commit.get("oid") or "")[:7] or "?"
            refusals.append(
                f"commit {sha} carries a `Co-authored-by:` trailer; a rebase lands it as written "
                "and commit-hygiene fails the release on the default branch - reword the branch"
            )

    if refusals:
        for reason in refusals:
            print(f"REFUSED: {reason}")
        return 1

    try:
        _gh("pr", "merge", str(args.pr), "--repo", args.repo, "--rebase")
    except RuntimeError as exc:
        print(f"FAIL: the merge itself failed: {exc}")
        return 1
    print(
        f"Merged {args.repo}#{args.pr} (rebase) over {who}'s VERDICT: PASS; "
        "the PR body's closing keyword ties the ticket."
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
