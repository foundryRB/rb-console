---
name: resolve-ticket
description: "Resolve one ticket through the maintenance loop: read the issue, branch (or main in direct mode), edit, run the repo's conformance, commit conventionally referencing the ticket, and open the PR (or push); in one-shot it merges on a passing review, never in gated mode. The unit act of REF-Maintenance, runnable interactively or headless."
galaxy: foundry
refs:
  - REF-Maintenance
---

# Resolve ticket

Invoked with a ticket to resolve: `resolve-ticket <issue-number>` (optionally `--mode gated|one-shot|direct`, default gated). The unit act of `REF-Maintenance.md` §3; the naming and ceremony rules live there (§2, §4), not here.

## Pre-flight

1. **Read** `REF-Maintenance.md` §2 to §5 if not already in context.
2. **Read the ticket**: `gh issue view <n> --comments` (title, body, labels, the conversation). The flag is load-bearing: a bare `gh issue view` prints the body alone and gives no sign a comment exists, so the scoping guidance, clarifications, and corrections that land on a ticket as comments are read as absent. No ticket in direct mode is fine; in gated or one-shot mode the ticket must exist first (§2: real issues only).
3. **Confirm the mode**. Default gated. Direct is a per-act operator choice; never assume it.
4. **Confirm the ticket's locus is THIS repo**: the file the fix changes must live here. Read the ticket's target and check it - `git ls-files` for the path it names, or a search for the symbol - before writing anything. A ticket whose fix lives in another repo cannot be resolved here at any effort: the branch, the conformance suite, `Closes #n`, and the PR are all repo-scoped (`REF-Maintenance.md` §2). When the target is elsewhere, do NOT open a cross-repo PR - take the **Wrong-repo park** below. A ticket that names a *subject* this repo serves (a corpus it renders, a playbook it hosts) is not thereby a ticket about this repo's code; what matters is where the file you would edit actually is. **Exception**: when the drive names a HOME the foundry does not own (see below), the locus you check is that home - you are cloned into it, and the fix living there is the arrangement working, not a wrong-repo ticket.
5. **Confirm scope fits a ticket**: one ticket = one branch = one PR = one concern. A rework, a new module, or a new major is a delivery line (`REF-Delivery.md`), not this skill - and when the ticket is genuinely that, do NOT force a PR: hand it off with the **Delivery-scale handoff** below. This is rare; default hard to a maintenance scope and escalate only when the ask cannot honestly be one focused change.
6. **Load the routed REFs** for the stack the fix will touch (the playbook routing table), so the change conforms to the same patterns any other change would.

## Steps

1. **Branch** (gated and one-shot): look first for work already on the ticket - an open PR referencing it (`gh pr list --search "#<n>"`) or a `{type}/{n}-*` head among `git ls-remote --heads origin`. What exists is the loop's own state in flight (a prior run's draft, a parked resolve), so continue on that branch rather than opening a rival: one ticket = one branch = one PR (§2). Otherwise `git switch -c {type}/{n}-{slug}` from the current default branch. Direct mode stays on the default branch.
2. **Edit** the minimal change that resolves the ticket. Match the repo's idiom; no drive-by fixes (a second concern found on the way becomes its own ticket).
3. **Prepare any affected `llm` reviews, then run conformance.** When an active `llm` claim or its named evidence is touched, commit a local snapshot for a fresh, report-only reviewer before the final audit. Have that reviewer return CSD-INTENT-01 §3.5 records for the snapshot, copy them verbatim into `intent.yaml`, and commit the metadata locally. The PR gate review still follows in step 5. **Run the repo's conformance** locally: its pre-commit hooks, its test suite, its intent audit when present. Red conformance never leaves the workspace.
4. **Commit conventionally**: `type: subject (#n)` with the closing keyword (`Closes #n`) in the body, and **no co-author trailers** (the platform's commit convention, `REF-AppContract.md` §4). Direct mode without a ticket makes the conventional message alone the record.
5. **Open the door for the gate**:
   - gated / one-shot: push the branch and `gh pr create --title "type(#n): subject"` with a body that puts the closing keyword `Closes #n` on its own line, then states how to verify. The keyword goes in the PR **body** as well as the commit: the body is what links the PR to its ticket on the repo host, and a keyword there closes the ticket on merge however the merge lands. Request the review (`review-pr`) **from fresh eyes**: a different agent or session that had no hand in this change - in a driven one-shot, spawn a clean context for it. Never run `review-pr` over your own output; the producer grading its own work is not a gate (§5, anti-pattern 7), and the merge helper's authorship check will refuse the result anyway.
   - direct: push the default branch. Done; the pipeline ships it (§3).
   When the reviewer returns per-claim `review` records, copy them verbatim into the relevant `intent.yaml` entries, commit them locally, run conformance, and push only when green. Their reviewed commit precedes this metadata commit. A current PASS is required for every active `llm` claim; the CSD auditor checks freshness.
6. **Report**: the PR URL (or the commit sha in direct mode), and what evidence the gate should look at.
7. **Merge (one-shot only)**: run the merge helper, never `gh pr merge` by hand - `python merge_on_pass.py --repo <owner>/<name> --pr <n>` (this skill's folder). It independently re-reads the PR and merges by rebase only over an APPROVED review ending `VERDICT: PASS` from an author who is neither the PR's author nor the merging identity, with every check green and no commit carrying a co-author trailer; it refuses anything short, with the reason (§5 - the maintenance analog of the delivery gate helper, `REF-Delivery.md` §1 "How a gate closes"). Triggering the one-shot drive is the operator's standing authorization for this merge (§4). A refusal parks the ticket for the operator, never merges. Gated stops at step 6 (the human merges); direct has no PR.

## Delivery-scale handoff (issue #13)

Pre-flight step 5 can conclude the ticket is not a maintenance concern at all: it asks for a rework, a new module or subsystem, a new major, work that plainly spans several PRs, or work that needs a design phase - a delivery line (`REF-Delivery.md` §1), not `one ticket = one branch = one PR`. This is RARE: default hard to a maintenance scope and escalate only when the ask cannot honestly be one focused change. When it genuinely is delivery-scale, do NOT open a PR. Hand the ticket off so the Console offers the operator "Switch to Delivery":

1. **Prepare the delivery prompt**: the ticket's ask restated as a delivery brief - what to build, the verbatim requirement, and why it is delivery-scale. This becomes the Delivery form's "Customer request", so write it as the customer-facing request, not a note to yourself.
2. **Post it to the ticket, marked**, so the Console reads it back: `gh issue comment <n> --body "$(printf '%s\n\n%s' '<!-- foundry:delivery-prompt -->' '<the prepared prompt>')"`. The HTML-comment marker is invisible in GitHub's rendered view; it is the machine handle the Console reads the prompt off, and the latest marked comment wins (a re-drive supersedes an earlier one).
3. **Ensure the labels exist and mark the ticket** so the Console can surface the offer and later hide the ticket: `gh label create foundry-delivery-scale --color BFD4F2 --description "Too big for a maintenance scope; switch to a delivery line" 2>/dev/null || true`; `gh label create foundry-hidden --color EDEDED --description "Hidden from the Foundry maintenance surfaces" 2>/dev/null || true`; then `gh issue edit <n> --add-label foundry-delivery-scale`. Creating `foundry-hidden` here (idempotent) means the Console's Switch act, which applies it, never fails on a repo that never had the label.
4. **Signal a headless worker to park delivery-scale**: when `FC_SIGNAL_DIR` is set, drop the sentinel the entrypoint reads there - `: > "$FC_SIGNAL_DIR/.foundry-delivery-scale"`. The worker reads it beside the ticket's `foundry-delivery-scale` label and exits 65, which Argo does not retry (a retry cannot shrink the ticket), so the run parks delivery-scale rather than degraded. The worker is the only thing that sets that variable, and the path it names sits OUTSIDE the clone: a signal between two processes in one pod never belongs in a git working tree, where one broad `git add` publishes it to every later clone of that repo and parks every later run before its agent has done anything. With the variable unset there is no wrapper to signal, so write nothing: the marked comment and the label carry the handoff, and an interactive run's long-lived clone stays clean.
5. **Stop.** Open no branch and no PR. Report that the ticket is delivery-scale, the prepared prompt is on it, and the operator can press "Switch to Delivery" (or re-drive with a prompt that forces a maintenance resolve). Do NOT open the delivery line yourself: opening it is the operator's deterministic act, and the ticket is hidden from the loop then, through #12's `foundry-hidden` (the Switch act applies it).

## Wrong-repo park (foundry-console#35)

Pre-flight step 4 can conclude the ticket is filed on the wrong repo: the fix's target lives somewhere else, so this repo can hold no branch, no conformance run, and no PR for it. The delivery-scale handoff's twin - that one is about a ticket's **size**, this one about its **locus** - and it takes the same shape, because the loop treats both as "valid ticket, not resolvable here".

Do NOT open the PR in the repo that holds the code, however obviously correct that patch is. It is invisible to this ticket's loop: `Closes #n` does not close across repos, the release lands under the other repo's history, and this repo's completeness check reports that nothing shipped (`REF-Maintenance.md` §2, anti-pattern 15).

1. **Identify the owning repo** as an `owner/name` slug, and be sure of it. For a playbook lesson (a REF, a skill, the handoff template) ask the playbook door rather than inferring: `get_sync_status` returns `repo`, the repo that door's own clone pushes to. The door's app repo is not the playbook - it serves the corpus, it does not contain it.
2. **Record the finding on the ticket**, so it survives this session: `gh issue comment <n> --body "The fix for this lives in \`<owner/name>\` (<the path>), not \`<this repo>\`. Nothing here can branch or open a PR for it. Transfer the ticket there and drive it from that repo's loop."`
3. **Ensure the label exists and mark the ticket**: `gh label create foundry-wrong-repo --color D93F0B --description "The fix lives in another repo; not resolvable in this one" 2>/dev/null || true`; then `gh issue edit <n> --add-label foundry-wrong-repo`. The console reads the label to explain why it offers no resolve act here and to point at the owning repo.
4. **Signal a headless worker to park on locus**: when `FC_SIGNAL_DIR` is set, drop the sentinel there carrying the owning repo on its first line - `printf '%s\n' "<owner/name>" > "$FC_SIGNAL_DIR/.foundry-wrong-repo"`. The worker reads it beside the ticket's `foundry-wrong-repo` label and exits 66, which Argo does not retry (no retry can move a file into this repo) and which parks the run instead of failing it red. The delivery-scale sentinel's rule holds here too: the path is outside the clone, so no `git add` can publish it, and with the variable unset write nothing, because the comment and the label already carry the finding.
5. **Stop.** Open no branch and no PR. Report the owning repo and that the ticket needs transferring (`gh issue transfer <n> --repo <this> <owner/name>` inside one org keeps the thread and leaves a redirect). Do **not** transfer it yourself: moving someone's ticket between repos is the operator's act, and an agent that relocates work mid-run moves it out from under whoever was watching it.

This is not rare in one specific way: a repo that *serves* a body of content attracts tickets about that content. Judge on where the file is, never on what the repo is named.

## When the home is not the foundry's (foundry-platform#130)

Some apps are **Managed**: the foundry runs their line, and their code lives in a repository another organization owns (`REF-Delivery.md` §1, and the `adopt` skill that enters one). A drive over such an app tells you so, naming both coordinates. They answer different questions and neither replaces the other:

- **The ticket repo is ours.** The issue, its comments, its labels, and anything the loop records live there. Read the ticket there; comment there; park there.
- **The home is theirs.** You are cloned into it. The branch, the conformance run, and the pull request all go there, against the base branch the drive names.

Four rules follow from not owning the place, and none of them is negotiable:

1. **Never merge.** The merge is theirs, in every mode - one-shot does not run for a Managed app at all, precisely because its shape ends in a merge.
2. **Never scaffold the foundry into their repository.** No conformance suite, no CI, no commit hooks, no `.delivery/`. Adoption changes nothing in a home the foundry does not own; what the foundry requires of its own repos is not a demand it makes of theirs.
3. **Work to their conventions and their tests.** Their suite is what proven-in-CI means for this app. Read what they do and match it; the playbook's routed REFs inform your judgement, they do not override their house style.
4. **`Closes #n` does not reach across.** The keyword closes nothing from their repository, so say plainly in the PR body which ticket this resolves and report the PR URL back - the loop closes the ticket on our side once they land it.

This is NOT the wrong-repo park. That park is for a ticket filed where its fix cannot live; here the fix lives exactly where the model says it should, and the drive put you there on purpose.

## Failure modes

- **Conformance is red and the fix is unrelated to the ticket**: stop; file the failure as its own ticket rather than widening this one.
- **The app's home is another organization's repository**: this is the Managed arrangement, not a wrong-repo ticket - work in the home you were cloned into, open the PR there, and never merge it.
- **The home's conformance is red for reasons that predate you**: report it on the ticket and fix only what your change touched. Repairing someone else's suite is not this ticket's scope, and a pull request that rewrites their house is not one they can review.
- **The ticket's fix lives in another repo**: take the wrong-repo park above - never a cross-repo PR, and never a "while I'm here" edit to the nearest local file that looks related.
- **The ticket is ambiguous**: ask on the issue (a comment), not in the chat; the ticket is the record (§2).
- **The change grew past ticket size**: stop; do not open a partial PR. Run the **Delivery-scale handoff** so the Console can offer the operator Switch to Delivery (§1).
- **Headless run**: no interactive channel exists; an ambiguous ticket is a failed run with the question posted to the issue, never a guess.
- **This skill never merges in gated mode** (§5): the merge is the human's act; decline and point at the mode's merge rule - and never offer to merge for them (the delivery line's AP-29, applied to the merge act). In **one-shot** the merge helper merges (step 7) on the recorded fresh-eyes `VERDICT: PASS`; a FAIL, a red check, or an authorship overlap parks the ticket for the operator, never merges.
