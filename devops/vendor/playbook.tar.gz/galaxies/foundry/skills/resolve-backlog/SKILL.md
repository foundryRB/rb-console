---
name: resolve-backlog
description: "Clear a repository backlog: earn-it triage, consolidate overlapping tickets, resolve with Sol or Opus, review once in fresh context with the same model, fix findings, rebase and fast-forward. Interactive decisions are the default."
galaxy: foundry
refs:
  - REF-Maintenance
  - REF-Autonomy
---

# Resolve backlog

Invoked with `resolve-backlog <repo> [model=Sol|Opus] [mode=interactive|one-shot]` when the operator wants a repository's ticket backlog judged, consolidated and carried through implementation to integration. The batch contract is `REF-Maintenance.md` section 4.1; ordinary single-ticket work uses `resolve-ticket`.

## Pre-flight

1. Read the repository instructions, `REF-Maintenance.md` sections 4.1 and 5.1, and the `earn-it` skill. Inspect the default branch, working changes, open PRs and active work before choosing an isolated checkout. Resume existing work for this run rather than starting a competing branch.
2. Resolve the mode and model under section 4.1. Announce them. Omitted mode is **interactive**; at a terminal, omitted interaction is **manual**. Use the requested Sol or Opus model from the runtime's available models. If omitted, prefer its configured Sol/Opus coding model, then available Sol, then available Opus. Record the actual model binding and use it for both implementers and reviewer. An unavailable requested model is a decision, never a silent substitution.
3. List the open issues and their labels. Exclude every `foundry-hidden` issue before reading its body, commenting, batching or assigning it; report the excluded count. Respect the repository-level exclusion in section 7 too. Read every included issue with its comments and linked work. Fix this snapshot as the run's scope; later arrivals wait unless the operator includes them.

## Steps

1. **Judge before batching.** Run `earn-it` over the included tickets against the current artifact and its history. Produce one evidenced ruling per concern: take at its smallest useful size, drop with a revisit trigger, already done with its pointer, or wrong home. Documentation is judged on reader usefulness and current accuracy; neither exempt it nor discard an actual gap as cosmetic. The ruling itself changes no ticket.
2. **Settle the batch plan.** Group survivors by the files, subsystem or reader surface they change. Put related documentation into one docs ticket; group code concerns that would collide in the same implementation. Preserve acceptance criteria and source issue IDs. Present the rulings, proposed batches and genuine decisions. In interactive/manual execution, obtain missing decisions before dependent edits or ticket closures; continue independent work. Existing explicit approval still applies. In one-shot or explicitly headless `interaction=auto`, apply the assumption protocol from `REF-Autonomy.md` and record assumptions on the batch issues; respect any external interactive gate under section 4.1.
3. **Land the plan.** Reuse or create the batch tickets, with source links, accepted scope, exclusions and verifiable acceptance. Comment the ruling on each source ticket. Close superseded tickets only after their batch exists, explicitly as superseded rather than implemented; close drops as not planned and already-done items with their completion pointer. Record a wrong-home outcome without pretending it was repaired here. Keep unresolved decisions open. The host's issues and eventual PR are the record, not a parallel tracker in the repository.
4. **Resolve with the selected model.** Delegate the batches to Sol or Opus using the recorded binding and `resolve-ticket`'s implementation and conformance practices. Give each worker its batch, current comments, file ownership and isolated branch; overlapping edits run serially or with explicit ownership. Workers know they share a codebase and must preserve other work. They commit conventionally with batch closing references and return test evidence; the coordinator owns integration. Collect their changes into one integration branch and one PR that links every batch. The batch specialization permits that combined PR; do not create one review gate per source ticket.
5. **Review once, fresh.** Once the combined changes and required checks are ready, spawn a reviewer with the **same actual model** and **no inherited implementation conversation**. Supply the repository instructions, batch issues with their comments, base/head SHAs, complete diff and test/CI evidence. The reviewer reads the artifacts directly, applies the routed REFs and `review-pr`'s content criteria, and records concrete findings plus a verdict under section 5.1. It edits nothing and never merges. One combined review covers all batches and their interactions.
6. **Fix and verify.** Return every actionable finding to the implementers. Record its disposition and regression evidence on the PR. The same reviewer checks the finding repairs and any consequential integration delta, then records closure against the resulting head. This is targeted follow-through on the one review, not another whole-backlog review. An unresolved defect or missing decision keeps the affected work open; a review-count preference cannot turn it into a pass.
7. **Rebase and fast-forward.** Apply section 5.1's final integration checks: fetch the current default branch, rebase the combined branch, resolve conflicts without losing accepted work, and run the affected checks on the resulting tree. Have the reviewer verify any semantic conflict resolution. Respect host protection and external approval requirements. With the run's decisions settled and evidence green, fast-forward the default branch to the verified head and push normally, never force it and never substitute a squash or merge commit. If the remote moved, fetch and repeat the rebase/check step. Record the final commit and verify batch closures.
8. **Report.** Give the batch links, rulings that removed work, hidden count, selected model, review/repair evidence, landed SHA and remaining blockers or assumptions. A batch is complete only when its accepted work is on the default branch. If blocked, leave its PR and batch open with the exact next action.

## Failure modes

- **A decision appears mid-run:** interactive/manual raises it then, not in the final report; one-shot or explicitly auto records the smallest authorized assumption. Mode defaults never change merely because the run is long or delegation is available.
- **An interactive/manual run loses its human channel:** record and park that dependency. Do not silently relabel it one-shot or auto. A launcher that explicitly supplied auto follows section 4.1's headless conduct.
- **Model or fresh-context delegation unavailable:** name the missing capability. In interactive execution ask for a supported binding; in unattended execution preserve the work and report the external dependency. Never let an implementation worker grade its own output.
- **Unrelated active work or dirty files:** isolate this run and preserve the existing work. A moving target is not permission to reset or force-push it.
- **Red checks or unresolved findings:** repair within accepted scope. Record unrelated failures and the decision they require. Neither a single-review request nor a backlog target authorizes claiming green evidence that does not exist.
- **Rebase changes behavior:** obtain focused review of the changed portion. If new scope needs a separate broad review, raise that departure in interactive mode or record it under one-shot; do not apply a stale verdict to new behavior.
- **Host policy prevents fast-forward:** report the precise restriction and retain the reviewed branch. Do not change branch protection or choose another merge strategy without authorization.
