---
name: foundry-onboard-events
description: Grant an admitted application publishing rights over its owned event domains and verify its one-way publisher and isolation.
galaxy: foundry
refs:
  - REF-AppContract
  - REF-Events
---

# Foundry: onboard events

## Pre-flight

1. Read `REF-AppContract.md` sections 2 and 3, the `platform-studio` door and the platform's current onboard-events runbook. Discover the bound door's interface; when it is unavailable, use that runbook's by-hand path.
2. Verify the app is already admitted to the intended install (`foundry-onboard-app`) and identify it by fleet name. Read its current grants; an existing grant needs the runbook's update path, never a duplicate grant.
3. Confirm the capability is in the operator request or priced delivery scope. Existing authorization is sufficient; do not prompt again for it.
4. Read `REF-Events.md` sections 3, 4, 6 and 7 for domain ownership, the one-way rule and the publisher boundary.

## Steps

1. Perform the capability grant through the current runbook. Read the change, conformance evidence and admission pull request. Repair a refusal rather than weakening its checks.
2. Wait for the platform CI's automatic merge within the runbook's bounds. Never merge an admission pull request yourself.
3. Complete the app-owned integration below using the grant's actual coordinates and credential references. Do not invent a Secret name or carry a secret through git, CI or the conversation.
4. Verify the capability's isolation and the application's use of it, then report the admission and application evidence.

## App-owned integration

Name every domain the app owns before granting; at least one is required and each has one owner. A collision is an ownership decision, never a reason to grant two producers the same domain. Subscriptions follow the event contract; domain ownership restricts publishing.

Use the runbook's current chart integration and required credential mounts. Keep the private seed in the app namespace; only public material may leave it. The app's publisher is its own outbound adapter (`REF-Events.md` section 7). Ship its event-type reference page with the code, held equal by tests. Prove the one-way rule: with the transport unreachable, the business act has the same response and durable outcome and logs each dropped publish. A grant cannot attest that application behavior.

## Failure modes

- The app is absent: admit it first. The platform capability is absent: report the platform dependency.
- A grant, credential or isolation check fails: use the runbook's diagnostics and repair the named cause; a green admission does not prove the app consumed its grant.
- An existing grant needs a change: follow its update procedure, preserving data and existing credentials.
- Neither the bound studio nor the current platform guide is available: report the missing authoritative procedure.
