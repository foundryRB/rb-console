---
name: foundry-offboard-app
description: Retire an application from an install after its data disposition is authorized; verify resource release before its fleet name can be reused.
galaxy: foundry
refs:
  - REF-AppContract
---

# Foundry: offboard app

Invoked for explicit retirement under `REF-AppContract.md` section 6. Pause is the reversible capacity action in section 4; retiring removes resources and can destroy data.

## Pre-flight

1. Read `REF-AppContract.md` sections 2, 4 and 6, the `platform-studio` door and the platform's current retirement and grant-teardown runbooks. Prefer the bound studio; use the platform's by-hand procedure only when it is unavailable.
2. Resolve the intended install and fleet name and read the admission record and every capability grant. The source repository's name or a rename is not retirement evidence.
3. Enumerate live volume claims in the application's namespace. Treat an unreadable claim set as present; the chart source is not a substitute for a live read.
4. Settle and record each volume's and grant's data disposition before invoking the act. Take required backups while credentials and workloads still exist. The admission pull request can merge automatically, so recording disposition after invoking retirement is too late for volumes.
5. With no operator reachable, proceed only when the claims were read and absent or prior authorization covers each claim's disposition. Otherwise park with the unresolved claims or failed read named. Never infer authorization to destroy data.

## Steps

1. Execute the platform's retirement runbook for the resolved app and install. Read its change, conformance evidence and pull request; preserve source-repository ownership with the application team.
2. Wait for the platform CI's admission merge within the runbook's bounds. Never merge it by hand. Verify removal has reconciled before reporting resource release.
3. Enumerate grants that survive admission removal and follow their authorized teardown disposition. A headless run parks this leg for the operator rather than choosing a drop.
4. Verify that the retired admission and resources are absent. A name is reusable only after the previous grants under it are disposed of; retaining a database or realm keeps name reuse blocked. Report the evidence and any intentionally retained state.

## Failure modes

- Intent is only to stop workloads: use pause; retain data and grants.
- A backup, claim read or disposition is missing: stop before invoking retirement, identify what remains unresolved and keep the app intact.
- The gate rejects removal or pruning stalls: follow the platform diagnostics; do not claim the name is free.
- A repository was renamed: inspect its admission and grants. A rename leaves them in place.
