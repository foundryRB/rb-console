"""Mechanical entry gate for reconcile-delivery.

Refuses (exit 1) when the journal's leading frontmatter already carries a dated
`learned:` stamp (Learn already executed; the next act is the close, never a
re-run), when the delivery scratch carries no handoff (.delivery/handoff.md),
when the handoff lacks the sections reconciliation verifies against (the evidence
chain, the degraded stop-states, the post-ship contract), or when the line's gates
are not actually closed: every record's frontmatter must carry a dated `signed:` and
a dated `reviewed:`, and build.md must read `status: complete` (REF-Delivery.md
section 1 - reconcile closes a done run, and closing a line whose delivery gate is
pending erases the evidence that no acceptance ever happened). A pending gate is
never signed from reconcile; it is handed back to its signer. `--degraded-ending`
(the deliberate-abandon path) downgrades the gate refusals to findings, since that
path writes the resume list instead of closing the line. On success it prints the
handoff's own evidence-chain items as the checklist the reconciling session must
satisfy independently.

A journal that does not exist AT ALL is a finding, not a refusal: no phase captured
the run's lessons as they happened, so the close runs in reconstruction mode and says
so. Refusing there would strand the close on a gap the close cannot fix - prevention
lives at the gate helpers, which refuse to stamp without a journal.

The handoff is ephemeral (REF-Delivery.md section 1): reconcile is the last step
that reads it, confirms every durable decision reached its durable home, then
closes the line - the annotated delivered tag minted on the branch tip and pushed,
the worktree removed, the ref deleted, with the records retained behind the tag.

Stdlib only. Usage:

    python preflight.py --repo <repo-root> [--degraded-ending]
"""

from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

if sys.stdout.encoding and sys.stdout.encoding.lower() != "utf-8":
    sys.stdout.reconfigure(encoding="utf-8")

# Section anchors from handoff-template.md; matched on heading text, not number.
_REQUIRED_HEADINGS = (
    ("evidence chain", re.compile(r"^##.*evidence chain", re.IGNORECASE | re.MULTILINE)),
    ("degraded stop-states", re.compile(r"^##.*degraded stop-state", re.IGNORECASE | re.MULTILINE)),
    ("post-ship", re.compile(r"^##.*post-ship", re.IGNORECASE | re.MULTILINE)),
)

# The four gate records and the gate each carries (REF-Delivery.md section 1).
_RECORDS = (
    ("proposal.md", "proposal"),
    ("design.md", "design"),
    ("handoff.md", "plan"),
    ("build.md", "delivery"),
)

_DATE_VALUE = re.compile(r"^\d{4}-\d{2}-\d{2}$")

_LEARNED_LINE = re.compile(r"^learned:\s*(\d{4}-\d{2}-\d{2})\s*$", re.IGNORECASE | re.MULTILINE)


_ABSENT = "ABSENT"


def _learned_stamp(scratch: Path) -> str | None:
    """The dated `learned:` in the journal's LEADING frontmatter, `_ABSENT` when the
    journal does not exist at all, else None. The stamp is written by this skill's own
    unattended close when the reconcile completed; present, it means Learn already
    executed and the next act is the close, not a re-run.

    A missing journal and an unstamped one are different states, and collapsing them to
    None hid the worse of the two: no phase captured this run's lessons as they happened,
    so the close runs in reconstruction mode. It is a finding, never a refusal - a
    journal-less line is still reconcilable from the records and reviews, and refusing
    here would strand the close on a gap the close cannot fix."""
    journal = scratch / "journal.md"
    if not journal.is_file():
        return _ABSENT
    text = journal.read_text(encoding="utf-8")
    if not text.startswith("---"):
        return None
    end = text.find("\n---", 3)
    if end == -1:
        return None
    match = _LEARNED_LINE.search(text[3:end])
    return match.group(1) if match else None


def _front_field(text: str, name: str) -> str | None:
    """A leading-frontmatter field's stripped value, or None. The frontmatter is the
    authoritative gate state (REF-Delivery.md section 1, anti-pattern 24)."""
    if not text.startswith("---"):
        return None
    end = text.find("\n---", 3)
    front = text[3:end] if end != -1 else text[3:]
    pat = re.compile(rf"^\s*{name}\s*:\s*(.*?)\s*$", re.IGNORECASE)
    for line in front.splitlines():
        m = pat.match(line)
        if m:
            return m.group(1).strip().strip('"').strip("'")
    return None


def _gate_findings(scratch: Path) -> list[str]:
    """Every way the line's gates are not actually closed, one line each."""
    findings: list[str] = []
    for fname, gate in _RECORDS:
        path = scratch / fname
        if not path.is_file():
            findings.append(f"{fname}: missing (its phase never recorded; the {gate} gate never happened)")
            continue
        text = path.read_text(encoding="utf-8")
        signed = _front_field(text, "signed") or ""
        reviewed = _front_field(text, "reviewed") or ""
        status = (_front_field(text, "status") or "").lower()
        if not _DATE_VALUE.match(signed):
            findings.append(f"{fname}: the {gate} gate is unsigned (`signed:` is {signed or 'absent'!r})")
        if not _DATE_VALUE.match(reviewed):
            findings.append(
                f"{fname}: no recorded fresh-eyes review (`reviewed:` is {reviewed or 'absent'!r}; "
                "every gate closes over it, REF-Delivery.md section 1)"
            )
        if fname == "build.md" and status != "complete":
            findings.append(f"build.md: status is {status or 'absent'!r}, not complete (the run did not reach done)")
    return findings


def _section_body(handoff: str, heading_re: re.Pattern[str]) -> str:
    match = heading_re.search(handoff)
    if not match:
        return ""
    start = match.end()
    nxt = re.search(r"^## ", handoff[start:], re.MULTILINE)
    return handoff[start : start + nxt.start()] if nxt else handoff[start:]


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", required=True, help="Delivery repo root (holds .delivery/)")
    parser.add_argument(
        "--degraded-ending",
        action="store_true",
        help="Deliberate-abandon path (REF-Delivery.md anti-pattern 26): gate findings are "
        "reported but do not refuse, since this path writes the resume list instead of "
        "closing the line.",
    )
    args = parser.parse_args()

    scratch = Path(args.repo) / ".delivery"

    stamp = _learned_stamp(scratch)
    if stamp == _ABSENT:
        print(
            "FINDING: no .delivery/journal.md - no phase captured this run's lessons, "
            "defects, or user sentiment as they happened (REF-Delivery.md section 1). "
            "Reconcile runs in RECONSTRUCTION MODE: recover what you can from the gate "
            "records and the .delivery/reviews/ artifacts, create the journal, and say "
            "in the summary that the run's sentiment and its gate-rejection feedback "
            "were never captured and are not recoverable from git."
        )
    elif stamp:
        print(
            f"NO-GO: Learn already executed on {stamp} (.delivery/journal.md frontmatter carries the "
            "learned: stamp). Do not re-run reconcile: the next act is the close - the console's "
            "Close-line act, or the terminal close (push the closing journal commit on the line's "
            "ref, tag the tip delivered/<slug>/P<n>, push the tag, remove the worktree, delete the "
            "ref). A deliberate re-learn starts by removing the stamp line in its own commit."
        )
        return 1

    handoff_path = scratch / "handoff.md"
    if not handoff_path.is_file():
        print(f"FAIL: no .delivery/handoff.md at {args.repo}; nothing to reconcile against")
        return 1
    handoff = handoff_path.read_text(encoding="utf-8")

    failures: list[str] = []
    for label, pattern in _REQUIRED_HEADINGS:
        if pattern.search(handoff):
            print(f"PASS: handoff carries its {label} section")
        else:
            failures.append(f"FAIL: handoff.md has no {label} section (handoff-template.md)")

    gate_findings = _gate_findings(scratch)
    if not gate_findings:
        print("PASS: all four gates signed and reviewed; build.md complete")
    elif args.degraded_ending:
        for finding in gate_findings:
            print(f"FINDING (degraded ending): {finding}")
    else:
        for finding in gate_findings:
            failures.append(f"FAIL: {finding}")

    if failures:
        print()
        for failure in failures:
            print(failure)
        print(
            "\nNO-GO: reconcile closes a done run (REF-Delivery.md section 1, section 6). A pending "
            "gate is never signed from here; hand it back to its signer (anti-pattern 29), or pass "
            "--degraded-ending for a deliberate abandon."
        )
        return 1

    body = _section_body(handoff, _REQUIRED_HEADINGS[0][1])
    items = [line.strip() for line in body.splitlines() if re.match(r"^\s*\d+\.", line)]
    print("\nEvidence-chain checklist to verify independently:")
    for item in items:
        print(f"  [ ] {item}")
    if not items:
        print("  (no numbered items found; read the section manually)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
