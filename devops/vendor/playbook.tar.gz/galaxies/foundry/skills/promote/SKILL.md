---
name: promote
description: "Promote a proven release beyond the entry environment: resolve a target from the app's promotion contract, perform its door, verify terms (deployed) then acceptance (proven); the same act at the previous version is the rollback."
galaxy: foundry
refs:
  - REF-AppContract
  - REF-Promotion
---

# Promote

Invoked as `promote <repo> <target> [--release vX.Y.Z]`: the deliberate act of the promotion line. Deployment is automatic exactly once - a build reaches the entry environment on its own - and every move beyond it is this act, against one target the app's own contract declares. Invoking it is the authorization: the act includes its own push, because an unpushed promotion promotes nothing.

## Pre-flight

1. Read the app's `devops/promotion.yaml` off its default branch and resolve `<target>` by name. No contract, an empty one, or an unknown name: stop and list what is declared - a promotion never invents a destination.
2. Resolve the release: `--release` when given, else the newest published one (the chart and every released image at that version on the registry).
3. Refuse an unproven release - refused, not warned. Proven means all of: the release's images and chart are published; the CI run that released it concluded green; the app serves that version live on its entry environment (read the platform door's current deployment evidence, else a cache-busted probe of the app's hostname).
4. For an `environment` target, read the target install's `foundry.yaml` off its deploy branch and confirm the named environment is in the declared list and is **not** its entry environment - the next automatic deployment would overwrite the write.

## Steps

For a `kind: environment` target (door `commit`, terms `version`):

1. Fetch the app repo's `deploy-<install>` branch for the target's install; work on the fresh tip, in a worktree if the branch is checked out elsewhere.
2. Write the terms into `<environment>/`: every image tag the entry environment's values carry, set to the release's tags, and the `Chart.yaml` pin set to the release's chart version.
3. Commit as the operator (`chore(promotion): <app> <environment> to <release>`) and push. A rejected push means the branch moved: fetch and redo on the fresh tip, never force.
4. Terms verify deployed: the target environment serves the release (cache-busted probe of its hostname) once the reconciler applies the branch.
5. Acceptance verifies proven: the declared signal answers fresh - a `suite` verdict read from the `suite:` URL the target declares and judged by its `suite_pass:` matcher (a 200 is transport, not a pass), a `probe` answering live - or `none` closes the promotion at deployed. Report the commit and the closing signal.

For a `kind: repository` target (door `pull-request`, terms `source`):

1. The named `credential` is the platform's to resolve, and it is resolved for you before you run. In a worker it arrives as `FC_PAIR_TOKEN` (reaching `FC_PAIR_HOST`, for the repository named in `FC_PAIR_REPO`), with git already configured to use it for that repository and nothing else: do not look it up, print it, echo it, or write it into a remote, a URL, or a file. There is no other way to obtain it - no door returns a pair credential's value, by design - so a repository door is **driven from the console**, never improvised at a terminal on a token a hand supplied. If nothing resolved it, that is a **shut door**: refuse, and say which name is unregistered. It is not a prompt to type one in.
2. Push a `promote/<release>` branch carrying the source at the release's tag to the pair's repo, and open the pull request against its declared base branch; the body states the release and its proven evidence. The push is git and is already authenticated for that repository. Opening the pull request is an **API** call, and it goes through the **door**: run `"$FC_PAIR_DOOR"` in place of `gh`, same arguments. Plain `gh` carries the foundry's own credential, which reaches our org and was never granted to theirs, so it would authenticate as us against a repository nobody gave us - the API twin of the mistake the git helper already refuses. One door for every act on their repo, so the day a pair is not on GitHub only the door changes.
3. Deployed when the merge lands - theirs to review; report the PR URL and stop there unless asked to watch it.
4. Acceptance: the declared signal when the pair exposes one; otherwise the act closes at the merge.

Rollback, either kind: the same act at the previous version.

## The apps this act does not reach

Promotion moves what an entry environment proved, so an app that has none is not a promotion subject at all. A **Managed** app - one whose home is another organization's repository and which runs on no foundry - is exactly that: its line closes at proven-in-CI-and-merged, and the pull request it lands is its delivery or maintenance line's own output, not a promotion.

The door machinery is shared between the tiers; which line drives it, and at which bar, is what differs. Pre-flight step 3 already refuses here by construction, since there is no entry environment to serve the release live - and that refusal is the model working, not a gap to route around. An app reached by this act despite having no entry environment means something upstream has stopped deriving the bar from what exists.

## Where a target stands, as data

`fixtures/` carries REF-Promotion sections 5 and 6's derivation as a corpus: a declared target and what it carries in, its derived position and the queue's order out, one case per file. It exists because more than one runtime answers this question - the console derives it in Python, the desk in TypeScript - so no shared implementation is available to them and the corpus is what is shared instead. A surface that re-derives promotion state runs every case, and a rule read differently there than here fails a test rather than shipping two views that disagree about the same target. `fixtures/README.md` states the shape.

## Failure modes

- **The release is unproven** (missing artifacts, red CI, entry environment not serving it): refuse with the failing leg named. Promotion moves proof, never hope.
- **The app has no entry environment**: refuse, and say the tier rather than the symptom - this is a Managed app, its bar is proven-in-CI-and-merged, and its changes cross back through the delivery or maintenance line. Never relax the proven check to let the act proceed; a promotion that skips the entry environment carries nothing that was proved.
- **The target names an entry environment**: refuse; that environment is written by the platform, and the promotion would be overwritten by the next build.
- **The target environment's folder is absent from the deploy branch**: the install does not declare it, or the branch predates the declaration - check the install's `foundry.yaml` against the platform's seed-an-install guide before writing anything.
- **The pair credential is not held**: stop and name the unregistered credential. Registering it is the operator's own act, because a token for another organization's repository is granted to us rather than minted by us - the one credential the platform receives instead of issuing. Never inline one, never paste one for the occasion, and never fall back to a personal token or to the foundry's own: ours reaches our org and was never granted to theirs, so borrowing it answers for a door that cannot be opened. **Reaching for plain `gh` on their repository is that same borrowing**, quietly - the shell hands it our token and the call may even succeed against a public repo, which is how it goes unnoticed. Their repo, the door; our repo, `gh`.
- **The door was not actually performed**: a run that ends with no pushed branch and no open pull request has promoted nothing, whatever its exit code said. Land the door before the act ends - never park a push behind a background job and stop - and treat a green run with no door as the failure it is.
- **The probe never turns fresh**: report the promotion as deployed-but-unproven with the probe's last answer; do not retry past a reasonable watch, and do not roll back on your own.
