---
domain: practice
---

# REF: Promotion

> Read this when moving a proven release beyond the entry environment: the app-owned promotion contract, the three definitions a target carries, the act, and the checks that hold them.

---

## 1. The rule

**Deployment is automatic, exactly once. Promotion is deliberate, everywhere else.**

An install declares its environments, in order, when it is created (`REF-AppContract.md` section 5). The first is the **entry environment**: the one the platform deploys automatically, where every release lands on its own and is proven live. Every other environment is **manual**: nothing writes it but a promotion.

Promotion is the third line, beside delivery and maintenance. It is not a phase of either:

- **Build+Ship ends at the entry environment**, in every mode. A delivery is done when its release is proven live there (§3); what has not yet been promoted is the promotion line's queue, never a delivery's unfinished business (`REF-Delivery.md` §5).
- **A merged ticket is done when it is merged** (`REF-Maintenance.md` §6). The release that carries it, and where that release has since travelled, belong here.

Promotion moves proof, never hope. A release that is not proven on the entry environment does not promote: refused, not warned.

## 2. The contract

Where an app's proven releases may move is declared in **one file the app owns**, `devops/promotion.yaml`, beside its other contracts. Targets are a **selection the app makes**, not a derivation from what exists: an app promotes where it says, and nowhere else.

Each target names a destination and carries its `door`, `terms`, and `acceptance` **written out in full**. Nothing is resolved by an engine at run time; what the file says is what happens. A new repository is scaffolded with the shape as comments over an empty target list, so an app promotes nowhere until a hand declares a destination.

**Credentials are named, never stored.** The contract carries coordinates and a credential *name*; the secret itself lives with the platform, and no token ever enters a repository.

A malformed contract is **refused loudly**, never skipped: a hand wrote something, and promoting against a contract the hand did not declare is exactly the failure the loudness prevents.

## 3. The three definitions

| Definition | The question it answers | Values |
| ---------- | ----------------------- | ------ |
| `door` | How is the write submitted? | `commit`, to a branch we can push; `pull-request`, theirs to review and merge |
| `terms` | What is written, and what does deployed mean? | `version`: image tags and the chart pin, deployed when the target serves them. `source`: the code itself, deployed when the merge lands |
| `acceptance` | What does proven-there mean? | `suite`, the app's own integrated suite verdict where it is published - a `suite` acceptance MUST also carry `suite:` (the URL the verdict is read from) and `suite_pass:` (the matcher that reads it as a pass; a 200 is transport, not a pass), and the contract parser refuses one without them; `probe` (optionally carrying a URL), the target answers live; `none`, the promotion closes at deployed |

Acceptance is a property of the **target**, not a universal step. A destination we cannot reach declares the shallower signal it does expose, and the act closes on that honestly rather than pretending to verify what it cannot see.

Tests are the app's own, always: an app's integrated suite may traverse other apps because the app's own paths do, and an environment owns no tests. The suite that runs against a live environment after a deployment is a distinct surface from the suite CI runs in isolation; never dispatch the isolation suite at a target.

**A release is proven by an evidence chain, never by a single probe.** This is what `proven` means wherever it is required: at the entry environment before a delivery is done (`REF-Delivery.md` §5), and at a `probe` or `suite` target before a promotion closes. The chain is: the build green; the artifacts published at the new version; the write-back visible in git; and a cache-busted probe of the public URL whose **freshness metadata postdates the release**. A plain 200 proves transport and nothing else, because a stale pod or an edge cache answers exactly like a fresh one.

**Freshness must come from something the release actually changes.** A hardcoded version string is not freshness, and neither is a content-addressed asset hash: identical inputs give identical hashes across releases, and a change confined to the server side moves neither. Prefer, in order: the served document's own last-modified metadata; the running image's tag plus its start time; a build-stamped runtime endpoint.

**Where an edge fronts the origin, the busted probe is not the live probe.** Busting the cache proves the *origin* serves the release and says nothing about what a browser receives, so the release is also asserted at the real URLs a user reaches, with the edge's own cache status and age recorded beside it. An edge still serving the previous release is a degraded stop, not a live one. Record a busted probe as "origin serves X", never as "verified live".

**A capability the scope priced is part of the proof, not a separate concern.** Where a datastore, an identity realm, or an equivalent was priced, proven additionally requires that the capability is provisioned and that the running app is wired to it rather than to an in-memory stand-in. A priced capability that is absent is a degraded stop however fresh the response, because a fresh bundle over an in-memory store satisfies the freshness chain completely while failing the delivery: the freshness chain cannot see it, so this check is separate and mandatory. Reading a capability as absent and recording it as intended is the failure this exists to stop. **Bound is not usable**: a bound realm proves the app is wired to it, never that anyone can pass it, and what proves that is a positive sign-in claim (`REF-CSD.md` §6), attested where the credential already lives (`REF-Autonomy.md` §3).

## 4. The kinds of target

**`environment`**: a manual environment of an install we run. It names the `install` and the `environment`, and the door is a commit to that install's `deploy-<install>` branch of the app's own repository. The next environment of this install and an environment of another install we run are the same act; the only difference is which deploy branch the commit lands on.

**`repository`**: a repository in another organization. It names the pair's repo, its base branch, and the credential, and the door is a branch pushed and a pull request opened, theirs to review. The merge is what lands it, and their platform serves what they merged.

An environment target must never name an install's **entry environment**: that environment is written automatically, so the promotion would be overwritten by the next release.

## 5. The act

One promotion is one app, one release, one target. The operator picks those three; everything else follows from the contract.

| Step | What happens |
| ---- | ------------ |
| Refuse or proceed | The release is proven on the entry environment (artifacts published, CI green, serving live, its declared suite green), or the act stops with the failing leg named |
| The door writes | The commit lands on the deploy branch, or the pull request opens on their repository. **Authored by the human who acted**; pushed with the machine's credential |
| The platform reconciles | The target's own reconciler applies the branch, or their review merges the pull request. Nothing here is ours to do |
| Terms verify deployed | The target serves the version, or the merge landed |
| Acceptance verifies proven | The declared signal answers, or the promotion closes at deployed |

**The record is git.** The commit or the pull request *is* the promotion's record; nothing else is stored, and history is read from the same place. **Rollback is the same act at the previous version**, not a special mechanism.

**Holding an app is the studio's toggle, not a contract edit.** `freeze_promotion` writes the Image Updater tag filters that hold one app on its current version in the entry environment (a direct commit to the install's branch, the lifecycle exception to the PR shape), and `resume_promotion` reverses it byte-for-byte; a frozen app then ships by a deliberate hand-set tag, the same shape as a chart pin. Neither touches declared targets, and a frozen app stays fully verified: the bindings stay in place, so the promotion conformance rows and the status read keep watching it.

## 6. Pending is derived

What a promotion has not yet moved is a comparison, never a stored state: the proven release against what each declared target currently carries. Every app and target resolves to exactly one of:

- **pending**: proven is ahead of accepted, and no door is in flight
- **in flight**: a door was submitted and has not yet deployed or merged
- **unproven**: deployed, but the declared acceptance does not answer
- **unreadable**: what the target carries, or its declared signal, could not be read, or its door could not be opened at all; unseen is reported as unseen, never as current
- **current**: nothing to do

An app's targets are ordered by attention, unproven first (something claims to serve and does not), then unreadable, then in flight, then pending, ties broken by target name compared code point by code point. Nothing here is ever counted against a finished delivery or a merged ticket; it is the promotion line's own work.

**It rides the maintenance inbox rather than keeping its own** (`REF-Maintenance.md` section 7). One queue across the fleet was the point of that habit, and a second sweep would make two lists of the same morning. A pending, unreadable or in-flight target reads as a `promotion` signal there, ranked after `unreleased`, its rows within one repo in the order above; a target that carries the release while its declared signal says nothing reads as `drift`, which is what that word already means.

## 7. The checks

Conformance holds the declarations to the ground, on the platform side:

1. Every app deploy branch carries one folder per declared environment, and no env-config folder outside the declaration.
2. Automatic deployment bindings exist on the entry environment only; a promotion never touches bindings.
3. A declared contract parses, its target names are unique, and each target carries the fields its kind requires.

And the act itself enforces what conformance cannot see from the branch alone: only a proven release promotes, and an entry environment is never a target.

## 8. Anti-patterns

| # | Anti-Pattern | Correct Approach |
|---|---|---|
| 1 | Folding promotion into Build+Ship so a delivery "finishes" at the customer's environment | Build+Ship ends at the entry environment in every mode (§1); the promotion line carries it from there |
| 2 | Promoting a release the entry environment does not serve | Refuse, naming the failing leg (§5). Promotion moves proof |
| 3 | Declaring a target on an entry environment | Every environment target is manual (§4); the next automatic deployment would overwrite the write |
| 4 | Writing a credential into the contract | The contract names credentials; the platform holds them (§2) |
| 5 | Inferring targets from what exists (every install, every environment) | Targets are the app's declared selection (§2) |
| 6 | A service identity authoring the promotion commit | The signed-in human authors; the machine's credential pushes (§5). Identity on the record cannot be backfilled |
| 7 | Claiming a promotion proven when the target exposes no signal | Acceptance is the target's property (§3): declare `none` and close at deployed, honestly |
| 8 | Storing pending state | Pending is derived from proven against accepted (§6) |
| 9 | Dispatching the app's CI isolation suite at a live target | The integrated suite is a distinct, app-owned surface (§3) |
| 10 | Rolling back with a bespoke mechanism | The same act at the previous version (§5) |

## 9. Cross-references

- `REF-AppContract.md` - the install's declared environments and the automatic deployment into the entry environment: the substrate this line runs beside.
- `REF-Delivery.md` - Build+Ship's done-definition, which ends at the entry environment.
- `REF-Maintenance.md` - the ticket loop's done-definition, and the inbox habit this line's sweep is the sibling of.

---

## 10. Skills that instantiate this REF

Generated by `scripts/sync_backlinks.py` from skill frontmatter; do not edit by hand.

Skills whose frontmatter `refs:` includes `REF-Promotion`:

- `adopt` - Enter an app whose home is another organization's repository: stand up the foundry-side repo the line runs in, declare the home as the promotion contract's door back, and name its credential - the instantiation and its done-bar then derive from what exists, never from a claim.
- `promote` - Promote a proven release beyond the entry environment: resolve a target from the app's promotion contract, perform its door, verify terms (deployed) then acceptance (proven); the same act at the previous version is the rollback.

---

## 11. Agents that orbit this REF

Generated by `scripts/sync_backlinks.py` from agent frontmatter; do not edit by hand.

Agents whose frontmatter `refs:` includes `REF-Promotion`:

- `release-manager` - Moves a proven release to its next environment or repository, and brings an app whose home is elsewhere into the Foundry; hand it a release to promote or an app to adopt.
