---
name: platform-studio
galaxy: foundry
refs:
  - REF-AppContract
---

# MCP: platform-studio

> Knock here to onboard and manage apps on an install of the Foundry: manifest and onboarding-record reads, conformance-gated onboardings, lifecycle toggles.

The platform control plane's door; each install runs its own studio, targeting its own deploy branch by default. Reads return the install's manifest, per-app onboarding-record facts, and conformance reports; onboardings run server-side, are gated by the platform's own conformance suite, roll back byte-identical when the gates fail, and ship as pull requests based on the install's branch, admitted by the platform repo's own CI moments after they open.

## Doctrine

- The studio never commits an onboarding directly; the PR, based on the install's branch, is the admission record, and the platform repo's CI merges it. Lifecycle toggles are the one direct-commit exception, since they admit no app and grant no hostname: scaling an app to zero and back, and holding an app on its current version and releasing the hold.
- Everything team-owned (the app repo's deploy branch, its secrets) stays the team's to execute; the onboarding prompt is the runbook.
