---
domain: methodology
---

# REF: Demo Delivery

> Read this when a delivery line rehearses a shipped one for a showcase: a repo named `demo-<x>` over a line `<x>` the org already holds, every phase copying that line's deliverable into its own key and attesting the copy, so the whole line runs in minutes with its gates intact.

---

## 1. Scope

A **demo line** is the delivery line of `REF-Delivery.md` run over a line the organisation already holds, so that a room can watch every phase, every gate, the onboarding, and the live address land inside a presentation slot. Nothing is authored: each phase copies the source line's deliverable into the demo's own key and attests that the copy is faithful, and every gate closes by the one mechanism every line uses. The demo is disposable, and it never stands in for the source.

Read this REF when:

- A repo named `demo-<x>` is established, and `<x>` is a repository of the same organisation that carries a `delivery/*` ref or a `delivered/*` tag: a line that ran, open or closed.
- A showcase needs the line end to end inside a slot, and the point is the line itself (the phases, the records, the gates, the onboarding, the URL) rather than what an agent authors from a raw ask.
- A worker finds `.delivery/demo.json` on its scratch (§2): the line was opened as a demo, and every phase after scope reads that pin.

A demo is the fourth seed of `REF-Delivery.md` §1, "What the line starts from", beside an ask, a shipped phase, and a foreign app. Like the others it is derived, never declared: the name carries the prefix and the organisation carries the source, and a `demo-` repo whose `<x>` is no line is an ordinary new line that happens to start with a prefix. A demo composes with nothing: it is never adopted, never promoted, never a follow-on's prior, and its close is retirement (§6).

Cite `REF-Delivery.md` for the lifecycle and its gate mechanism. This REF says what each phase reads and copies instead of authoring, what the gate's review is on a copy, and what makes the line fast without leaving a gap in it.

---

## 2. The source and the key

The **source** is the line `<x>`: its repository at one commit, its estimation project, its prototype, and its onboarded app. The demo's **key** is `demo-<x>`, the repo's own name, and the delivery-side studios key on it as on any line (`REF-Delivery.md` AP-33): the demo's estimation project and prototype are `demo-<x>`, never a second name and never the source's. The demo's **app name** is `demo-` followed by the source app's fleet name, which equals `demo-<x>` only where the organisation names its repositories for the apps they hold (`REF-AppContract.md` §1).

Scope pins the source once, through the `demo-line` helper's `open`, into `.delivery/demo.json` on the line's scratch: the source repository, the commit every phase copies from (the source's default branch head at that moment), the two keys, the two app names, and the locked logo's path. Every later phase reads the pin and resolves nothing about the source on its own; a phase that resolved the source again could copy from a commit the previous phase did not, and the attestation would then compare two different things.

Rules:

- **The source is read over its own doors, at the pinned commit.** The estimation project over the estimation engine, the prototype over the prototyping hub, the tree and the locked logo over git at the pinned commit. The source repository is touched by nothing: no branch, no tag, no commit, no ticket.
- **The source's studio projects are read, never revised.** A demo over a source whose estimation audit is red stops at scope and says so. It fixes nothing in the source, because a demo that repairs its source is a maintenance act wearing a costume.
- **Secrets never ride in.** The carry (§3) leaves behind the env files an archive establish refuses (`REF-Recast.md` §2), examples excepted.

---

## 3. What each phase copies

The phases run in their order with their own skills. Each takes the pin as input and runs the `demo-line` helper for the mechanical half; what remains for the agent is the record, the journal line, and the platform acts every line performs.

| Phase | Copies, through `demo-line` | Still does as any line |
| ----- | --------------------------- | ---------------------- |
| Scope (`deliver-engagement`) | the source's estimation project into `demo-<x>`, file for file, under the demo's own display name (`copy-estimation`); the audit and the generated artifacts are re-run on the copy | the proposal record, pinning the same `delivers: P<n>` as the source's newest phase and that phase's requirement IDs as the spine; the journal; the gate |
| Design (`design-session`) | the source's theme, schemes, and screens into the prototype `demo-<x>`, and the source's locked logo into `docs/` (`copy-prototype`) | the design record through the close helper, locked over the copied theme and the carried logo; the gate |
| Intent + plan (`intent-session`) | the source tree at the pinned commit over the repo's skeleton, the identity renamed to the demo's, the locked logo kept verbatim (`carry-repo`); `intent.yaml` and every file that attests one of its claims arrive with it, and the carry is pushed on the default branch as one `feat(demo): carry <owner/source> at <sha>` commit, so the release builds while the plan gate is signed | the audit; the handoff, short and complete, pinning the repo strategy as **carried** at that commit and every capability grant the source holds under the demo's app name; the gate |
| Build + ship (`run-delivery-plan`) | nothing: the tree landed at plan, and `attest --phase build` re-reads it against the source | the release CI cut on the carried commit (or on the repair commit, §5), the entry environment's chart pin moved to that release (§5), the onboarding sequence the handoff orders, the reconcile when the sync holds a comparison from before the release, the four reads of the evidence chain (§5); the record; the gate |
| Learn (`reconcile-delivery`) | nothing | optional (§6) |

Three rules hold across the table:

1. **Copy, never author.** A phase that finds the copy incomplete for its gate reports the gap and stops. It does not fill the gap with authored substance, because the room would then be watching an ordinary line at demo speed while being told it is a copy.
2. **The identity rename is the only edit.** The source's name and the source app's name become the demo's, as whole tokens, in every text file the tree carries; the locked logo is excluded, binary files are excluded, and nothing else changes. What the room sees is the source app under a demo name at a demo address.
3. **Nothing improves.** A defect in the source is copied, attested as copied, and left where it is. Improving it is a ticket on the source's maintenance loop (`REF-Maintenance.md`), filed by a person after the show.

**The carry lands at plan, after the design gate.** Each phase's deliverable appears when that phase's agent runs and not before: the prototype is copied during design, and the tree, with the docs and the identity it carries, reaches the repo only once the design gate is signed. Landing it at plan rather than at build puts the release's CI behind the plan gate and the build pod's start, so build + ship begins with images to onboard; landing it at scope would show the room a look before design locked one.

**The carry is a releasing commit.** The release tool cuts a version only from a releasing Conventional Commit type (`REF-AppContract.md` §4), so a carry committed as a delivery record (`delivery(...)`, `docs(...)`) merges green, ships nothing, and leaves the demo's hostname serving the skeleton. Its subject is therefore pinned: `feat(demo): carry <owner/source> at <sha>`. A release alone is not the carried app live, though: the image updater moves only image tags (`REF-AppContract.md`), and the deploy branch the repo was born with pins the skeleton's chart, whose Service and environment do not fit the carried image. Build + ship moves that pin (§5).

---

## 4. The gate on a demo line: the fidelity check is the review

Every gate closes by the one transaction of `REF-Delivery.md` §1: a record at `status: gate`, a committed review artifact whose last `VERDICT` token is `PASS`, the deterministic export where the phase has a tool, and the stamper's signature. A demo line changes none of it. What changes is who writes the review artifact and what it asserts.

On an ordinary line the artifact is a fresh-eyes adversarial review: judgement over authored substance. On a demo line nothing was authored, and the substance's quality evidence already exists in the source line's own signed gates, closed over its own reviews. So the demo's review is a **fidelity check**, written by the `demo-line` helper's `attest`, deterministic and finished in seconds: it compares the copy with the source at the pinned commit and asserts only that the copy is faithful, naming what it compared, the source and the commit, and the source line's gates as the quality evidence. Its last line is `VERDICT: PASS` when every comparison holds and `VERDICT: FAIL` otherwise, and a failing round is still written and committed, because a FAIL on a copy is exactly the evidence the retried phase needs.

Rules:

- **The artifact is the helper's, never hand-written.** An agent that writes `VERDICT: PASS` into a review file itself is the forged signature of `REF-Delivery.md` §1 one step earlier, and the stamper cannot tell the difference. The rule is therefore the phase's: on a demo line the only writer under `.delivery/reviews/` is `attest`.
- **No adversarial review runs on a demo line.** A reviewer reading the copy reads the source's quality, which the source's gates already judged, and any defect it finds is one the demo must not fix (§3). Running it is the duplicated cost of `REF-Delivery.md` AP-41 at best and a repair of the source at worst.
- **The mechanical guards stay.** The journal a stamp refuses without, the `delivers:` pin the proposal export needs, the theme and the logo the design close needs, the handoff anchors the build pre-flight needs, and the `docs/` pages the build's exit check needs are each met by what the copy carries. A demo phase names each guard it satisfies rather than assuming the copy covered it.

---

## 5. Minutes, and what stays bounded

A phase on a demo line is mechanical but for its record: the helper copies in seconds, the fidelity check writes the review in seconds, and the agent's own work is the record's prose, the journal line, and the platform acts. The floors that remain are the platform's, not the agent's:

| Phase | What sets its floor |
| ----- | ------------------- |
| Scope, design, intent + plan | the worker's fixed costs: the clone, the skill read, the copy, the record, the push |
| Build + ship | the onboarding pull request's admission, the GitOps sync, the DNS record, the live probe; CI runs behind the plan gate (§3) |
| Learn | the journal stamp |

Rules for the build's evidence:

- **The evidence chain is four reads.** The build's evidence chain (`REF-Promotion.md` §3; the handoff's verification section) on a demo line is: the carried commit's CI run green, where the source's own suites ran against the carried tree; the platform reporting the app synced and healthy; one probe of the demo's hostname answering 200 with the carried page; and the build fidelity PASS. No local suite run, no probe per asset, no cache-busting: the claims were attested on the source line and CI attested them again on the carry, so a third run proves nothing the room needs and costs the minutes the demo exists to save.
- **Release first; reconcile a sync that cached the miss.** An onboarding that precedes the first green release leaves the GitOps Application holding an error for a chart that did not exist yet, and it stays there after the chart lands until the app is reconciled. With the carry at plan the release normally lands first; when the platform still reports a comparison from before the release, the build reconciles the app rather than waiting on a poll that never clears it.
- **The carry's release reaches the entry environment at build, and build repairs one that released nothing.** Two writes, both build + ship's on every demo line and within any demo handoff's grant whatever else it lists, because each authors nothing (§3): (1) **the repair commit**, only when the carried commit's CI is green, no release tag contains it (`git tag --contains <carried sha> --list 'v[0-9]*'` prints nothing), and no `fix(release): release the carried tree` commit already sits after it (a repair landed by an earlier, killed attempt is waited on, never repeated): one empty commit with that subject on the default branch, pushed, then its release run waited on, a green run with a new `v` tag continuing and a red or tagless run being a degraded stop that names the run; (2) **the chart pin**: on `deploy-<install>`, the entry environment's `Chart.yaml` dependency on the app's chart set to the released version, one commit `chore(deploy): pin the <app> chart at <version>`, pushed, skipped when the pin already names it. Read 1 of the evidence chain then names the commit the release was cut on, the carry's or the repair's. This is what lets a plain re-drive of build + ship finish a line whose plan phase carried under a non-releasing type, and a line carried correctly still needs (2).

Rules for the room:

- **Run the line interactive.** Each gate parks until the operator signs, so the run waits for the presenter and never the reverse; a one-shot demo races the slot.
- **Start before the slot.** Build + ship is bounded by CI and the sync; a line started a few minutes early lands its live moment inside the slot.
- **Pick a small source.** The source's image build time is the demo's floor.
- **Say what it is.** The room is watching the line at rehearsal speed over a delivery that already shipped: real records, real gates, a real onboarding, and a real address. It is not watching an agent scope or design from a raw ask; the source line's own cockpit shows that.
- **Rehearse on the same ground.** Every studio, the model credential, the git identities, and the edge must be up. A completed demo line's cockpit is the fallback when the live one stalls, because the state is derived and reads the same either way.

---

## 6. Learn and retirement

Learn is optional on a demo line. The line reads delivered once the delivery gate is signed, and that is the showcase's end. When Learn runs it files nothing: no `learn(...)` ticket on the playbook and no `learn:` ticket on the demo repo, because a rehearsal teaches the playbook nothing and the demo repo has no future. It journals its summary and, unattended, stamps the journal as on any line.

A demo is **retired**, never closed as a delivery: no `delivered/demo-<x>/P<n>` tag is minted, and the line's ref goes with the repo. The name is the key every surface files the line under, the executor's runs and the console's settings as much as the studios, the registry, the platform, and the platform's shared database, identity, and event-bus instances, so retirement frees the name only when nothing keyed on it remains. It is five acts, run by an operator after the show, in this order:

1. **Delete the line's runs, and the settings the console keeps for it.** The console reads a line's run off the name alone and takes the newest whatever its phase, so a run left behind attaches to the next line under the same name: a run parked on a gate turns the fresh line's cockpit into a gate that line can never sign, and a finished or failed one offers its own act in place of Drive. Delete rather than stop, because a stopped run still attaches. This is the act retirement cannot inherit from closing: closing a line stops its runs, and a demo is never closed.
2. **Offboard the app** (`foundry-offboard-app`, which frees the hostname and the namespace), when the line reached its onboarding, then **drop the database and realm** it was granted and **retire its events grant**. Offboarding leaves the database and realm on the shared instances (`REF-AppContract.md` section 6), and the bus may keep the app's reflected credentials and keeps its durable consumers; a grant for the next demo under the name provisions onto what they still hold, so that line would start on this one's data and credentials. The platform's tear-down-a-grant guide covers all three. A demo's data is disposable: the retirement is the disposition, for the grants and for the volumes the offboarding deletes with the namespace.
3. **Delete the two studio projects `demo-<x>`.** Archiving is not enough: an archived project keeps its key, and the next scope cannot create the project it copies into.
4. **Delete the app's packages** in the registry: its app image, its docs image, and its chart. A line retired before build + ship holds them too, because the skeleton it is established on already cuts a release. A package outlives the repository that published it and stays bound to it, so the next repository under the same name is refused when its release pushes, and the demo dies at its first release with a permission error that names nothing about packages.
5. **Delete the repo**, last. Archiving it keeps the name taken.

Retirement is done when a search for the name finds nothing on any of those surfaces. The next showcase then establishes `demo-<x>` again from the source as it stands that day.

---

## 7. Anti-Patterns

| # | Anti-Pattern | Correct approach |
| - | ------------ | ---------------- |
| 1 | Running the adversarial review on a demo phase, or fixing in the source what it found | The fidelity check is the review (§4); a source defect is copied, attested, and ticketed on the source after the show (§3) |
| 2 | Writing the review artifact by hand, or a `VERDICT: PASS` the helper did not compute | `attest` is the only writer under `.delivery/reviews/` on a demo line (§4) |
| 3 | Authoring what the copy lacks so that the gate closes | Report the gap and stop; a demo that authors is an ordinary line claiming to be a copy (§3) |
| 4 | Resolving the source again in a later phase | Every phase reads the pin in `.delivery/demo.json`; scope writes it once (§2) |
| 5 | Renaming inside the locked logo, or renaming by substring instead of whole tokens | The rename is whole tokens over text files, the logo excluded (§3) |
| 6 | Declaring a demo in a form, a flag, or a record | It is read off the name and the organisation: the prefix, and a source that is a line (§1) |
| 7 | Presenting the demo as authoring, or leaving it onboarded after the show | Say what it is (§5); retire it (§6) |
| 8 | Closing a demo with a delivered tag, or filing its lessons as tickets | A demo is retired, not delivered, and Learn files nothing (§6) |
| 9 | Running the demo one-shot inside the slot, or starting it when the slot starts | Interactive, started early, over a small source (§5) |
| 10 | Landing the carry at scope, or any phase showing a deliverable before its own agent ran | The prototype is copied during design and the tree lands at plan, after the design gate (§3) |
| 11 | Re-running the source's suites locally, or probing every asset, as the build's evidence | The four reads (§5) |
| 12 | Onboarding ahead of the first green release, then waiting on a sync that cached the miss | Release first, and reconcile the app when the platform reports a stale comparison (§5) |
| 13 | Retiring by deleting the repo alone, or archiving what must be deleted, so the next line under the name inherits a run, a setting, a project key, a package, or a granted database, realm, or bus credential | The five acts of §6 in order, runs first and the repo last; the name is free when nothing keyed on it remains (§6) |
| 14 | Carrying the tree under a non-releasing commit type, re-driving build + ship around a carry that released nothing, or taking a release for the app live while the deploy branch still pins the skeleton's chart | The carry is `feat(demo): carry <owner/source> at <sha>` (§3); build + ship lands one empty `fix(release)` commit when the carry cut no release, then pins the entry environment's chart at the released version (§5) |

---

## 8. Skills that instantiate this REF

Generated by `scripts/sync_backlinks.py` from skill frontmatter; do not edit by hand.

Skills whose frontmatter `refs:` includes `REF-Demo`:

- `demo-line` - The demo line's deterministic helpers per REF-Demo: pin the source at scope, copy its estimation project, its prototype, its claims and its tree into a demo-<x> line's own key, rename the identity, and write each gate's fidelity check as the review artifact the stamp closes over.
