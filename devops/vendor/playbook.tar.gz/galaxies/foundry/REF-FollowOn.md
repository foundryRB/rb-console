---
domain: methodology
---

# REF: Follow-on Delivery

> Read this when a delivery line is a follow-on to a shipped prior phase over the same repo and customer (same slug, new phase). Covers the durable homes a follow-on reads (the delivered tag object, the open forward tickets, the repo itself), how to carry what the prior line left unresolved as the leading hypothesis for the new BUG-NNN assumption, what not to redo (onboard, re-estimate, re-lock design), and how to keep the cockpit's slug linkage intact.

---

## 1. Scope

A **follow-on delivery** is a new phase over a repo that already shipped a prior phase for the same customer. Same git repo, same estimation slug, same protopane project, and the same platform manifest entry - which is keyed on the app's own name, not on that slug (section 5). A new phase, not a new line. The follow-on is **additive, never a supersede** (`REF-Delivery.md` AP-27).

Read this REF when:

- A new customer request arrives on a repo carrying a `delivered/<estimation-slug>/P<n>` tag - a prior line closed with a signed delivery gate.
- The new request overlaps what the prior line left unresolved - the open `learn:` forward tickets reconcile filed on the delivery repo (`REF-Maintenance.md` §7).
- You need to decide what to carry forward and what to treat as new.

Cite `REF-Delivery.md` for the overall lifecycle and AP-27 (don't supersede a shipped estimate) and #33 (don't reword the estimation slug). This REF fills the gap between those two: **how to triage the new request against the prior line's durable output without re-deriving what the prior phase already surfaced.**

---

## 2. What a follow-on reads: durable homes only

A follow-on line reads **only durable homes**. Three, and nothing else:

- **The delivered tag object is the marker.** The annotated `delivered/<estimation-slug>/P<n>` tag object carries everything a phase needs about the prior close: its existence (the phase shipped and is frozen, `REF-Delivery.md` AP-35), the phase in its name, its date, and the `attests:` default-branch SHA - the anchor to exactly what shipped, so drift since delivery is the diff between that SHA and the default branch's HEAD. Read the tag, never its tree.
- **What the prior line left unresolved lives as its open forward tickets.** Reconcile files the run's forward recommendations - its unresolved `PD-NNN` items included - as `learn:`-titled issues on the delivery repo (`REF-Maintenance.md` §7). The follow-on reads the **open** tickets; a closed one was resolved and carries its resolution.
- **Current truth is the repo itself**: `docs/` (the brand page, the architecture target, the ADRs), `intent.yaml` and its tests, and the code. The repo drifts between a delivery and its follow-on, so nothing that describes the repo at delivery time substitutes for reading it now.

The tag-anchored scratch history - the prior line's retained records, reachable behind the tag - is a **human audit trail, and nothing more**: a person tracing how the prior line ran can surface it, and **no phase takes it as input**. A prior `build.md` describes the repo at delivery time, so a phase that reads it substitutes a stale snapshot for current truth; and any read of the tag's tree binds the doctrine to how a particular close happened to retain the records. The three homes above are the whole read surface.

---

## 3. The leading-hypothesis rule

When the customer's new request carries a `BUG-NNN` whose symptom overlaps an unresolved item from the prior line - an open forward ticket on the delivery repo (§2) - the follow-on scope phase **must not** treat the defect as a from-scratch mystery. The leading hypothesis for the `ASM-DEFECT-NNN` assumption is the prior line's unresolved `PD-NNN` as its ticket states it, with the signal it named and the evidence the ticket carries.

Mechanically:

1. **Read the delivery repo's open `learn:` tickets before writing the new assumption** (§2). Every `PD-NNN` the prior phase left unresolved at its close - items it named but did not close, draft `INT-*` claims it left `draft`, pending work whose evidence chain was never completed - is a forward ticket there; find the ones the new request's symptom overlaps.
2. **Cite the `PD-NNN` and its ticket in the assumption's rationale.** The assumption reads: "Customer report of X; leading hypothesis is prior `PD-NNN` (issue #NN, <one-line summary of what it named>). Triage starts there; if the root cause turns out to be different, that is new information flagged for reconcile, not a scope miss."
3. **Confidence is MEDIUM by default, not LOW.** The prior phase already did diagnostic work; the follow-on inherits it. Raise confidence only when the follow-on's own evidence (a reproduced test, a fresh log) strengthens the hypothesis beyond what the ticket carries.
4. **Propagate to every file that names the requirement.** The estimatekit audit checks structural consistency but not semantic consistency across files. The same hypothesis must appear in the BRD, the assumptions sheet, the matrix notes, and the phase description. A contradiction the audit doesn't catch is still a defect; surface it in the fresh-eyes review.

This is not a limit on discovery. If triage surfaces a different root cause than the prior `PD-NNN` named, that is new information. Flag it at reconcile as a lesson the prior phase missed, and codify it. The rule prevents the more common failure mode: throwing away the prior phase's diagnostic signal and paying for it twice.

---

## 4. What not to redo

The follow-on phase inherits the prior phase's durable output. Do not redo it. Specifically:

- **Do not re-onboard the platform manifest entry.** The prior phase already created it. The follow-on only syncs or extends it. Re-onboarding risks collisions (duplicate ArgoCD Application, duplicate Gateway) and orphans the app the cockpit already tracks. The commonest way a follow-on reaches that mistake is addressing platform-studio by the delivery slug, finding nothing, and reading the miss as "never onboarded" (section 5).
- **Do not re-lock the design.** The visual identity (palette, typography, logo) the prior phase committed to `docs/brand.md` is frozen. The follow-on reuses it; `docs/design.md` in the new scratch only points at the prior lock.
- **Do not re-estimate the prior requirements.** Phase 1's 15 requirement IDs stay frozen. The follow-on adds new requirement IDs for the new ask only. The estimate audit re-runs only over the new IDs.
- **Do not re-sign prior gates.** A signed proposal, design, plan, or delivery gate from the prior phase is not reopened. The follow-line's own gates close over the follow-on's own work.

The follow-on's scratch records (`.delivery/proposal.md`, `.delivery/design.md`, `.delivery/handoff.md`, `.delivery/build.md`) note the prior phase by its `delivered/<estimation-slug>/P<n>` tag - the marker (§2) - not by restating its content.

---

## 5. Slug linkage

Every **delivery-side** studio the follow-on touches (estimatekit, protopane) must be addressed by the **verbatim slug** the prior phase used. Never reword, hyphenate, prefix, or suffix the slug. The cockpit links the new phase's artifacts to the prior phase's artifacts through the slug; a reworded variant produces a new, orphan project the cockpit cannot relate to the original delivery.

**platform-studio is not one of them.** It keys on the app's FLEET name - the manifest entry, and so the namespace, the hostname label, the chart and the GHCR packages - which is a fact of its own (`REF-AppContract.md` section 1) and equals the delivery slug only where an organisation names its repositories for the apps they hold. Addressing it by the slug on an install where the two differ returns nothing, which reads as "never onboarded", and the follow-on then onboards a SECOND time: a duplicate manifest entry, namespace, hostname and Gateway that only an offboard undoes (section 4 forbids exactly this).

Mechanically:

- If the prior phase used slug `2ez4tv`, every delivery-side studio call in the follow-on uses `2ez4tv`.
- Address platform-studio by the app's name, which the prior phase pinned in its handoff and the admission record still carries. Read the app's identity and source repository through the door rather than deriving its name from the slug.
- If a delivery-side studio rejects the slug (for example, a DNS-1035 label rule that rejects a leading digit), the fix belongs on that studio's side, not on the slug. The slug is the durable linkage key.
- Record the verbatim slug in the follow-on's `.delivery/proposal.md` frontmatter, the estimate project's identity, and the protopane project's identity. The platform manifest entry is keyed on the app's name, not this slug, and is not restated here.

This rule is AP-33 in `REF-Delivery.md`; this REF restates it because it is the single most common way follow-on lines silently disconnect from their prior phase.
