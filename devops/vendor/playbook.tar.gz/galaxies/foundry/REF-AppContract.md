---
domain: practice
---

# REF: Application Contract

> Read when shaping an application for delivery on the Foundry, onboarding its capabilities, or retiring it. The application owns its source, tests, documentation, images, chart and environment configuration; the install owns admission and grants. Current platform procedures live in its own documentation and the `platform-studio` door.

## 1. Application identity and ownership

The app's fleet name and its repository are separate facts. The fleet name identifies the admitted application; the repository identifies its source. Declare both, and address the platform by the fleet name even when the delivery's key is the repository name.

The application chart ships its own workloads and route, bound to its own Gateway. Install-owned resources belong to the admission record. Duplicating a platform-owned route in the chart makes two reconcilers claim it and can block other applications' admission.

Every value that differs by install or environment is required configuration. Missing configuration fails at rendering or startup, naming the missing key. A default is valid only when correct in every supported context.

## 2. Admission

Onboarding admits an application and its hostname to a particular install. The operator's request authorizes that act; a pre-authorized delivery's priced scope already authorizes its application and priced capability grants (`REF-Autonomy.md`). Do not ask the operator to repeat that decision.

The onboarding record is rendered from the install's own facts and the app's declared identity, never copied from a neighboring app. Application identity and capability choices are explicit: a public scaffold does not establish an application's authentication posture.

Admission lands as a conformance-gated pull request against the install's deploy branch. The platform's CI merges it; nobody merges an onboarding pull request by hand. Repair a failed gate before admission and follow the platform runbook's bounded wait and failure reporting.

Create a greenfield repository through the platform's current scaffold. Shape an existing repository to section 4 before onboarding. A deployable documentation image is mandatory. Completion requires the released application to serve at its declared address, with its granted capabilities and intended authentication verified. A merged admission record alone is insufficient.

## 3. Capability and credential boundaries

- A database grant gives the app its own database and least-privilege owner role. The app cannot connect to or access another app's database. Connection coordinates are configuration; the password is a secret.
- An identity grant gives the app its own realm and realm-scoped administration. Its chart binds only its own issuer, client and credential. Register each required callback through the identity provider's procedure. The application chooses which routes require login and verifies unauthenticated access fails closed.
- An event grant authorizes publishing only under the domains the app owns. Each domain has one owner. The private signing seed stays in the application's namespace; the app owns its publisher and the one-way test (`REF-Events.md`).
- Platform-provisioned credentials are generated in-cluster and scoped to their consumers. An app never receives an administrative credential or another app's credential. Provisioning is idempotent and does not rotate a live value on a repeat run.
- A machine endpoint authenticates its machine audience even when a browser proxy protects the human surfaces. Its credential must reach that endpoint intact; verify both authentication paths (`REF-MCP.md`, `REF-Identity.md`).

The platform's capability guides own grant rendering, provisioning and teardown. Follow those guides through the door; the runbook and its conformance evidence determine which team-owned configuration remains to apply.

## 4. The app-repo contract

An onboardable app repo carries a fixed layout so the platform builds, deploys, and documents every app uniformly:

```text
<repo>/                      # the code repo, main branch - named for the REPOSITORY, which
                             # is a fact of its own; every other <app> below is the app's
                             # FLEET name (namespace, hostname, chart, packages), and the
                             # two are equal only where an organisation names its
                             # repositories for the apps they hold (section 1)
  .github/workflows/  build is a THIN CALLER of the shared build workflow; test is app-owned - never a hand-rolled pipeline, never a per-app registry token:
    build.yml    uses: <org>/ci/.github/workflows/build.yml@main (secrets: inherit) - the section 4 conformance gate, release, and publish (images, chart, docs)
    test.yml     REQUIRED, and must run on pull_request (INT-FOUNDRY-063): the app's OWN unit/e2e/docs/intent suites (they vary too much to share a workflow); plain actions/setup-node, never assigning NODE_AUTH_TOKEN - csd-library's npm packages are public
  devops/      docker-compose.yml, the source of truth for the images the repo builds: one build: service per image, each named by its image: (see "Images the repo builds" below); no image-push script (CI publishes)
  k8s/         a Helm chart (Chart.yaml, values.yaml, templates/), not loose manifests
    secrets/<name>.env.example   only when values.yaml sets a non-empty auth.existingSecret (see "Auth secrets" below)
  docs/        a deployable docs site, built under base /apps/<app>, carrying the STARLIGHT intent bundle:
    Dockerfile               a plain `npm ci` - csd-library's npm packages resolve from public npm, so no build secret and no .npmrc
    intent.yaml              the bundle's INT-STARLIGHT-* claims (docs frontmatter)
    vitest.config.ts         runs the meta-test
    tests/starlight.test.ts  a vitest-intent meta-test attesting every page's frontmatter
  README.md    sections: run with docker, develop without docker, layout, commits (names the commit convention)
  .env.example runtime configuration, documented
  intent.yaml  CSD-INTENT-01 claims (see REF-CSD.md)
  .pre-commit-config.yaml  a bypassable commit-msg hook checking Conventional Commits (the version scheme reads them)
  .gitignore   REQUIRED (INT-FOUNDRY-064): the build trees the repo's own tooling writes - node_modules/ beside each package.json, dist/ and .astro/ beside each Astro config, __pycache__/ where the repo carries Python
```

Plus, on `origin`, a **`deploy-<install>` orphan branch** per install the app runs on (no shared history with `main`) holding that install's per-environment config the GitOps controller watches: one folder per environment the install declares (section 5), each a `values.yaml` and a `Chart.yaml` pinning a published chart version from the org's chart registry (`oci://<registry>/<owner>/charts`). Per-install config (host, issuer, any value that differs per install) lives on its own branch, so an app on two installs never shares one `prod/values.yaml`. The in-repo `k8s/` chart is the source the published chart is cut from; the `deploy-<install>` branch pins which published version each environment runs. This is the env-config housing - one repo per app (N+1), config in a branch rather than a separate config repo.

Hostname, image, and chart are never hardcoded on the platform side: the hostname is fixed once, at onboarding approval, in the app's `teams/<app>/` folder on the install's branch, and the image and chart version are pinned per environment on the `deploy-<install>` branch.

**A repo ignores what it generates.** The layout above is authored files; everything the repo's own tooling writes beside them is artifact, and `.gitignore` is what holds the two apart (INT-FOUNDRY-064). The scaffold renders the file with the contract files, and conformance holds every repo to it: without it, `node_modules/`, `dist/`, `.astro/`, and `__pycache__/` sit untracked and unignored from the first clone, and one `git add -A` commits them. The demand is per evidence - a repo is never asked to ignore a tree it cannot produce, because a gate that fires on an impossible tree is noise, and noise is how a gate gets skipped - and git answers the ignore question itself, so a nested `.gitignore` or a negation counts exactly as git counts it.

### CI: build is a thin caller, test owns its suites

An app repo does not author its build pipeline: `build.yml` is a thin caller of the reusable build workflow in the org's `ci` repo (`uses: <org>/ci/.github/workflows/build.yml@main`, `secrets: inherit`), which owns conformance, release, and publish in one place so it cannot drift. That reusable workflow runs the per-app conformance suite from the ci repo's own `conformance/` directory (the single home of the section 4 claims: an executable pytest suite with its intent claims, pointed at the one checked-out app) plus the `csd-intent` audit, the commit-hygiene check, and the org's secrets scan, and `release needs` them, so a repo that bypasses it is never conformance-gated before publish and every release rides the scan. The suite lives beside the workflow that runs it, and never as a re-implementation inside the workflow: a hand-mirrored copy of the checks is exactly the parallel-maintained duplicate universal violation #1 forbids, and it drifts precisely where it hurts (the claims added after the mirror was written).

Test is deliberately not a thin caller: suites are genuinely per-app (a python `pytest`, a sibling-clone Playwright e2e, an Astro `validate`), so there is no single reusable test workflow to call. Each app owns its `test.yml`, and a node job in it is a plain `actions/setup-node` - there is nothing shared left for it to source, because there is no credential.

**Its contents are the app's; its existence is not.** `test.yml` must exist and must run on `pull_request` (INT-FOUNDRY-063). Because the *suite* is per-app there is nothing to share, so the contract holds the *file*: a repo without one runs no CI on a pull request. That costs nothing while every commit lands on `main` by a trusted hand, and everything the moment a repo is public: an outside contributor's PR merges with nothing having run against it. The scaffold therefore ships the file carrying the one gate every app repo has by contract, the `csd-intent` audit of its `intent.yaml`, plus a commented placeholder for the app's own suites.

Two consequences follow, and both are contract, not style:

- **No hand-rolled build pipeline.** A per-app workflow that re-implements release / publish inline is a violation even if it works today: it duplicates logic that must stay single-sourced, and it skips the conformance gate the shared build workflow enforces (INT-FOUNDRY-013).
- **No per-app registry token.** An app never assigns `NODE_AUTH_TOKEN`, and there is nothing for it to assign: csd-library's npm packages are published to the **public npm registry** (csd-library ADR-0003), so `npm ci` resolves them anonymously - no `.npmrc`, no scope mapping, no PAT, no build secret. A workflow that sets the token variable is wiring a credential the registry never asks for, and fails closed when the secret it names does not exist (INT-FOUNDRY-039). This matters beyond tidiness: GitHub Packages requires auth to *read* even a public package, so **an app repo that depends on a package served from there can be made public but not forked**: an outside contributor gets a 401 on `npm ci`, and the repo is readable without being buildable. Public npm is what makes an open-sourced app repo genuinely forkable. (A repo may still hold `PACKAGES_READ_TOKEN` for GHCR pushes into an org namespace; that is an image-registry credential and unrelated to npm.)

The scaffold drops both workflows from fixed templates - `build.yml` (the thin caller) and `test.yml` (the app-owned PR gate, stubbed with the intent audit); a delivery's build phase must never write CI from first principles.

### The dependency-audit bar is the app bundle, not the docs bundle

A Foundry app ships two npm bundles whose exposure is not remotely the same, and the dependency-audit gate a handoff pins (`REF-Delivery.md` §4) does not apply to both alike.

- **The app bundle is the bar** and must audit clean: every finding fixed, or accepted as below. It serves users, takes input, and runs against the app's own routes.
- **The docs bundle is a fully static, prerendered Starlight site** (the layout above): no SSR path, no dynamic render, no request-time input, nothing running server-side after `astro build`. Advisories that require exactly those paths - the Astro SSR-render classes and the `sharp`/libvips image-processing ones are the recurring examples - are not reachable in it.

Two rules follow, and they exist because otherwise every app with a docs bundle rediscovers and re-argues them from scratch, at build time, alone:

- Advisories against the **pinned platform docs toolchain** that need an unreachable path are accepted at platform level, **once, here**. A delivery does not re-litigate them, and a run that stops on them has stopped at a wall that is not there (`REF-Delivery.md` §10 degraded stop-states).
- **Do not diverge from the pinned baseline to chase them.** Astro and Starlight move together in a peer range; a major bump to clear a docs advisory breaks that range and strands the app on a toolchain no other app runs - a real, permanent cost paid against an unreachable finding.

This is a claim about **reachability**, not a blanket exemption for anything under `docs/`. An advisory that does apply to a static, prerendered, input-free site is an ordinary finding there like anywhere else, and a docs bundle that stops being static stops qualifying for any of this.

#### Accepted advisories and Dependabot alerts

**An app bundle accepts an advisory only when the app is not affected by it.** A fixable advisory is fixed, never accepted, and an inconvenient fix is not a reason. An advisory with no fix the app can take, which does not affect the app for one of VEX's not_affected justifications, is recorded as a VEX not_affected statement in the repo's root `accepted-advisories.yaml`, through a reviewed pull request. The shared build workflow's dependency audit reads the file and holds its schema.

Dependency and Dependabot work follows this procedure:

1. Read the advisory, affected versions and each affected manifest, then inspect the repo's existing `accepted-advisories.yaml` and its review record. Check the vulnerable path against the repo's actual use; a development dependency or a `docs/` path alone proves no exemption. One advisory can affect several bundles, and acceptance must hold for each affected use.
2. For app findings, apply the acceptance rule above. Reuse a reviewed entry while its evidence still holds; additions and corrections go through a reviewed pull request and validate against the current shared dependency-audit composite's `accepted-advisories.schema.json`. That schema owns the fields and justification values; never invent a parallel exception format. For qualifying pinned static docs findings, use the docs policy above and verify that this repo meets its conditions.
3. Once the applicable acceptance is established, with any new or changed repo entry on the default branch, explicitly dismiss each matching open Dependabot alert in GitHub or through its API. The YAML serves the CI audit; GitHub's alert state requires this separate act. Use `not_used` when the vulnerable path is unused, or another supported dismissal reason that matches the evidence. The dismissal comment names the advisory and manifest, explains the reachability finding, and links the merged acceptance record or the applicable docs policy. Dismiss only the alerts whose affected uses were checked.
4. Read each alert back and verify its state, dismissal reason and comment; record the alert links and outcome on the maintenance issue or PR. Missing alert access or an affected manifest whose acceptance is unproven remains explicit follow-up. A merged acceptance entry alone does not complete that follow-up. Reassess entries and reopen dismissed alerts when a change invalidates their evidence.

For an unused vulnerable path, the explicit CLI act and read-back are:

```bash
gh api --method PATCH 'repos/<owner>/<repo>/dependabot/alerts/<number>' -f state=dismissed -f dismissed_reason=not_used -f 'dismissed_comment=<reachability evidence and acceptance link>'
gh api 'repos/<owner>/<repo>/dependabot/alerts/<number>' --jq '{state, dismissed_reason, dismissed_comment}'
```

The [Dependabot alerts API](https://docs.github.com/en/rest/dependabot/alerts#update-a-dependabot-alert) defines the supported reasons and required access.

### Images the repo builds (compose is the manifest)

The shared build caller's app-name input is the fleet name. When the source repository has a different name, set that input explicitly: its default is the repository name, which would publish packages under a name the deployment does not watch.

Build only from sources the build environment reaches reliably. A large payload fetched from an external CDN can stall restricted runners even when it works on a developer's machine; vendor or remove such a payload rather than making release depend on that download.

A repo may ship more than one image (a static site plus a backend, an app plus a companion service). `devops/docker-compose.yml` is the single source of truth for that set: each image is a `build:` service, named by its compose `image:`, and CI builds and pushes every buildable service under that name. The single-Dockerfile repo is the one-image case of the same rule. So adding a second image to an existing app is a compose edit (declare the new `build:` service), not a CI change; CI enumerates what the compose declares rather than being told the image count out of band. A build target the compose does not declare is not built, and one declared without an `image:` publishes nowhere.

The compose file is parsed, never run: CI reads it for the build set, and nothing in the cluster consumes it. Running the stack locally with `docker compose up` is a second use the same file serves, which is why one `devops/Dockerfile` backs both the local run and the shipped image (ADR-018), which removes the drift between what runs locally and what deploys.

**The docs image is the one released image the compose does not declare.** CI builds `docs/Dockerfile` separately and publishes it as `<app>-docs` whenever that file exists, so a repo's full released set is its compose `build:` services **plus** that image. Everything reasoning over the released set counts both halves: the deployment's image bindings (one per released image), the released components declared at onboarding, and the install's `image-updater-released-set` conformance row, which derives the set from those same two paths on the app repo's default branch. Since the repo shape above gives every app a `docs/` with a `Dockerfile`, an app onboarded off the compose alone under-counts by exactly one, and the docs image ends up with no alias watching it: it pins its first tag forever while CI keeps publishing new ones, with no crash and no red status.

### Auth secrets (fail-closed)

An app that protects routes names its credential through `auth.existingSecret` in `k8s/values.yaml` and **fails closed**: every protected route returns `503` until that Kubernetes `Secret` exists. The real value never enters git. A platform-provisioned credential exists before the app does (the grant's in-cluster generator mints it on sync); only a value the cluster cannot generate (an external fact: SMTP credentials, a PAT) is applied out of band by the platform's secret-provisioning runbook from a git-ignored `<name>.env`. What the repo commits is the discoverable template `k8s/secrets/<name>.env.example` (which keys to supply); an app that names `auth.existingSecret` but ships no matching example leaves the credential silently absent and serves nothing once deployed. The fail-closed default is what makes publishing a public hostname safe: a not-yet-provisioned or misconfigured app refuses requests rather than exposing an unprotected surface. The check holds vacuously when `auth.existingSecret` is unset (an app gated elsewhere, or one keying its `Secret` differently).

### Machine-door keys (chart-minted)

An app whose MCP door carries its own HTTP Basic key (`REF-MCP.md` §7) and hands that key to a signed-in person through its own route (a credential endpoint behind the app's sign-in, feeding a connect-an-agent panel that shows the ready connect command) holds a value nobody needs before it exists, so the cluster generates it: the app's **own chart** mints it with the same generate-if-absent idiom the grants use. A `ServiceAccount`, a `Role` granting `create` on secrets and `get`/`patch` on that one Secret name, and its `RoleBinding` sync at the earliest wave; a `Sync`-hook Job at the next wave creates the Secret only when absent, mints the password from `/dev/urandom` as hex without echoing it, and reflects nowhere; the `Deployment` syncs after both and reads the Secret by **required** reference, so the pod never starts without its key. Sync waves order resources only within one sync, which is why the mint ships in the chart that ships the `Deployment` rather than in a grant the platform syncs on its own. The chart names the Secret itself, never through `auth.existingSecret`, and ships no `.env.example` for it. Key rotation follows the application's credential runbook and requires reconnecting its consumers.

### Out-of-band secret ordering (optional envFrom resolves once, at start)

A container's `envFrom` reads a `Secret` only at start, and an `optional: true` reference is what lets a pod schedule before its out-of-band secret exists (section 3): the kubelet resolves the reference at container start and, finding the secret absent, injects nothing rather than blocking. It does not re-resolve when the secret appears later. So a fail-closed sidecar or app whose credential comes from an `optional: true` secret `envFrom` starts **without** the env whenever the secret is created concurrently with the pod (the kubelet saw it absent), and stays credential-less until a `rollout restart` re-reads the now-present secret. The workload never becoming ready looks like a bad secret, but the secret is fine; only the read is stale. Provision the out-of-band secret **before** the workload that consumes it, or restart the workload once after applying the secret. This is the ordering counterpart of the checksum-annotation rule below: that rerolls on a *changed* config, this covers a config that was *absent* at the one start that read it.

### Config rollout (checksum annotation)

Kubernetes does not restart pods when a `ConfigMap` changes, and env vars injected via `envFrom` are read only at container start. Without a trigger, a config-only change syncs as a silent no-op: the GitOps controller applies the new `ConfigMap`, the running pods keep the old values, and the gap is invisible until the next image roll.

Any chart `Deployment` that consumes the app `ConfigMap` via `envFrom` therefore carries a `checksum/config` annotation on its **pod template** (not the `Deployment` metadata; only a pod-template change rolls pods), hashing the config it consumes so any change to it re-renders the annotation and rolls the pods:

```yaml
  template:
    metadata:
      annotations:
        # ConfigMap in its own template file (the common case): hash the rendered file
        checksum/config: {{ include (print $.Template.BasePath "/configmap.yaml") . | sha256sum }}
```

When the `ConfigMap` renders in the same template file as the `Deployment`, hash the values that feed it instead - `include` of the file the annotation itself lives in would recurse:

```yaml
        checksum/config: {{ .Values.<config-key> | toYaml | sha256sum }}
```

The rule holds vacuously for a `Deployment` with no `envFrom` `ConfigMap` reference (a static docs server, say): nothing read at start, nothing to roll.

### Pause (scale-to-zero)

A single node has finite capacity, so an onboarded app can be switched off without being offboarded. A paused app keeps its namespace, routing, database, and identity but runs no workload pods, releasing the CPU and memory a running pod reserves; data is never at stake, because pause is not offboarding.

The chart expresses this as a top-level `paused` value, defaulting to running, that every non-docs workload reads for its replica count, so one flag scales all of an app's workloads to zero at once:

```yaml
spec:
  replicas: {{ if .Values.paused }}0{{ else }}1{{ end }}
```

```yaml
# values.yaml: apps ship running.
paused: false
```

The rule holds vacuously for the docs `Deployment`: documentation stays served while an app is paused, so its replicas never read `paused`.

Operational pause is controlled through the platform, separately from the application's version pins. The deploy branch owns which version runs; the platform owns whether it runs at all.

### Commit convention

The release tool computes artifact versions from Conventional Commits, and the shared CI checks every pushed commit against the platform's commit convention before the release job runs, so a commit outside it merges and ships nothing. The convention itself (the admitted types, what each releases, the no-trailer rule) is documented once, on the platform's docs portal; the scaffolded README names it and points there, and the scaffolded `.pre-commit-config.yaml` runs the same checks at `commit-msg` once installed per clone (`pre-commit install`), bypassable by design. Only the config is committed and conformance-checked.

### Releasing chart-source fixes

The in-repo `k8s/` chart is the source; the registry holds the published chart the release tool cuts from it. Because that tool derives the version from the Conventional Commit type, a fix to the chart source reaches the published chart only under a releasing type (`fix`, `feat`). A `chore(chart)` is a well-formed message that cuts no chart version, so the published chart keeps its old default while the source on `main` is corrected - a silent divergence that surfaces on the next fresh install, not in the running app.

Rule of thumb: if a chart change must be consumable by a fresh install (a new environment pulling the published chart), commit it as `fix`/`feat`; `chore(chart)` is fine only for edits that never need to reach the registry, or a value the running environment already overrides on its `deploy-<install>` branch. When a correction ships as `chore`, that environment is right only because its deploy-branch overlay pins the corrected value; the registry default stays wrong until a releasing commit re-cuts the chart.

## 5. Environments and release evidence

Each install declares its ordered environments. The first is the entry environment, deployed automatically; later environments are written only by deliberate promotion (`REF-Promotion.md`). An environment is live only when a reconciling deployment targets it: verify that fact before requiring live acceptance there.

An application has a `deploy-<install>` orphan branch per install, containing one folder for each declared environment with its chart pin and values. Each install's host, issuer and version configuration belongs on that install's branch. The source chart and the published version an environment consumes are distinct artifacts.

Automatic deployment moves image tags in the entry environment. Chart changes require a deliberate published-chart pin update; a new image does not prove a new chart is deployed. For an umbrella chart, values and image write-back paths use the subchart prefix. Every released image, including docs, must be represented and consumed by the matching chart value. The platform's runbook owns the binding layout.

Verify publication, deployed revision, credentials and the live edge response. Standing platform conformance covers install-owned state; app-side agreement is checked at admission/reconciliation and in the app's release pipeline. A green install report alone does not attest the application.

## 6. Retirement and name reuse

Offboarding is an explicitly authorized retirement. It removes the admission record and releases the application's platform resources through the conformance-gated admission path. Source-repository archival or rename remains the owning team's decision.

Before invoking retirement, enumerate the live namespace's volume claims and the application's grants. The live state is authoritative; a chart source can differ from the deployed version, values or subcharts. Take required backups while the credentials and workloads still exist. Record the disposition of every volume and granted datastore or realm before the act can destroy it.

A run without an operator never decides to destroy data. It can proceed only when it has proved no live volume claims exist or already has explicit authorization for each claim's disposition. An unreadable claim set counts as present and parks the act with the failed read named. After offboarding, enumerate grant teardown and park that leg for the operator; never guess a drop (`REF-Autonomy.md`).

Deleting a namespace can delete its volumes and their data. Shared databases and realms can outlive admission removal; the platform's teardown runbook owns their disposal. A fleet name is reusable only after retirement and disposal of the previous app's grants under that name. Renaming a repository releases none of those resources and cannot make the name safe to reuse.

## 7. Application conformance

The application passes its owned suites and the shared app contract gates. Required evidence includes:

| Guarantee | Evidence |
| --- | --- |
| The repo satisfies section 4 | Shared repo-contract, workflow-caller, commit-hook and ignore-coverage checks |
| The declared images and docs are published and represented in deployment | App CI reconciliation plus admission evidence |
| Every declared environment has the required branch configuration | Environment and deploy-branch checks |
| Documentation is deployable and attested | Docs image and full STARLIGHT bundle tests |
| Authentication fails closed and identity belongs to this app | Credential, auth-template, identity-binding and human/machine route tests |
| Configuration changes reach the process | Config-checksum and rollout evidence |
| All app workloads pause while docs remain served | Pause-toggle checks |
| Third-party sidecar images are pinned | Image-pin checks |
| Every Deployment references the install's registry pull secret through `imagePullSecrets` | Pull-secret checks (INT-FOUNDRY-045) |
| Docs workload labels match their Service selector and the app's docs tile | Docs-label checks: `app.kubernetes.io/name: <chart>-docs` on the docs pod |
| The chart owns no install-owned resources | Route-parent and resource-ownership checks |

Use the platform runbook's current evidence surfaces for the install's half. Fix an unmet contract where its owner can resolve it; never waive a failed gate because another surface reports green.

## 8. Anti-Patterns

| Anti-pattern | Required approach |
| --- | --- |
| A hand-written release pipeline or copied shared conformance suite | Use the shared build caller and app-owned test suites (§4). |
| An app chart declaring a platform-owned route or another app's identity | Bind only its own granted routing and identity (§1, §3). |
| Copying a neighbor's onboarding folder | Render from this install's facts and explicit app identity (§2). |
| Manually merging an admission pull request | Let the platform CI admit the conformance-gated change (§2). |
| Declaring success at merge or image publication | Verify the deployed revision and intended live behavior (§5). |
| Deriving the released set from compose alone | Include the separately published docs image (§4). |
| Treating missing configuration as a reason to inherit another install's value | Require each install's own configuration (§1, §5). |
| Retiring an application to reclaim capacity | Pause when the intended act preserves its data (§4, §6). |
| Reusing a name after only renaming the source repository | Offboard and dispose of the previous grants before reuse (§6). |

---

## 9. Skills that instantiate this REF

Generated by `scripts/sync_backlinks.py` from skill frontmatter; do not edit by hand.

Skills whose frontmatter `refs:` includes `REF-AppContract`:

- `foundry-offboard-app` - Retire an application from an install after its data disposition is authorized; verify resource release before its fleet name can be reused.
- `foundry-onboard-app` - Onboard an application onto an install of the Foundry through its conformance-gated admission path, then verify the released application serves with its intended capabilities.
- `foundry-onboard-database` - Grant an admitted application its own isolated database and verify its application-owned connection under the platform runbook.
- `foundry-onboard-events` - Grant an admitted application publishing rights over its owned event domains and verify its one-way publisher and isolation.
- `foundry-onboard-keycloak` - Grant an admitted application its own identity realm and verify its human and machine authentication under the platform runbook.
- `promote` - Promote a proven release beyond the entry environment: resolve a target from the app's promotion contract, perform its door, verify terms (deployed) then acceptance (proven); the same act at the previous version is the rollback.

---

## 10. Agents that orbit this REF

Generated by `scripts/sync_backlinks.py` from agent frontmatter; do not edit by hand.

Agents whose frontmatter `refs:` includes `REF-AppContract`:

- `builder` - Builds the app its handoff describes and takes it to a live address; hand it a closed plan gate, or an app to onboard onto the Foundry.
- `release-manager` - Moves a proven release to its next environment or repository, and brings an app whose home is elsewhere into the Foundry; hand it a release to promote or an app to adopt.
