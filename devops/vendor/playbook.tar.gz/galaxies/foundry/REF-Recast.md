---
domain: methodology
---

# REF: Recast Delivery

> Read this when a delivery line starts from a working application rather than from an ask: an existing, usually vibecoded, app that is re-coded to the playbook's standards and onboarded on a foundry. Covers what a recast reads (the app in the repo, the ask when there is one), what each phase derives from the app instead of authoring, the improvement floor a recast never inherits, and how the source stays the oracle for the delivered functionality.

---

## 1. Scope

A **recast** is a delivery line whose seed is a working application rather than an ask: an app that exists, usually built fast in a prototyping tool, that the line re-codes to this playbook's standards and onboards on a foundry. The app is the first input; the customer's words, when there are any, are the second. The line is the ordinary five-phase line of `REF-Delivery.md`, with the same skills, gates, and records. What changes is what each phase reads and what it derives instead of authoring.

Read this REF when:

- The line's scratch carries an application under `_recast/` that is not yet one of ours - the code, the screens, and often the data - and a `seed/<slug>` tag marks the commit that brought them. The repo itself is born the ordinary way: templated with the app contract where a studio can, so `main` is green and holds none of the source from its first commit.
- The operator handed the app to establish as an archive (a console's establish takes it as a zip and lands it under `_recast/` on the scratch it mints), or copied it into `.delivery/_recast/` by hand on a line established at a terminal and committed it on the line's ref.
- The ask, if any, says "make this real" or "bring this onto the platform", or names the app rather than describing a feature.

Which seed a repo carries is read at scope per `REF-Delivery.md` §1, "What the line starts from", and nothing declares it. This REF governs the foreign-app seed; it applies beside `REF-FollowOn.md` when the repo also carries a delivered tag.

Cite `REF-Delivery.md` for the lifecycle and `REF-FollowOn.md` for the sibling case. This REF fills the gap between an ask that describes what should exist and an app that already shows it: **how to derive scope, design, and claims from running software without inheriting its substance.**

---

## 2. The source: read as evidence, kept as history

The app the line starts from is the **source**. It sits under `_recast/` on the line's own scratch ref - `.delivery/_recast/` in a mounted worktree - and nowhere on the default branch, and it has exactly one role: evidence of intent. Scope reads it to learn what the app does, design reads it to learn how the app looks, intent reads it to learn what must stay true. No phase reads it as a specification of how anything is built.

- **The source is a legacy artifact from the first commit** (`REF-Delivery.md` §1, "What survives"): frozen, viewable, never maintained - by construction, not by convention. The scratch is an orphan ref no workflow triggers on, so the source meets none of the app contract's gates that `main` enforces; close tags the ref `delivered/<slug>/P<n>` and removes it, so the source stays reachable under that tag and under `seed/<slug>` for as long as the repo exists, which is the provenance a later reader needs. A line established before the scratch carried `_recast/` holds its source on the default branch instead: read it there, and expect the build to replace it.
- **The ask is still captured verbatim.** The customer's words say why; the source says what. A recast with no customer words captures the operator's own line, so the request record exists and the coverage audit has a text to trace.
- **Secrets never ride in.** A source that carries keys in tree (an env file, a token in a config) is refused at the door: a console's establish refuses the archive naming the files, and a hand push is the operator's own screen before the line opens. A key that reached history is rotated, never merely deleted.

---

## 3. What each phase derives

The phases run in their order with their own skills. Each takes the source as input and derives what a greenfield line would author.

| Phase | Derives from the source | Still authored |
| ----- | ----------------------- | -------------- |
| Scope (`deliver-engagement`) | the requirement spine: one requirement per screen, route, action, and entity the source exposes, priced; the brownfield schema walk of `REF-Delivery.md` §2, where the schema is usually browser storage or flat files and every entity gets a disposition in the recast | the improvements (§4), each as its own requirement ID; anything the ask adds |
| Design (`design-session`) | the visual identity, harvested from the running UI into tokens (palette, type, the logo or mark it already carries) and locked into `.delivery/design.md`; the approved screens are captures of the source | the art direction paragraph and the interaction model, pinned from what the source does; any dimension the source never showed |
| Intent + plan (`intent-session`) | one claim per behaviour the spine names, attested by a test the recast must pass; the build handoff pins the repo strategy as **rebuild**: into the scaffold the repo was born with (a console line is templated at establish; a line established by hand without one runs the bootstrap skills first), the source under `_recast/` read as reference, the frontend markup carried where it holds under `REF-Frontend.md` | the claims for the improvements; the assumption protocol for what the source leaves ambiguous |
| Build + ship (`run-delivery-plan`) | the delivered surface: the same screens, the same actions, the same words; the identity landed from `docs/` | the app contract (`REF-AppContract.md`), identity, persistence, tests, onboarding |
| Learn (`reconcile-delivery`) | as any line | as any line |

Three rules hold across the table:

1. **Derive the surface, never the substance.** What the user sees and does is carried; how the source achieved it is rebuilt. A backend copied because it works has inherited every shortcut the recast exists to remove.
2. **Change the frontend as little as possible.** The customer accepted the look they have. Markup and styling carry across where they hold under the frontend REFs; where they do not, the change is the smallest that makes them hold, and it is named in the design record.
3. **Every deviation from the source is a requirement.** An improvement (§4), a dropped surface, a renamed action: each is a requirement ID in the spine, priced and visible to the signer. Nothing improves quietly.

---

## 4. The improvement floor

Some things a recast never carries over, whatever the source did. Each is pinned at scope as a requirement and attested at intent as a claim; none is an implicit upgrade.

| The source typically has | The recast has |
| ------------------------ | -------------- |
| No accounts, or a login that is decoration | an identity rung chosen per `REF-Identity.md`, the account spine from its bootstrap skill |
| State in browser storage, flat files, or a hosted backend with its key in the client | a database the platform grants (`foundry-onboard-database`), a schema, and the disposition of every existing entity (§3) |
| Keys in the tree | secrets held by the platform, cited by name |
| No tests | intent claims and their tests, the only maintained spec (`REF-Delivery.md` §1) |
| One file per concern, or one file for everything | the architecture the stack's REFs prescribe, recorded in `docs/` and its ADRs; its claim attests by a boundary test (`REF-Tests.md` §2), never by the page or the ADR existing |
| No app contract | the platform's contract, landed at build and onboarded (`REF-AppContract.md`) |

The floor is a floor: the ask may add to it, and the signer may decline an item at the proposal gate. It is never lowered by omission.

---

## 5. The source as oracle

The claims a recast writes describe behaviour the source already exhibits, so the source is the oracle for them. Where the source runs, run the behaviour tests against it first: a test that fails against the source describes something the source never did, and it is either a pinned improvement or a wrong claim. Then the same tests must pass against the recast. A divergence between the two at the delivery gate is either a requirement the signer accepted or a defect; there is no third reading.

Where the source cannot run (a hosted export with no runtime), the oracle is the captured screens and the operator's walk of the app, recorded in the design record, and each claim cites the capture it derives from.

---

## 6. Anti-Patterns

| # | Anti-Pattern | Correct approach |
| - | ------------ | ---------------- |
| 1 | Copying the source's backend, data layer, or login because it works | Derive the surface, rebuild the substance (§3); the improvement floor names what is never inherited (§4) |
| 2 | Improving the UI because the builder could | Change the frontend as little as possible; every deviation is a requirement the signer sees (§3) |
| 3 | Skipping design because a look already exists | The identity still has to be harvested into tokens and locked, then landed in `docs/`; the build never invents one (`REF-Delivery.md` §3) |
| 4 | Treating the ask as the spine when the app is the seed | The source is the first input; the ask adds to it (§2) |
| 5 | Claiming behaviour the source never had, or dropping one it had, without a requirement | One requirement per surface, one per deviation (§3); the oracle run catches the rest (§5) |
| 6 | Reading the source as a specification of how to build | It is evidence of intent and a legacy artifact (§2); the architecture comes from the stack's REFs |
| 7 | Leaving a key that reached history in place | Refuse at the door; rotate what got through (§2) |
| 8 | Declaring "this is a recast" in a record, a flag, or a form | It is read off the repo at scope, like every other fact about a line (§1) |
| 9 | A handoff pinning the repo strategy "in place" on a recast, or a stack ADR carrying the source's structure | The repo strategy is rebuild, into the scaffold the repo was born with (§3); an ADR fixes frameworks, and the layout is what the stack's REFs prescribe (§4) |
