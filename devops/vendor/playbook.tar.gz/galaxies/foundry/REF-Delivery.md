---
domain: methodology
---

# REF: Delivery

> Read this when taking a customer idea end to end: scope, design, intent and plan, build and ship, and the learning loop that closes each engagement and feeds the playbook.

---

## 1. The delivery line

Five phases carry an idea to a live app you can trust. Each phase is **one delivery skill driving a tool underneath**; each hands to the next **across a gate**; a learning loop runs through all five and is closed once at the end. This REF is the connective tissue: it orders the phases, says what each leaves behind and where it lives, and states the one rule that keeps the repo clean. Cite the phase REFs and the tool REFs; do not restate them.

The versioned phase definition is `deliver-engagement/lifecycle.json`. Its catalog references, artifact handlers and dependency order are checked by `validate_lifecycle.py`; that helper generates the table below with `--write`. `artifact-handlers.json` names the supported artifact identities. The gate stamper selects the phase's exporter from its declared artifact in `--definition`, which defaults to the canonical definition beside the helper. Runners package the stamper, artifact catalog and definition from one immutable source revision.

<!-- lifecycle-table:start -->
| # | Phase | Delivery skill | Drives (the tool underneath) | Question it answers | Gate it closes |
| - | ----- | -------------- | ---------------------------- | ------------------- | -------------- |
| 1 | Scope | `deliver-engagement` | the estimation engine (`REF-Estimation.md`) | What is asked, and what would it cost? | proposal |
| 2 | Design | `design-session` | the prototyping hub (`REF-Design.md`) | What should it look and feel like? | design |
| 3 | Intent + plan | `intent-session` | CSD intent authoring (`REF-CSD.md`) | What must be true, and how do we build it? | plan |
| 4 | Build + ship | `run-delivery-plan` | the platform (`REF-AppContract.md`) | Is it working software, and is it live? | delivery |
| 5 | Learn | `reconcile-delivery` | the playbook (`REF-Authoring.md`) | What did it teach, and what comes next? | (closes the loop) |
<!-- lifecycle-table:end -->

The delivery skill *drives* the tool; it is not the tool. `deliver-engagement` runs the estimation engine, it is not the engine; `intent-session` drives CSD intent authoring, which is a methodology, not a skill of its own. Keep the two layers distinct: each tool owns its mechanics, stated by its door's own guide or by its own REF; this REF and the skills own the lifecycle.

`deliver-engagement` is also the **entry point**. In interactive mode it is just phase 1 and hands you the next command; in one-shot mode it runs the whole line itself (below). The other four skills each take only the delivery `<repo>` and read the scratch to know where they are.

### The four gates

Five phases, four handoffs, one gate at each. A gate is a dated approval recorded in the phase's own scratch record; the next phase does not start without it. **Every gate is the same mechanism** - there is no special "operator gate" or "customer gate", only who signs a given one:

| Gate | Signed by (customer engagement) | Recorded in | Unblocks |
| ---- | ------------------------------- | ----------- | -------- |
| proposal | the customer accepts the estimate and quote | `.delivery/proposal.md` (+ the estimation project) | Design |
| design | the customer approves the look | `.delivery/design.md` (the locked visual identity) | Intent + plan |
| plan | the operator signs the build handoff | `.delivery/handoff.md` | Build + ship |
| delivery | the responsible operator accepts the shipped app against the claims table | `.delivery/build.md` (the operator's validation vs the claims) | Learn |

In an internal or self-serve engagement one person signs all four; record them anyway, so the trail reads the same either way. The uniform gate is the point: do not build a heavier ceremony around one handoff than another.

**The delivery gate is the responsible operator's acceptance.** The operator validates the shipped app against the claims table, may give feedback and re-drive, and signs. The customer's acceptance (UAT) starts after the line closes and never holds it: it is the evolution loop's first entry, feeding new requirement IDs (`REF-Maintenance.md` §1). In one-shot the engine's stamp over the fresh-eyes review is that acceptance, and on a Managed line the home's merge closes the gate (`run-delivery-plan`); in every case the customer's acceptance follows the close.

**How a gate closes - one transaction, every mode.** A gate closes in exactly one way, whoever drives, in four steps:

1. The phase's record reaches the gate in the canonical state (`status: gate`, `signed: pending`), written by the record helper (`deliver-engagement/reach_gate.py`), never by hand.
2. The phase's fresh-eyes adversarial review passes, every round of it saved verbatim as a committed review artifact (`.delivery/reviews/<record-stem>-<date>-r<N>.md`, the record's newest being the gate's evidence) and recorded in the record's `reviewed:` field.
3. For a phase with a tool, the stamp's **deterministic gate export** freezes that phase's engineering deliverables into the scratch: proposal exports the delivered phase's architecture and assumptions from the estimation project into `.delivery/architecture/` and `.delivery/assumptions/`, and its estimated effort: the phase's activity files verbatim into `.delivery/estimate/` (`P<n>-build.tsv`, `P<n>-project.tsv`) and a per-stream effort table appended to the proposal record when it carries none (a heading, `| Stream | Effort |`, one `| <stream> | <N> MD |` row per stream summed from the project activities, and a `| Total | <N> MD |` row; a point per stream, since the estimate is the person-alone baseline); design exports the approved screens and theme from the prototype into `.delivery/design/`. **A gate cannot freeze what it cannot read**, so an unreachable tool, a missing pointer, or a phase without its activity files refuses the stamp.
4. The deterministic **gate helper** (`deliver-engagement/stamp_gate.py`; the design phase's `close_gate.py` composes the identity lock with this same stamp) writes the signature.

Who may write it:

- **The helper is the only writer of `signed:`, in any mode**, and it refuses without the evidence: a recorded passing review always, plus the signer's approval in interactive (the date and by-whom the operator relays). Beside the date, in the same act, it writes the closure's two machine-read fields: `signed_at:` (the signing moment, UTC to the second) and `outcome:` (how the gate closed: `as it stood`, `with edits`, or `re-driven`; the signer's `--outcome`, else derived from the record's attempt and its review rounds, and only a signer says `with edits`).
- **Authority and mechanism are distinct.** The *signer* authorizes - the customer or operator in interactive, the operator's standing pre-authorization exercised by the engine over the passing review in one-shot - and the *helper* writes.
- An agent may run the helper carrying the signer's relayed approval, but **never decides a gate, never edits `signed:` by hand, and never offers to sign a pending gate**: a pending gate is handed back to its signer, with the exact helper command the signer can authorize.
- **Runners never re-implement the stamp** (no `sed`, no inline substitute): they run the helper itself, so the trail is byte-identical everywhere and every guard rides along.
- **Re-read a record against HEAD before offering it for signature.** It was written while the work moved under it, so early assertions may be false now, especially after a re-cut release: re-run its verifying commands at HEAD and restate each assertion as the command's current output, preferring the command over the remembered fact.

**How a signed gate is un-signed - the only two legitimate acts.** Un-signing returns `signed:` to `pending`; it is never a re-stamp (the stamp stays `stamp_gate.py`'s alone, AP-30), and only two acts do it. (1) An **operator re-opens a phase**, deliberately sending the line back to an earlier gate: that gate un-signs and every downstream record stays in place, flagged present-but-needs-review, never deleted, so nothing already built is lost (INT-FC-R40; the console's `reopen_gate`). (2) The **runtime's self-sign fail-safe**: a dated `signed:` found in a record *before* the stamp helper has run is the agent forging its own gate (a live worker did exactly this, despite the "do not sign" instruction), so the runner strips it back to `pending`, clears the self-written `reviewed:`, commits the correction at once, and closes the gate the legitimate way for the mode. A self-signature is never trusted; every runner strips it, the console-less one-shot in the run itself, because otherwise a forged signature closes a gate with zero fresh-eyes review. This is the counterpart to the only-writer rule above: a signed gate is authoritative (AP-24, a downstream phase never re-opens it on stale prose), and these two acts are the only ways it becomes unsigned.

A gate review has **two recorded outcomes**. Signing accepts: the dated stamp in the record. Rejecting is **re-driving the phase with recorded feedback**: the review's reasons are appended to `.delivery/journal.md` before the rerun and hand the phase its new input, so it revises the existing artifact and record instead of reproducing them from unchanged inputs. Rejecting without reasons is not a review - an unsteered rerun of the same inputs remakes the same record. Only the re-driven phase sees the feedback; downstream phases read the revised record, not the review. The loop itself has exactly **two carriers**: the committed artifacts in `.delivery/reviews/` and the record's `reviewed:` field. A record body that narrates its own review loop - round counts, verdict tallies, correction commentary - is itself a finding, and its resolution is **deletion, never correction**: corrected narration is new unread prose the next round must judge, so it cannot converge, while deletion leaves nothing to re-read: a live, done app can be held degraded for round after round by its record's own loop narration. And the journal's mid-loop entries - the rejection feedback above, lessons logged as they happen (`REF-Maintenance.md` §7) - are reconcile's input, never gate evidence: the review blocks on the record alone.

### Two ways to run the line

`deliver-engagement` takes `mode=`. Both modes run the same deterministic orchestrator; what differs is only what a gate does.

- **Interactive** (`mode=interactive`, the default): *you drive.* The gates are real: when a phase reaches its gate the run suspends and waits for your signal, then resumes into a fresh session with the next command. The default for customer work, where the gates are real conversations.
- **One-shot** (`mode=one-shot`): *it drives, from the trigger to the done-definition, with no human in the loop.* The gates compile to no suspend steps, because choosing one-shot is the operator's standing pre-authorization of them (`REF-Autonomy.md` §3), but each gate still **closes over evidence, per phase, at run time**.
  - **Every gate still earns its stamp**: the phase's fresh-eyes review of the committed record, and on its PASS the deterministic stamp ("How a gate closes", above; the helper, never an agent). **The runner spawns no review of its own.** The review is the phase's, run through the `adversarial-review` skill before the record reaches its gate; the runner (the one-shot sequencer, the console's worker entrypoint) locates the record's newest committed review mechanically, reads its last `VERDICT` token, and stamps over it (AP-40). The stamp being a helper rather than the orchestrator is what keeps the console **optional** (the accelerator principle, §1), so a console-less runner closes its own gates by that lookup and the helper alone.
  - **One-shot never stops to ask.** Any decision the durable inputs do not answer takes the assumption protocol (`REF-Autonomy.md` §1) and the run continues; a failing review is a failed attempt retried fresh against the recorded critique ("A gate review has two recorded outcomes", above), never a stop.
  - **The one ending short of the done-definition is a genuine external wall** - the cluster off, a registry unreachable - taken as the handoff's named degraded stop-state, reported plainly and never faked live (`REF-Promotion.md` §3).
  - **Whether a phase may ask a human mid-run is not a mode the operator picks** but the launcher's `interaction` flag (below); absent recorded overrides, one-shot runs on conservative defaults and logs what it assumed (`REF-Autonomy.md` §1, §2). Choosing one-shot is itself the human judgment: supervising a first run on unfamiliar ground is guidance, not a gate the tooling may stop on (AP-12).

Both run over the same artifacts and the same orchestrator, so a run started one way can be finished the other.

### `interaction`: whether a skill may ask

`mode` decides what a gate does; `interaction` decides whether the *running skill* may talk to a human, and it is a property of **where the skill executes**, not of the delivery. A skill launched inside an automated pod (the console compiling a phase into an Argo step) runs `interaction=auto`: no human is reachable inside the pod, in either mode, so it must never block on a prompt. Any decision the inputs do not answer takes the assumption protocol (`REF-Autonomy.md` §1) and the run continues; a skill that stops to ask in a pod hangs it. A skill a person runs directly at a terminal runs `interaction=manual`: the human is there, so it may ask and resolve decisions in a back-and-forth.

This is not a presence dial the operator authors, and not a third run mode: the launcher sets it. The console always passes `auto`, because a pod never holds a human, even for an interactive-mode delivery whose operator signs the gates from the console between steps. A bare invocation with no flag defaults to `manual`, an unflagged call being almost always a person at a terminal. Because it describes the runner and not the run, it is passed per invocation and never persisted in the scratch: a delivery begun `manual` and resumed in a pod runs that phase `auto`, with no stale flag to mislead it.

### Each phase runs an adversarial review

Adversarial review is a **reflex of every phase**, not a step of one. Before a phase closes its gate and drops its scratch record, its output goes through a **fresh-eyes** review: not the agent that produced the output re-reading its own assumptions, but a fresh, independent context (the `adversarial-review` skill) hunting what the producer's context made invisible.

- **What it reviews, per phase**: the scope for unpriced asks and silent scope drops; the design for un-shown dimensions; the handoff for unpinned decisions and cross-document contradictions; the built software for correctness, security, and contract conformance, and the documentation pages it landed against `REF-Documentation.md` §7.11.
- **The review reports; it does not fix.** The caller resolves the findings: under `interaction=auto` it fixes them and assumes per `REF-Autonomy.md` §1, under `manual` it settles them with the operator.
- **Rounds converge on a prior, and a PASS ends them.** A re-review reads the previous round's committed report as part of its standard (the skill derives it), verifies its blockers closed, and applies its lenses only to what changed since; unchanged bytes are not re-read (AP-32). Every round is committed, FAIL included, as `<record-stem>-<date>-r<N>.md`. A re-review is owed only after a FAIL; a PASS is the review, and non-blocking findings folded in afterwards ride the attempt without another round (AP-41).
- **A passing review is a precondition of the stamp in both modes** (§1), recorded in the record's `reviewed:` field: in one-shot it is what lets the engine stamp the gate, in interactive it additionally informs the signer, who approves over it.
- **The verdict is machine-readable.** The review ends with a single `VERDICT: PASS` or `VERDICT: FAIL` line, and every runner reads the last such line the review carries (tolerant of markdown emphasis and trailing prose), so any runner can gate on it mechanically.
- **Verbatim protects the reasoning and verdict from being edited to fit; it was never a mandate to commit credential-shaped strings.** Every release rides the org's secrets scan (`REF-AppContract.md` §4), which cannot tell a reviewer's throwaway `user:pass` placeholder in a quoted transcript from a leak, and a verbatim artifact cannot be reworded after the fact - so redact such strings at authoring time (`<redacted>`, noted in place).

The build's code review is the most visible instance, but the discipline is uniform: no phase hands to the next on its own first draft, and the trust comes from the review and the gate, not from the model that produced the draft.

### The scratch, and how a phase resumes

Phases hand over **via artifacts, not memory**, and each handover is **to a fresh agent**. Fresh context cuts bias, hidden assumptions, and token cost, and each handover doubles as a natural review gate.

- **The handover surface is `.delivery/`, the delivery scratch**, and it lives on **one orphan git branch per line, `delivery/<line-id>`**, holding the whole scratch and nothing else. The line id is the line's establish date (`delivery/2026-08-18`) and the records sit at the branch root. The branch shares no history with the default branch, so the app's history carries only the app's own commits, and its CI, its check signal and its release train never see a scratch write.
- **In a working checkout the branch mounts at `.delivery/` as a linked git worktree**, minted with the mount in one deterministic act by `establish_scratch.py`. The default branch git-ignores `.delivery/` - the mount point, never the records, which are committed on their own ref. On disk every record reads `<repo>/.delivery/<record>`, so the gate helpers stay single-root file I/O and every skill's paths hold whatever ref carries the bytes.
- **Exactly one `delivery/*` ref may exist per repo.** The ref's existence *is* the "this repo carries a live delivery" fact: discovery enumerates the namespace and resolves the single ref, establish refuses to mint while any exists, and every reader treats more than one as an anomaly to surface, never a state to silently pick from.
- **A cancelled run resumes exactly where it stopped.** A fresh checkout remounts by running the establish helper itself, which resolves the single ref and adds the worktree idempotently - the true helper, never a hand-rolled mount (AP-30) - fetching first where the checkout is stale, since the helper reads only the refs it already knows. It then reads which records exist and continues from the first one missing.
- **There is no progress file to drift.** Progress is *derived* from the scratch itself, the way a GitOps loop derives state from the world rather than trusting a status field.

**Each phase commits its record and pushes it, naming the line's ref.** The fresh agent the next phase hands to may be a fresh *clone* - a cloud sandbox, another machine, a new session with no shared working tree - so a commit that never leaves the local tree is invisible to it, and the resumability guarantee above silently fails: the run loses the record or repeats the phase. A committed-**and-pushed** record is the only handover that holds across sessions, so the push after each phase's commit is part of the contract, not an environment nicety that some consoles happen to do and others skip - and it names its ref explicitly (`git -C .delivery push origin delivery/<line-id>`; a console's API writes carry the resolved ref), because a bare `git push` lands on whatever branch is checked out, which is exactly how scratch commits would reach a history that never wanted them. Triggering the delivery run is the operator's authorization for these pushes - the delivery-specific reading of the workspace's "push is the operator's call" default, where the call is made once, at launch. A run that *cannot* push (no credentials, remote unreachable) stops at a degraded stop-state on the first failed push, applied per ref, and reports it, rather than pressing on to lose the work silently at the end.

**Every one of those commits follows the platform's commit convention** (`REF-AppContract.md` §4), on the scratch ref and on the app's default branch alike; on the default branch it is a release precondition.

One record per phase, plus a journal that runs through all of them:

| Record | Written by | Holds |
| ------ | ---------- | ----- |
| `.delivery/proposal.md` | Scope | the requirement-ID spine, the proposal-gate stamp, and the frozen per-stream effort table the stamp appends; points at the estimation project and carries the stamp's export beside it (`.delivery/architecture/`, `.delivery/assumptions/`, `.delivery/estimate/` - the delivered phase's engineering deliverables and its activity files, frozen at the signature); the sales artifacts stay behind |
| `.delivery/design.md` | Design | the locked visual identity (logo, palette, type) and the design-gate stamp; the stamp's export beside it (`.delivery/design/screens/`, `.delivery/design/theme.css`, and `.delivery/design/design-system.md` when the hub recorded which system seeded the identity - the approved screens and their rationale, frozen at the signature); plus throwaway build guidance the prototype cannot carry |
| `.delivery/handoff.md` | Intent + plan | the one-shot build handoff (the "plan"): run-scoped decisions, pointers to the durable homes, the plan-gate stamp |
| `.delivery/build.md` | Build + ship | the build-and-ship log and the evidence chain; the delivery-gate stamp |
| `.delivery/journal.md` | every phase | lessons, defects, and user sentiment logged as they happen, closed once at reconcile (`REF-Maintenance.md` §7) |
| `.delivery/reviews/` | every phase | the verbatim fresh-eyes review outputs, one artifact per round (`<record-stem>-<date>-r<N>.md`, FAIL rounds included); the runner closes the gate over the record's newest, and the gate helper reads that artifact's last `VERDICT` token as the review evidence, so a claimed pass and its on-disk review cannot disagree (§1) |

**The journal is a phase-exit obligation, not a habit.** It is opened by the **first** phase and appended by every phase after it, and a phase that logged no lesson still leaves the file present, because "nothing to report" and "nobody reported" are different states and only the first is trustworthy. Telling every phase to log "as it happens" is not enough on its own - two real lines reached reconcile having never created the file, and nothing in the lifecycle noticed until the close - so the gate helpers enforce it: `stamp_gate.py` and `close_gate.py` **refuse to close a gate while `.delivery/journal.md` is absent**. Every phase closes its gate through one of them (AP-30), which is what makes one check bind all of them. An absent journal at reconcile is therefore a finding, not a refusal - the close still runs, in reconstruction mode, and says so - because by then the loss is already taken: the evidence chain is reconstructable from git, and the run's **sentiment** and its **gate-rejection feedback** (the reasons appended before a re-drive, above) are not.

reconcile-delivery closes the whole scratch at the end: it confirms every durable decision reached its durable home, codifies the surviving lessons (`REF-Maintenance.md` §7), then closes the line - the annotated `delivered/` tag pushed, the mount removed, the ref deleted at a terminal (`interaction=manual`), or the journal stamped and the branch left for the operator's console close when unattended (`interaction=auto`, `reconcile-delivery`) - so nothing ephemeral is ever maintained and nothing durable is lost.

### The record frontmatter

Every record above opens with the same flat frontmatter block, so progress and provenance are read from the record itself, not reconstructed. The skill that writes the record owns its block:

```
---
phase: scope | design | intent+plan | build+ship | learn
skill: <skill that wrote it>
status: in-progress | complete | aborted | gate
gate: <gate name, or empty if the phase has none>
signed: <YYYY-MM-DD when the gate is signed, else 'pending'>
signed_at: <ISO timestamp of the signature, UTC to the second; written with `signed:`, absent until then>
outcome: as it stood | with edits | re-driven  <how the gate closed; written with `signed:`, absent until then>
reviewed: <YYYY-MM-DD when the phase's fresh-eyes review passed, else empty>
run: <opaque run id>
attempt: <integer, 1-based>
mode: interactive | one-shot
started: <ISO timestamp>
finished: <ISO timestamp, or empty while in-progress>
credential_ref: <name of the credential that drove the run, never the secret value>
---
```

Invariants: the block is flat key/value, no nesting, and **an identifier a record already carries outranks a document's example of it** - a phase finding the two disagreeing keeps the record's value and files the disagreement. Migrating an identifier is a deliberate act across every record, never a side effect of a re-open.

| Field | What it means, and who may write it |
| ----- | ----------------------------------- |
| `phase` | The closed vocabulary the block enumerates, spelled exactly as the phase table names it (`intent+plan` and `build+ship` carry the `+`). Machine-read, so an identifier and never free prose |
| `status` | Starts `in-progress` and becomes `complete` only when the phase's work is done, so a crash leaves `in-progress`, which reads as not-done. `aborted` is an explicit give-up; `gate` means the worker deliberately reached one |
| `signed` | A real date only when the gate helper stamps it over the signer's authority: the human's approval in interactive, the operator's standing pre-authorization over a passing review in one-shot (§1, "How a gate closes"). **The helper is its only writer, in any mode**; an agent never edits it by hand and never offers to sign. `pending`, or absent, is never a signature |
| `signed_at` | The signing moment as an ISO-8601 UTC timestamp with seconds, written by the gate helper (`stamp_gate.py`) in the same act as `signed:` and absent until then; `signed:` stays the date the signer gave. Idle time (finished to signed) is read from it, which a date alone resolves only to the day. |
| `outcome` | How the gate closed, exactly one of `as it stood`, `with edits`, `re-driven`, written by the gate helper with `signed:` and absent until then: the signer's `--outcome` when given, else derived from the record (`re-driven` when `attempt` exceeds 1 or a review round before the passing one failed, `as it stood` when the first round passed on a first attempt); `with edits` is only ever the signer's word. Machine-read, so a value outside the vocabulary is refused. Neither closure field is carried across a re-open: the record helper leaves both out, since it runs only on an open gate. |
| `reviewed` | A real date only when the phase's fresh-eyes review passed, and a gate does not close without it. It is evidence about **this attempt's** document, so re-opening the record clears it: a carried date would let the stamp close the new attempt's gate over the predecessor's review |
| `mode` | The current attempt's, never the record's history; a re-drive under a different mode passes `--mode` explicitly |
| `finished` | Filled by the stamp when it completes the phase, in every mode (a manual design close runs the stamp over the record it wrote), and cleared when the record re-opens for work. Carried instead it is unwritable for the rest of the line, because no helper overwrites a value already there and no agent may hand-edit frontmatter (AP-30) |
| `started` | The moment the record was opened, so a re-driven record spans its first attempt's start to its last attempt's end. Per-attempt timing is the journal's, not the block's |
| `credential_ref` | A citation of the driving credential, never the secret value |

`reach_gate.py` carries unhandled fields over between attempts, which is right for provenance and wrong for `mode`, `finished` and `reviewed`: the first two are set by explicit flag, the third is cleared at the re-open for the gate helper to re-earn. `signed_at` and `outcome` it never carries: they describe a closure, and the helper runs only on an open gate.

### What survives, and what does not

The defect this model prevents: a plan, a design brief, or a BRD, hand-maintained inside the repo, drifts from the code and then gets consulted after it has gone stale. So every artifact has exactly one of **three fates**.

**Maintained** - updated for the app's life:

| Artifact | Home | Note |
| -------- | ---- | ---- |
| The correctness spec | `intent.yaml` + its tests | the only maintained spec in the repo; ordinary evolution follows it and nothing else |
| The visual identity | the app's `docs/` | a brand page, the committed logo asset, the palette and type as the frontend's theme tokens |
| Architecture decisions and the target | the app's `docs/` | ADRs in the decisions collection plus the target in the index and the module pages (`REF-Documentation.md` §7.11); every deviation is an ADR, never a code comment |
| The app and its live URL | the repo and the running deployment | the deliverable itself |

**Legacy** - frozen when its phase ends, viewable, never touched again:

| Artifact | Home | Note |
| -------- | ---- | ---- |
| The estimate, roadmap, workbooks | the estimation project | an assistant that did its job in the scope phase; the delivered phase's architecture, assumptions and estimated effort were exported into the scratch at the proposal stamp (§1), so nothing downstream reopens the project; reopen it read-only if anyone needs the history |
| The design prototype | the prototyping hub, reachable over its MCP | a throwaway reference, never the source of the built look (the visual identity in `docs/` is); the approved screens were exported into the scratch at the design stamp (§1) - throwaway after the signature never means unread before it |

Legacy artifacts are not maintained and not deleted; they are left where they are. They are assistants, not specifications: nothing downstream reads them as truth.

**Ephemeral** - lives in `.delivery/` (the line's `delivery/<line-id>` branch), retired at reconcile behind the `delivered/` tag: the five scratch records above.

Ordinary evolution follows `intent.yaml`. A full v2 re-triggers the scope and design skills with new input (a fresh estimate, a fresh prototype, a fresh handoff); it never edits a retained plan or brief, because none is retained. Accreting planning documents into the repo for a v2 (a rewritten plan, a stacked-approvals brief, a "rethink" doc kept as authoritative) is exactly the drift this model exists to stop.

**A follow-on line over a shipped app is additive, never a supersede.** When new scope arrives for a repo that already delivered - a "phase 2", a next capability, a `[DELIVERY]` ticket against a live app - it re-triggers the scope phase with a **fresh estimate** and leaves the delivered line's estimate **frozen** (a legacy artifact, §1 / AP-19): the new scope becomes a new phase in the repo's estimation project, and the prior estimate is never reopened and overwritten in place. The build then *adds* capability over the delivered surface, minting new intent claims and never mutating or regressing the shipped ones. "Completely new scope" describes what is being *added*; it is not licence to drain and rewrite the delivered line. Overwriting a frozen estimate to make room for the new scope destroys the delivered line's record - the additive-vs-supersede defect this model forbids. Where the operator's words are ambiguous ("create a new phase", "new scope"), the additive reading is the default, because it is reversible and preserves the delivered work; superseding is not.

### Phased delivery: one line delivers exactly one phase

"Phase" names two things; keep them distinct. An **estimation phase** is quote structure in the estimation project (`REF-Estimation.md`): a priced, roadmapped slice of the ask (P1, P2, P3). A **lifecycle phase** is an execution step of one delivery line: the five phases of this REF. The ledger remembers what was sold; the repo remembers what is; the tag (below) remembers what shipped. **One repo has exactly one estimation project, named for the repo**: the delivery key is the repo name everywhere it is read (the console's `delivery_slug()`, the delivery-side studios' project keys, the stamp's export), so every phase a repo ever sells lives in that one project and phases are told apart by their `P<n>` alone, never by a second slug. A repo holding several projects splits its own tag namespace, and the damage is not theoretical: one repo accumulated three (`solveos-rules`, `solveos-tasks`, `SolveOS`), a delivered line tagged `delivered/SolveOS/P1` from the bare repo name while its project was slugged otherwise, and the next line then minted a project whose single phase was labelled **P2 rather than P1 purely to dodge that tag** - a phase number chosen by collision avoidance instead of by scope. Six rules bind the two:

1. **One line, one phase.** Every delivery line delivers exactly one estimation phase. Scope pins it in the proposal record: a `delivers: P<n>` frontmatter field (a scope-owned field beyond the canonical block, the `onboarding_pr:` pattern of the build-and-ship record; the record helper writes it - `reach_gate.py --delivers P<n>`, never by hand - and carries it over) and a requirement spine listing exactly that phase's IDs (§2). Every later lifecycle phase reads the record, never the estimation project, so design, intent+plan, and build+ship are phase-specific by construction; no downstream skill needs its own phase check, because a line's scratch can only exist for a phase scope admitted. The record's gate export travels with it (§1): the frozen architecture, assumptions, estimated effort, and approved screens sit beside the records, so “reads the record” includes reading those files - never the live tool. Scope pins the increment's surface the same way: a `surface: surfaced | none` field (`reach_gate.py --surface none`), read by the design phase (§3) and the plan; `none` names an increment with no human surface, a service, a worker, a proxy, whose only DOM is its docs site.
2. **Scope may quote ahead.** The scope phase may mint estimation phases beyond the one its line delivers, when the ask naturally splits: priced and roadmapped quote structure, delivering nothing until each gets its own line.
3. **Delivered means tagged.** With the delivery gate signed, the close mints the annotated git tag `delivered/<estimation-slug>/P<n>` on the line's branch tip and pushes it **before** the line's ref is deleted (`reconcile-delivery`). The tag is the only durable marker of a delivered phase - not a status written back into the estimation project (legacy is never touched, AP-19), not a docs page (AP-13), not the scratch (retired at reconcile) - and it is the anchor that keeps the line's records reachable - a human audit trail a person can still surface from a fresh clone, never a phase input (`REF-FollowOn.md` §2). A delivered-on event is immutable history, so the tag never drifts.
4. **Undelivered is revisable.** A phase with no tag is not frozen, however it got there: a quoted-ahead phase and a phase whose line was abandoned are both revised in place by the next line that takes them up, with the new verbatim ask appended to the customer-requirements input (provenance recorded) and a re-audit. Minted requirement IDs stay immutable (§2): descope explicitly, never delete.
5. **A phase boundary separates surfaces, not quality levels.** Everything inside the phase's requirement spine ships finished to the bar the customer stated; "polish", "we can go further later", and "the next phase picks this up" are not available for work already in scope. Only genuinely new scope - a surface the spine never priced - defers, and that deferral is the customer's explicit decision surfaced as a question (`REF-CSD.md` §6), never a doc note, a record entry, or a filed ticket. Before closing any phase, sweep its own artifacts for deferral language and resolve each one to *done* or *the customer said no*.
6. **One door, three verbs.** `deliver-engagement` decides at entry from the target phase's state alone. Tagged: **refuse**; the phase is frozen legacy, and the new wants become a new phase over the delivered surface, which is read from the repo (`intent.yaml`, `docs/`, the code), never from the ledger. In the estimation project but untagged: **revise**; re-audit, revise in place if reality moved, write the spine, close the proposal gate. Not in the estimation project: **author** the next phase. This is the mechanical form of the additive follow-on rule above, and ambiguous phrasing still defaults to additive.

### The ways in: where the app lives, and what done means

A line does not only work apps born on a foundry. An app whose home is another organization's repository is worked the same way, and the only thing that changes is **what done means for it**. Three instantiations, by the names the offer uses:

| Instantiation | Where the kit stands | Done means |
| ------------- | -------------------- | ---------- |
| **Complete** | the whole kit on one side, the app onboarded to a foundry there | proven live |
| **Hybrid** | the code on both sides: proven live on our foundry, carried across by the promotion line | proven live here, promoted there |
| **Managed** | the line here, the rest theirs: every change lands in their repository by reviewed pull request | proven in CI, merged |

**The instantiation is derived, never claimed.** Two facts settle it, both readable: whether the app has an **entry environment** (it is onboarded to an install, `REF-AppContract.md`), and whether its promotion contract declares a **`repository` target** (a door into another organization, `REF-Promotion.md`). Onboarded with no such door is Complete; onboarded with one is Hybrid; not onboarded is Managed, and the promotion line does not run for it at all, because promotion moves what an entry environment proved. A declared tier could lie; a derived one cannot, which is why nothing declares it.

**The done-bar follows the instantiation, and is never silently raised.** An app with no entry environment has nothing that can serve a release, so its line closes at proven-in-CI-and-merged and says so; claiming proven-live for it is the failure this rule exists to prevent (`REF-Promotion.md` §1: proof, never hope).

**Adopt beside establish.** Establishing a line opens `.delivery/` on an app the foundry already holds. **Adopting** one enters an app whose home is elsewhere: the foundry-side repository becomes where the line runs and where the scratch lives, the home repository is declared as a `repository` target of the promotion contract (the door every change crosses back through), and the credential is named there while the secret stays with the platform. For Managed nothing of the app is copied: the foundry side holds the pointer and the scratch, and each act clones the home repository into its own workspace, edits, runs that repository's own tests, and opens the pull request. The skill is `adopt`.

**Durable homes on a Managed line.** The table of what survives (above) names the app's own repo as the home of the maintained artifacts. On a Managed line that repo is theirs: the line lands there only what a contributor would land, code, tests in their framework, and docs in their conventions, and never the foundry's contract, conformance, or scaffolding. The scratch, the records, and the tickets stay on the foundry-side repo. The identity the design phase locks is the one their frontend already carries, harvested rather than invented (`REF-Recast.md` §3), unless the customer asked for a new one.

### What the line starts from: the seed, and what it derives

A line's seed is read off the repo at scope, like its instantiation, and nothing declares it. Four seeds, by what the repo holds when the line is established:

| Seed | The repo holds | Read as | Governed by |
| ---- | -------------- | ------- | ----------- |
| **An ask** | nothing yet, or a fresh scaffold | a new line: scope authors the spine from the verbatim request | this REF |
| **A shipped phase** | a `delivered/<estimation-slug>/P<n>` tag | a follow-on: additive over the delivered surface, the prior line's open tickets as the leading hypotheses | `REF-FollowOn.md` |
| **A foreign app** | a `seed/<slug>` tag, and the application it brought under `_recast/` on the line's scratch - code and screens that are not yet ours - beside a `main` born with the app contract | a recast: scope, design, and claims derived from the app, its substance rebuilt to standard | `REF-Recast.md` |
| **A shipped sibling** | the repo is named `demo-<x>`, and the organisation holds `<x>` carrying a `delivery/*` ref or a `delivered/*` tag | a demo: every phase copies `<x>`'s deliverable into this line's own key and attests the copy, so the line runs in minutes for a showcase | `REF-Demo.md` |

The two axes compose. Any instantiation can carry any seed: a Managed line over an app whose home is elsewhere is nearly always recast-shaped, since the app exists and its look is settled; and a repo carrying both a delivered tag and a foreign surface is a follow-on whose new scope is a recast, where both REFs apply because one says what not to redo and the other what to derive. The scope door reads the tag first (§2); when the repo holds an application, it reads that next. A demo composes with neither axis: it is disposable, never adopted, never promoted, and retired rather than closed (`REF-Demo.md` §6).

### AI is an accelerator, not a requirement

Every phase has a fully human-followable path: a person can drive the estimation engine, the prototyping hub, the intent authoring, and the code by hand. The trust in the output comes from the guards and gates (the estimation audit, the intent tests, the platform conformance suite, the per-phase adversarial review), not from the model, so correctness is a property of the gates no matter who or what produced the artifact. An LLM is an accelerator that produces trustworthy output faster; it is never a dependency of the flow, and no phase requires a top-tier model to run. Each skill front-loads the model-heavy authoring so the execution and the gate-closing stay mechanical (`design-session` is the pattern: an LLM prepares the options, then the operator or a small model drives the live session and closes the gate).

---

## 2. Scope phase - `deliver-engagement`

The scope phase captures what is asked and what it would cost, and it is the engagement's entry point: the customer's verbatim request becomes the requirement-ID spine every downstream artifact traces to, and the proposal gate closes over it. Its doctrine and its procedure both live with the skill that runs the phase, `deliver-engagement`.

---

## 3. Design phase - `design-session`

The design phase settles what the thing will look like, and produces one durable output: the **visual identity**, whose contract - what it is, where it lands, and the rule that aesthetics are never delegated to the build - is `REF-Design.md` §8. Route to the prototyping hub (the protopane door) when the UI is conventional DOM screens; when it is not (3D scenes, canvas or WebGL rendering, generative or game-like visuals), do not force the tool and do not skip the phase, but capture the same dimensions as prose the build can follow, held in the delivery scratch rather than as a maintained repo file. When the proposal record carries `surface: none` there is no human surface at all: the identity is the docs site's, a vendored design system's tokens and the logo by its ladder, locked without a session, the record's interaction model states that every exchange is machine to machine, and the gate still closes over the phase's fresh-eyes review.

The design gate is recorded when the visual identity is locked. The prototype itself is a **legacy** artifact (§1): left in the hub, reachable, and never the source of the built look. Running the session, walking the dimension check, and locking the identity with or without a customer in the room are `design-session`'s.

---

## 4. Intent + plan phase - `intent-session`

This phase answers both "what must be true" and "how do we build it", and it is one skill because the two are written against each other: the plan's test surface is what the claims must be attestable by. `intent-session` drives CSD intent authoring (`REF-CSD.md`) to write the spec, then assembles the build handoff. In interactive mode it is a working session with the operator and many decisions are made here; in one-shot those decisions are taken by the assumption protocol and documented (`REF-Autonomy.md` §1), never prompted for.

### 4a. Intent (the proposal-to-delivery bridge)

The delivery-side requirements artifact is the intent spec (`REF-CSD.md`), not the proposal BRD, and it is the only **maintained** spec in the repo (§1). The claims are derived from the line's requirement spine and carry its IDs, so what was priced and what is attested stay the same set: that derivation, and what a claim statement must be able to prove, are `REF-CSD.md` §6. Driving the authoring, and wiring the intent runtime the build's stack calls for, are `intent-session`'s.

### 4b. The build handoff (the ephemeral plan)

The build handoff is the single artifact an autonomous build reads. It lives in the delivery scratch as `.delivery/handoff.md`, is committed with the rest of the scratch, and is retired with the line at reconcile (§1). `intent-session` builds it once the claims are drafted, because the plan and the claims are written against each other, and it is assembled from the durable sources while restating none of them: it points at the line's requirement spine in `.delivery/proposal.md`, the gate exports beside the records, the visual identity and ADRs in `docs/`, and `intent.yaml`, and adds only the run-scoped decisions.

**A handoff is complete when every question the build could ask has its answer written down or pointed to.** Test it by reading it as the run: any decision you would still have to make yourself is a handoff defect. Which decisions it must pin is the shape of `intent-session`'s handoff template, the one place that list is maintained; how a run behaves where the handoff still leaves something open is `REF-Autonomy.md`.

---

## 5. Build + ship phase - `run-delivery-plan`

One skill builds the working software and ships it live, because the build conforms the repo to the platform contract and containers everything shipping needs, so shipping is onboarding a ready artifact, not a separate repackaging phase. `run-delivery-plan` reads `.delivery/handoff.md` (and `.delivery/design.md`, `docs/`, `intent.yaml`) in a fresh builder session and follows the handoff; a decision the handoff does not answer is a plan defect, not a question.

### 5a. Build

The build works from the handoff to green tests, puts the built software and the documentation pages it landed through the phase's fresh-eyes adversarial review (§1), and lands the run's durable decisions in their homes before it can claim done: the visual identity as the brand page (`REF-Design.md` §8), the architecture target and its first ADR as the application documentation set lands them (`REF-Documentation.md` §7.11): the index and the module pages, the ADR in the decisions collection. Landing them is the build's job and never reconcile's, which only confirms they arrived. The repo is shaped to the platform's app-repo contract from scaffold time rather than retrofitted (`REF-AppContract.md` §4), because the conformance gate blocks release and a retrofit costs a full round trip. The build sequence itself, its exit checks and its push cadence are `run-delivery-plan`'s.

### 5b. Ship

Shipping is onboarding a ready artifact, not repackaging one, because the build already conformed the repo to the platform contract and containerized what the ship needs (`REF-AppContract.md` §4). The deploy and every priced capability go through the onboarding skills, which own the mechanics (`REF-AppContract.md` §2); deployment into the entry environment is automatic and every environment beyond it is the promotion line's act, never a step of this phase (`REF-Promotion.md` §1).

**The phase is not done until the app is verified live**, in either mode, and what counts as proof is one definition shared with promotion: an evidence chain, never a single probe, including the priced capabilities being bound and not merely the app answering (`REF-Promotion.md` §3). A capability the run could have onboarded and chose not to is the delivery failing, not an assumption the protocol may take (`REF-Autonomy.md` §1). Where the chain cannot be completed, the run stops at a named degraded stop-state and says so plainly; it never loops and never claims live. Collecting the chain, working a settling cluster, and the build-and-ship record itself are `run-delivery-plan`'s.

---

## 6. Learn phase - `reconcile-delivery`

The learning loop runs through every phase and resolves once, at the close: the line confirms it reached done rather than a degraded stop, confirms every durable decision reached its durable home, triages what the run logged, and retires the scratch behind the phase's delivered tag (§1, "Phased delivery"). It **proposes rather than writes** - the lessons leave as tickets the maintenance loop reviews (`REF-Maintenance.md` §7), never as edits made from inside the run that captured them - and first ship opens that loop rather than closing the engagement (`REF-Maintenance.md` §1). The close acts themselves, and how they differ between a watched terminal and an unattended pod, are `reconcile-delivery`'s.

---

## 7. Anti-Patterns

Each row carries a stable `AP-NN` id: cite it as `REF-Delivery.md` AP-NN, never by position. Ids are permanent and never reused, so a retired row leaves a gap rather than renumbering the rest and silently redirecting every citation to it.

| ID | Anti-Pattern | Correct approach |
| -- | ------------ | ---------------- |
| AP-01 | Treating the proposal BRD as the delivery requirements artifact | Delivery requirements are intent claims with `derived_from` traceability (`REF-CSD.md` §6) |
| AP-03 | A handoff with open questions ("the run decides X") | Decide X in the handoff wherever you can; what genuinely cannot be pinned falls to the one-shot assumption protocol - a documented reasonable default, not a stall (`REF-Autonomy.md` §1) |
| AP-04 | An autonomous mandate silently bypassing human gates | Pre-authorize each gate in writing, scoped to the run or the standing profile (`REF-Autonomy.md` §3) |
| AP-07 | Looping forever when an external dependency is down | Stop at the handoff's degraded terminal state and say so plainly (`REF-Promotion.md` §3) |
| AP-10 | Skipping a gate because the operator is confident | The four §1 gates are recorded even when self-serve; every gate is the same mechanism |
| AP-12 | Treating "supervise unfamiliar ground first" as a gate the tooling enforces - refusing, stalling, or interrogating a one-shot run that was explicitly triggered | One-shot means one-shot: it runs to the done-definition with no human in the loop, assuming and documenting per the protocol (`REF-Autonomy.md` §1). Supervising a new stack's first run is *advice* for cleaner results, never a precondition the run may stop on |
| AP-13 | Maintaining a `PLAN.md` or `DESIGN-BRIEF.md` as a committed, updated repo file | Both are ephemeral scratch records (`.delivery/handoff.md`, `.delivery/design.md`), committed on the line's `delivery/<line-id>` branch for resumability and retired with the line at reconcile; the durable design artifact is the visual identity in `docs/`, the durable spec is `intent.yaml` (§1) |
| AP-14 | Running a v2 by editing or accreting the old plan, brief, or "rethink" docs in the repo | Re-trigger the scope and design skills with new input; ordinary change follows `intent.yaml` (§1, `REF-Maintenance.md` §1) |
| AP-15 | Letting the build invent a look, or shipping with no locked logo | The visual identity is produced and locked in the design phase - the logo supplied or generated there, wordmark floor included (`REF-Design.md` §8) |
| AP-16 | Only the build gets an adversarial review | Every phase runs a fresh-eyes adversarial review before it closes its gate; the build's code review is one instance, not the only one (§1) |
| AP-17 | Codifying a lesson into a REF or skill mid-run, before review | Capture to `.delivery/journal.md`; at reconcile the survivors become `learn(...)` tickets the maintenance loop reviews and lands (`REF-Maintenance.md` §7) |
| AP-18 | Assuming a phase needs an LLM, or a top-tier one, to run | Every phase has a human-followable path; the gates provide the trust, the model only the speed (§1) |
| AP-19 | Treating the estimation project or the prototype as a maintained spec, or deleting it | Both are **legacy**: frozen when their phase ends, viewable, never touched again and never read downstream as truth (§1) |
| AP-20 | Confusing a delivery skill with the tool it drives (an "estimatekit skill", a "CSD skill") | The five skills are the lifecycle; estimatekit, the prototyping hub, CSD intent authoring, and the platform are the tools they drive (§1) |
| AP-21 | A `.delivery/PROGRESS` file, or a scratch that lives loose - an uncommitted local directory, or scratch records committed into the app's own history on the default branch | The scratch lives on its own `delivery/<line-id>` branch, committed and pushed, mounted at `.delivery/` as a worktree - never loose-and-ignored, never on the default branch (whose ignore line hides only the mount point) - and progress is derived from which records exist on that ref, so a cancelled run resumes and nothing drifts (§1) |
| AP-22 | Marking an intent claim `active` because its named test passes, while the mechanical audit that actually gates attestation (`csd-intent` / `audit-intent`) never ran anywhere, deferred to a later CI stage the run itself may skip | Run the audit (locally, or as a hard build-exit-criterion) before claiming "active and attested" (`REF-CSD.md` §6); a claim attested only by a comment promising CI will check it later is unattested the moment that later step doesn't happen |
| AP-23 | Executing post-ship / evolution-seed actions (backlog issues, project boards) in the same pass as a build that never completed its ship sequence (push, CI, registry, onboarding) | Gate any post-ship action on the evidence chain actually being collected first (`REF-Promotion.md` §3); the phase split (`run-delivery-plan` ships, `reconcile-delivery` opens the evolution loop, `REF-Maintenance.md` §1) enforces this by construction; do not fold post-ship steps back into an unfinished build-and-ship run |
| AP-24 | A gate's frontmatter carries a dated `signed:` line - a human's signature in interactive, the engine's in one-shot - while the record's own prose still narrates the gate as unsigned; and a later phase (the build's pre-flight above all) reads that prose and stops | The frontmatter `signed:` line is the authoritative gate state (§1), in **both modes and for every reader**: a signed gate is signed, so a downstream phase **never re-opens it and never degrades on the body's stale narration - it builds**. The prose is phase narration written *before* the signature; the signature outranks it, and a signed `.delivery/design.md` means the visual identity is locked whatever its body says. **The stamp creates this contradiction; the review cannot catch it.** The prose was true when the review read it - one reviewer explicitly blessed `signed: pending` as correct, and the stamp falsified that sentence the same day - so the remedy belongs to the step that makes it false: `stamp_gate.py` (and design's `close_gate.py`) put the closure line at the **top** of the body, above the narration it supersedes, not appended below it where a reader meets a hundred-odd lines of "the gate awaits its signer" first. Open, unresolved rubric rows are the different, review-owned case: #37 |
| AP-25 | Leaving a fix that a blocked credential can't push as an uncommitted local file for "a future session" to pick up | Phase handovers are fresh sessions with no shared working tree (§1); an uncommitted file does not survive to the next one and is silently lost. Either get it committed some other way (a broader-scoped credential, an operator add) before the session ends, or paste its full content into a committed scratch record (`.delivery/journal.md` or the handoff) so a later fresh session can recreate it verbatim instead of rediscovering the same block |
| AP-26 | Sending a degraded (unfinished) build to `reconcile-delivery` as the reflexive next step - or the run's own final report pointing there "regardless" | A degraded stop is not a finished run: reconcile is the **close** and it closes the scratch (`reconcile-delivery`), so a delivery you still intend to complete must first clear the recorded blocker and re-drive the phase to the done-definition (the cockpit's Re-drive, or re-running `run-delivery-plan`). Reconcile a degraded run only when the delivery is deliberately abandoned - reconcile's degraded-ending mode then writes the resume list instead of closing. Fix, re-drive to done, *then* reconcile; never reconcile something still failing |
| AP-27 | Re-scoping a follow-on or next-phase delivery by overwriting the delivered line's frozen estimate in place - reading "new scope" or "a new phase" as licence to supersede, drain, and rewrite the shipped line | A follow-on line is **additive** (§1, "a follow-on line over a shipped app is additive"): leave the delivered estimate frozen (legacy, #19), add the new scope as a fresh estimate (a new phase in the repo's one estimation project, never a second project), and build additively over the shipped surface with new intent claims that never mutate the delivered ones. Ambiguous phrasing defaults to the additive reading, because it preserves the delivered work and is reversible |
| AP-29 | Offering to sign a pending gate ("shall I sign it so we can continue?"), or hand-writing a `signed:` date into a record | A pending gate is handed back to its signer with the exact helper command they can authorize; the gate helper is the only writer of `signed:` and refuses without the recorded review and the signer's approval (§1, "How a gate closes") |
| AP-30 | Re-implementing the gate stamp in a runner (a `sed`, an inline regex, a console writing record frontmatter itself) | Run `deliver-engagement/stamp_gate.py` itself, everywhere; a hand-ported stamp drifts from the helper's guards and breaks the byte-identical trail (§1). The same rule covers every deterministic lifecycle script - `establish_scratch.py`'s branch mint and worktree mount included: run the true helper, never a port |
| AP-31 | The build finishing with its durable decisions still in the scratch, leaving reconcile to *create* the brand and architecture pages instead of confirming them; or "fixing" that gap by scaffolding a `docs/quality.md` out of the run's done-definition and evidence chain; or, on a repo whose `docs/` is a docs site, landing flat `docs/brand.md` / `docs/architecture.md` pointer files beside the real rendered pages purely to satisfy the check | Landing the durable homes is a **build**-exit criterion (`run-delivery-plan`): the visual identity is the brand page and the architecture target plus first ADR land where `REF-Documentation.md` §7.11 puts them (the index and the module pages, the ADR in the decisions collection), all authored by the build in the app's real docs home (the flat path in a plain docs folder, the content root when `docs/` is a site). `run-delivery-plan/postflight.py` verifies mechanically that the brand page and a home for the target and its first ADR carry real content, and reconcile only **confirms** them (`reconcile-delivery`, whose move-if-found-in-scratch clause is a backstop, not the path). The done-definition and evidence chain are **ephemeral** (`.delivery/build.md`, retired with the line at reconcile) and quality bars are attested as **intent claims** (`REF-CSD.md` §6), so there is no durable `docs/quality.md`: copying this run's evidence into one is a frozen snapshot that drifts |
| AP-32 | Re-driving a phase when two consecutive invocations produced no new evidence and no new gate-review feedback (the record grows but nothing changes) | Cap re-drives at two consecutive stale runs: surface the stale-evidence condition explicitly, recommend closing the loop or supplying new input, and refuse to produce another near-identical record. A re-drive past the cap without new journal input is not a fresh pass; it is duplicated evidence and duplicated cost (`reconcile-delivery`; "only the survivors" applies to runs too). |
| AP-33 | Addressing **platform-studio** by the delivery key, or reading a mismatch there as a formatting fallback | The delivery key is the repo name, and the delivery-side studios (estimatekit, protopane) are keyed on it. platform-studio is not: it keys on the app's FLEET name, a fact of its own (`REF-AppContract.md` section 1) that equals the repo name only where an organisation names its repositories for the apps they hold. That divergence is **semantic, not cosmetic** - it is a different fact, not a prettier spelling - and the miss is silent: the query returns nothing, which reads as "never onboarded", and the run onboards a SECOND time (duplicate manifest entry, namespace, hostname, Gateway; only an offboard undoes it). Address platform-studio by the app's name and pass the repository explicitly. For the delivery-side studios, still log any charset fallback (lowercase, hyphenated) in the plan defects so the next run does not rediscover it. |
| AP-35 | Recording "phase delivered" anywhere but the tag: a status written back into the estimation project, a delivery-history docs page, a memory note | The annotated `delivered/<estimation-slug>/P<n>` tag, minted on the line's branch tip at close over the signed delivery gate and pushed before the line's ref is deleted, is the only durable marker and the anchor of the line's retained records (§1); the ledger stays a quote, the docs stay product truth, the door reads the tag (§2), and a follow-on reads only the tag object and the other durable homes - the retained records behind the tag are a human audit trail, never a phase input (`REF-FollowOn.md` §2) |
| AP-36 | A line whose scope spans several estimation phases, or one that re-drives a phase already tagged delivered | One line delivers exactly one phase, pinned in the proposal record's `delivers:` field and spine (§1, §2); the door refuses a tagged phase, and the new wants become a new phase (§2) |
| AP-37 | A record requesting gate closure whose body still lists **open, unresolved rubric rows** - decisions genuinely unmade at the moment the fresh-eyes review read it | The review-owned half of #24, and the half a review really can catch: open rows exist *while* the reviewer is reading, unlike the stale gate narration the stamp creates afterwards. The phase's adversarial review refuses to request closure, or the rows are resolved and the prose rewritten, before the date is stamped. One found at reconcile is a review-process defect, logged as such (`REF-Maintenance.md` §7) |
| AP-38 | Reaching reconcile with no `.delivery/journal.md`, because every phase was *told* to log "as it happens" and none was ever *checked* | The journal is a phase-exit obligation enforced at the gate helpers, which refuse to stamp without it (§1) - prose alone already failed this way on two real lines. "Nothing to report" leaves an entry saying so; only "nobody reported" leaves no file. Reconcile reports an absent journal as a finding and closes in reconstruction mode, because by then the loss is taken: sentiment and gate-rejection feedback are the run's only unreconstructable records (§1) |
| AP-39 | Closing a phase with in-scope work recorded as "polish", "later", or a next-phase item - the requirement met structurally while the customer's stated bar is not, or a review's own findings written into the record instead of fixed | A phase boundary separates **surfaces**, not quality levels (§1): everything inside the phase's requirement spine finishes to the stated bar before the phase closes. Recording a defect is not remedying it, and a finding from a review the run itself commissioned is inside scope by construction. Only genuinely new scope defers, as the customer's explicit decision surfaced as a question (`REF-CSD.md` §6) |
| AP-40 | A runner spawning a gate review of its own - a console entrypoint or a one-shot sequencer prompting a second reviewer, in wording of its own, over a record whose phase already ran its review | The review is the phase's, run through the `adversarial-review` skill before the record reaches its gate; the runner locates the newest committed review, reads its verdict, and stamps (§1). A runner-authored review prompt is a hand-restated copy of the skill that drifts from its lenses (universal violation #1), a second review over unchanged bytes is duplicated cost (#32), and a FAIL such a runner discards is exactly the evidence the retried phase needed |
| AP-41 | Review rounds that never converge: a re-review re-reading bytes the prior round already passed, or a verification round spawned over a PASS to confirm non-blocking fixes | A re-review reads the prior and reviews the delta; a PASS ends the rounds and its non-blocking findings ride the attempt as ordinary commits (§1, the `adversarial-review` skill). Each fresh reviewer's different taste over the same bytes is variance, not a finding |
| AP-42 | Listing the pod's environment (`env`, `printenv`, or either through a redaction filter) to discover what the launcher set | The environment holds live credentials and the run's transcript is retained: list variable names only (`compgen -v FC_`) and read one non-secret value by name. A redaction filter fails open on the first credential it does not know |

---

## 8. Skills that instantiate this REF

Generated by `scripts/sync_backlinks.py` from skill frontmatter; do not edit by hand.

Skills whose frontmatter `refs:` includes `REF-Delivery`:

- `adopt` - Enter an app whose home is another organization's repository: stand up the foundry-side repo the line runs in, declare the home as the promotion contract's door back, and name its credential - the instantiation and its done-bar then derive from what exists, never from a claim.
- `adversarial-review` - Fresh-context adversarial review of a delivery artifact (a scope trace, a visual identity, a build handoff, or the built code) against its standard: a second agent that had no hand in producing the artifact hunts what its author's context made invisible and returns findings only, never edits.
- `deliver-engagement` - Enter and scope a delivery engagement per REF-Delivery: capture the customer's verbatim request as the requirement spine over the estimation engine, close the proposal gate, and either hand the operator the next command (interactive) or drive the whole line itself to done with no human in the loop (one-shot).
- `demo-line` - The demo line's deterministic helpers per REF-Demo: pin the source at scope, copy its estimation project, its prototype, its claims and its tree into a demo-<x> line's own key, rename the identity, and write each gate's fidelity check as the review artifact the stamp closes over.
- `design-session` - Run the design gate for an engagement over a prototyping instance and lock its one durable output, the visual identity (logo, colour scheme, typography), into .delivery/design.md.
- `intent-session` - Run the intent-and-plan phase per REF-Delivery: drive CSD intent authoring to write intent.yaml and its tests against the proposal requirement IDs, then assemble the committed one-shot build handoff (.delivery/handoff.md) against that test surface, run a fresh-eyes adversarial review of both, and close the plan gate.
- `reconcile-delivery` - Reconcile a finished delivery run per REF-Delivery: confirm the run reached done (Build+Ship already verified the app live, so reconcile does not re-probe liveness), confirm every durable decision reached its durable home, file the run's surviving lessons and recommendations as learn-titled tickets - proposed REF/skill changes on the playbook repo, forward recommendations on the delivery repo - for the maintenance loop to review and land (reconcile proposes, it never edits the playbook), then close the delivery line by the interaction mode (tag the line's branch delivered, push the tag, then delete the ref at a terminal; stamp learned: into the journal frontmatter, journal a summary, and LEAVE the scratch for the operator's console Close-line act when it runs unattended, since the console's Learn pane is that journal and the stamp is how a finished Learn stays derivable).
- `run-delivery-plan` - Execute a REF-Delivery build handoff (.delivery/handoff.md) end to end in a fresh builder session, building and shipping in one phase: mechanical pre-flight refuses on a missing handoff, a missing locked visual identity, or an unrecorded gate, then the run follows the handoff's authorization, build sequence (visual-identity landing, the documentation set, then a fresh-eyes adversarial review), evidence chain, and degraded stop-states to its done-definition, recording the build-and-ship log in .delivery/build.md.

---

## 9. Agents that orbit this REF

Generated by `scripts/sync_backlinks.py` from agent frontmatter; do not edit by hand.

Agents whose frontmatter `refs:` includes `REF-Delivery`:

- `architect` - Scopes a customer's ask into requirements, the architecture that answers them, and a priced proposal; hand it a new engagement or a scope to re-drive.
- `builder` - Builds the app its handoff describes and takes it to a live address; hand it a closed plan gate, or an app to onboard onto the Foundry.
- `designer` - Runs the design gate over the prototyping hub and locks the visual identity; hand it an engagement whose proposal gate is closed.
- `librarian` - Closes a finished delivery line and files its lessons as tickets for the maintenance loop; hand it a run that reached done.
- `planner` - Writes the intent claims and their tests, then the build handoff; hand it an engagement whose visual identity is locked.
- `release-manager` - Moves a proven release to its next environment or repository, and brings an app whose home is elsewhere into the Foundry; hand it a release to promote or an app to adopt.
- `reviewer` - Reviews with fresh eyes what it had no hand in, a phase artifact or a pull request, and returns findings and a verdict; hand it anything that needs an outsider's read before a gate or a merge.
