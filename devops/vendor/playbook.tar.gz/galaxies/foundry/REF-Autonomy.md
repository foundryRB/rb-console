---
domain: methodology
---

# REF: Autonomy

> Read this when a phase runs with no human in the room: how an unattended run settles a decision its inputs left open, what it does with an irreversible one, and how a plan is written so nobody has to be present for it to finish. The delivery lifecycle's phases and gates live in `REF-Delivery.md`; this REF is the conduct of a run that nobody is watching, and every phase falls back on it.

---

## 1. The assumption protocol

Any decision the durable inputs and the run's authorization leave open - at kickoff or mid-run, from repo strategy to a blank dataset field to an auth flow - is resolved by **the smallest reasonable assumption**, written to the phase record's assumptions log, surfaced in the final report, and the run continues. It never halts for a human over a decision.

The single exception is a genuine external-dependency failure, which stops at that dependency's named degraded stop-state (`REF-Delivery.md` §5): the world blocking the run, not the run asking a question.

Two things make this a protocol rather than a licence:

- **The assumption is recorded where it can be challenged.** An assumption in the run's head is indistinguishable from a decision nobody made. It lands in the phase record and in the final report, so the close can catch a wrong one (`REF-Maintenance.md` §7).
- **Smallest means smallest.** The assumption that closes the decision and nothing more; it is not licence to choose the interesting option, widen scope, or settle a question the inputs deliberately left to a person.

Reversible choices (a colour, a copy tweak) are assumed and logged without ceremony. Irreversible ones are §2.

## 2. Irreversible and outward-facing decisions default to the safe option, loudly

For anything hard to walk back - public versus private visibility, a licence choice, anything that publishes or sends - the reasonable assumption is the **conservative** one: least exposure, permissive-only licensing, gated by default. Flag it as the most prominent lines of the final report, so a wrong default is caught at reconcile rather than discovered by whoever it reached.

The asymmetry is deliberate. A conservative default that was wrong costs one follow-up; a permissive default that was wrong cannot be recalled.

## 3. Pre-authorization: human gates are granted before the run, never created inside it

A "never prompts the human" mandate does not create mid-run human gates; it **pre-authorizes** them. Every human gate a plan names is granted in writing before the run: by the operator per run, or once as an optional **standing autonomous-delivery profile**, a recorded set of gate grants the operator pre-authorizes for any run they trigger from their own machine with their own rights.

The profile is an **override, never a precondition**. A run with no profile does not stall and does not drop to interactive: it proceeds on conservative defaults and records what it assumed (§1, §2). Where a profile exists, its grants win over the defaults.

Pre-authorizing which gates a run may pass is a different question from whether a skill may pause for a human at all. The second is the launcher's `interaction` flag (`REF-Delivery.md` §1), always `auto` in an automated pod.

**One shape no pre-authorization redeems: a human gate on a phase's evidence path.** A gate whose act the phase's done-definition or evidence chain waits on parks every unattended run of the line by construction - a run proves it live, nine of ten evidence items collected, the tenth behind a secret only a person could set - and the phases behind it inherit the park. Design the gate off the path instead.

A human gate is for acts genuinely outside the run's own completion (a callback registration with an external identity provider, real-user provisioning), never for evidence.

## 4. Designing a plan that can run unattended

- **Pre-resolve the stall points you can foresee.** An empty dataset field, a first-release bootstrap ordering, a known auth flow: name the resolution in the plan rather than leaving it to the assumption protocol to rediscover. **The protocol is the safety net, not the plan.**
- **Where a one-time act needs an authorized trigger, use a lifecycle moment that is already authorized** (boot, the release, a readiness gate) before minting a credentialed surface or a manual step. A credentialed trigger adds a secret, a person, and a deploy-to-act window; a lifecycle trigger, made **status-gated and idempotent**, brings its own proof - the status - readable by anything that gates on it. Reuse the pattern the repo already trusts for this class of act. One limit: it proves the act *ran*, not what it *wrote*, so where the evidence is about the data, log the counts where the run can read them.
- **Check every pinned evidence relation's read path while authoring.** An item readable only through an interactive login (an identity-provider exec plugin, a browser device flow) is a plan defect at authoring time, not a run-time surprise: "infrastructure up, app serving, admin access interactive" is its own degraded row, distinct from the infrastructure being down.

## 5. Anti-patterns

| # | Anti-Pattern | Correct Approach |
|---|---|---|
| 1 | An unattended run stopping to ask a question | Settle it by the smallest reasonable assumption, record it, continue (§1) |
| 2 | An autonomous mandate read as licence to pass a gate nobody granted | The mandate pre-authorizes named gates in writing; it creates none (§3) |
| 3 | A standing profile treated as a precondition, so a run with none stalls or drops to interactive | The profile is an override; absent one, conservative defaults apply (§3) |
| 4 | A human gate sitting on a phase's evidence path | Design the gate off the path; a human gate is for acts outside the run's completion (§3) |
| 5 | An assumption held in the run rather than written to the record | An unrecorded assumption is a decision nobody made; it lands in the record and the report (§1) |
| 6 | Taking the permissive option on an irreversible decision because it was more useful | Conservative default, flagged loudest in the final report (§2) |
| 7 | Leaving a foreseeable stall point to the assumption protocol | Name the resolution in the plan; the protocol is the safety net (§4) |
| 8 | Minting a credential and a manual step for a one-time act | Use an already-authorized lifecycle moment, status-gated and idempotent (§4) |

---

## 6. Cross-references

- `REF-Delivery.md` - the five-phase lifecycle, its gates, and the `mode` and `interaction` dials this REF's conduct hangs off (§1).
- `REF-CSD.md` - the intent claims an unattended build is measured against.
- `REF-Maintenance.md` - the ticket loop's own unattended ceremony modes.

---

## 7. Skills that instantiate this REF

Generated by `scripts/sync_backlinks.py` from skill frontmatter; do not edit by hand.

Skills whose frontmatter `refs:` includes `REF-Autonomy`:

- `adversarial-review` - Fresh-context adversarial review of a delivery artifact (a scope trace, a visual identity, a build handoff, or the built code) against its standard: a second agent that had no hand in producing the artifact hunts what its author's context made invisible and returns findings only, never edits.
- `contentful-content-management` - Work a Contentful space: hunt for the type that already exists and show it before ever proposing a new one, rule on the standing question every content request really asks - reuse, extend, or create - and never touch an existing type without putting its entry counts, inbound links and outside consumers in front of the user first.
- `deliver-engagement` - Enter and scope a delivery engagement per REF-Delivery: capture the customer's verbatim request as the requirement spine over the estimation engine, close the proposal gate, and either hand the operator the next command (interactive) or drive the whole line itself to done with no human in the loop (one-shot).
- `design-session` - Run the design gate for an engagement over a prototyping instance and lock its one durable output, the visual identity (logo, colour scheme, typography), into .delivery/design.md.
- `intent-session` - Run the intent-and-plan phase per REF-Delivery: drive CSD intent authoring to write intent.yaml and its tests against the proposal requirement IDs, then assemble the committed one-shot build handoff (.delivery/handoff.md) against that test surface, run a fresh-eyes adversarial review of both, and close the plan gate.
- `reconcile-delivery` - Reconcile a finished delivery run per REF-Delivery: confirm the run reached done (Build+Ship already verified the app live, so reconcile does not re-probe liveness), confirm every durable decision reached its durable home, file the run's surviving lessons and recommendations as learn-titled tickets - proposed REF/skill changes on the playbook repo, forward recommendations on the delivery repo - for the maintenance loop to review and land (reconcile proposes, it never edits the playbook), then close the delivery line by the interaction mode (tag the line's branch delivered, push the tag, then delete the ref at a terminal; stamp learned: into the journal frontmatter, journal a summary, and LEAVE the scratch for the operator's console Close-line act when it runs unattended, since the console's Learn pane is that journal and the stamp is how a finished Learn stays derivable).
- `resolve-backlog` - Clear a repository backlog: earn-it triage, consolidate overlapping tickets, resolve with Sol or Opus, review once in fresh context with the same model, fix findings, rebase and fast-forward.
- `run-delivery-plan` - Execute a REF-Delivery build handoff (.delivery/handoff.md) end to end in a fresh builder session, building and shipping in one phase: mechanical pre-flight refuses on a missing handoff, a missing locked visual identity, or an unrecorded gate, then the run follows the handoff's authorization, build sequence (visual-identity landing, the documentation set, then a fresh-eyes adversarial review), evidence chain, and degraded stop-states to its done-definition, recording the build-and-ship log in .delivery/build.md.
