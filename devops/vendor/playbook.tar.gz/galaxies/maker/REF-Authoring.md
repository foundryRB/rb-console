---
domain: meta
---

# REF: Authoring (Meta-REF)

> The meta-REF. Documents the universe's four levels (playbook, galaxy, REF, planet), the relationship between REFs and the skills and agents that orbit them, and how to write/maintain each. Read this before creating or editing any REF, SKILL, or agent; `REF-Universe.md` holds the structural doctrine.

---

## 1. The four levels

| Level | What | Where | How many |
|---|---|---|---|
| **Playbook** (the universe) | Entry-point index. Lists the universal violations, routes to galaxies. | `AI-PLAYBOOK.md` at the repo root | Exactly **one** |
| **Galaxy** | One body of earned knowledge: its routing table, skills registry, and subject violations. | `galaxies/<name>/GALAXY.md` | One per subject |
| **REF** (`REF-*.md`) | Reference docs - cross-project pattern guides for categories of work. The suns. | `REF-*.md` on its galaxy's shelf | Many |
| **Skill** (runtime-registered) | Concrete invocable units, callable via the `Skill` tool. Carried planets. | Master copy: `skills/<name>/SKILL.md` in its galaxy. Runtime install location: the Claude runtime's installed-skills directory. | Few; only when promotion makes sense |
| **Agent** | Who runs the skills: character, licence, posture. Carried planets, the same level as a Skill (§13). | `agents/<name>.md` in its galaxy | One per distinct worker someone hands work to |

CLAUDE.md (project-level) points to the playbook. The playbook routes Claude to the galaxies; each galaxy's `GALAXY.md` routes to relevant REFs and lists its available Skills. REFs provide the patterns; Skills execute concrete operations; agents (§13) are who runs them, riding the same planet level as skills. `REF-Universe.md` holds the structural doctrine (planets, doors, unique names, free travel).

History: originally REFs were called `SKILL-*.md` (conflated with Anthropic's invocable Skills), then briefly `PLAYBOOK-*.md` (conflated with the singular Playbook). Both wrong. They're REFs.

---

## 2. Golden Rule - Nothing Specific to a Machine, User, Project, Company, or Industry

> **This folder is published for use across all of those. Nothing inside may be specific to any of them.**

A reader pulling this folder onto a fresh box, into an unrelated repo, in a different language ecosystem, must find every word still applicable. Applies to **every** file: `AI-PLAYBOOK.md`, `REF-*.md`, every `SKILL.md`, every script, every README, every frontmatter line, every Skill description string. The one file outside it is `OWNERS` at the root: it names who may change this copy of the corpus, so it belongs to the install that carries it, never to the doctrine (`REF-Universe.md` §5).

### Forbidden

| Forbidden | Why it breaks portability |
| --------- | ------------------------- |
| Absolute filesystem paths (`D:\<...>`, `/Users/<...>`, `C:\Users\<name>\<...>`) | Drives, drive letters, home dirs differ per machine and per user |
| Project-specific paths (`projects/rb-local-m2m/`, `web/src/api/generated/openapi.json`) | Only meaningful in one repo |
| Concrete package / module names (`engine.adapters.inbound.http.app`) | Only valid in one codebase |
| Concrete URLs / ports (`http://localhost:8000`, `localhost:5173`) | Project-chosen |
| Concrete script invocations (`npm run api:sync`) | Project-chosen |
| Project domain terms ("SIM cards", "billing invoices", "audit checks") | Industry- and company-specific |
| Vault / private-system paths (`<drive>:\<vault-root>\_System\`) | User- and machine-specific; vault may not even exist |
| References to private folders, repos, companies, or people | Specific to one user |

### Use instead

| Use | Example |
| --- | ------- |
| Bare filename for sibling files in this folder | `` `REF-<topic>.md` ``, `` `AI-PLAYBOOK.md` `` (resolver walks up from the source file) |
| Repo-relative paths for in-folder children | `` `skills/<name>/SKILL.md` ``, `` `scripts/check_links.py` `` |
| Sibling-relative paths for adjacent repos | `` `../csd-library/pytest-intent/` ``, `` `../protopane/design-systems/<id>/` `` |
| `<placeholder>` syntax for variable parts | `<package>`, `<entity>`, `<output-dir>/openapi.json` |
| Generic role description for project-specific things | "the project's `README.md`", "the project's vault", "the canonical CSD source" |

### One narrow exception: the Anthropic Claude runtime install location

Skills the user invokes via the `Skill` tool are loaded by the Claude runtime from a fixed runtime-managed directory. References to that location (typically `~/.claude/skills/<name>/SKILL.md`) are **acceptable** because they describe a runtime convention common to every Claude install, not a user/machine specific path. Use sparingly and only when the runtime location is genuinely the subject.

### Sibling-clone deployment topology

The playbook and adjacent repos (e.g. `csd-library/`) are designed to be cloned as siblings under a common workspace:

```
<workspace>/
├── playbook/   ← the playbook
├── csd-library/         ← runtimes + intent bundles
└── …
```

References across repos use sibling-relative paths (`../csd-library/...`). The README documents this layout for new contributors.

### Enforcement

`scripts/check_links.py` resolves every reference and fails if any path is broken. The intent tests at the playbook root (`tests/`) regex-audit every file for forbidden absolute paths. Both run in CI and pre-commit.

---

## 3. Structure of a REF

```text
---
domain: <meta|architecture|language|framework|practice|methodology|pkm>
---

# REF: <Name>

> One-line summary of when to read this REF.

---

## 1. <First topic>
## 2. <Second topic>
...
## N. Anti-Patterns (if applicable)
```

Guidelines:

- **`domain:` frontmatter** - classifies the REF for grouping in visualizations and tooling. One value from the canonical enum above; enforced by the intent tests (INT-SHAPE-004).
- **Numbered sections** - makes cross-references unambiguous (e.g. "see §3"). Sequential from 1; enforced by the intent tests (INT-SHAPE-003).
- **Rules, not tutorials** - state what to do and what not to do. Skip narrative.
- **Tables for contrasts** - "Do this / Not this" tables are fast to scan.
- **Code examples are generic** - use `<package>`, `<entity>`, `MyEntity`, `FooResponse`. Never real class names from a project.

---

## 4. Scope

**Authoring is expensive; earn every addition.** The corpus loads on every prompt, so every line is context each future read pays for, and volume buries the signal that matters. Default to *not* adding. A lesson, section, or REF earns a place only when it is durable, cross-project, not already stated (§5, Top Violation #1), and not derivable from training or an obvious read of the code. One-offs, fixed incidents, project runbooks, and facts the code already shows belong in a project repo or nowhere; when in doubt, leave it out.

Each REF covers **one concern** - a language, a framework, an architectural layer, or a cross-cutting practice. If a REF grows beyond ~300 lines, split it.

**Name things with words that already exist.** Before coining a term, find the existing one: in the codebase first (the domain constants, the enum members, the config keys the thing is already called), then the industry's standard word. Invented vocabulary creates a parallel language beside the one the code and the field already speak - two names for one concept, drifting apart - and it makes the work unpresentable, because the reader must learn the metaphor before the doctrine when plain words carry the doctrine whole.

The reasoning scaffolding built to hold concepts apart *during* analysis is not vocabulary; it stays in the working conversation and never ships in the artifact. Deliberate metaphor is reserved for the few subjects the corpus brands once and owns (`REF-Universe.md`), never stacked onto standard concepts that already have names.

**Name a library only when the library is the deliverable.** A REF about a framework names that framework; a REF about linting names the linter. But where the REF's subject is a *choice*, naming the winner installs a dependency the REF cannot version: an agent reads the name and installs it, long after the package was abandoned. Where the shape is small enough to own, teach the shape and name the selection criteria instead.

| Scope | Example files |
| ----- | ------------- |
| Language conventions | `REF-Python.md`, `REF-PowerShell.md` |
| Framework patterns | `REF-FastAPI.md`, `REF-React.md` |
| Architecture layer | `REF-UseCase.md`, `REF-InboundPort.md` |
| Cross-cutting concern | `REF-Tests.md`, `REF-Documentation.md` |

---

## 5. Composition Standard (Core + Specialization)

When two REFs overlap, define one as the canonical core and the other as a specialization.

Rules:

- Put framework-agnostic rules in the core REF.
- Put framework- or tool-specific deltas in specialization REFs.
- Specialization REFs must reference the core section they extend.
- Do not duplicate generic rules across REFs.
- In the galaxy's `GALAXY.md`, route overlapping tasks as `Core + Specialization`.

Example: core `REF-Documentation.md` + specialization `REF-StarlightDocs.md`.

---

## 6. Cross-references between REFs

When a REF needs to point at another REF, use a clear inline reference:

```markdown
- See `REF-Tests.md` §4 for the same pattern in test code.
- Specialization: `REF-StarlightDocs.md` extends this.
```

Just plain links/file references - no special syntax. The "REF" naming convention is the pointer; that's enough.

---

## 7. Maintenance

- **Who may change a file is `OWNERS`' answer** (`REF-Universe.md` §5): admins everything, a galaxy writer its galaxy (`/galaxies/<name>/`), an atom owner its one planet: a skill, agent, MCP or RAG card. A change beyond your rights goes to whoever holds them.
- **Edit a REF when a pattern changes** - e.g. the team adopts a new testing convention.
- **Never edit a REF to add project context** - put that in the project's `README.md`, `CLAUDE.md`, or vault `_System/`.
- **When reviewing a REF edit, check:** could this sentence apply to any project using this tech stack? If not, it doesn't belong.

---

## 8. Relationship to AI-PLAYBOOK.md (the playbook)

`AI-PLAYBOOK.md` is the entry point - it indexes the galaxies and lists the universal violations; each galaxy's `GALAXY.md` routes tasks to the right REFs and lists that galaxy's skills and violations. A `GALAXY.md` may reference project-specific files (like `README.md`) because its job is orientation. REFs themselves remain generic within their galaxy's subject.

The playbook is **singular** - there is exactly one. Don't create another. Anything you'd want to add to "another playbook" is either a galaxy (a new body of earned knowledge, per `REF-Universe.md` §7), a REF (pattern guide), or belongs in a project-specific file.

---

## 9. REFs vs Skills - the mental model

REFs are **patterns** (long-form, generic, principles). Skills are **instantiations** (concrete, invocable, do-this-now). Skills *consume* REFs.

**REF examples:**
- `REF-CleanArchitecture.md` - what hexagonal architecture is, how layers compose, dependency rules
- `REF-Python.md` - Python conventions (frontmatter imports, `__all__`, type hints, etc.)
- `REF-Tests.md` - how to organize tests, naming, layering, what to mock vs not

**Skill examples (potential):**
- `bootstrap-hexagonal-python` - given a fresh project, scaffold the directory tree, create empty layers, write a stub use case + adapter. Refs: `REF-CleanArchitecture`, `REF-Python`, `REF-Domain`, `REF-InboundPort`, `REF-OutboundPort`, `REF-UseCase`, `REF-Tests`.
- `bootstrap-csd-tests` - given an existing project, scaffold pytest tests following CSD invariants. Refs: `REF-Tests`, `REF-Python`.
- `bootstrap-docs-site` - set up Starlight docs scaffolding. Refs: `REF-Documentation`, `REF-StarlightDocs`.
- `digest` (vault) - read Inbox, extract to PARA, write audit footer. Refs: future `REF-Foreign-Brain` if the vault pattern gets extracted.

Skills are *much* more specific than REFs. They take patterns from one or more REFs and apply them to produce concrete output.

## 10. Skill frontmatter convention (Skill → REF)

Every `SKILL.md` declares which REFs it instantiates:

```yaml
---
name: bootstrap-hexagonal-python
description: Scaffold a clean hexagonal architecture Python project from scratch.
refs:
  - REF-CleanArchitecture
  - REF-Python
  - REF-Domain
  - REF-InboundPort
  - REF-OutboundPort
  - REF-UseCase
  - REF-Tests
---
```

`refs:` is the explicit dependency declaration. Loading the Skill (or invoking it) implies the listed REFs should be in context - without them, the patterns the Skill enforces are ungrounded. AI invoking the Skill should ensure the REFs are loaded before executing.

For Skills that don't yet have REF coverage, declare `refs: []` and add a note. Goal: every Skill ultimately has REF backing, so the layered view is complete.

## 11. REF back-link convention (REF → planet)

The relationship between a REF and the planets that orbit it must be visible in **both** directions. Planet frontmatter (§10) covers planet → REF. The reverse - every REF that any planet cites carries a section listing those planets - covers REF → planet.

Each REF that a Skill points to via `refs:` carries a `## N. Skills that instantiate this REF` section listing every such Skill with a one-line summary. Those sections live in the file's **tail**: the generated sections close the REF, and no authored section follows the first of them (INT-SHAPE-006).

Generated form (what `scripts/sync_backlinks.py` emits):

```markdown
## 13. Skills that instantiate this REF

Generated by `scripts/sync_backlinks.py` from skill frontmatter; do not edit by hand.

Skills whose frontmatter `refs:` includes `REF-Foreign-Brain`:

- `archive` - Archive a project / area / resource in a Foreign Brain vault [...]
- `conversation-open` - Run at the start of every session in a Foreign Brain vault [...]
- `digest` - Process unprocessed Inbox files in a Foreign Brain vault [...]
```

Why both directions: a reader landing on a REF should see what concrete invocations exist for it without grepping the skills folder. A reader landing on a Skill should see what patterns ground it.

The back-link sections are **generated**, not hand-written: `scripts/sync_backlinks.py` projects them from skill frontmatter (Top Violation #1 - propagation between synced artifacts must be mechanical). After authoring or editing a Skill's frontmatter, run the generator; the intent tests fail on any drift (INT-LAYER-002 catches a missing link, INT-LAYER-004 catches any divergence from the generated form).

Agents (§13) declare `refs:` the same way and project the same way: the generator renders a second section, `## N. Agents that orbit this REF`, from agent frontmatter. The two generated sections are the file's tail, skills first and agents last, and neither is ever hand-edited.

## 12. Promoting a REF section to a Skill

When a section of a REF becomes concrete enough to invoke as a command (e.g. "run the digest pipeline"), promote it:

1. Identify the concrete operation. If it's just rules, it's a REF; if it's a verb-shaped action, it's a Skill.
2. Run the `bootstrap-skill` skill: it scaffolds the galaxy's `skills/<name>/SKILL.md` (frontmatter `name`, `description`, `galaxy`, `refs:`), then regenerates both projections of that frontmatter in one transaction, the galaxy's `GALAXY.md` § Available Skills table and the back-link sections (per §11). (New REFs scaffold via `bootstrap-ref`.)
3. Author the SKILL.md body around the three canonical slots - `## Pre-flight`, `## Steps`, `## Failure modes`, in that order, extra sections permitted anywhere (INT-SHAPE-005). It references the source REF section(s); operational rules live in the REF, not duplicated in the Skill.
4. Run the gates (`python -m pytest -q`, `python scripts/check_links.py`).
5. Install to the runtime: `python scripts/install_playbook.py --only <name>`.

Don't pre-promote - only promote when there's a real invocation pattern.

---

## 13. Structure of an agent file

An agent is the fourth planet kind (`REF-Universe.md` §4): a skill is what gets done, an agent is who does it. One file per agent on its galaxy's shelf, at `agents/<name>.md`. The file is an agent definition in the shape every agent runtime reads: a name, a description the runtime routes on, a system prompt, the tools it may use, and how freely it may act. Each runtime spells those fields its own way, and the file installs into any of them by a mechanical transform (the same delivery leg `install-playbook` gives a skill), so the corpus authors one agent and every harness, desk, and pipeline spawns that one.

```text
---
name: <kebab-case>              # equals the filename
title: <Display Name>           # the job title: what the room draws and the run log names
description: <one line: when to hand work to this agent>
galaxy: <galaxy>
refs:                           # home sun first, citations after
  - REF-<Home>
skills:                         # the runbooks it is licensed to run: at least one, each resolving
  - <skill-name>
doors:                          # the mcp doors it needs bound; may be empty
  - <door-name>
posture:
  permission: <how often it stops to ask, in the runtime's own mode vocabulary>
  writes: <true|false>            # may it change the artifacts it works on
  fresh_eyes: <true|false>        # is its value having had no hand in what it reads
appearance:                     # omitted entirely when fresh_eyes is true
  hair: <short|long|bun|crest|bald>
  headwear: <none|cap|beanie|hardhat|headphones>
  eyes: <dot|wide|tired|visor>
  face: <plain|smile|moustache|beard|stubble>
---

# Agent: <Title>

<One paragraph, written to be run under: what this agent is here to do, how it reports, and what it refuses.>
```

Guidelines:

- **The description is the router.** One line saying when to hand work to this agent, in the terms a task arrives in: "reviews a pull request against its ticket", "takes one ticket to a pull request". A runtime that delegates on its own reads this line and nothing else to choose a worker, so it names the work, never the character; it is also the agent's line in every REF back-link and catalog. A harness that spawns a named agent (a pipeline's phase map, a desk's picker) keys on `name:` and ignores it, which is why many agents may be licensed for one skill and one agent for many: the licence is what it may run, the description is when it is chosen, and neither is a lookup table.
- **The body is the system prompt.** It is the paragraph the worker runs under, so it is written to be obeyed rather than browsed: the role in one clause, then how it reports (what it hands back, and in what form) and what it refuses. A catalogue blurb that describes the worker from outside is the failure mode: it reads well and changes nothing about how the worker behaves. Voice is the smallest part, and it belongs here too when it matters: terse or explanatory, when it stops to ask.
- **Character, not procedure.** The body never restates a step its skill already carries; that copy is the one that goes stale (`REF-Universe.md` §4). The gates enforce it: no ordered step lists, no code fences, a length cap, and at least one named skill that resolves.
- **The refusals are the load-bearing half.** "What it refuses" is what distinguishes one worker from another, and the corpus usually already states it: take the refusal from the REF and the skills the agent runs rather than inventing a new one, and keep their words.
- **Posture says three narrow things.** `permission:` is how often the worker stops to ask before it acts, named in the runtime's own mode vocabulary, which is the same word a consumer passes when it starts one (`default`, `plan`, `auto` are the Claude Code modes this corpus's roster uses); a worker that must confirm each act is not the one that runs unattended. `writes:` is whether it may change **the artifacts it works on**, so a reviewer posting a verdict declares `false`: the code it read comes back untouched. `fresh_eyes:` is whether its whole value is having had no hand in what it now reads. The gate requires `permission:`, never a particular list of modes, so a runtime that gains one does not fail the corpus: a pinned enum here would be a dependency this REF cannot version (Anti-Pattern 3a).
- **Appearance names features, never colours.** The corpus says what a figure is; the renderer owns the palette, so no hex value or swatch enters an agent file. A fresh-eyes agent carries no `appearance:` at all: the outsider has to read as not-the-team, so the look belongs to the role rather than to whoever fills it.
- **Nothing the environment binds.** No model id, no endpoint, no credential, no git identity: those are the environment's half of the same split that governs doors (`REF-Universe.md` §3).
- **Scaffold with `bootstrap-agent`**, then run the gates. An agent is discovered through its home sun: the REF back-links are generated from its frontmatter, exactly as a skill's are (§11), so no roster is maintained by hand anywhere.

---

## 14. Anti-Patterns

| # | Anti-Pattern | Correct Approach |
| - | ------------ | ---------------- |
| 1 | Absolute filesystem paths anywhere in this folder | Bare filename / repo-relative / sibling-relative per §2 |
| 2 | Hardcoding project URLs, ports, or domain terms in a REF | `<placeholder>` syntax or generic description |
| 3 | Naming real project classes or modules | Use generic names: `MyEntity`, `<package>`, `FooResponse` |
| 3a | Naming a winning third-party library for a problem whose shape is small enough to own | Name a library only when the library **is** the deliverable (§4). Otherwise teach the shape: a named package is a dependency the REF cannot version, and an agent installs whatever the REF names |
| 3b | Coining a term for a concept that already has a name in the code or the industry | Reuse the existing word (§4); an invented name is a second vocabulary that drifts, and it forces the reader to learn a metaphor before the rule |
| 4 | Writing a REF that only makes sense for one project | Generalize, or move content to project's `README` / `CLAUDE.md` |
| 5 | Duplicating content already in another REF | Cross-reference: "see `REF-<topic>.md` §N" |
| 6 | Writing tutorial-style prose | State rules and patterns; skip the storytelling |
| 7 | Creating overlapping REFs with duplicated rules | Split into Core + Specialization and route both in the playbook |
| 8 | Calling a reference doc a "Skill" (or "this skill" inside a REF body) | If it teaches *patterns*, it's a REF. Skills are *invocable* (runtime-registered). |
| 9 | Creating multiple "playbooks" | The playbook is singular. Additional content goes in a REF. |
| 10 | Hand-editing a REF back-link section | Edit skill or agent frontmatter, then run `scripts/sync_backlinks.py` (§11). The intent tests enforce sync. |
| 11 | An agent file carrying its skill's steps | The agent names the skills; the runbook stays in the skill (§13) |
| 12 | A model id, credential, or endpoint in an agent file | The corpus holds the character, the environment holds the binding (§13) |

---

## 15. Skills that instantiate this REF

Generated by `scripts/sync_backlinks.py` from skill frontmatter; do not edit by hand.

Skills whose frontmatter `refs:` includes `REF-Authoring`:

- `bootstrap-agent` - Scaffold a new agent onto a galaxy's shelf in one deterministic transaction (agents/<name>.md with resolving frontmatter, regenerated REF back-links).
- `bootstrap-galaxy` - Scaffold a new galaxy in the universe in one deterministic transaction (galaxies/<name>/ with the GALAXY.md skeleton, the planet seats, and the AI-PLAYBOOK.md index row).
- `bootstrap-ref` - Scaffold a new REF onto a galaxy's shelf from the REF-Authoring template (frontmatter with domain, title, summary blockquote, first numbered section).
- `bootstrap-skill` - Scaffold a new Skill onto a galaxy's shelf in one deterministic transaction (SKILL.md skeleton with frontmatter, then the galaxy's regenerated Available Skills table and the regenerated REF back-links).
- `forge-smelt` - Judge a territory's nebula with the operator: cluster the stardust (ignite, accrete, ash), propose take or burn with recorded reasons, author every take into the universe through the bootstraps, and flip note statuses in place.
- `install-playbook` - Install or refresh the whole playbook toolchain on this machine (every skill, and the agent roster rendered for the harness you run) in one mechanical command, then relay the installer's summary table.

---

## 16. Agents that orbit this REF

Generated by `scripts/sync_backlinks.py` from agent frontmatter; do not edit by hand.

Agents whose frontmatter `refs:` includes `REF-Authoring`:

- `librarian` - Closes a finished delivery line and files its lessons as tickets for the maintenance loop; hand it a run that reached done.
