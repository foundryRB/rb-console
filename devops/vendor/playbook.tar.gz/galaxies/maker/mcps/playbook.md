---
name: playbook
galaxy: maker
refs:
  - REF-Universe
---

# MCP: playbook

> Knock here to read or edit the universe itself over its studio door: parsed REFs, skills, the graph, gated writes, and the sync acts.

The door to the corpus. Reads return parsed content rather than raw files; writes are gated by the universe's own validation suite and roll back byte-identical when the gates fail; skill installs follow the client-executes idiom (the door returns the files, the caller writes them into its runtime).

## Doctrine

- Bind the door with your own personal token, minted from the studio's Connect menu and sent as a Bearer header. The door then acts as you: every write carries your name as its author, and you may write what the playbook's `OWNERS` gives you. The shared credential belongs to services and acts as the service; never hand it to a person.
- Rights are literal paths. An admin owns the root (everything, the sync acts included), a galaxy writer `/galaxies/<name>/` (its page, its REFs, every planet in it, and creating planets there), an atom owner one planet: a skill, agent, MCP or RAG card; everyone else reads. A refused write names the role it needs: ask whoever holds that role, never borrow a credential that holds it.
- The door serves a server-side clone, separate from any local checkout: ship a local edit by pushing to the repo, and the clone takes it on its own upstream poll, or at once when an admin asks the door to refresh; edit over the door and the change is committed server-side.
- Never hand-write what the gates generate: back-link sections come from `scripts/sync_backlinks.py`, table rows from the scaffolders.
- A failed write is a verdict: read the validation report it returns; fix the content, never fight the gate.
