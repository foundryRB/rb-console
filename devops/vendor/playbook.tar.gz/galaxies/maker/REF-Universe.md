---
domain: meta
---

# REF: Universe

> Read this when working on the corpus itself: adding or reorganizing galaxies, declaring planets (skills, agents, mcps, rags), or deciding where knowledge lives. The universe is one repo of earned knowledge; this REF is its physics: the four levels, the residence axis, the routing rules, and how the maker grows it.

---

## 1. The universe: one repo, four levels

The model brings the generic; the universe holds what we earned; the maker grows it. Everything the org knows that a model does not lives in this one repository, structured in four levels so an agent loads exactly what a task needs:

| Level | Artifact | Job |
|---|---|---|
| Universe | `AI-PLAYBOOK.md` at the repo root | The galaxy index and the universal violations; the only page always in context |
| Galaxy | `galaxies/<name>/GALAXY.md` | One body of earned knowledge: its routing table, its skills registry, its subject's violations |
| Solar system | `REF-<Name>.md` | The sun: principles, taste, the why for one category of work; routes to its planets |
| Planet | `skills/<name>/`, `agents/<name>.md`, `mcps/<name>.md`, `rags/<name>.md` | The actionable attachments of a sun: carried runbooks, carried workers, declared doors, reserved retrieval seats |

The shape on disk:

```
AI-PLAYBOOK.md              the universe: galaxy index + universal violations
galaxies/
  <name>/
    GALAXY.md               the galaxy's routing table and skills registry
    REF-<Name>.md           suns, one per solar system
    skills/<name>/          carried planets (runbooks)
    agents/<name>.md        carried planets (who runs them, one file per agent)
    mcps/<name>.md          declared doors (one file per door)
    rags/<name>.md          reserved seats (empty until a corpus outgrows navigation)
nebulae/
  <territory>/              unearned research, quarantined (§8): stardust notes + NEBULA.md
scripts/  tests/            one chassis; the gates run for the whole universe
```

One chassis serves every galaxy: `scripts/` and `tests/` exist once at the root and validate the whole universe. A galaxy never carries its own copy of the tooling.

## 2. Galaxies are one kind

A galaxy is one body of earned knowledge. There is no taxonomy of galaxy kinds: `craft` (building software) and a customer industry and a product and an operational practice are all just galaxies. A galaxy's subject can be anything; **earned is the only bar**: it is built from engagements, experts, and deliberate research, and a galaxy nobody in the org can stand behind does not ship.

Every galaxy carries:

| Element | Requirement |
|---|---|
| `GALAXY.md` | The routing table (task to REFs), the Available Skills registry, and the galaxy's own violations. Opens with a `Galaxy at a glance` block naming the galaxy, subject, owner, and anchor REF |
| An owner | One resident expert whose judgment the galaxy's content answers to, named by role in the at-a-glance block |
| An index row | One row in `AI-PLAYBOOK.md`'s galaxy table: name, subject, entry link |
| Green gates | The universe's test suite and link checker pass with the galaxy in place |

The maker (`galaxies/maker/`) is a galaxy in shape and lives under `galaxies/` like every other; it is special only in subject: the corpus itself.

## 3. Planets: carried, declared, bound

Four planet kinds orbit a sun, split by one axis: what the corpus can hold versus what it can only point at. Two are carried, two are declared.

| Kind | Residence | The corpus holds |
|---|---|---|
| **skill** | Carried in the repo: `skills/<name>/` | Everything: the runbook is text, versioned and fully gated. The agent installs and follows it |
| **agent** | Carried in the repo: `agents/<name>.md` | Who does the work: its character, the skills it is licensed to run, the doors it needs bound, its posture and its appearance. Never the procedure (its skills carry that) and never the binding. Its rendered form is a **ship**: a crewed vessel on a route through the planets its licence names, a traveller among the bodies and never a body itself |
| **mcp** | Declared in the galaxy: `mcps/<name>.md` | The door's name, its purpose, when to knock, and the earned doctrine about using it well. Never the interface (the server self-declares its tools at connect) and never a credential |
| **rag** | Declared in the galaxy: `rags/<name>.md` | Same declaration shape as a door; the seat is reserved and stays empty until a corpus outgrows agentic navigation of its index. Its rendered form is a **satellite**: a placed body the corpus points at, never a moon it holds |

The third residence is the **environment**: bindings. A declared door becomes usable when the environment binds its name to an endpoint and a credential (an `.mcp.json` entry, a platform connector, a cluster secret). A fresh agent reading only the corpus sees every door by name and purpose; binding stays a deliberate operator act, which is a security property, never a gap. A person binds the playbook's own door with their own personal token, minted from the studio, so the door acts as that person, with their rights and their name on every change (§5); a service binds the service's credential and acts as the service.

A carried agent splits the same way. The file holds who the worker is and how it behaves; the environment supplies the model it thinks with, the credential it acts under, the identity its commits carry, and the endpoints behind the doors it names. So a file says "thinks with a strong reasoning model, never writes to the default branch" and a consumer's runtime settings decide which model that is and whose key it spends.

The split of responsibilities is absolute: **the door declares its interface; the corpus holds the doctrine; the environment holds the binding.** None of the three ever holds another's part. A door file that lists the server's tools is duplication of a self-declaring interface (universal violation #1); a door or agent file that names an endpoint or credential breaks portability (universal violation #3).

Planet files link upward by frontmatter: a skill's `refs:`, an agent's `refs:` and a door's `refs:` name the suns it draws doctrine from, and every planet's `galaxy:` names the galaxy it sits in. The gates check `galaxy:` against the folder; back-link sections in REFs are rendered mechanically by `scripts/sync_backlinks.py`, never by hand.

A planet cites many suns but **lives with one**: the FIRST entry in `refs:` is its **home sun**. The home is an ownership statement, not a link: the skill primarily serves that subject, it orbits that sun in every view, and when the home REF changes, the skill is re-read to see whether it still makes sense. The other refs are citations: real, traveled, rendered as connections, but never mistaken for residence. Order `refs:` deliberately: home first, citations after. Every skill and every agent has a home (the gates enforce a non-empty `refs:`).

A carried planet's supporting files are its **moons** and its **rings**: everything in the skill folder beyond `SKILL.md` orbits the planet it serves. `SKILL.md` is the planet's own body; a loose file beside it (a scaffolder script, a helper) is a moon, and a folder (templates, fixtures, themes) is a ring, one band per file: the material the planet holds, drawn around it rather than scattered as a swarm. Moons and rings travel with the planet on install and render around it in the views. They are natural bodies, born with the planet and held by the corpus; a rag's **satellite** is the placed counterpart, pointed at and never carried, the same holds-versus-points-at split that separates a carried skill from a declared door. So the pictures render from residence: the corpus holds moons and rings and points at satellites, and the ships that work among them are the agents.

## 4. Agents: who does the work

A skill is what gets done; an agent is **who does it**. An agent file holds only what a skill cannot: who it is, with a title and a one-line description a runtime routes work by; the paragraph it runs under, stating what it is here to do, how it reports, and what it refuses; the `skills:` it is licensed to run; the `doors:` it needs bound; its posture, meaning how often it stops to ask, whether it may write, and whether it is a fresh-eyes role; and its appearance, so a rendered agent reads as a person rather than a colourway.

**An agent exists where someone wants to hand work to a distinct worker**: distinct by what it may run, by how freely it acts, or by having had no hand in what it reads. Whoever that someone is makes no difference, an operator in a terminal, a delivery pipeline, a desk, because the file is one agent definition and every runtime spawns the same one from it: an agent installs into a harness as that harness's own agent shape by a mechanical transform, exactly as a skill installs as a skill, and a pipeline or a desk reads the same file over the playbook door. A worker that differs from an agent on the shelf only in which run it is on is that agent. A distinct worker nobody hands work to is a roster entry, and the roster is what makes the set readable, reviewable, and changed on purpose.

**An agent file may not contain procedure.** That is a gate, not a guideline: an agent that restates its skill is a second copy to maintain in parallel (universal violation #1), and the copy in the agent file is the one nobody updates. The gates hold the line mechanically rather than by good intentions: no ordered step lists, no code fences, a length cap, and at least one named skill that resolves.

**`skills:` is a licence, not a lock.** It declares what an agent is meant to run, so a roster can be read and reasoned about; it enforces nothing. Enforcement stays where it already lives: in the worker's tool configuration and in the credential the environment binds. Nothing downstream may read an agent file as a security boundary.

**Agents are not operators.** These are generic and publishable, bound to skills and REFs that exist only here. Who our *people* are is personal data (identity, preferences, memory, access), and it lives in its own private store, never in a published corpus (universal violation #3). The two mirror each other; they are never one store. The one exception is `OWNERS` (§5): a person's sign-in email and the paths they may change, nothing else about them, held by the install that carries it.

## 5. Routing: one entry, free travel

`AI-PLAYBOOK.md` is the only always-loaded page. From it the agent enters whichever galaxies the task needs, several at once; galaxies borrow from each other and borrowing is ordinary. There is no declaration gate, no per-engagement galaxy binding, and no routing machinery beyond the tables themselves. Travel is free; **writing is gated** (every corpus change passes the test suite and the link checker) **and owned**.

`OWNERS` at the root is the corpus's rights, in CODEOWNERS syntax: a literal path anchored at the root (no wildcards), then the people who own it, by the email their sign-in carries. A person may change a path a line gives them, or anything under it: an admin owns `/` (everything, `OWNERS` itself and the studio's sync acts included), a galaxy writer owns `/galaxies/<name>/` (its page, its REFs, every planet in it, and creating planets there), an atom owner owns one planet (a skill, agent, MCP or RAG card). Everyone else reads. These are write rights; the galaxy's owner in §2 is the expert its content answers to, whether or not they also write it. The studio decides every write through either of its doors from this one file, and a refusal names the role the write needs; with no `OWNERS`, everyone reads. It is the one root file that names people, so it is the install's own: a copy of the corpus carried to another install leaves it behind, and that install writes its own.

Names are unique universe-wide: REF names, skill names, agent names, and door names never collide across galaxies, so a bare `` `REF-<Name>.md` `` or skill name resolves wherever it lives and prose never needs galaxy-qualified references. Choose descriptive names (`REF-AppContract`, `REF-CleanArchitecture`) so uniqueness stays natural as galaxies multiply.

Two size disciplines keep progressive disclosure alive as the universe grows: the universe index stays under a page, and each `GALAXY.md` routing table stays a table an agent can scan, never a document it must study.

Engineering practice in `craft` is independent of the delivery system in `foundry`: foundry REFs may cite craft REFs; authored craft REF content never cites foundry REFs. Generated reverse links identify the skills and agents that consume a practice and do not create a doctrine dependency.

## 6. The maker

The maker owns the universe's physics: this REF, `REF-Authoring.md` (how suns and planets are written), the scaffolding skills (`bootstrap-ref`, `bootstrap-skill`, `bootstrap-agent`), the toolchain install (`install-playbook`), and the gates in `tests/`. It is deliberately tiny: the meta subject plus what the structure itself needs, nothing more.

Forging a new galaxy is the maker's second job. A galaxy is born from earned knowledge: engagement exhaust, expert interviews, deliberate research distilled into suns and planets through the same gates as everything else. The forge is research-driven and always ends at the same bar: an owner who stands behind the content.

## 7. Growing the universe

To add a galaxy: run the `bootstrap-galaxy` skill (it creates `galaxies/<name>/` with the `GALAXY.md` skeleton, the planet seats, and the `AI-PLAYBOOK.md` index row in one transaction), then author the routing table and forge the first sun and planets through `bootstrap-ref`, `bootstrap-skill`, and `bootstrap-agent`. The gates enforce the contract: a galaxy folder without a `GALAXY.md`, an index table that disagrees with the folders, a colliding name, or a planet whose frontmatter names the wrong galaxy all fail the suite.

To retire a galaxy: galaxies are earned, so retirement is an operator decision, executed as an ordinary gated change: remove the folder and its index row together.

RAG's seat is reserved, not built. The revisit trigger: a galaxy's content outgrows what agentic navigation of a small index can serve (the routing table stops fitting a scan, or retrieval demonstrably misses content an index hop should have found). When the trigger bites, grep-shaped search comes before vectors.

## 8. Nebulae: the unearned zone

Research in progress lives beside the galaxies, never among them: `nebulae/<territory>/` at the repo root holds one folder per territory under study, written by the Forge's expeditions and judged by its smelt (`REF-Forge.md`). Each folder holds typed stardust notes and a fronting `NEBULA.md`: the subject, the off-limits banner, the roster of notes, and the discarded-claims ledger.

Nebulae are unearned, and the quarantine is mechanical: no galaxy content links into `nebulae/` (a gate fails it), the playbook door serves galaxies only, and `AI-PLAYBOOK.md` states the rule every agent reads on every prompt. Stardust informs nothing until the smelt promotes it through the bootstraps, at which point it enters a galaxy like any other authored material. The studio's views render nebulae dim beside the earned galaxies: visible, second-class, honest.

## 9. Cross-references

- `REF-Authoring.md` - how suns and carried planets are written: templates, the golden rule, the section conventions this REF's structure follows.
- `REF-Forge.md` - the research craft that fills nebulae and smelts them into galaxies (§8).
- `AI-PLAYBOOK.md` - the universe index this REF is the doctrine for.
- Each galaxy's `GALAXY.md` - the per-galaxy instantiation of the contract in §2.

## 10. Anti-patterns

| # | Anti-Pattern | Correct Approach |
|---|---|---|
| 1 | A taxonomy of galaxy kinds (craft vs domain vs industry) | Galaxies are one kind; the subject varies, the shape does not (§2) |
| 2 | A door file cataloging the server's tools | The door self-declares its interface at connect; the file holds purpose and doctrine only (§3) |
| 3 | An endpoint or credential in the corpus | Bindings live in the environment; the corpus is published cross-environment (§3) |
| 4 | Declaration gates on routing (an engagement must name its galaxy) | One entry, free travel; the index is the only door (§5) |
| 5 | Galaxy-qualified names in prose (`craft:REF-X`) | Names are unique universe-wide; bare names resolve anywhere (§5) |
| 6 | A galaxy carrying its own `scripts/` or `tests/` copy | One chassis at the root serves the whole universe (§1) |
| 7 | An empty galaxy scaffolded ahead of its content | Structure trails knowledge; a galaxy ships when its content is earned and owned (§2, §7) |
| 8 | Building a RAG while the index still fits a scan (a satellite rendered with content before the trigger bites) | The seat stays reserved until the trigger bites; grep-shaped search before vectors (§7) |
| 9 | Galaxy content linking into `nebulae/` | Nebulae are unearned and quarantined; only the smelt promotes stardust into the universe (§8) |
| 10 | An agent file that restates its skill's steps | The agent names the skills it runs; the runbook lives in the skill, and the gates refuse procedure in an agent file (§4) |
| 11 | Reading an agent's `skills:` as a permission boundary | It is a licence declaration; enforcement is the worker's tool configuration and the bound credential (§4) |
| 12 | Personal data about an operator in an agent file | Agents are generic and publishable; who a person is lives in its own private store (§4) |

---

## 11. Skills that instantiate this REF

Generated by `scripts/sync_backlinks.py` from skill frontmatter; do not edit by hand.

Skills whose frontmatter `refs:` includes `REF-Universe`:

- `bootstrap-agent` - Scaffold a new agent onto a galaxy's shelf in one deterministic transaction (agents/<name>.md with resolving frontmatter, regenerated REF back-links).
- `bootstrap-galaxy` - Scaffold a new galaxy in the universe in one deterministic transaction (galaxies/<name>/ with the GALAXY.md skeleton, the planet seats, and the AI-PLAYBOOK.md index row).
- `forge-smelt` - Judge a territory's nebula with the operator: cluster the stardust (ignite, accrete, ash), propose take or burn with recorded reasons, author every take into the universe through the bootstraps, and flip note statuses in place.
