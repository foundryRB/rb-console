---
domain: meta
---

# REF: Self-Maintenance (the playbook's own upkeep loop)

> Read this when tending the playbook itself: how REF-Forge's expeditions and REF-Authoring's writes sequence into one repeatable upkeep cycle, and how a session picks the loop up from wherever the last one left it.

---

## 1. Scope

This REF sequences the playbook's own upkeep work: turning research into corpus growth (REF-Forge) and writing that growth correctly (REF-Authoring) into one loop a session can run end to end, and resume from wherever a prior session left it.

It does not restate either REF's doctrine. Read REF-Forge for how one territory becomes stardust and how a smelt judges it; read REF-Authoring for how one REF, skill, or agent is structured and cross-referenced. This REF states the sequence that ties them together, the state that carries the loop across sessions, and the checks that keep the corpus internally consistent (no orphaned skill, no REF nobody routes to, no agent whose doors do not exist) as it grows.

Out of scope: tending a *delivered* app's own repo, which is REF-Maintenance's ticket loop over a different codebase entirely.

## 2. The loop

One cycle, five stages, each already a skill:

1. **Expedition** (`forge-expedition`) - research a territory the universe has not worked; commit surviving claims as stardust to its nebula.
2. **Smelt** (`forge-smelt`) - judge the nebula with the operator; take or burn, reasons recorded, statuses flipped in place.
3. **Author** - every take lands through its own bootstrap, never a hand-written file: `bootstrap-ref` for doctrine, `bootstrap-skill` for an operationalization of it, `bootstrap-agent` for a chartered runner, `bootstrap-galaxy` only when the take founds a whole new area no existing galaxy fits.
4. **Sync** (`sync-skills`) - install or refresh the whole skill and agent roster into the harness that runs it, so a take is usable the same session it lands.
5. **Assay** (`forge-assay`) - when the territory is a live delivery rather than a blank one, a second opinion run over its estimation project's own subject checks a corpus claim against the territory's own findings.

A stage is skipped only when its precondition is already satisfied (an agent scaffolded straight from an existing skill needs no expedition), never to save a step the doctrine requires.

## 3. Resuming across sessions

The loop's state lives in the corpus itself, never in a session's own memory:

- **A nebula's stardust statuses** (`ignite` / `accrete` / `ash`) say what a territory still has open; a session resumes a smelt by reading them, not by re-running the expedition.
- **`get_sync_status`** says whether the working clone has unpushed writes; a session that finds any picks up the push before starting new work, since a second session authoring against the same stale base is the fork the gate cannot catch.
- **`get_graph`** says what already exists - every REF, skill, agent, and the edges between them - so a session checks it before proposing a REF or skill that already covers the territory, rather than after.

A session that cannot read this state before acting treats the loop as starting fresh, never as continuing one it cannot see.

## 4. Anti-Patterns

| # | Anti-Pattern | Correct Approach |
|---|---|---|
| 1 | Hand-writing a REF, skill, or agent file directly | Every one is authored through its bootstrap or its `create_*`/`update_*` tool, gated the same way every time (§2) |
| 2 | A skill or agent that exists with no REF routing to it | Authoring always pairs the operational piece with the doctrine it instantiates (§2, REF-Authoring §9) |
| 3 | Treating a session's own memory as the loop's state | The corpus is the state: nebula statuses, sync status, the graph (§3) |
| 4 | Starting a new expedition over a territory whose nebula already has open stardust | Smelt what is already there before researching more of it (§2) |
| 5 | Skipping `sync-skills` after a take lands | An unsynced take is invisible to the harness that would run it; the loop is not done until it is usable (§2) |
| 6 | Authoring a REF, skill, or agent nobody will run this session | The gate accepts an unattached write; the loop does not - closing it means the take is reachable, not merely committed (§2) |
