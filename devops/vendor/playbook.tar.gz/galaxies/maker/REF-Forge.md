---
domain: meta
---

# REF: Forge

> Read this when researching a territory the universe has not worked: the Forge turns deliberate research into universe material through expeditions, nebulae, stardust, and the smelt.

---

## 1. The one picture

The Forge is the maker's research craft. It enters a territory the universe has not worked, asks of it what pre-sales asks of an industry, and smelts what survives into universe material. Earned is the only bar; the Forge is how a subject nobody here has worked clears it.

| Stage | Nature | What | Who | Gate |
|---|---|---|---|---|
| Territory | a concept | A subject, nothing else: no files, no state | The operator names it, one line | None |
| Expedition | a skill (`forge-expedition`) | Asks the five questions from the territory's seats over the research engine; commits the stardust | The agent, alone after one scope nod | The stardust gate: no commit until the pile passes |
| Stardust | an artifact | Typed notes in the territory's nebula, one note per finding | Anyone exploring; agents only inside forge work | The stardust gate, held in the test suite |
| Smelt | a skill (`forge-smelt`) | Clusters the stardust, proposes take or burn with reasons, authors takes through the bootstraps | The operator and the agent together; no autonomous mode | The universe gates, on every commit |
| Universe | the galaxies | Receives the takes as galaxies, suns, and planets | The gates | The validation suite; failures roll back whole |

Most of the stardust burns; what survives is earned.

Vocabulary seam: the craft's acts speak metallurgy (forge, smelt, burn) and the universe's structures and outcomes speak cosmology (nebula, galaxy, sun, planet, ignite, accrete). The founding sentence of the hybrid is the maker's own charter: it forges new galaxies. Stardust is the material nebulae are made of; the smith works the sky.

## 2. The territory and the expedition

A territory is a subject the universe has not worked: an industry, a practice, a product category, an operation. It is named in one line (the subject, why now, a customer attached or not) and carries no artifact of its own.

An expedition researches the territory along five questions, each asked from the territory's seats rather than head-on (a questioning method harvested from perspective-guided research systems such as storm; the idea travels as prompt structure, never as a dependency):

| # | Question | Asks for |
|---|---|---|
| Q1 | The map | Segments, value chain, who pays whom |
| Q2 | The players | Incumbents, disruptors, what is already sold there |
| Q3 | The needs | What buyers ask for, what their projects look like |
| Q4 | The shapes | Architectures, standards, regulation the territory trusts |
| Q5 | The angle | Where this practice could land; what it would author there, what it would rent |

The canonical seats: buyer, operator, regulator, incumbent, builder. An expedition instantiates them for the territory (a club owner sits the buyer-and-operator chair, a federation the regulator's) and the notes record the instantiated names.

Interaction is one nod, then alone. Before spending anything the expedition plays back the five questions instantiated for the subject, the seats it will interview, and a cost note; the operator adjusts or nods once. An ambiguous subject earns up to three clarifying questions before launch, never during: a fan-out cannot stop midway to chat. After the nod the expedition runs to the end and commits the stardust to the territory's nebula.

The engine is rented: a deep-research skill of the agent runtime (fan-out search, source fetching, adversarial claim verification, cited synthesis). The Forge adds no dependency of its own; the engine is the swappable part.

## 3. Stardust and the nebula

Stardust is the expedition's return: one small typed note per finding that survived verification. A note is smeltable material, which a linear report is not: it can be judged, taken, or burned alone.

Note frontmatter (the stardust schema):

| Field | Values | Rule |
|---|---|---|
| `type` | tool, concept, practice, regulation, news, learning, article, viewpoint | Closed list |
| `confidence` | high, medium, low, derived | `derived` only for synthesis notes (type viewpoint) |
| `vote` | `"N-M"` (for votes, against) | Required except on derived notes |
| `seats` | list of the territory's instantiated seat names | The chairs the finding was heard from (§2) |
| `sources` | list of URLs | At least one, except on derived notes |
| `links` | list of note names | Resolve inside the same territory |
| `status` | unsmelted, taken, burned | The smelt flips it in place |

The note body is a few lines: the claim, its consequence, and inline `[[note-name]]` references to neighbours.

The nebula is where stardust lives: `nebulae/<territory>/` at the corpus root, one folder per territory, committed to git because expeditions are expensive and git is the safe store. `NEBULA.md` fronts each folder with the subject, the off-limits banner, the roster of notes, and the discarded-claims ledger (every claim verification killed, with its vote and source), so nothing is silently dropped. A spent nebula deletes in one commit; history remembers it.

## 4. The quarantine

Nebulae are unearned. A nebula's content informs nothing until it is smelted, and the structure enforces that mechanically:

- Nothing routes in: no index row, no `GALAXY.md` reference, and no link from any galaxy file into `nebulae/`. A gate fails any galaxy content that tries.
- The playbook door serves galaxies only; nebula content never crosses the MCP.
- `AI-PLAYBOOK.md` carries the rule in plain words, so every agent reads it on every prompt.
- Agents open nebulae only inside forge work (an expedition writing, a smelt judging, the operator exploring).

## 5. The smelt

The smelt is the judging act and it is always attended: every take enters doctrine, and doctrine needs an owner who stands behind it. There is no autonomous smelt.

The session walks the territory's nebula in three moves:

1. **Arrange**: cluster the notes into candidates: what could ignite (found a galaxy), what could accrete (suns and planets on existing galaxies), what looks like ash.
2. **Propose**: per note, take or burn, each proposal carrying its reason; the reasons stay on record either way (a gate design harvested from criteria-gated screening tools such as elicit). The operator decides every take; whole-cluster answers are allowed.
3. **Promote**: takes are authored immediately through the bootstraps (`bootstrap-galaxy`, `bootstrap-ref`, `bootstrap-skill`), gates run, and each promoted or burned note's `status` flips in place.

The session ends with a complete ledger of what entered the universe, what burned, and why. The universe keeps what was smelted, never the stardust.

## 6. The gates

Two gates, both mechanical:

- **The stardust gate** (the nebula suite in `tests/`): every note parses; `type` comes from the closed list; `confidence`, `vote`, and at least one source present per the schema; `links` resolve inside the territory; `NEBULA.md` lists every note and carries the discarded ledger; no galaxy content links inward. The expedition runs the same checks before it commits; the suite holds the line ever after.
- **The universe gates**: the smelt's takes land through the bootstraps and the validation suite checks every change as it checks any other authoring; a failed gate rolls the scaffold back byte-identical. The Forge builds nothing here; it inherits the universe's own tests.

## 7. The assay

An aside, not a stage: the expedition pointed at a finished estimate, for a second opinion from the territory itself. The assay reads an estimation project over its door, researches the project's territory fresh, and hands back findings: needs the estimate never priced, solution shapes the territory trusts that it ignores, assumptions the territory contradicts. It writes nothing, needs no nebula to exist, and sits outside the picture: the Forge runs whole without it, and any delivery process runs whole without the Forge. Findings-only through a door is the entire seam.

## 8. Anti-patterns

| # | Anti-Pattern | Correct Approach |
|---|---|---|
| 1 | An autonomous smelt | Doctrine needs an owner; the operator decides every take (§5) |
| 2 | Routing or linking galaxy content into a nebula | Quarantine: stardust informs nothing until smelted (§4) |
| 3 | Research returned as one linear report | Stardust: typed notes, judged and burned one by one (§3) |
| 4 | Research kept outside the corpus (loose folders, chat scrollback) | The nebula: committed, gated, rendered by the studio (§3) |
| 5 | A Forge studio, server, or state of its own | Two skills and a folder; the studio's maps render nebulae, the door never serves them (§4) |
| 6 | Founding a galaxy straight from an expedition | Only the smelt promotes, through the bootstraps and gates (§5) |
| 7 | Dropping refuted claims silently | The discarded ledger in `NEBULA.md`; exclusions stay on record (§3, §6) |
| 8 | Flags and modes on the forge skills | One required parameter each; the expedition always takes the nod, the smelt is always attended, the assay only returns findings (§2, §5, §7) |

---

## 9. Skills that instantiate this REF

Generated by `scripts/sync_backlinks.py` from skill frontmatter; do not edit by hand.

Skills whose frontmatter `refs:` includes `REF-Forge`:

- `forge-assay` - A second opinion from the territory itself: run a scoped expedition over a finished estimation project's subject, read its requirements and assumptions against the findings, and hand back findings only.
- `forge-expedition` - Research a territory the universe has not worked: instantiate the five pre-sales questions from the territory's seats, run them over the deep-research engine, and commit the surviving claims as typed stardust notes to the territory's nebula, gated by the stardust schema.
- `forge-smelt` - Judge a territory's nebula with the operator: cluster the stardust (ignite, accrete, ash), propose take or burn with recorded reasons, author every take into the universe through the bootstraps, and flip note statuses in place.
