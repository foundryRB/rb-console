---
name: bootstrap-galaxy
description: Scaffold a new galaxy in the universe in one deterministic transaction (galaxies/<name>/ with the GALAXY.md skeleton, the planet seats, and the AI-PLAYBOOK.md index row). Author the routing table and forge the first suns and planets afterwards, then run the gates. A galaxy ships earned and owned, never empty.
galaxy: maker
refs:
  - REF-Universe
  - REF-Authoring
---

# Bootstrap galaxy

Invoked when a new body of earned knowledge is ready to join the universe: a product, a practice, an industry, an operation. The scaffold is mechanical; the galaxy is not: its content must be earned (engagements, experts, deliberate research) and a resident-expert owner must stand behind it (`REF-Universe.md` §2, §7).

## Pre-flight

1. Confirm the subject is earned: there is real content ready to land (REFs to write from experience, not scraped filler). An empty galaxy scaffolded ahead of its content is the anti-pattern (`REF-Universe.md` §10.7).
2. Confirm the owner: one resident-expert role who answers for the content.
3. Confirm the name: kebab-case, unique among `galaxies/*/`, descriptive of the subject.

## Steps

1. Run the scaffolder (the `bootstrap.py` beside this SKILL.md) from the playbook root, or pass `--playbook-root <path>` from anywhere else:

   ```bash
   python bootstrap.py \
       --name <galaxy> --subject "One-line subject." --owner "The resident-expert role"
   ```

   This creates `galaxies/<name>/` (GALAXY.md skeleton, `skills/`, `mcps/`, `rags/` seats) and appends the galaxy's row to `AI-PLAYBOOK.md`'s index table (INT-UNIV-002).
2. Author the GALAXY.md: the at-a-glance anchor REF, the Task Routing table, and the galaxy's own violations, per the craft and maker shelves as examples.
3. Forge the first suns and planets: `bootstrap-ref --galaxy <name>` for each REF, `bootstrap-skill --galaxy <name>` for each skill; declare doors as `mcps/<name>.md` files (purpose and doctrine, never interface or credentials).
4. Run the gates: `python -m pytest -q` and `python scripts/check_links.py`; the INT-UNIV suite enforces the galaxy contract.
5. Ship: push, then `refresh_content` over the playbook door; install any new skills with `python scripts/install_playbook.py`.

## Failure modes

- **The galaxy already exists**: the scaffolder refuses; extend the existing shelf instead of re-scaffolding.
- **Gates red after scaffolding**: the INT-UNIV suite names the broken contract (index row, GALAXY.md heading, name collision, planet frontmatter). Fix the content; never loosen the gate.
- **No content lands after the scaffold**: an empty shelf misleads every reader of the index. Either land the first sun in the same change or revert the scaffold.
