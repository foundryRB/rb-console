#!/usr/bin/env python3
"""Scaffold a new Skill in the playbook: the mechanical half of REF-Authoring section 12.

One deterministic transaction:
1. Writes the galaxy's skills/<name>/SKILL.md (frontmatter with
   name/description/galaxy/refs + body skeleton).
2. Runs scripts/sync_registry.py so the galaxy's Available Skills table gains the
   row projected from that frontmatter (INT-LAYER-003, INT-LAYER-006).
3. Runs scripts/sync_backlinks.py so referenced REFs gain their back-link entries
   (INT-LAYER-004).

Refuses to overwrite an existing skill. The caller authors the SKILL.md body,
runs the gates, and copies the folder to the runtime skills directory.

Usage:
    python bootstrap.py --name do-thing --description "One-line description." \
        [--refs REF-A,REF-B] [--galaxy craft] [--playbook-root <path>]
"""

from __future__ import annotations

import argparse
import json
import re
import subprocess
import sys
from pathlib import Path

__all__ = ["main"]

NAME_RE = re.compile(r"^[a-z][a-z0-9]*(-[a-z0-9]+)*$")


def _universe_root(explicit: Path | None) -> Path:
    """The directory holding AI-PLAYBOOK.md: the one named, else the working directory. A maker
    scaffolder is run from the corpus it writes into, wherever its own file was installed."""
    root = explicit or Path.cwd()
    if (root / "AI-PLAYBOOK.md").is_file():
        return root
    hint = "pass the playbook root" if explicit else "run from the playbook root or pass --playbook-root <path>"
    raise SystemExit(f"error: no AI-PLAYBOOK.md in {root}; {hint}")

SKILL_TEMPLATE = """---
name: {name}
description: {description_json}
galaxy: {galaxy}
{refs_block}---

# {title}

Invoked when the user wants to run this operation. Describe the trigger here.

## Pre-flight

1. State what to read or confirm before acting.

## Steps

1. State the first step here.

## Failure modes

- State what goes wrong and what to do about it.
"""


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--name", required=True, help="Skill name, kebab-case")
    ap.add_argument("--description", required=True, help="One-line description")
    ap.add_argument("--refs", default="", help="Comma-separated REF ids the skill instantiates")
    ap.add_argument("--galaxy", default="craft", help="Galaxy the skill shelves in (default: craft)")
    ap.add_argument("--playbook-root", type=Path, default=None)
    args = ap.parse_args()

    root = _universe_root(args.playbook_root)
    name = args.name.strip()
    description = args.description.strip()
    refs = [r.strip() for r in args.refs.split(",") if r.strip()]

    if not NAME_RE.match(name):
        print(f"error: name must be kebab-case: {name!r}", file=sys.stderr)
        return 2
    if not description:
        print("error: description is required", file=sys.stderr)
        return 2
    galaxy_md = root / "galaxies" / args.galaxy / "GALAXY.md"
    if not galaxy_md.is_file():
        print(f"error: unknown galaxy: {args.galaxy!r} (no {galaxy_md})", file=sys.stderr)
        return 2
    for ref in refs:
        found = (root / f"{ref}.md").is_file() or any(root.glob(f"galaxies/*/{ref}.md"))
        if not found:
            print(f"error: unknown REF: {ref}", file=sys.stderr)
            return 2
    collisions = [
        d for d in [root / "skills" / name, *root.glob(f"galaxies/*/skills/{name}")] if d.exists()
    ]
    if collisions:
        print(f"error: {collisions[0]} already exists (names are unique universe-wide)", file=sys.stderr)
        return 2
    skill_dir = root / "galaxies" / args.galaxy / "skills" / name

    refs_block = "refs:\n" + "".join(f"  - {r}\n" for r in refs) if refs else "refs: []\n"
    skill_dir.mkdir(parents=True)
    (skill_dir / "SKILL.md").write_text(
        SKILL_TEMPLATE.format(
            name=name,
            description_json=json.dumps(description),
            galaxy=args.galaxy,
            refs_block=refs_block,
            title=name.replace("-", " ").capitalize(),
        ),
        encoding="utf-8",
        newline="\n",
    )
    print(f"Created {skill_dir / 'SKILL.md'}")

    for script_name in ("sync_registry.py", "sync_backlinks.py"):
        script = root / "scripts" / script_name
        if not script.is_file():
            continue
        proc = subprocess.run(
            [sys.executable, str(script)], cwd=root, capture_output=True, text=True
        )
        print(proc.stdout.strip())
        if proc.returncode != 0:
            print(proc.stderr, file=sys.stderr)
            return proc.returncode
    return 0


if __name__ == "__main__":
    sys.exit(main())
