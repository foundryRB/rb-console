---
name: bootstrap-skill
description: Scaffold a new Skill onto a galaxy's shelf in one deterministic transaction (SKILL.md skeleton with frontmatter, then the galaxy's regenerated Available Skills table and the regenerated REF back-links). Author the body afterwards, run the gates, and copy the folder to the runtime skills directory.
galaxy: maker
refs:
  - REF-Authoring
---

# Bootstrap skill

Invoked when a new Skill is being promoted per `REF-Authoring.md` §12. Handles every mechanical step of the promotion; the judgment steps (the body content, whether promotion is warranted at all) stay with the author.

## Pre-flight

1. **Read** `REF-Authoring.md` §9 to §12 (REFs vs Skills, frontmatter, back-links, promotion).
2. **Confirm with user**: skill name (kebab-case), one-line description, and which REFs it instantiates (`refs:`).
3. **Don't pre-promote**: only scaffold when there is a real invocation pattern (§12).

## Steps

1. **Run the scaffolder** from the playbook root, or pass `--playbook-root <path>` from anywhere else:
   ```bash
   python bootstrap.py --name <skill-name> \
       --description "<one line>" --refs REF-A,REF-B
   ```
   This writes the galaxy's `skills/<name>/SKILL.md`, then runs `scripts/sync_registry.py` (INT-LAYER-003, INT-LAYER-006) and `scripts/sync_backlinks.py` (INT-LAYER-004), so both projections of the new frontmatter land in the same transaction.
2. **Author the SKILL.md body**: pre-flight, steps, failure modes. Operational rules live in the REFs it references, not duplicated in the Skill (§12).
3. **Run the gates**: `python -m pytest -q` and `python scripts/check_links.py` from the playbook root.
4. **Install to the runtime**: `python scripts/install_playbook.py --only <name>`.

## Failure modes

- **Skill already exists**: the scaffolder refuses; rev the existing skill instead.
- **Unknown REF in --refs**: the scaffolder refuses; create the REF first (`bootstrap-ref`) or fix the id.
- **Gates fail**: usually a hand-edited back-link section or a malformed frontmatter; the tests name the file.
