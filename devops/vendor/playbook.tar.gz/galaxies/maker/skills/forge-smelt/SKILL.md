---
name: forge-smelt
description: "Judge a territory's nebula with the operator: cluster the stardust (ignite, accrete, ash), propose take or burn with recorded reasons, author every take into the universe through the bootstraps, and flip note statuses in place. Always attended; there is no autonomous smelt."
galaxy: maker
refs:
  - REF-Forge
  - REF-Universe
  - REF-Authoring
---

# Forge smelt

Invoked when the operator wants a territory's nebula judged into the universe (`REF-Forge.md` §5). Always attended; the session ends with takes authored, statuses flipped, and the ledger complete.

## Pre-flight

1. **Read** `REF-Forge.md` §3 to §6, `REF-Universe.md` §2, §3 and §7 (the galaxy bar, planets, growing the universe), and `REF-Authoring.md` §3 and §10 to §12 (authoring shapes and promotion).
2. **Locate** `nebulae/<territory>/` and run the stardust gate first (`python -m pytest tests/test_nebulae.py -q`); refuse to smelt a missing or red nebula.
3. **Confirm the operator is present.** There is no autonomous smelt; if invoked unattended, stop.

## Steps

1. **Arrange**: read every note; cluster into candidates: ignite (could found a galaxy), accrete (suns and planets on existing galaxies), ash. Present the clusters, one line each.
2. **Propose**: walk cluster by cluster, note by note: take or burn, each proposal with its reason. The operator decides every take. A whole-cluster answer is allowed only when the cluster shares ONE reason and the operator has seen each member's one-line claim first - clustering organizes the walk, it never shrinks the decision surface. Few questions is a defect signal, not efficiency: most stardust burns, so a smelt with two or three asks has bundled judgments the operator never made. Record every reason.
3. **Promote takes immediately**: an igniting body founds a galaxy via the `bootstrap-galaxy` skill (subject plus a named owner; the bar of `REF-Universe.md` §2 applies). Accreting notes become sections on existing REFs, or new REFs and skills via the `bootstrap-ref` and `bootstrap-skill` skills on the receiving galaxy. Regenerate back-links where frontmatter changed (`scripts/sync_backlinks.py`).
4. **Flip statuses in place**: `taken` or `burned`; `unsmelted` remains only on notes deliberately deferred.
5. **Run the gates**: `python -m pytest -q` and `python scripts/check_links.py` from the repo root; fix until green.
6. **Close**: append the session ledger to `NEBULA.md` (what entered the universe and where, what burned, and why), commit the smelt as one commit (universe changes and status flips together), and report the ledger to the operator. Subject: `feat(<galaxy>): <what entered>` when the smelt lands a new sun or planet, `docs(<galaxy>): <what changed>` when every take was an edit to existing ones.

## Failure modes

- **Operator absent, or answering wholesale** ("take everything"): stop and restate the bar; most of the stardust burns, and a wholesale take defeats the smelt.
- **A take fails the universe gates**: fix the authored material, never the gate; the bootstraps roll back on failure, retry after the fix.
- **Ignite proposed on thin mass**: default to accrete; a galaxy ships earned and owned, never empty (`REF-Universe.md` §2).
- **Territory spent** (every note taken or burned): offer the one-commit deletion of the nebula; history remembers it.
