---
name: install-playbook
description: "Install or refresh the whole playbook toolchain on this machine (every skill, and the agent roster rendered for the harness you run) in one mechanical command, then relay the installer's summary table. With a local playbook clone, run scripts/install_playbook.py; with only the playbook connector, call get_install_command and run the line it returns. Takes no arguments: it always installs everything, because a partial toolchain is the problem it exists to prevent."
galaxy: maker
refs:
  - REF-Authoring
---

# Install playbook

Invoked to install or refresh **every** skill the playbook has, and its whole agent roster, on the machine this session runs on: after anything changes upstream, on a fresh machine, or when a skill you need is missing or behaves from an older text. It takes **no arguments and always installs the whole set**: a runtime that matches the playbook includes the skills added since the last install, not only fresh copies of the ones already there.

Both paths end in the same mechanical act: the playbook's installer, `scripts/install_playbook.py`, run once. It installs from a playbook clone or from the install bundle the playbook studio serves, and from either source it guarantees:

- **every file of every skill**, byte for byte and with its executable bit, written only where it differs from what is installed, each skill folder swapped in whole;
- **agents rendered by the playbook's own installer** for the harness that reads them, never by hand;
- **nothing deleted without `--prune`**.

Its output is one summary table (new, updated, unchanged, and gone upstream, for the skills and for each harness's agents) and, when anything changed, a note to restart the session so the harness loads them. Relaying both is the report. The skills it installs are authored per `REF-Authoring.md`; this is their delivery leg, the counterpart to `bootstrap-skill` (which authors a new one).

## Pre-flight

1. **Pick the source.** A playbook clone on this machine takes the clone path, which also refreshes the on-disk REFs. Without one, the playbook connector takes the connector path: bound with your own personal token from the studio's Connect menu, sent as a Bearer header. An install only reads, so any role installs. With neither, see Failure modes.
2. **Know the harness you run** (`claude-code`, `opencode`): the connector path installs its agents for that one harness.

## Steps

### With a local playbook clone

1. Run `git -C <clone> pull --quiet && python <clone>/scripts/install_playbook.py` once: it brings the clone to the upstream head, then installs from it (Windows PowerShell 5.1 has no `&&`; run the two commands in turn there). A clone install renders the roster for every harness the installer knows, so one run serves all of them.
2. Relay the installer's summary table and its restart note.

### With only the playbook connector

1. Call `get_install_command` with `runtime` set to the harness this session runs in (`claude-code` or `opencode`).
2. Run the returned line once: `posix` on Linux, macOS, or Git Bash; `powershell` on Windows PowerShell or pwsh. It downloads the whole toolchain as one bundle and runs the same installer against it, for that harness. The line carries a download token that expires minutes after the call; for a later run, call again.
3. Relay the installer's summary table and its restart note.

## Options

Append them to either command:

- `--runtime-dir <path>`, `--agents-dir <path>` and `--opencode-agents-dir <path>` set where the skills and each harness's agents land (by default `~/.claude/skills`, `~/.claude/agents`, and `$XDG_CONFIG_HOME/opencode/agents`, which is `~/.config/opencode/agents` where that variable is unset).
- `--prune` removes **every** folder in the skills directory that is not a current playbook skill, and every agent file that is not a current playbook agent: the orphans an install leaves behind (a renamed or deleted skill), but equally anything installed from another source, because nothing on disk tells them apart. Reach for it only when the runtime should be an exact mirror of the playbook; the deletion is irreversible. A symlinked folder or file stays put, so a skill developed against a live runtime through a link survives. Without the flag, the table lists those same entries as gone upstream.

For one skill right now rather than the whole set, `get_skill_files <name>` returns that skill's files to write under the skills directory.

## Failure modes

- **Neither a playbook clone nor the playbook connector is reachable**: there is no source to install from; stop and say so.
- **The harness you run is not one `get_install_command` accepts**: the installer renders no agents for it. Report the gap and stop. Adding a harness is a change to `scripts/install_playbook.py`, where every rendering lives; an agent rendered by hand is a second copy of that mapping, and it drifts.
- **The command fails before the table** (no Python 3.8 or newer on the machine, an expired line, a network error): report what it printed; for an expired line, call `get_install_command` again.
- **The table lists `failed` entries**: a failed write left that entry as it was, and a failed prune may have removed part of a folder before it stopped. Report them; on Windows a file held open by another process is the usual cause, and a rerun once it is closed completes the run.
- **Tempted to install only the one skill you think changed**: don't. The install is all-or-nothing, and a run with no upstream change writes nothing and reports everything unchanged, so the whole set costs nothing extra.
