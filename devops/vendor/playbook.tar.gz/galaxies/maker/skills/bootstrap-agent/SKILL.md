---
name: bootstrap-agent
description: "Scaffold a new agent onto a galaxy's shelf in one deterministic transaction (agents/<name>.md with resolving frontmatter, regenerated REF back-links). Author the character paragraph afterwards and run the gates; an agent names the skills it runs and never restates them."
galaxy: maker
refs:
  - REF-Authoring
  - REF-Universe
---

# Bootstrap agent

Invoked when someone wants to hand work to a worker the corpus has no name for: a phase worker, a reviewer, a programmer, a release manager. Handles every mechanical step; the judgment (who this worker is, and what it refuses) stays with the author.

## Pre-flight

1. **Read** `REF-Universe.md` §4 (agents: who does the work) and `REF-Authoring.md` §13 (the file's shape).
2. **Check the roster first.** A worker that differs from an existing agent only in which run it is on is that agent, not a new one. Add an agent when the worker is distinct: a different licence, a different posture, a different set of refusals, or the outsider's stance.
3. **Confirm with the author**: name (kebab-case), title (the job title), the one-line description a harness routes on, home sun plus citations, the skills it is licensed to run, the doors it needs bound, and its posture (permission mode, whether it may write, whether it is fresh-eyes).
4. **Know what you may not write.** No model id, no credential, no endpoint, no git identity: the environment binds those (`REF-Universe.md` §3).

## Steps

1. **Run the scaffolder** (the `bootstrap.py` beside this SKILL.md) from the playbook root, or pass `--playbook-root <path>` from anywhere else:
   ```bash
   python bootstrap.py --name <agent-name> --title "<Job Title>" \
       --description "<when to hand work to it>" --refs REF-Home,REF-Cited \
       --skills skill-a,skill-b --doors door-a --permission auto --writes
   ```
   Add `--fresh-eyes` for a reviewer: it writes no appearance, because the outsider's look belongs to the role, and it takes the read-only permission mode, because a reviewer that may edit starts owning what it reads. Draw anyone else with `--hair/--headwear/--eyes/--face`, and name `--permission` whenever the role's default is not what this worker needs. The scaffolder refuses a name already taken, an unknown galaxy, and any ref, skill, or door that does not resolve; then it runs `scripts/sync_backlinks.py` so every cited REF gains its back-link (INT-LAYER-002, INT-LAYER-004). The description *is* the agent's line in those sections, so write it as the sentence a router and a reader both need.
2. **Author the paragraph the worker runs under.** One paragraph, written to be obeyed: the role in a clause, how it reports, and what it refuses. Take the refusals from the REF and the skills it runs, in their words; they are the half that distinguishes one worker from another.
3. **Run the gates**: `python -m pytest -q` and `python scripts/check_links.py` from the playbook root.
4. **Install it**: `python scripts/install_playbook.py` writes every agent into the Claude runtime's agents directory in the runtime's own shape, beside the skills (`install-playbook`).

## Failure modes

- **The paragraph turns into a runbook**: INT-AGENT-002 refuses ordered step lists, code fences, and a body over the cap. The steps belong to the skill; cite it and delete them.
- **A skill or door that does not resolve**: the scaffolder refuses. Create the planet first, or fix the id.
- **A home sun in another galaxy**: INT-LAYER-005 refuses. Either the agent is shelved in the wrong galaxy, or its `refs:` are ordered wrong (home first, citations after).
- **A fresh-eyes agent given a look**: INT-AGENT-003 refuses. Fresh eyes have to read as not-the-team, so the appearance is the role's rather than the operator's.
- **Asked for an agent that enforces a permission**: `skills:` is a licence declaration, never a security boundary (`REF-Universe.md` §4). Enforcement lives in the worker's tool configuration and its bound credential; say so rather than encoding a rule the file cannot hold.
