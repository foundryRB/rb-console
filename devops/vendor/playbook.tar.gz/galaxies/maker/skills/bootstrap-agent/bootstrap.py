#!/usr/bin/env python3
"""Scaffold a new agent: the mechanical half of REF-Authoring section 13.

One deterministic transaction:
1. Writes the galaxy's agents/<name>.md (frontmatter naming the description a
   harness routes on, the home sun, the licensed skills, the doors it needs
   bound, its posture and its appearance, plus a body skeleton the author
   replaces with the paragraph the worker runs under).
2. Runs scripts/sync_backlinks.py so every cited REF gains its back-link entry
   (INT-LAYER-002, INT-LAYER-004).

Refuses to overwrite an existing agent, and refuses any ref, skill, or door that
does not resolve: an agent whose licence names nothing real is a roster entry
that cannot be acted on. What it does NOT check is the closed vocabularies
(permission modes, appearance features) - those are the gates' to state, and a
second copy here would be the parallel-maintained duplicate the corpus forbids.

Usage:
    python bootstrap.py --name <agent> --title "<Display Name>" \
        --description "<when to hand work to it>" \
        --refs REF-Home,REF-Cited --skills skill-a,skill-b [--doors door-a] \
        [--permission <mode>] [--writes] [--fresh-eyes] \
        [--hair short] [--headwear cap] [--eyes dot] [--face plain] \
        [--galaxy craft] [--playbook-root <path>]
"""

from __future__ import annotations

import argparse
import re
import subprocess
import sys
from pathlib import Path

__all__ = ["main", "resolve_permission", "yaml_scalar"]

NAME_RE = re.compile(r"^[a-z][a-z0-9]*(-[a-z0-9]+)*$")


def resolve_permission(explicit: str | None, fresh_eyes: bool) -> str:
    """The posture's permission mode: what was asked for, or the role's default.

    An unasked default is the one an author never revisits, so fresh eyes take
    the read-only mode rather than the acting one. A reviewer that can edit is
    a reviewer that starts owning the artifact, which is the whole thing the
    role exists not to do; a scaffold that hands it write access by omission
    contradicts every fresh-eyes agent already on the shelf.
    """
    if explicit and explicit.strip():
        return explicit.strip()
    return "plan" if fresh_eyes else "auto"

AGENT_TEMPLATE = """---
name: {name}
title: {title}
description: {description}
galaxy: {galaxy}
refs:
{refs_block}skills:
{skills_block}doors:{doors_block}
posture:
  permission: {permission}
  writes: {writes}
  fresh_eyes: {fresh_eyes}
{appearance_block}---

# Agent: {title}

State in one paragraph, written to be run under, what this agent is here to do, how it reports, and what it refuses.
"""

APPEARANCE_TEMPLATE = """appearance:
  hair: {hair}
  headwear: {headwear}
  eyes: {eyes}
  face: {face}
"""


def yaml_scalar(text: str) -> str:
    """A one-line YAML value, double-quoted so punctuation never changes its meaning."""
    return '"' + text.replace("\\", "\\\\").replace('"', '\\"') + '"'


def _universe_root(explicit: Path | None) -> Path:
    """The directory holding AI-PLAYBOOK.md: the one named, else the working directory. A maker
    scaffolder is run from the corpus it writes into, wherever its own file was installed."""
    root = explicit or Path.cwd()
    if (root / "AI-PLAYBOOK.md").is_file():
        return root
    hint = "pass the playbook root" if explicit else "run from the playbook root or pass --playbook-root <path>"
    raise SystemExit(f"error: no AI-PLAYBOOK.md in {root}; {hint}")


def _split(raw: str) -> list[str]:
    return [item.strip() for item in raw.split(",") if item.strip()]


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--name", required=True, help="Agent name, kebab-case")
    ap.add_argument("--title", required=True, help="Display name, e.g. 'Builder'")
    ap.add_argument(
        "--description",
        required=True,
        help="One line: when to hand work to this agent (the line a harness routes on)",
    )
    ap.add_argument("--refs", required=True, help="Comma-separated REF ids, home sun first")
    ap.add_argument("--skills", required=True, help="Comma-separated skills it is licensed to run")
    ap.add_argument("--doors", default="", help="Comma-separated doors it needs bound")
    ap.add_argument(
        "--permission",
        default=None,
        help="How often it stops to ask (default: plan for --fresh-eyes, else auto)",
    )
    ap.add_argument("--writes", action="store_true", help="It may change the artifacts it works on")
    ap.add_argument("--fresh-eyes", action="store_true", help="It reviews what it had no hand in")
    ap.add_argument("--hair", default="short")
    ap.add_argument("--headwear", default="cap")
    ap.add_argument("--eyes", default="dot")
    ap.add_argument("--face", default="plain")
    ap.add_argument("--galaxy", default="craft", help="Galaxy the agent shelves in (default: craft)")
    ap.add_argument("--playbook-root", type=Path, default=None)
    args = ap.parse_args()

    root = _universe_root(args.playbook_root)
    name = args.name.strip()
    title = args.title.strip()
    description = " ".join(args.description.split())
    refs = _split(args.refs)
    skills = _split(args.skills)
    doors = _split(args.doors)

    if not NAME_RE.match(name):
        print(f"error: name must be kebab-case: {name!r}", file=sys.stderr)
        return 2
    if not title:
        print("error: title is required", file=sys.stderr)
        return 2
    if not description:
        print("error: description is required; a harness routes on it", file=sys.stderr)
        return 2
    galaxy_dir = root / "galaxies" / args.galaxy
    if not (galaxy_dir / "GALAXY.md").is_file():
        print(f"error: unknown galaxy: {args.galaxy!r}", file=sys.stderr)
        return 2
    if not refs:
        print("error: --refs must name a home sun", file=sys.stderr)
        return 2
    if not skills:
        print("error: --skills must name at least one runbook", file=sys.stderr)
        return 2

    for ref in refs:
        if not ((root / f"{ref}.md").is_file() or any(root.glob(f"galaxies/*/{ref}.md"))):
            print(f"error: unknown REF: {ref}", file=sys.stderr)
            return 2
    if not (galaxy_dir / f"{refs[0]}.md").is_file():
        print(
            f"error: home sun {refs[0]} does not live in '{args.galaxy}'; "
            "a citation may cross galaxies, a home may not",
            file=sys.stderr,
        )
        return 2
    for skill in skills:
        if not any(root.glob(f"galaxies/*/skills/{skill}/SKILL.md")):
            print(f"error: unknown skill: {skill}", file=sys.stderr)
            return 2
    for door in doors:
        if not (any(root.glob(f"galaxies/*/mcps/{door}.md")) or any(root.glob(f"galaxies/*/rags/{door}.md"))):
            print(f"error: unknown door: {door}", file=sys.stderr)
            return 2

    collisions = [p for p in root.glob(f"galaxies/*/agents/{name}.md")]
    if collisions:
        print(f"error: {collisions[0]} already exists (names are unique universe-wide)", file=sys.stderr)
        return 2

    agents_dir = galaxy_dir / "agents"
    agents_dir.mkdir(parents=True, exist_ok=True)
    agent_path = agents_dir / f"{name}.md"
    appearance = (
        ""
        if args.fresh_eyes
        else APPEARANCE_TEMPLATE.format(
            hair=args.hair, headwear=args.headwear, eyes=args.eyes, face=args.face
        )
    )
    agent_path.write_text(
        AGENT_TEMPLATE.format(
            name=name,
            title=title,
            description=yaml_scalar(description),
            galaxy=args.galaxy,
            refs_block="".join(f"  - {r}\n" for r in refs),
            skills_block="".join(f"  - {s}\n" for s in skills),
            doors_block=("\n" + "".join(f"  - {d}\n" for d in doors)).rstrip("\n") if doors else " []",
            permission=resolve_permission(args.permission, args.fresh_eyes),
            writes="true" if args.writes else "false",
            fresh_eyes="true" if args.fresh_eyes else "false",
            appearance_block=appearance,
        ),
        encoding="utf-8",
        newline="\n",
    )
    print(f"Created {agent_path}")

    sync_script = root / "scripts" / "sync_backlinks.py"
    if sync_script.is_file():
        proc = subprocess.run(
            [sys.executable, str(sync_script)], cwd=root, capture_output=True, text=True
        )
        print(proc.stdout.strip())
        if proc.returncode != 0:
            print(proc.stderr, file=sys.stderr)
            return proc.returncode
    return 0


if __name__ == "__main__":
    sys.exit(main())
