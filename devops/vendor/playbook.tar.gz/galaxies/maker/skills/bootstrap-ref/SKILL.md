---
name: bootstrap-ref
description: Scaffold a new REF onto a galaxy's shelf from the REF-Authoring template (frontmatter with domain, title, summary blockquote, first numbered section). Deterministic skeleton only; author the sections and add the galaxy's GALAXY.md routing-table row afterwards, then run the gates.
galaxy: maker
refs:
  - REF-Authoring
---

# Bootstrap REF

Invoked when a new REF is needed in the playbook. Produces the template-conformant skeleton; the substance (rules, tables, anti-patterns) is authored afterwards per `REF-Authoring.md`.

## Pre-flight

1. **Read** `REF-Authoring.md` (the whole meta-REF; especially §2 portability, §3 template, §4 scope).
2. **Confirm with user**: REF id (`REF-<PascalCase>`), domain (one of: meta, architecture, language, framework, practice, methodology, pkm), title, one-line summary.
3. **Check scope**: one concern per REF. If the topic overlaps an existing REF, extend that REF or use Core + Specialization (`REF-Authoring.md` §5) instead of creating a near-duplicate.

## Steps

1. **Run the scaffolder** from the playbook root, or pass `--playbook-root <path>` from anywhere else:
   ```bash
   python bootstrap.py --name REF-<Name> --domain <domain> \
       --title "<Title>" --summary "<When to read this REF.>"
   ```
2. **Author the sections** (numbered `## N.`, rules not tutorials, generic examples only).
3. **Add a routing-table row** in the galaxy's `GALAXY.md` § Task Routing so tasks actually load the REF.
4. **Run the gates**: `python -m pytest -q` and `python scripts/check_links.py` from the playbook root.

## Failure modes

- **Target REF already exists**: the scaffolder refuses; extend the existing REF instead.
- **Gates fail after authoring**: fix the reported violation (numbering, portability, em-dash); the tests name the file and line.
