#!/usr/bin/env python3
"""Scaffold a new REF file in the playbook (REF-Authoring section 3 template).

Writes <playbook-root>/<name>.md with frontmatter, title, summary blockquote,
and a first numbered section. Refuses to overwrite. Deterministic skeleton
only; the caller authors the sections, adds the routing-table row, and runs
the gates afterwards (see SKILL.md).

Usage:
    python bootstrap.py --name REF-Topic --domain language \
        --title "Topic Conventions" --summary "When doing X, follow these rules." \
        [--galaxy craft] [--playbook-root <path>]
"""

from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

__all__ = ["main"]

DOMAINS = ("meta", "architecture", "language", "framework", "practice", "methodology", "pkm")
NAME_RE = re.compile(r"^REF-[A-Z][A-Za-z0-9-]*$")


def _universe_root(explicit: Path | None) -> Path:
    """The directory holding AI-PLAYBOOK.md: the one named, else the working directory. A maker
    scaffolder is run from the corpus it writes into, wherever its own file was installed."""
    root = explicit or Path.cwd()
    if (root / "AI-PLAYBOOK.md").is_file():
        return root
    hint = "pass the playbook root" if explicit else "run from the playbook root or pass --playbook-root <path>"
    raise SystemExit(f"error: no AI-PLAYBOOK.md in {root}; {hint}")

TEMPLATE = """---
domain: {domain}
---

# REF: {title}

> {summary}

---

## 1. Scope

State the first rule set for this REF here.
"""


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--name", required=True, help="REF id, e.g. REF-Terraform")
    ap.add_argument("--domain", required=True, choices=DOMAINS)
    ap.add_argument("--title", required=True, help="Becomes the '# REF: <Title>' heading")
    ap.add_argument("--summary", required=True, help="The one-line when-to-read blockquote")
    ap.add_argument("--galaxy", default="craft", help="Galaxy the REF shelves in (default: craft)")
    ap.add_argument("--playbook-root", type=Path, default=None)
    args = ap.parse_args()

    root = _universe_root(args.playbook_root)
    if not NAME_RE.match(args.name):
        print(f"error: name must match REF-<PascalCase>: {args.name!r}", file=sys.stderr)
        return 2
    galaxy_dir = root / "galaxies" / args.galaxy
    if not (galaxy_dir / "GALAXY.md").is_file():
        print(f"error: unknown galaxy: {args.galaxy!r} (no {galaxy_dir / 'GALAXY.md'})", file=sys.stderr)
        return 2
    collisions = [p for p in [root / f"{args.name}.md", *root.glob(f"galaxies/*/{args.name}.md")] if p.exists()]
    if collisions:
        print(f"error: {collisions[0]} already exists (names are unique universe-wide)", file=sys.stderr)
        return 2
    path = galaxy_dir / f"{args.name}.md"

    content = TEMPLATE.format(
        domain=args.domain, title=args.title.strip(), summary=args.summary.strip()
    )
    path.write_text(content, encoding="utf-8", newline="\n")
    print(f"Created {path}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
