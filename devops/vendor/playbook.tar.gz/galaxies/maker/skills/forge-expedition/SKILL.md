---
name: forge-expedition
description: "Research a territory the universe has not worked: instantiate the five pre-sales questions from the territory's seats, run them over the deep-research engine, and commit the surviving claims as typed stardust notes to the territory's nebula, gated by the stardust schema. One scope nod, then autonomous."
galaxy: maker
refs:
  - REF-Forge
---

# Forge expedition

Invoked when the operator names a territory to research: a subject the universe has not worked, given as one line (`REF-Forge.md` §2). One scope nod, then autonomous; the run ends with the stardust committed to the territory's nebula.

## Pre-flight

1. **Read** `REF-Forge.md` (whole; especially §2 questions and seats, §3 the stardust schema, §6 the gates).
2. **Confirm the territory line**: the subject and why now, with a customer attached or not. An ambiguous subject earns up to three clarifying questions here, none later.
3. **Play back the scope**: the five questions instantiated for this subject, the seats to be interviewed, and a cost note (fan-out size and model tier; pin the engine's fan-out to an economical tier). Wait for the operator's single nod; there is no unattended variant.
4. **Slug the territory** (kebab-case) and check `nebulae/<territory>/` does not exist yet; refuse if it does.

## Steps

1. **Research**: for each of the five questions, run the runtime's deep-research skill with the question instantiated for the subject and phrased from the territory's seats (`REF-Forge.md` §2). Collect surviving claims, their votes, and their sources; keep the refuted claims and votes for the ledger.
2. **Condense**: deduplicate across runs, then write one stardust note per surviving finding, conforming to the schema (`REF-Forge.md` §3): `type`, `confidence`, `vote`, `seats`, `sources`, `links`, `status: unsmelted`; body of a few lines (the claim, its consequence, `[[links]]` to neighbours).
3. **Front the nebula**: write `nebulae/<territory>/NEBULA.md` with the subject line, the off-limits banner, the roster (every note, one line each), the open questions the research left, and the discarded-claims ledger (every killed claim with its vote and source).
4. **Run the stardust gate**: `python -m pytest tests/test_nebulae.py -q` from the repo root; fix violations until green. Never commit red.
5. **Commit** the nebula as one commit, subject `chore(nebula): <territory>`:
   a quarantined nebula ships nothing, so `chore`.
6. **Report**: note count and type spread, discarded count, open questions; point the operator at `forge-smelt` for the judging session.

## Failure modes

- **Nebula already exists**: refuse; the operator smelts it first, deletes it (one commit), or names a distinct territory.
- **No research engine in the runtime**: stop and say so; the expedition has no manual fallback worth its cost.
- **Stardust gate red**: fix the notes or `NEBULA.md` until green; the gate names the file and rule.
- **Verification kills nearly everything**: commit the thin nebula anyway and say so plainly; a territory opaque to public sources is information, not failure, and the kills stay on the ledger.
