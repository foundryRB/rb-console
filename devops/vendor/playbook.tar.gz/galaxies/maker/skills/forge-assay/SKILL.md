---
name: forge-assay
description: "A second opinion from the territory itself: run a scoped expedition over a finished estimation project's subject, read its requirements and assumptions against the findings, and hand back findings only. Writes nothing; needs no nebula to exist."
galaxy: maker
refs:
  - REF-Forge
---

# Forge assay

Invoked when the operator wants a finished estimation project challenged by its own territory (`REF-Forge.md` §7). An aside to the Forge, not a stage of it: findings only, nothing written.

## Pre-flight

1. **Read** `REF-Forge.md` §2 and §7.
2. **Reach the project over its door** (the estimation engine's MCP) and read its brief, requirements, and assumptions. If the door is not bound in this environment, stop and say so.
3. **Derive the territory line** from the project's brief; play back the scoped questions (typically the players, the needs, and the shapes) with a cost note, and take the operator's nod.

## Steps

1. **Research**: run a scoped expedition over the project's territory: the relevant questions over the runtime's deep-research skill. No nebula is written; the material stays in-session.
2. **Read against**: hold the project's requirements and assumptions against the findings, hunting three classes: needs the estimate never priced; solution shapes the territory trusts that the estimate ignores; assumptions the territory contradicts.
3. **Hand back findings only**: each finding carries the claim, its source, and the requirement or assumption it touches. Never write into the project; never file tickets uninvited.

## Failure modes

- **Door unbound or project unreadable**: stop; the assay has no offline mode.
- **A finding tempts an edit** ("just fix the assumption"): refuse; findings-only is the contract and the entire seam between the Forge and any delivery process (`REF-Forge.md` §7).
- **The research contradicts nothing**: say so plainly; a clean assay is a real result, not a failed one.
